import { mkdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { getConformanceDigest, getConformanceVectors } from '../public/industrial-standard.mjs';

const conformance = getConformanceVectors();
const document = {
  documentType: 'TwinCircuit industrial rule conformance vectors',
  version: conformance.version,
  digestScope: 'SHA-256 of UTF-8 JSON.stringify(conformance) without indentation',
  conformanceSha256: await getConformanceDigest(),
  profileCount: Object.keys(conformance.circuits).length,
  vectorCount: Object.values(conformance.circuits).reduce((sum, group) => sum + group.vectors.length, 0),
  conformance,
};
const destination = fileURLToPath(new URL('../public/standard/conformance.json', import.meta.url));
await mkdir(fileURLToPath(new URL('../public/standard/', import.meta.url)), { recursive: true });
await writeFile(destination, JSON.stringify(document, null, 2) + '\n');
console.log(JSON.stringify({ destination, version: document.version, profileCount: document.profileCount, vectorCount: document.vectorCount, conformanceSha256: document.conformanceSha256 }));
