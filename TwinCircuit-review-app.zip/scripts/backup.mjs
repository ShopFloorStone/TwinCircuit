import { DatabaseSync, backup } from 'node:sqlite';
import { chmod, mkdir, stat } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const source = resolve(process.env.DATA_DIR || resolve(root, 'data'), 'twincircuit.sqlite');
const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
const destination = resolve(process.argv[2] || resolve(process.env.BACKUP_DIR || resolve(root, 'backups'), `twincircuit-${timestamp}.sqlite`));

try {
  if (source === destination) throw new Error('备份文件不能与源数据库相同。');
  if (!(await stat(source)).isFile()) throw new Error('未找到源数据库。');
  try { await stat(destination); throw new Error('目标文件已存在；请换一个备份文件名。'); }
  catch (error) { if (error.code !== 'ENOENT') throw error; }
  await mkdir(dirname(destination), { recursive: true, mode: 0o700 });
  const db = new DatabaseSync(source, { readOnly: true });
  let pages;
  try { db.exec('PRAGMA busy_timeout=10000'); pages = await backup(db, destination); }
  finally { db.close(); }
  await chmod(destination, 0o600);
  const check = new DatabaseSync(destination, { readOnly: true });
  try {
    const result = check.prepare('PRAGMA quick_check').all();
    if (result.length !== 1 || Object.values(result[0])[0] !== 'ok') throw new Error('备份 quick_check 未通过，请勿将此文件作为可恢复备份。');
  } finally { check.close(); }
  console.log(JSON.stringify({ ok: true, source, destination, pages, checkedAt: new Date().toISOString() }));
} catch (error) {
  console.error(`备份失败：${error.message}`);
  process.exitCode = 1;
}
