import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import ganache from 'ganache';
import {BrowserProvider,ContractFactory} from 'ethers';
import {compilePayments} from './compile-payments.mjs';

// This CLI deliberately has no external-network signer/private-key option.
// Public-network deployment uses public/payments.mjs + an actual reviewed wallet.
if(!process.argv.includes('--local')){
  console.log('Usage: node scripts/deploy-payments.mjs --local\nDeploys a DEVELOPMENT token and escrow only on a new in-process chain 1337.\nFor X Layer use createPaymentsClient(config,{provider,onReview}).deployEscrow({releaseDelay}).\nAfter the user signs, independently verify the receipt/address and configure the server allowlist. No key is read by this script.');
}else{
  const artifacts=await compilePayments();
  const eip=ganache.provider({chain:{chainId:1337,hardfork:'shanghai'},wallet:{totalAccounts:10},logging:{quiet:true}});
  const provider=new BrowserProvider(eip);provider.pollingInterval=10;
  try{
    const signer=await provider.getSigner(0);
    const token=await new ContractFactory(artifacts.MockToken.abi,artifacts.MockToken.bytecode,signer).deploy(8);await token.waitForDeployment();
    const escrow=await new ContractFactory(artifacts.TwinCircuitEscrow.abi,artifacts.TwinCircuitEscrow.bytecode,signer).deploy(await token.getAddress(),60);await escrow.waitForDeployment();
    const data={mode:'local-development-only',chainId:1337,tokenAddress:await token.getAddress(),tokenDecimals:8,symbol:'TEST',escrowAddress:await escrow.getAddress(),releaseDelay:60,tokenTransactionHash:token.deploymentTransaction().hash,escrowTransactionHash:escrow.deploymentTransaction().hash,networkLifetime:'destroyed when this script exits; addresses are not mainnet deployments',createdAt:new Date().toISOString()};
    const directory=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..','contracts','deployments');await fs.mkdir(directory,{recursive:true});await fs.writeFile(path.join(directory,'local.json'),JSON.stringify(data,null,2)+'\n');console.log(JSON.stringify(data,null,2));
  }finally{provider.destroy();await eip.disconnect();}
}
