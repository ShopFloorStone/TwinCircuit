/** Actual BEM bytecode/storage fork test. ALL external RPC traffic is read-only.
 * Mainnet transactions cannot pass through the explicit relay allowlist.
 * Local impersonation/native balances are test fixtures, never account ownership.
 */
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
import ganache from 'ganache';
import {BrowserProvider,ContractFactory,Contract,keccak256,toUtf8Bytes,Interface} from 'ethers';
import {compilePayments} from './compile-payments.mjs';
import {decodeReceipt,formatAtomicUnits} from '../public/payments.mjs';

const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const DEST=path.resolve(ROOT,'..','qa-payments');
const RPC='https://rpc.xlayer.tech';
const TOKEN='0x60e62efa9405d6873c5deabd4e6cc91c25363952';
const HOLDER='0x2ccf8aa17f5df9fb5d51c9de12135a913ff29f7a';
const READS=new Set(['eth_chainId','net_version','eth_blockNumber','eth_getBlockByNumber','eth_getBlockByHash','eth_getCode','eth_getBalance','eth_getTransactionCount','eth_getStorageAt','eth_getProof','eth_getTransactionByHash','eth_getTransactionReceipt','eth_getLogs','eth_call','eth_gasPrice','eth_maxPriorityFeePerGas']);
const tokenABI=['function symbol() view returns(string)','function decimals() view returns(uint8)','function balanceOf(address) view returns(uint256)','function transfer(address,uint256) returns(bool)','function approve(address,uint256) returns(bool)'];
const ti=new Interface(tokenABI),hash=text=>keccak256(toUtf8Bytes(text));
const report={startedAt:new Date().toISOString(),mode:'local-EVM-fork-of-read-only-mainnet-state',mainnetTransactionsSent:0,upstreamRPC:RPC,chainId:196,tokenAddress:TOKEN,holderCandidate:HOLDER,upstreamMethods:{},stage:'initial',passed:false};
let nextId=0,relay,eip,provider;
async function upstream(method,params=[]){
  if(!READS.has(method))throw new Error('External RPC mutation rejected: '+method);
  report.upstreamMethods[method]=(report.upstreamMethods[method]??0)+1;
  let failure;
  for(let attempt=0;attempt<3;attempt++)try{
    const response=await fetch(RPC,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:++nextId,method,params}),signal:AbortSignal.timeout(20000)});
    if(!response.ok)throw new Error('Upstream HTTP '+response.status);
    const data=await response.json();if(data.error)throw new Error(data.error.message);if(!Object.hasOwn(data,'result'))throw new Error('No RPC result');return data.result;
  }catch(error){failure=error;if(attempt===2)throw failure;}
}
const remoteCall=async(name,args,block)=>ti.decodeFunctionResult(name,await upstream('eth_call',[{to:TOKEN,data:ti.encodeFunctionData(name,args)},block]))[0];
try{
  report.stage='mainnet-read-only-metadata';
  assert.equal(BigInt(await upstream('eth_chainId')),196n);
  const height=BigInt(await upstream('eth_blockNumber'))-8n,block='0x'+height.toString(16);
  const blockData=await upstream('eth_getBlockByNumber',[block,false]);
  const code=await upstream('eth_getCode',[TOKEN,block]);
  const holderCode=await upstream('eth_getCode',[HOLDER,block]);
  const symbol=await remoteCall('symbol',[],block),decimals=Number(await remoteCall('decimals',[],block));
  const holderBalance=await remoteCall('balanceOf',[HOLDER],block);
  Object.assign(report,{forkBlock:Number(height),forkBlockHex:block,forkBlockHash:blockData.hash,tokenCodeBytes:(code.length-2)/2,tokenCodeHash:keccak256(code),symbol,decimals,holderBalanceAtomic:holderBalance.toString(),holderHasCode:holderCode!=='0x'});
  assert.notEqual(code,'0x');assert.equal(symbol,'BEM');assert.equal(decimals,8);assert.ok(holderBalance>=10000n,'Candidate holder does not hold sufficient BEM; no fake token balance is injected.');
  // Ganache can only reach the mainnet through this relay. Even accidental send calls are rejected.
  relay=http.createServer(async(req,res)=>{
    try{if(req.method!=='POST')throw new Error('POST only');let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>2000000)throw new Error('Request too large');}const payload=JSON.parse(raw);const one=async p=>{try{if(!READS.has(p.method))throw new Error('READ-ONLY relay rejected '+p.method);return {jsonrpc:'2.0',id:p.id,result:await upstream(p.method,p.params??[])};}catch(error){return {jsonrpc:'2.0',id:p.id,error:{code:-32000,message:error.message}};}};const result=Array.isArray(payload)?await Promise.all(payload.map(one)):await one(payload);res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(result));}catch(error){res.writeHead(400,{'content-type':'application/json'});res.end(JSON.stringify({error:{message:error.message}}));}
  });
  await new Promise(resolve=>relay.listen(0,'127.0.0.1',resolve));
  const relayURL=`http://127.0.0.1:${relay.address().port}`;
  report.stage='local-ganache-fork';
  eip=ganache.provider({fork:{url:relayURL,blockNumber:Number(height),requestsPerSecond:8},chain:{chainId:196,hardfork:'shanghai'},wallet:{totalAccounts:10,unlockedAccounts:[HOLDER]},miner:{blockGasLimit:30000000},logging:{quiet:true}});
  provider=new BrowserProvider(eip);provider.pollingInterval=10;
  assert.equal(await eip.request({method:'eth_chainId',params:[]}),'0xc4');
  const signers=await Promise.all(Array.from({length:8},(_,i)=>provider.getSigner(i))),addresses=await Promise.all(signers.map(s=>s.getAddress()));
  assert.equal(keccak256(await provider.getCode(TOKEN)),report.tokenCodeHash,'BEM code must stay byte-for-byte identical.');
  // A pool contract cannot normally originate a transaction. Clear its code ONLY on the local fork
  // to model an authorised holder; token bytecode and token balance/storage are not modified.
  if(holderCode!=='0x'){await eip.request({method:'evm_setAccountCode',params:[HOLDER,'0x']});report.localHolderCodeClearedForImpersonation=true;}
  await eip.request({method:'evm_setAccountBalance',params:[HOLDER,'0x56bc75e2d63100000']});
  const holder=await provider.getSigner(HOLDER),token=new Contract(TOKEN,tokenABI,signers[0]);
  const before=await token.balanceOf(addresses[0]);
  report.stage='actual-BEM-local-transfer';
  const transferReceipt=await(await token.connect(holder).transfer(addresses[0],10000n,{gasLimit:500000})).wait();
  assert.equal(await token.balanceOf(addresses[0]),before+10000n);
  assert.equal(await token.balanceOf(HOLDER),holderBalance-10000n);
  report.localTransfer={transactionHash:transferReceipt.hash,status:transferReceipt.status,amountAtomic:'10000',amountBEM:formatAtomicUnits('10000',8),from:HOLDER,to:addresses[0]};
  report.stage='local-escrow-deploy';
  const artifacts=await compilePayments({write:false});
  const escrow=await new ContractFactory(artifacts.TwinCircuitEscrow.abi,artifacts.TwinCircuitEscrow.bytecode,signers[0]).deploy(TOKEN,60);await escrow.waitForDeployment();
  const escrowAddress=await escrow.getAddress(),recipients=addresses.slice(2,7),amounts=[4000n,2000n,1500n,1500n,1000n];
  const orderKey=hash('BEM fork-only order '+blockData.hash),termsHash=hash('frozen five-party BEM amounts'),evidenceHash=hash('TEST ONLY: simulated acceptance declaration, no physical proof');
  const now=Number((await provider.getBlock('latest')).timestamp),refundAfter=now+7200;
  report.stage='actual-BEM-local-exact-approve-and-fund';
  const approveReceipt=await(await token.approve(escrowAddress,10000n,{gasLimit:300000})).wait();
  const fundReceipt=await(await escrow.fund(orderKey,termsHash,evidenceHash,addresses[1],recipients,amounts,10000n,refundAfter,{gasLimit:1500000})).wait();
  const id=await escrow.dealIdFor(addresses[0],orderKey);
  assert.equal(await escrow.totalLocked(),10000n);assert.equal(await token.balanceOf(escrowAddress),10000n);
  const recipientBefore=await Promise.all(recipients.map(a=>token.balanceOf(a)));
  report.stage='actual-BEM-local-accept-release';
  const acceptReceipt=await(await escrow.connect(signers[1]).accept(id,termsHash,evidenceHash,{gasLimit:500000})).wait();
  await eip.request({method:'evm_increaseTime',params:[61]});await eip.request({method:'evm_mine',params:[]});
  const releaseReceipt=await(await escrow.release(id,{gasLimit:1500000})).wait();
  const recipientAfter=await Promise.all(recipients.map(a=>token.balanceOf(a)));
  for(let i=0;i<5;i++)assert.equal(recipientAfter[i]-recipientBefore[i],amounts[i]);
  assert.equal(await token.balanceOf(escrowAddress),0n);assert.equal(await escrow.totalLocked(),0n);assert.equal((await escrow.getDeal(id)).state,4n);
  assert.equal(keccak256(await provider.getCode(TOKEN)),report.tokenCodeHash);
  const summarise=r=>({transactionHash:r.hash,status:r.status,gasUsed:r.gasUsed.toString(),events:decodeReceipt(r,{address:escrowAddress})});
  Object.assign(report,{passed:true,stage:'complete',localEscrowAddress:escrowAddress,localDealId:id,totalAtomic:'10000',totalBEM:formatAtomicUnits('10000',8),frozenTermsHash:termsHash,frozenEvidenceHash:evidenceHash,localReceipts:{approval:summarise(approveReceipt),fund:summarise(fundReceipt),accept:summarise(acceptReceipt),release:summarise(releaseReceipt)},payouts:recipients.map((address,i)=>({address,amountAtomic:String(amounts[i]),amountBEM:formatAtomicUnits(String(amounts[i]),8),actualIncreaseAtomic:String(recipientAfter[i]-recipientBefore[i])})),limitations:['This is a local fork at one fixed mainnet block, not a mainnet deployment or payment.','Holder impersonation/native gas are local test fixtures, not wallet ownership.','No assertion about future token policy, blacklisting, upgrade/admin actions or physical industrial acceptance.','No independent security audit has been completed.']});
}catch(error){report.error={message:error.message,shortMessage:error.shortMessage??null,code:error.code??null};report.actualBEMTransferCompatibility=report.localTransfer?'local transfer passed; full escrow path failed at stage '+report.stage:'NOT VERIFIED';process.exitCode=1;}
finally{
  if(provider)provider.destroy();if(eip)try{await eip.disconnect();}catch{}if(relay)await new Promise(resolve=>relay.close(resolve));
  report.finishedAt=new Date().toISOString();report.upstreamWrites=Object.keys(report.upstreamMethods).filter(m=>!READS.has(m));assert.deepEqual(report.upstreamWrites,[]);
  await fs.mkdir(DEST,{recursive:true});await fs.writeFile(path.join(DEST,'bem-fork-result.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({passed:report.passed,stage:report.stage,error:report.error??null,forkBlock:report.forkBlock,decimals:report.decimals,tokenCodeBytes:report.tokenCodeBytes,upstreamReads:Object.values(report.upstreamMethods).reduce((a,b)=>a+b,0),mainnetTransactionsSent:0,evidence:path.join(DEST,'bem-fork-result.json')}));
}
