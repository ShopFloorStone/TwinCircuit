# 视觉资源与外部项目说明

## 项目插画

本应用的虚拟工厂视觉来自本次 TwinCircuit 设计过程生成的概念界面图，由 OpenAI ImageGen 根据项目需求生成。运行界面通过 CSS 裁切其中的工厂场景，交互控件由 HTML / CSS / JavaScript 实现。

| 本包资源 | 对应生成图 | 用途 |
| --- | --- | --- |
| `public/assets/mockup-01.png` | `01-capabilities.png` | 能力目录中的虚拟工厂 A / B 插画 |
| `public/assets/mockup-04.png` | `04-execution-switch.png` | 故障与接替流程的虚拟工厂插画 |

这些图像不是实拍设备、实时视频、已连接工厂或生产质量证据。图中的部件外观与屏幕信息属于概念表现，不代表相应设备确实存在或实现了所示功能。

`public/assets/favicon.svg` 和界面内联 SVG 是随本包交付的界面图形。没有在本包中捆绑第三方字体或图标 npm 包；字体使用浏览器可用的系统字体。

本文件记录本次交付中的已知来源，不对未知素材杜撰上游许可，也不把 AI 生成结果描述为第三方工业厂商授权素材。

## 名称、接口与基础软件

- TwinCircuit 是本项目的概念产品名称。
- TapeOut、X Layer、OKB 等名称用于说明外部协议与接口，相关商标和外部合约不属于本项目。
- 合约地址、ABI 函数名和 RPC 接口用于兼容性适配。本包没有据此获得外部合约的所有权，也不代表官方认可。
- Node.js 与 Caddy 是部署基础软件，容器镜像由部署时从各自镜像仓库获取；本文件不替代这些项目的许可证与分发条款。
- Blueprint 是研究时参考的产品类型，本包没有捆绑其代码、品牌图片或声明与其存在合作。

自写应用代码的交付使用说明见 [LICENSE](LICENSE)，产品能力边界见 [LIMITATIONS.md](docs/LIMITATIONS.md)。
