import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { gunzipSync } from 'node:zlib';
import { mkdtemp, readFile, rename, rm, stat, utimes, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createApp } from '../server.mjs';

async function fixture(t) {
  const publicDir = await mkdtemp(join(tmpdir(), 'twincircuit-static-'));
  const app = createApp({ dbPath: ':memory:', setupToken: 'qa-setup', publicDir, log() {} });
  await new Promise(resolve => app.server.listen(0, '127.0.0.1', resolve));
  t.after(async () => { await app.close(); await rm(publicDir, { recursive: true, force: true }); });
  const origin = 'http://127.0.0.1:' + app.server.address().port;
  const request = (path, method = 'GET', headers = {}, data) => new Promise((resolve, reject) => {
    const req = http.request(origin + path, { method, headers: { origin, ...headers } }, res => {
      const chunks = [];
      res.on('data', part => chunks.push(part));
      res.on('end', () => {
        const wire = Buffer.concat(chunks);
        const text = (wire.length && res.headers['content-encoding'] === 'gzip' ? gunzipSync(wire) : wire).toString('utf8');
        resolve({ code: res.statusCode, headers: res.headers, wire, text });
      });
    });
    req.on('error', reject);
    req.end(data === undefined ? undefined : JSON.stringify(data));
  });
  return { publicDir, request };
}

test('cached static assets negotiate identity/q=0 and gzip and send matching headers on HEAD', async t => {
  const { publicDir, request } = await fixture(t);
  const expected = 'industrial-asset/'.repeat(1000);
  await writeFile(join(publicDir, 'bundle.css'), expected);
  for (const [accept, compress] of [['gzip', true], ['br, GZIP; q=0.5', true], ['gzip;q=0', false], ['br, gzip;q=0, *;q=1', false], ['', false]]) {
    const headers = { 'Accept-Encoding': accept };
    const get = await request('/bundle.css', 'GET', headers);
    const head = await request('/bundle.css', 'HEAD', headers);
    assert.equal(get.code, 200);
    assert.equal(head.code, 200);
    assert.equal(get.headers['content-encoding'], compress ? 'gzip' : undefined);
    assert.equal(get.headers.vary, 'Accept-Encoding');
    assert.equal(get.text, expected);
    assert.equal(get.wire.length, Number(get.headers['content-length']));
    assert.equal(head.wire.length, 0);
    for (const field of ['content-encoding','content-length','cache-control','content-type','vary']) {
      assert.equal(head.headers[field], get.headers[field]);
    }
  }
});

test('same-size asset replacement preserves fresh compressed bytes on atomic rename and on in-place edits', async t => {
  const { publicDir, request } = await fixture(t);
  const asset = join(publicDir, 'bundle.js'), swap = join(publicDir, 'replacement.js');
  const get = () => request('/bundle.js', 'GET', { 'Accept-Encoding': 'gzip' });
  const payload = letter => '/*' + letter.repeat(4000) + '*/';
  await writeFile(asset, payload('A'));
  const initial = await get();
  const timestamp = await stat(asset);
  await writeFile(swap, payload('B'));
  await utimes(swap, timestamp.atime, timestamp.mtime);
  await rename(swap, asset);
  const updated = await get();
  assert.equal(initial.headers['content-encoding'], 'gzip');
  assert.equal(updated.headers['content-encoding'], 'gzip');
  assert.equal(initial.text, payload('A'));
  assert.equal(updated.text, payload('B'));
  await writeFile(asset, payload('C'));
  await utimes(asset, timestamp.atime, new Date(Date.now() + 5000));
  const edited = await get();
  assert.equal(edited.text, await readFile(asset, 'utf8'));
  assert.equal(edited.text, payload('C'));
});

test('concurrent authenticated responses keep workspace data, CSRF values and caches separate', async t => {
  const { request } = await fixture(t);
  const jsonHeaders = { 'Content-Type': 'application/json', 'Accept-Encoding': 'gzip' };
  const a = await request('/api/auth/setup', 'POST', jsonHeaders, {
    email: 'profile-a@example.invalid', name: 'private-factory-a', password: 'testing-network-isolation', setupToken: 'qa-setup',
  });
  const b = await request('/api/auth/signup', 'POST', jsonHeaders, {
    email: 'profile-b@example.invalid', name: 'private-factory-b', password: 'testing-network-isolation',
  });
  for (const res of [a,b]) assert.equal(res.code, 200);
  const accounts = [a,b].map(res => ({ cookie: res.headers['set-cookie'][0].split(';')[0], user: JSON.parse(res.text) }));
  assert.notEqual(accounts[0].user.workspace.id, accounts[1].user.workspace.id);
  assert.notEqual(accounts[0].user.csrfToken, accounts[1].user.csrfToken);
  const sets = await Promise.all(Array.from({ length: 24 }, async (_, i) => {
    const who = accounts[i%2], other = accounts[(i+1)%2];
    const gzip = i%4 < 2;
    const result = await request('/api/bootstrap', 'GET', { Cookie: who.cookie, 'Accept-Encoding': gzip ? 'gzip' : 'gzip;q=0' });
    assert.equal(result.code, 200);
    assert.equal(result.headers['cache-control'], 'no-store');
    assert.equal(result.headers['content-encoding'], gzip ? 'gzip' : undefined);
    const state = JSON.parse(result.text);
    assert.equal(state.workspace.id, who.user.workspace.id);
    assert.equal(state.csrfToken, who.user.csrfToken);
    for (const secret of [other.user.workspace.id, other.user.csrfToken, other.user.user.email]) {
      assert.equal(result.text.includes(secret), false);
    }
    return state.user.email;
  }));
  assert.equal(new Set(sets).size, 2);
});
