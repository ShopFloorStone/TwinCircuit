import test from 'node:test';
import assert from 'node:assert/strict';
import {TwinCircuitClient} from '../public/sdk.mjs';

test('browser SDK preserves host fetch receiver, CSRF and explicit revision conflict handling',async()=>{
 const requests=[];
 const client=new TwinCircuitClient({baseURL:'http://localhost:4173',fetchImpl:function(url,options){
  assert.equal(this,globalThis);requests.push({url:String(url),options});
  if(String(url).endsWith('/api/session'))return Promise.resolve(Response.json({user:{id:'owner'},csrfToken:'test-csrf'}));
  if(String(url).endsWith('/api/bootstrap'))return Promise.resolve(Response.json({revision:4,orders:[]}));
  return Promise.resolve(Response.json({error:{code:'REVISION_CONFLICT',message:'Read the current state'}},{status:409}));
 }});
 await client.bootstrap();
 await assert.rejects(client.command('order.create',{quantity:1},{requestId:'sdk-request-1'}),error=>error.status===409&&error.code==='REVISION_CONFLICT');
 assert.equal(requests.length,3);assert.equal(requests[2].options.headers['X-CSRF-Token'],'test-csrf');
 assert.equal(JSON.parse(requests[2].options.body).expectedRevision,4);
 assert.equal(JSON.parse(requests[2].options.body).requestId,'sdk-request-1');
 await assert.rejects(client.request('https://different.invalid/api/session'),/Cross-origin/);
 assert.equal(requests.length,3);
});

test('SDK keeps business and operations revisions independent, including imported measurement evidence',async()=>{
 const requests=[];let opsRevision=0;
 const client=new TwinCircuitClient({baseURL:'http://localhost:4173',fetchImpl:async(url,options)=>{
  const path=new URL(url).pathname,body=options.body?JSON.parse(options.body):null;requests.push({path,body});
  if(path==='/api/session')return Response.json({csrfToken:'sdk-two-revisions'});
  if(path==='/api/bootstrap')return Response.json({revision:7});
  if(path==='/api/operations')return Response.json({revision:opsRevision,devices:[]});
  assert.equal(options.headers['X-CSRF-Token'],'sdk-two-revisions');
  if(path==='/api/operations/command'){assert.equal(body.expectedRevision,opsRevision);opsRevision++;return Response.json({revision:opsRevision,...(body.type==='evidence.fromJobs'?{business:{revision:9}}:{})});}
  assert.equal(body.expectedRevision,7);return Response.json({revision:8});
 }});
 await assert.rejects(client.operationsCommand('device.arm',{}, {requestId:'must-read-first'}),/operations\(\)/);
 await client.bootstrap();await client.operations();assert.equal(client.revision,7);assert.equal(client.operationsRevision,0);
 await client.operationsCommand('device.register',{}, {requestId:'register-test'});assert.equal(client.revision,7);assert.equal(client.operationsRevision,1);
 await client.command('supplier.create',{}, {requestId:'business-test'});assert.equal(client.revision,8);
 await client.operationsCommand('evidence.fromJobs',{}, {requestId:'import-test'});assert.equal(client.revision,9);assert.equal(client.operationsRevision,2);
 assert.equal(requests.filter(r=>r.path==='/api/operations/command').length,2);
});
