import test from 'node:test';
import assert from 'node:assert/strict';
import {seedWorkspace,applyCommand} from '../lib/domain.mjs';
import {setLanguage} from '../public/i18n.mjs';
import {seededText,memberDisplayName} from '../public/seed-labels.mjs';

test('starter labels follow the UI language without translating authored or imported records',()=>{
  const state=seedWorkspace('Test',true), saved=structuredClone(state);
  const seed=state.suppliers[0], actor={role:'owner',id:'operator',name:'Operator'};
  try{
    setLanguage('en');
    assert.equal(seededText(state,seed),'Virtual Factory A');
    assert.equal(seededText(state,state.orders[0]),'Digital I/O test service · 100 tests');
    assert.match(seededText(state,state.specs[0],'description'),/^The output is 1/);
    assert.equal(seededText(state,{...seed,id:'supplier_custom'}),seed.name);
    assert.equal(seededText(state,{...seed,name:'用户的实验室'}),'用户的实验室');
    const changed=applyCommand(state,'supplier.update',{supplierId:seed.id,name:'用户的实验室'},actor);
    const restored=applyCommand(changed,'supplier.update',{supplierId:seed.id,name:seed.name},actor);
    assert.equal(seededText(restored,restored.suppliers[0]),seed.name);
    assert.match(seededText(restored,restored.suppliers[0],'description'),/^Virtual/);
    const imported={...state,events:[{type:'workspace.import'}]};
    assert.equal(seededText(imported,seed),seed.name);
    const reset=applyCommand(imported,'workspace.reset',{confirmation:'RESET DEMO'},actor);
    assert.equal(seededText(reset,reset.suppliers[0]),'Virtual Factory A');
    setLanguage('zh-CN');
    assert.equal(seededText(state,seed),seed.name);
    assert.deepEqual(state,saved);
  }finally{setLanguage('zh-CN');}
});

test('the generated guest is localized by identity rather than username',()=>{
  const user={id:'guest',isDemo:true,name:'演示访客'};
  try{
    setLanguage('en');
    assert.equal(memberDisplayName(user,user),'Demo Guest');
    assert.equal(memberDisplayName({...user,id:'member'},user),'演示访客');
    assert.equal(memberDisplayName(user,{...user,isDemo:false}),'演示访客');
  }finally{setLanguage('zh-CN');}
});
