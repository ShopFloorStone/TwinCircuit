import test from 'node:test';
import assert from 'node:assert/strict';
import {createFinancialScopeGuard} from '../public/operations-ui.mjs';

test('financial scope rejects stale preflight and identity changes while a review is open',async()=>{
 let identity='generation1/workspaceA/ownerA/sessionA',resolveReview,called=0;
 const guard=createFinancialScopeGuard(()=>identity);
 const reviewing=guard.review(async()=>{called++;return new Promise(resolve=>{resolveReview=resolve;});},{action:'fund'});
 identity='generation2/workspaceB/ownerA/sessionA';resolveReview(true);
 assert.equal(await reviewing,false);assert.equal(called,1);
 assert.equal(await guard.review(async()=>{called++;return true;},{}),false);assert.equal(called,1);
 assert.throws(()=>guard.assertCurrent(),{code:'PAYMENT_SCOPE_CHANGED'});
});

test('provider checks current application scope at final send and preserves provider method binding',async()=>{
 let identity='workspaceA/ownerA/generation1';const calls=[],listener=()=>{};
 const original={request(req){assert.equal(this,original);calls.push(req);return Promise.resolve('local-result');},on(event,fn){assert.equal(this,original);assert.equal(fn,listener);calls.push({on:event});},removeListener(event,fn){assert.equal(this,original);assert.equal(fn,listener);calls.push({remove:event});}};
 const guard=createFinancialScopeGuard(()=>identity),provider=guard.wrapProvider(original);
 assert.equal(await guard.review(async()=>true,{}),true);
 provider.on('accountsChanged',listener);provider.removeListener('accountsChanged',listener);
 // This is AFTER review and models a switch during SDK gas estimation / wallet snapshot awaits.
 identity='workspaceB/ownerA/generation2';
 assert.throws(()=>provider.request({method:'eth_sendTransaction',params:[{value:'0x0'}]}),{code:'PAYMENT_SCOPE_CHANGED'});
 assert.equal(calls.filter(c=>c.method==='eth_sendTransaction').length,0);
 // Read access remains available to trace an already submitted transaction.
 assert.equal(await provider.request({method:'eth_getTransactionReceipt',params:['0xlocal']}),'local-result');
});

test('clearing then returning to the same workspace cannot revive a captured operation',()=>{
 let generation=1;const guard=createFinancialScopeGuard(()=>`${generation}|same-workspace|same-user`);
 generation++;assert.equal(guard.isCurrent(),false);
 const next=createFinancialScopeGuard(()=>`${generation}|same-workspace|same-user`);assert.equal(next.isCurrent(),true);
});
