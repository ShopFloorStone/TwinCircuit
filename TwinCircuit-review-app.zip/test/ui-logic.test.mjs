import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import * as engine from '../public/engine.mjs';
import {t,getLocale,errorMessage,setLanguage,hasTranslation} from '../public/i18n.mjs';
import {techText,techToken} from '../public/precision.mjs';
import {seededText} from '../public/seed-labels.mjs';
import translations from '../public/locales/app.mjs';

// Run the actual UI helpers with controlled state, without executing app startup.
const source=readFileSync(new URL('../public/app.mjs',import.meta.url),'utf8');
function extract(name){const re=new RegExp(`(?:async )?function ${name}\\(`);const found=re.exec(source);assert.ok(found,name);const rest=source.slice(found.index);const end=rest.slice(1).search(/\n(?:async )?function |\nconst |\ndocument\./);return end<0?rest:rest.slice(0,end+1);}
const h=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function setup(){const c=engine.compileCME1();const spec={id:'s1',version:1,expression:c.expression,circuit:c};const order={id:'o1',specId:'s1',specVersion:1,specSnapshot:{...spec,vectors:engine.truthTable(c).map(r=>({inputs:Object.fromEntries(['C','M','E'].map((k,i)=>[k,r.inputs[i]])),expected:{Y:r.output}}))},batches:[]};const nodes=new Map();const sandbox={engine,t,getLocale,errorMessage,ui:{page:'tools',wallet:'0x1111111111111111111111111111111111111111',chainBusy:false,chainTarget:{circuit:c,context:{workspaceId:'w1',specId:'s1',specVersion:1,orderId:'o1'}}},data:{workspace:{id:'w1'}},currentSpec:()=>spec,currentOrder:()=>order,allBatches:o=>o.batches,h,badge:(text,tone)=>`<badge tone="${tone}">${h(text)}</badge>`,icon:()=>'',notice:text=>text,toast:(...args)=>sandbox.toasts.push(args),toasts:[],modal:()=>{},dialogReturn:null,$:selector=>{if(!nodes.has(selector))nodes.set(selector,{innerHTML:'',textContent:'',isConnected:true});return nodes.get(selector);},chainRPC:()=>{},chain:{},console};vm.createContext(sandbox);for(const name of ['circuitKey','scopedChainReport','chainReportForSpec','chainReportForOrder','waveform','renderBatchWaves','renderTruthRows','parseBitField','closeModal','reviewPublication','publishChainTarget','readChainTarget','chainResult'])vm.runInContext(extract(name),sandbox);return {sandbox,c,spec,order,nodes};}
test('public NAND and partial reports never count as the current specification',()=>{
  const {sandbox:x,c}=setup();x.ui.chainReport={ok:true,total:8,circuit:c,scope:'existing-reference-nand',context:{workspaceId:'w1',specId:'s1',specVersion:1}};assert.equal(x.chainReportForSpec(c),null);
  x.ui.chainReport.scope='single-input-vector';assert.equal(x.chainReportForSpec(c),null);
});
test('full reports are isolated by workspace, version, exact netlist and frozen order',()=>{
  const {sandbox:x,c,order}=setup();const report={ok:true,total:8,circuit:c,scope:'imported-circuit-all-inputs',context:{workspaceId:'w1',specId:'s1',specVersion:1,orderId:'o1'}};x.ui.chainReport=report;assert.equal(x.chainReportForSpec(c),report);assert.equal(x.chainReportForOrder(order),report);
  assert.equal(x.chainReportForSpec(engine.compileExpression('C && E')),null);
  assert.equal(x.chainReportForOrder({...order,id:'o2'}),null);
  report.context.specVersion=2;assert.equal(x.chainReportForSpec(c),null);report.context.specVersion=1;
  x.data.workspace.id='w2';assert.equal(x.chainReportForSpec(c),null);
});
test('waveforms encode actual vector bits and identify simulation and non-time axis',()=>{
  const {sandbox:x,order}=setup();const a=x.waveform([false,true,false],'sample'),b=x.waveform([true,false,true],'sample');assert.notEqual(a,b);assert.match(a,/<title>sample：0, 1, 0/);
  assert.match(x.renderBatchWaves(order),/暂无可用向量记录/);
  const tests=structuredClone(order.specSnapshot.vectors).map(t=>({...t,actual:{Y:!t.expected.Y}}));order.batches=[{id:'b1',mode:'virtual',records:[{unit:7,tests}]}];const html=x.renderBatchWaves(order);assert.match(html,/服务端虚拟轨迹/);assert.match(html,/件号 7/);assert.match(html,/不表示实时采样/);assert.match(html,/#b34232/);assert.match(html,/公开 NAND 参考不计入/);
});
test('null truth-table comparisons are explicitly unverified and input parsing is strict',()=>{
  const {sandbox:x}=setup();assert.match(x.renderTruthRows([{inputs:[0,0,1],output:false,pass:null}]),/未附独立规则/);assert.throws(()=>x.parseBitField('1,0',3,'输入'));
  assert.deepEqual(Array.from(x.parseBitField('',3,'输入')),[false,false,false]);
});
test('closing publication review resolves false instead of leaving a pending promise',async()=>{
  const {sandbox:x}=setup();const promise=x.reviewPublication({from:'a',address:'b',feeOKB:'0.001',feeWei:'1',gasEstimate:'0x10',tokenConsumption:{NAND:5,LATCH:0},transaction:{}});x.closeModal();assert.equal(await promise,false);assert.equal(x.ui.publishReviewResolve,null);
});
test('cancelled publishing does not poll a receipt or announce transaction submission',async()=>{
  const {sandbox:x}=setup();let called=0;x.chain.publishExistingCPU=async options=>{assert.equal(options.rpc,x.chainRPC);return {submitted:false,cancelled:true};};x.chain.waitForReceipt=()=>{called++;};await x.publishChainTarget('a');assert.equal(called,0);assert.equal(x.toasts[0][0],'已取消，未发送交易。');assert.equal(x.ui.chainBusy,false);
});
test('late chain response cannot attach evidence to a different current workspace',async()=>{
  const {sandbox:x}=setup();x.data.workspace.id='w2';const r=await x.chainResult(async()=>({ok:true}),{workspaceId:'w1'});assert.equal(r.ignoredForCurrentWorkspace,true);assert.equal(x.ui.chainReport,undefined);
});

function loadBreadcrumb(sandbox) {
 Object.assign(sandbox,{techText,techToken,displayText:(record,field)=>seededText(sandbox.data,record,field)});
 vm.runInContext(extract('workspaceDisplayName'),sandbox);
 vm.runInContext(extract('renderBreadcrumb'),sandbox);
}

test('operations breadcrumbs use their page and workspace rather than an unrelated legacy order',()=>{
 const x={t,ui:{page:'devices'},data:{workspace:{name:'<Panel workcell>'},user:{isDemo:false}},h,icon:()=>''};vm.createContext(x);loadBreadcrumb(x);
 const order={id:'TC-024',name:'Old virtual order · 100 units'};
 for(const [page,label]of [['devices','实际控制与测量'],['lines','产线接入目录'],['payments','BEM 主网付款']]){x.ui.page=page;const html=x.renderBreadcrumb(order);assert.match(html.replace(/<[^>]*>/g,''),new RegExp(label));assert.match(html,/&lt;Panel workcell&gt;/);assert.doesNotMatch(html,/TC-024|100 units|data-action="order-switch"/);assert.match(html,/data-action="refresh"/);}
 x.ui.page='execution';assert.match(x.renderBreadcrumb(order),/TC-024/);assert.match(x.renderBreadcrumb(order),/data-action="order-switch"/);
});

test('netlist download keeps the selected specification profile for panel and legacy IO',()=>{
 const statement=source.match(/case 'export-netlist':\{[^\n]+break;\}/)?.[0];assert.ok(statement);let spec={id:'panel',version:1,name:'Panel',profile:'TC-PANEL/0.1'},downloaded;
 const x={t,currentSpec:()=>spec,draftCircuit:()=>engine.compileCME1(),engine,download:(name,body)=>downloaded=JSON.parse(body)};vm.createContext(x);
 vm.runInContext(`switch('export-netlist'){${statement}}`,x);assert.equal(downloaded.profile,'TC-PANEL/0.1');
 spec={...spec,profile:'TC-IO/0.1'};vm.runInContext(`switch('export-netlist'){${statement}}`,x);assert.equal(downloaded.profile,'TC-IO/0.1');
 const firmware=source.match(/case 'export-firmware':[^\n]+break;/)?.[0];assert.ok(firmware);let generated=0;x.engine={...engine,firmware(){generated++;return 'fixture GPIO sketch';}};x.download=(name,body)=>downloaded=body;
 spec={...spec,profile:'TC-PANEL/0.1'};assert.throws(()=>vm.runInContext(`switch('export-firmware'){${firmware}}`,x),/panel 专用固件/);assert.equal(generated,0);
 spec={...spec,profile:'TC-IO/0.1'};vm.runInContext(`switch('export-firmware'){${firmware}}`,x);assert.equal(generated,1);
});

test('English catalog covers explicit UI copy and preserves every interpolation parameter',()=>{
 for(const [key,value] of Object.entries(translations)){
  assert.equal(typeof value,'string',key);assert.ok(value.length,key);assert.doesNotMatch(value,/[\u3400-\u9fff]/u,key);
  const tokens=text=>[...text.matchAll(/\{(\w+)\}/g)].map(m=>m[1]).sort();assert.deepEqual(tokens(value),tokens(key),key);
 }
 for(const match of source.matchAll(/\bt\(("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')/g)){
  const text=vm.runInNewContext(match[1]);if(/[\u3400-\u9fff]/u.test(text))assert.ok(hasTranslation(text),text);
 }
});

test('runtime labels switch in place while business names and values remain unchanged',()=>{
 const {sandbox:x}=setup();x.data={workspace:{name:'用户工作区 <A>'},user:{isDemo:false}};
 loadBreadcrumb(x);vm.runInContext(extract('roleName'),x);
 try{
  setLanguage('en');x.ui.page='devices';const html=x.renderBreadcrumb({id:'o1',name:'用户订单'});assert.match(html,/Physical control and measurement/);assert.match(html,/用户工作区 &lt;A&gt;/);assert.equal(x.roleName('verifier'),'Verifier');assert.match(x.renderTruthRows([{inputs:[false,false,true],output:false,pass:null}]),/No independent rule attached/);
  assert.equal(t('{p0} 次',{p0:123}),'123 tests');
  setLanguage('zh-CN');assert.equal(x.roleName('verifier'),'验证者');assert.match(x.renderBreadcrumb(),/实际控制与测量/);
 }finally{setLanguage('zh-CN');}
});

test('language switching is cancelled during dialogs, business writes, wallet work and serial tests',()=>{
 const x={t,busy:false,serialBusy:false,ui:{chainBusy:false},ops:{isBusy:()=>false},$:()=>null,toasts:[],toast:(...args)=>x.toasts.push(args)};vm.createContext(x);vm.runInContext(extract('beforeLanguageChange'),x);
 const event=()=>({defaultPrevented:false,preventDefault(){this.defaultPrevented=true;}});
 let e=event();x.beforeLanguageChange(e);assert.equal(e.defaultPrevented,false);
 x.$=()=>({});e=event();x.beforeLanguageChange(e);assert.equal(e.defaultPrevented,true);assert.match(x.toasts.at(-1)[0],/关闭当前对话框/);x.$=()=>null;
 for(const kind of ['busy','serialBusy','chainBusy','ops']){
  x.busy=kind==='busy';x.serialBusy=kind==='serialBusy';x.ui.chainBusy=kind==='chainBusy';x.ops.isBusy=()=>kind==='ops';e=event();x.beforeLanguageChange(e);assert.equal(e.defaultPrevented,true,kind);
 }
 const count=x.toasts.length;e=event();e.preventDefault();x.beforeLanguageChange(e);assert.equal(x.toasts.length,count,'a previous guard must not produce duplicate warnings');
});

test('public signup renders only email and a new password in both languages', () => {
 const x={t, h, icon:()=>'', session:{setupRequired:false}, location:{search:''}, URLSearchParams};
 vm.createContext(x);
 for (const name of ['field','renderAuthForm','initialAuthTab']) vm.runInContext(extract(name),x);
 try {
  for (const [locale,label] of [['zh-CN','邮箱注册'],['en','Sign up']]) {
   setLanguage(locale);
   assert.ok(x.renderAuthForm('login').includes(label));
   const html=x.renderAuthForm('signup');
   assert.match(html,/data-form="auth-signup"/);
   assert.deepEqual([...html.matchAll(/<input name="([^"]+)"/g)].map(m=>m[1]),['email','password']);
   assert.match(html,/type="email"[^>]*autocomplete="username"/);
   for (const form of [html,x.renderAuthForm('join')]) {
    const password=form.match(/<input name="password"[^>]*>/)[0];
    assert.match(password,/\brequired\b/);
    assert.match(password,/autocomplete="new-password"/);
    assert.doesNotMatch(password,/minlength=/);
    assert.match(form,locale==='en'?/recommend 12 or more characters/:/建议使用 12 个或更多字符/);
   }
  }
  x.location.search='?signup=1';
  assert.equal(x.initialAuthTab(),'signup');
  assert.match(x.renderAuthForm('login'),/data-form="auth-login"/);
  x.location.search='?signup=1&invite=sample-token';
  assert.equal(x.initialAuthTab(),'join');
  assert.match(x.renderAuthForm('join'),/name="token"[^>]*value="sample-token"/);
  x.session.setupRequired=true;
  assert.equal(x.initialAuthTab(),'setup');
  const setup=x.renderAuthForm('setup');
  assert.doesNotMatch(setup,/data-tab="signup"/);
  assert.match(setup,/name="setupToken"/);
  assert.match(setup,/<input name="password"[^>]*minlength="12"/);
 } finally { setLanguage('zh-CN'); }
});

test('auth draft capture is memory-only and preserves passwords and setup tokens across rerenders',()=>{
 let inputs=[{name:'email',value:'member@example.test'},{name:'password',value:'private typed password'},{name:'setupToken',value:'one-time token'}];
 const x={authTab:'setup',authDrafts:Object.create(null),$:()=>({}),$$:()=>inputs};vm.createContext(x);vm.runInContext(extract('captureAuthDraft'),x);vm.runInContext(extract('restoreAuthDraft'),x);x.captureAuthDraft();
 inputs=inputs.map(input=>({...input,value:''}));x.restoreAuthDraft();assert.deepEqual(inputs.map(i=>i.value),['member@example.test','private typed password','one-time token']);
 vm.runInContext(extract('clearAuthDrafts'),x);x.clearAuthDrafts();assert.equal(x.authTab,null);assert.equal(Object.keys(x.authDrafts).length,0);
 assert.match(source,/auth-language-row/);assert.match(source,/header-actions">\$\{languageSwitcher\(\)\}/);assert.match(source,/TwinCircuit 1\.4 · 自托管版/);
});

test('language rerender preserves page, order, filters, unsaved controls and focus without commands',()=>{
 const old={name:'query',id:'',value:'尚未提交 <text>',checked:false,selectionStart:2,selectionEnd:4};let inputs=[old],renders=0,commands=0;const next={name:'query',id:'',value:'',checked:false,focus(){this.focused=true;},setSelectionRange(a,b){this.selection=[a,b];}};
 const x={document:{activeElement:old},ui:{page:'capabilities',orderId:'o1',search:'saved-filter',supplierMode:'external'},data:{},session:{},authTab:null,$:()=>({}),$$:()=>inputs,captureAuthDraft(){},render(){renders++;inputs=[next];},command(){commands++;},api(){commands++;},renderAuth(){throw Error('unexpected auth render');}};
 vm.createContext(x);vm.runInContext(extract('handleLanguageChange'),x);x.handleLanguageChange();assert.equal(renders,1);assert.equal(commands,0);assert.equal(next.value,old.value);assert.equal(next.focused,true);assert.deepEqual(next.selection,[2,4]);assert.equal(x.ui.page,'capabilities');assert.equal(x.ui.orderId,'o1');assert.equal(x.ui.search,'saved-filter');assert.equal(x.ui.supplierMode,'external');
});

