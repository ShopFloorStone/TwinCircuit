import test from 'node:test';
import assert from 'node:assert/strict';
import { applyCommand, seedWorkspace, availability, validateImport } from '../lib/domain.mjs';
const owner = { id: 'owner', role: 'owner', name: 'Owner' };
const operator = { id: 'operator', role: 'operator', name: 'Operator' };
const verifier = { id: 'verifier', role: 'verifier', name: 'Verifier' };

function harness() { let state = seedWorkspace('Test', true); return { get state() { return state; }, run(type, payload = {}, actor = owner) { state = applyCommand(state, type, payload, actor); return state; }, get order() { return state.orders[0]; } }; }
function prepare(h) { h.run('reservation.create', { orderId: 'TC-024', supplierId: 'supplier_a', quantity: 60 }); h.run('reservation.create', { orderId: 'TC-024', supplierId: 'supplier_b', quantity: 40 }); for (const r of h.order.reservations) h.run('reservation.confirm', { orderId: 'TC-024', reservationId: r.id }); h.run('order.confirm', { orderId: 'TC-024' }); h.run('order.start', { orderId: 'TC-024' }); }

test('100-unit fault/reassignment journey preserves quantity, evidence and exact ledger', () => {
  const h = harness(); prepare(h); const a = h.order.reservations[0].id, b = h.order.reservations[1].id;
  h.run('execution.advance', { orderId: 'TC-024', reservationId: a, count: 40 }, operator);
  assert.equal(h.order.batches[0].records[0].unit, 0); assert.equal(h.order.batches[0].records[0].tests.length, 8);
  h.run('order.fault', { orderId: 'TC-024', reservationId: a, cancelRemaining: true });
  h.run('reservation.reassign', { orderId: 'TC-024', reservationId: a, supplierId: 'supplier_b', quantity: 20 });
  const replacement = h.order.reservations[2].id;
  assert.throws(() => h.run('order.start', { orderId: 'TC-024' }), /confirmed/);
  h.run('reservation.confirm', { orderId: 'TC-024', reservationId: replacement }); h.run('order.start', { orderId: 'TC-024' });
  h.run('execution.advance', { orderId: 'TC-024', reservationId: b, count: 40 }, operator); h.run('execution.advance', { orderId: 'TC-024', reservationId: replacement, count: 20 }, operator);
  assert.equal(h.order.status, 'awaiting_verification'); assert.equal(h.order.completedQuantity, 100); assert.equal(h.order.acceptedQuantity, 0);
  assert.throws(() => h.run('order.settle', { orderId: 'TC-024' }), /accepted/);
  for (const batch of h.order.batches) h.run('batch.accept', { orderId: 'TC-024', batchId: batch.id, note: 'Reviewed simulated vectors' }, verifier);
  h.run('order.accept', { orderId: 'TC-024' }, verifier); h.run('order.settle', { orderId: 'TC-024' });
  const entries = h.order.settlement.entries;
  assert.deepEqual(entries.map(e => e.amountCents), [2800, 4200, 1500, 1000, 500]); assert.equal(entries.reduce((n, e) => n + e.amountCents, 0), 10000);
  assert.equal(h.order.settlement.mode, 'simulation'); h.run('order.settle', { orderId: 'TC-024' }); assert.equal(h.state.ledger.length, 1);
  assert.equal(h.order.reservations[0].cancelledQuantity, 20); assert.equal(availability(h.state, 'supplier_b'), 60);
});

test('state machine, capacity and permissions reject unsafe transitions without mutating input', () => {
  const h = harness(), before = structuredClone(h.state);
  assert.throws(() => h.run('order.start', { orderId: 'TC-024' }), /confirmed/);
  assert.throws(() => h.run('reservation.create', { orderId: 'TC-024', supplierId: 'supplier_a', quantity: 61 }), /capacity/);
  assert.throws(() => h.run('spec.create', { name: 'Forbidden' }, { id: 'viewer', role: 'viewer' }), /role/);
  assert.deepEqual(h.state, before); prepare(h);
  assert.throws(() => h.run('execution.advance', { orderId: 'TC-024', reservationId: h.order.reservations[0].id, count: 61 }), /remaining/);
  assert.throws(() => h.run('reservation.create', { orderId: 'TC-024', supplierId: 'supplier_b', quantity: 1 }), /draft/);
});

test('published specification changes create versions while order snapshots remain frozen', () => {
  const h = harness(); const snapshot = structuredClone(h.order.specSnapshot);
  h.run('spec.update', { specId: 'spec_io_v1', expression: 'C && M && E', variables: ['C', 'M', 'E'] });
  assert.equal(h.state.specs[0].version, 2); assert.equal(h.state.specs[0].status, 'draft'); assert.deepEqual(h.order.specSnapshot, snapshot);
  assert.throws(() => h.run('spec.update', { specId: 'spec_io_v1', expression: 'globalThis.process.exit()' }), /Expression|expression/);
});

test('external suppliers require sourced evidence and a different verifier', () => {
  const h = harness(); h.run('supplier.create', { name: 'External', capacity: 1, mode: 'external' }); const supplierId = h.state.suppliers.at(-1).id;
  assert.throws(() => h.run('supplier.update', { supplierId, mode: 'virtual' }), /immutable/);
  h.run('order.create', { name: 'One real evidence unit', quantity: 1, budgetCents: 103, specId: 'spec_io_v1' }); const orderId = h.state.orders.at(-1).id;
  h.run('reservation.create', { orderId, supplierId, quantity: 1 }); let order = h.state.orders.at(-1), reservationId = order.reservations[0].id;
  assert.throws(() => h.run('reservation.confirm', { orderId, reservationId }), /reference/);
  h.run('reservation.confirm', { orderId, reservationId, confirmationRef: 'provider-confirmation-123' }); h.run('order.confirm', { orderId }); h.run('order.start', { orderId });
  assert.throws(() => h.run('execution.advance', { orderId, reservationId, count: 1 }), /External suppliers/);
  const records = [{ unit: 0, source: 'Instrument report #123', tests: order.specSnapshot.vectors.map(t => ({ ...structuredClone(t), actual: structuredClone(t.expected) })) }];
  const forged = structuredClone(records); forged[0].tests[0].expected.Y = true;
  assert.throws(() => h.run('evidence.submit', { orderId, reservationId, records: forged }), /frozen/);
  const failing = structuredClone(records); failing[0].tests[0].actual.Y = !failing[0].tests[0].expected.Y;
  h.run('evidence.submit', { orderId, reservationId, records: failing }); const failedBatch = h.state.orders.at(-1).batches[0].id;
  assert.throws(() => h.run('batch.accept', { orderId, batchId: failedBatch, note: 'Check failing instrument report' }, verifier), /failing/);
  h.run('batch.reject', { orderId, batchId: failedBatch, note: 'Output for vector zero did not match the frozen specification.' }, verifier);
  assert.equal(h.state.orders.at(-1).completedQuantity, 0);
  h.run('evidence.submit', { orderId, reservationId, records }); order = h.state.orders.at(-1); const batchId = order.batches[0].id;
  const correctedBatchId = order.batches.at(-1).id;
  assert.throws(() => h.run('batch.accept', { orderId, batchId: correctedBatchId, note: 'Inspected instrument report' }), /another user/);
  h.run('batch.accept', { orderId, batchId: correctedBatchId, note: 'Reviewed submitted digital vectors only; physical provenance unverified.' }, verifier);
  h.run('order.accept', { orderId }, verifier); h.run('order.settle', { orderId }); assert.equal(h.state.orders.at(-1).settlement.totalCents, 103);
});

test('imports reject fabricated execution, oversized quantities and unknown schemas', () => {
  const seed = seedWorkspace('Import', true); assert.equal(validateImport(seed, seed, owner).orders.length, 1);
  const fake = structuredClone(seed); fake.orders[0].status = 'settled'; assert.throws(() => validateImport(fake, seed, owner), /unexecuted/);
  const bad = structuredClone(seed); bad.orders[0].quantity = 1.5; assert.throws(() => validateImport(bad, seed, owner), /integer/);
  assert.throws(() => validateImport({ ...seed, unexpected: true }, seed, owner), /Unknown/);
});
