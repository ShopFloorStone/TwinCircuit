import test from 'node:test';
import assert from 'node:assert/strict';
import {decimalToUnits,unitsToDecimal,BEM_ASSET} from '../public/line-templates.mjs';
test('BEM eight-decimal form amounts retain exact integers above Number precision',()=>{
 assert.equal(BEM_ASSET.decimals,8);
 assert.equal(decimalToUnits('0.00000001',8),'1');
 const display='9007199254740993.12345678';
 assert.equal(decimalToUnits(display,8),'900719925474099312345678');
 assert.equal(unitsToDecimal('900719925474099312345678',8),display);
 for(const invalid of ['0','-1','1e8','0.000000001','1,000','Infinity',''])assert.throws(()=>decimalToUnits(invalid,8));
 assert.throws(()=>decimalToUnits('1',undefined));
});
