import assert from 'node:assert/strict';
import test from 'node:test';
import { applyCommand, availability, seedWorkspace, viewState } from '../lib/domain.mjs';
import { Store } from '../lib/store.mjs';

test('public domain results remain independent, and projected capacity matches reservation accounting', () => {
  const actor = { role: 'owner', id: 'sample', name: 'Owner' };
  const original = seedWorkspace();
  const allocated = applyCommand(original, 'reservation.create', {
    supplierId: 'supplier_a', orderId: 'TC-024', quantity: 19,
  }, actor);
  assert.equal(original.orders[0].reservations.length, 0);
  allocated.orders[0].reservations[0].cancelledQuantity = 2;
  allocated.orders.push({ status: 'settled', reservations: [{ supplierId: 'supplier_a', quantity: 60, cancelledQuantity: 0 }] });
  allocated.orders.push({ status: 'draft', reservations: [{ supplierId: 'supplier_b', quantity: 12, cancelledQuantity: 3 }] });

  const projected = viewState(allocated);
  for (const supplier of projected.suppliers) {
    assert.equal(supplier.available, availability(allocated, supplier.id));
    assert.equal(supplier.availableCapacity, supplier.available);
  }
  projected.orders[0].reservations[0].quantity = 58;
  assert.equal(allocated.orders[0].reservations[0].quantity, 19);
  assert.equal('availableCapacity' in allocated.suppliers[0], false);
});

test('write responses, aborted updates and retried commands resolve against the current authorized database state', t => {
  const store = new Store(':memory:');
  t.after(() => store.close());
  const login = store.setup({ email: 'owner@example.invalid', password: 'long-test-password', setupToken: 'setup' }, 'setup');
  const owner = store.session(login.secret);
  const run = (actor, type, payload, overrides = {}) => store.command(actor, {
    type, payload, expectedRevision: store.state(actor).revision, ...overrides,
  });
  const firstId = owner.workspaceId;
  const payload = { email: 'viewer@example.invalid', role: 'viewer' };
  const issued = run(owner, 'member.invite', payload, { requestId: 'issue-invite' });
  const invitationToken = issued.invitation.token;
  issued.orders[0].name = 'tampered local copy';
  assert.notEqual(store.state(owner).orders[0].name, issued.orders[0].name);
  assert.equal('availableCapacity' in store.state(owner).suppliers[0], false);

  const before = store.state(owner);
  assert.throws(() => run(owner, 'supplier.update', { supplierId: 'supplier_a', name: 'uncommitted', status: 'invalid' }));
  assert.deepEqual(store.state(owner), before);

  const second = run(owner, 'workspace.create', { name: 'Second' }, { requestId: 'create-second' });
  assert.deepEqual(second.workspaces.map(workspace => workspace.id), [firstId, second.workspace.id]);
  assert.deepEqual(second.invites, []);
  const reader = store.session(store.register({ name: 'Viewer', email: payload.email, password: 'test', token: invitationToken }).secret);
  assert.equal(store.bootstrap(reader).user.role, 'viewer');
  assert.deepEqual(store.bootstrap(reader).invites, []);
  const replay = run(owner, 'member.invite', payload, { requestId: 'issue-invite', expectedRevision: 0 });
  assert.equal(replay.workspace.id, firstId);
  assert.equal(replay.invitation, undefined);
  assert.ok(replay.invites[0].usedAt > 0);
  assert.deepEqual(replay, store.bootstrap(owner));
  assert.equal(run(owner, 'workspace.create', { name: 'Second' }, { requestId: 'create-second' }).workspace.id, second.workspace.id);
});
