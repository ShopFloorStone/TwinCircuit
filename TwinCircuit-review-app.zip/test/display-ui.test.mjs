import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { displayDiagnosticsMarkup, buildGatewayConfig } from '../public/operations-ui.mjs';
import { LINE_TEMPLATES } from '../public/line-templates.mjs';
import { validateConfig } from '../gateway/config.mjs';

const h = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
test('display UI labels optional, disabled and failed diagnostics without claiming physical visibility', () => {
  assert.match(displayDiagnosticsMarkup(undefined, h), /尚未上报.*displayTelemetry: true/);
  assert.match(displayDiagnosticsMarkup({ enabled: false }, h), /未启用 TFT/);
  const failed = displayDiagnosticsMarkup({ diagnosticStatus: 'error', error: '<img src=x onerror=alert(1)>' }, h);
  assert.match(failed, /正常 TC1 连接与控制许可独立判断/); assert.doesNotMatch(failed, /<img/); assert.match(failed, /&lt;img/);
  for (const value of [undefined, { enabled: false }, { diagnosticStatus: 'error' }]) assert.match(displayDiagnosticsMarkup(value, h), /实体画面未验证/);
});
test('raw controller ID, driver status and assumed controller never become a screen verification', () => {
  const reported = displayDiagnosticsMarkup({ enabled: true, controller: 'ILI9341<script>', width: 320, height: 240, rawControllerId: '0x00009341', controllerIdAvailable: true, initStatus: 'driver-begin-returned', visibleVerified: true, receivedAt: '<svg onload=bad()>' }, h);
  assert.match(reported, /0x00009341/); assert.match(reported, /320 × 240/); assert.match(reported, /配置假设/); assert.match(reported, /驱动 begin 已返回/);
  assert.match(reported, /实体画面未验证/); assert.match(reported, /不证明屏幕可见/); assert.doesNotMatch(reported, /<script>|<svg/);
  assert.match(reported, /采样来源：启动缓存/); assert.match(reported, /现场照片或人工确认须单独记录/);
  const current = displayDiagnosticsMarkup({ enabled: true, registerSampledAtTickMs: 12345, readRegisterHz: 1000000, sampleScope: 'current-display-query' }, h);
  assert.match(current, /采样来源：本次 DISPLAY 查询 · 1 MHz · 设备 tick 12345 ms/); assert.match(current, /实体画面未验证/); assert.doesNotMatch(current, /采样来源：启动缓存/);
});
test('firmware guide retains default downloads and adds explicit optional TFT power and wiring information', () => {
  const source = readFileSync(new URL('../public/operations-ui.mjs', import.meta.url), 'utf8');
  assert.match(source, /displayDiagnosticsMarkup\(d\.localState\?\.display,h\)/);
  assert.match(source, /displayTelemetry:panel/); assert.match(source, /firmware\/esp32-s3\/firmware.bin/);
  for (const file of ['bootloader.bin', 'partitions.bin', 'firmware.bin', 'manifest.json']) assert.ok(source.includes(`/firmware/esp32-s3-tft/${file}`));
  for (const file of ['bootloader.bin', 'partitions.bin', 'firmware.bin', 'manifest.json']) assert.ok(source.includes(`/firmware/esp32-s3-panel/${file}`));
  for (const pin of ['GPIO13', 'GPIO11', 'GPIO12', 'GPIO10', 'GPIO9', 'GPIO14']) assert.ok(source.includes(pin));
  assert.match(source, /按模块供电 \/ J1 状态确认/); assert.match(source, /3V3（非 GPIO）/); assert.match(source, /触摸与 SD 引脚保持不接/);
  assert.match(source, /仅作相似模块参考/); assert.match(source, /不要在未知模块上短接 J1/);
});

test('all seven UI connector downloads pass the actual gateway validator and stay disabled; TFT cannot become GPIO', () => {
  assert.equal(LINE_TEMPLATES.length, 7);
  for (const template of LINE_TEMPLATES) {
    const raw = buildGatewayConfig({ id: 'fixture', protocol: template.protocol, signals: template.signals }, 'http://127.0.0.1:4173'), validated = validateConfig(raw), d = validated.devices[0];
    assert.equal(d.enabled, false); assert.equal(d.outputsEnabled, false); assert.equal(d.tokenEnv, 'TC_DEVICE_TOKEN');
    if (template.id === 's3-panel') { assert.equal(raw.devices[0].protocol, 'esp32-tft'); assert.equal(d.capability, 'tft-panel'); assert.equal(d.path, 'COM4'); assert.equal(d.displayTelemetry, true); assert.deepEqual(Object.keys(d.signals), ['panel_vector']); }
    if (template.id === 's3-io') { assert.equal(d.capability, undefined); assert.equal(d.displayTelemetry, false); }
    if (template.protocol === 'opcua') { assert.equal(d.securityMode, 'SignAndEncrypt'); assert.equal(d.trustedServerCertificate, './certificates/approved-server.der'); }
    if (template.protocol === 'mqtt') { assert.equal(d.feedbackMaxAgeMs, 5000); assert.equal(d.usernameEnv, 'TC_MQTT_USER'); }
  }
});
