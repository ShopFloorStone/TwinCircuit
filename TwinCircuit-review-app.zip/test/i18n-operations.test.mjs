import test from 'node:test';
import assert from 'node:assert/strict';
import { t, setLanguage, getLanguage, getMissingTranslations, clearMissingTranslations } from '../public/i18n.mjs';
import operationsCatalog from '../public/locales/operations.mjs';
import { createOperationsUI, displayDiagnosticsMarkup } from '../public/operations-ui.mjs';
import { LINE_TEMPLATES, BEM_ASSET, decimalToUnits } from '../public/line-templates.mjs';

const h = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const chinese = text => /[\u3400-\u9fff]/u.test(text);
const params = text => [...text.matchAll(/\{([A-Za-z][A-Za-z0-9_]*)\}/g)].map(m => m[1]).sort();

test('all operation messages and seven static line templates have complete English copy without mutating business definitions', () => {
  const snapshot = JSON.stringify(LINE_TEMPLATES);
  assert(Object.keys(operationsCatalog).length >= 490);
  for (const [source, english] of Object.entries(operationsCatalog)) {
    assert(english.trim(), source); assert(!chinese(english), source); assert.deepEqual(params(english), params(source), source);
  }
  try {
    setLanguage('en');
    for (const template of LINE_TEMPLATES) for (const text of [template.name, template.subtitle, template.kind, template.description, template.endpoint, template.equipment, template.metric, ...template.stages]) assert(!chinese(t(text)), text);
    assert.throws(() => decimalToUnits('1.234', 2), /at most 2 decimal places/);
    assert.equal(decimalToUnits('12.34', 8), '1234000000');
    setLanguage('zh-CN'); assert.throws(() => decimalToUnits('1.234', 2), /最多 2 位小数/);
    assert.equal(JSON.stringify(LINE_TEMPLATES), snapshot); assert.equal(BEM_ASSET.address, '0x60e62efa9405d6873c5deabd4e6cc91c25363952');
  } finally { setLanguage('zh-CN'); }
});

function fixture(testContext, {onCommand, beforeRead}={}) {
  const saved = Object.fromEntries(['document', 'window', 'location', 'ethereum', 'setInterval', 'localStorage'].map(k => [k, globalThis[k]]));
  const listeners = new Map(), calls = [], dialogs = [], toasts = [], renderings = [];
  globalThis.document = { addEventListener(name, fn) { listeners.set(name, fn); }, querySelector() { return null; }, documentElement: {}, visibilityState: 'hidden' };
  globalThis.window = new EventTarget(); globalThis.location = { origin: 'https://isolated-i18n.invalid' }; globalThis.setInterval = () => 0;
  globalThis.localStorage = { getItem() { return null; }, setItem() {} };
  globalThis.ethereum = { request() { throw Error('No wallet request is permitted during language rendering'); } };
  const now = Date.now(), device = { id: 'tft-fixture', name: '用户自填 <工作台>', endpoint: '用户自填 COM4 地址', protocol: 'esp32-tft', signals: [{ name: 'panel_vector', type: 'number', min: 0, max: 7, critical: false }], status: 'registered', revision: 8, armedUntil: now + 60000, lastSeen: now, localState: { connected: true, armedUntil: now + 60000 } };
  const inputs = n => ({ C: Boolean(n & 4), M: Boolean(n & 2), E: Boolean(n & 1) });
  const jobs = Array.from({ length: 8 }, (_, value) => ({ id: 'measurement-' + value, deviceId: device.id, state: 'succeeded', payload: { signal: 'panel_vector', value }, revision: value, createdAt: now, expiresAt: now + 60000, result: { revision: value + 1, evidence: { actualY: Boolean(value & 1) && Boolean(value & 6), pixel: { actualColor: value & 1 && value & 6 ? 0xffffff : 0 } } } }));
  const order = { id: 'TC-PANEL-I18N', name: '用户自填测试订单', status: 'awaiting_verification', quantity: 1, acceptedQuantity: 0, specSnapshot: { profile: 'TC-PANEL/0.1' }, batches: [{ id: 'external-batch', mode: 'external', status: 'pending', submittedBy: 'another-operator', records: [{ unit: 0, source: '用户原始来源，不翻译', tests: jobs.map((j, i) => ({ inputs: inputs(i), expected: { Y: j.result.evidence.actualY }, actual: { Y: j.result.evidence.actualY } })), provenance: { measurements: jobs.map((j, i) => ({ jobId: j.id, vectorIndex: i, evidence: j.result.evidence })) } }] }] };
  let business = { revision: 1, csrfToken: 'isolated-csrf', workspace: { id: 'isolated-workspace' }, user: { id: 'owner-reviewer', role: 'owner', isDemo: false }, suppliers: [], orders: [order] };
  const operations = { revision: 5, devices: [device], jobs, workcells: [{ deviceId: device.id, orderId: order.id }], paymentPlans: [{ id: 'payment-plan', orderId: order.id, status: 'planned', amount: '1234000000', tokenDecimals: 8, tokenSymbol: 'BEM', claimedBuyer: '0x' + '1'.repeat(40), verifierAddress: '0x' + '2'.repeat(40), escrowAddress: '0x' + '3'.repeat(40), proofs: [{ transactionHash: '0x' + '4'.repeat(64) }] }], config: { payment: { tokenConfigured: true, configured: true, tokenAddress: BEM_ASSET.address, decimals: 8, confirmations: 3, metadataVerified: true, escrowAllowlist: ['0x' + '3'.repeat(40)] } } };
  const ctx = { escape: h, getState: () => business, setBusiness(next) { business = next; }, getPage: () => 'devices', api: async (url, options) => { calls.push({ url, options }); if (options && url === '/api/operations/command' && onCommand) return onCommand(options.body, operations); assert(!options, 'A render or dialog must not send a command'); if (url === '/api/operations') { beforeRead?.(operations); return structuredClone(operations); } if (url === '/api/bootstrap') return structuredClone(business); throw Error('Unexpected API'); }, rerender() { renderings.push(getLanguage()); }, modal(title, body, footer) { dialogs.push({ title, body, footer }); }, toast(...args) { toasts.push(args); }, closeModal() {}, navigate() {}, download() {} };
  const ui = createOperationsUI(ctx);
  const click = (action, id = '') => listeners.get('click')({ target: { closest() { return { disabled: false, dataset: { ops: action, id } }; } } });
  testContext.after(() => { for (const [key, value] of Object.entries(saved)) { if (value === undefined) delete globalThis[key]; else globalThis[key] = value; } setLanguage('zh-CN'); });
  return { ui, calls, dialogs, toasts, renderings, click, listeners, operations, business: () => business, device };
}

test('populated devices, seven lines and payments rerender both languages while preserving names, evidence, addresses and scope', async tc => {
  const f = fixture(tc); setLanguage('zh-CN'); await f.ui.refresh(false);
  const state = JSON.stringify(f.ui.getState()), business = JSON.stringify(f.business()), reads = f.calls.length;
  assert.match(f.ui.renderDevices(), /真实 TFT 测试工作单/); clearMissingTranslations();
  setLanguage('en');
  const lines = f.ui.renderLines(), devices = f.ui.renderDevices(), payments = f.ui.renderPayments();
  assert.match(lines, /Seven integration templates/); assert.match(lines, /Precision assembly station/); assert.match(lines, /Environment and facilities station/); assert.doesNotMatch(lines, /[\u3400-\u9fff]/u);
  assert.match(devices, /Real TFT test work order/); assert.match(devices, /Awaiting independent review/); assert.match(devices, /controller GRAM readback/); assert.match(devices, /does not verify optical output/);
  assert(devices.includes('用户自填 &lt;工作台&gt;')); assert(devices.includes('用户自填 COM4 地址')); assert(devices.includes('用户自填测试订单')); assert(!devices.includes('&amp;lt;'));
  const headingText = html => html.match(/<h1>([\s\S]*?)<\/h1>/)[1].replace(/<[^>]*>/g, '');
  assert.match(headingText(payments), /BEM mainnet payments/); assert.match(payments, /Escrow contract/); assert(payments.includes(BEM_ASSET.address)); assert(payments.includes('12.34')); assert(payments.includes('0x' + '1'.repeat(40)));
  setLanguage('zh-CN'); assert.match(headingText(f.ui.renderPayments()), /BEM 主网付款/); assert.match(f.ui.renderDevices(), /真实 TFT 测试工作单/);
  assert.equal(f.calls.length, reads); assert.equal(JSON.stringify(f.ui.getState()), state); assert.equal(JSON.stringify(f.business()), business); assert.deepEqual(getMissingTranslations(), []);
});

test('escrow setup follows the server allowlist, account role and configuration state in both languages', async tc => {
  const f = fixture(tc);
  const payment = f.operations.config.payment;
  const deploy = /data-ops="deploy"/;
  const first = payment.escrowAllowlist[0], other = '0x' + '5'.repeat(40);
  payment.metadataVerified = false;
  await f.ui.refresh(false);
  const render = () => f.ui.renderPayments();
  for (const [lang, label] of [['zh-CN','托管合约已接入'], ['en','Escrow connected']]) {
    setLanguage(lang);
    assert(render().includes(label));
    assert(render().includes('https://web3.okx.com/explorer/x-layer/address/' + first));
    assert.doesNotMatch(render(), deploy);
    assert(!render().includes('PAYMENT_ESCROW_ALLOWLIST'));
  }
  payment.escrowAllowlist.push(other);
  await f.ui.refresh(false);
  assert(render().includes('https://web3.okx.com/explorer/x-layer/address/' + other));
  assert(render().includes('https://web3.okx.com/explorer/x-layer/address/' + first));
  await f.click('deploy');
  assert.equal(f.dialogs.length, 0);
  payment.configured = false;
  payment.escrowAllowlist = ['invalid-entry'];
  await f.ui.refresh(false);
  assert(render().includes('Check the mainnet escrow configuration'));
  assert.doesNotMatch(render(), deploy);
  payment.escrowAllowlist = [];
  await f.ui.refresh(false);
  assert.match(render(), deploy);
  assert(render().includes('Escrow address not configured'));
  await f.click('deploy');
  assert.match(f.dialogs.at(-1).body, /data-ops-form="deploy"/);
  f.business().user.role = 'viewer';
  assert.doesNotMatch(render(), deploy);
  await f.click('deploy');
  assert.equal(f.dialogs.length, 1);
  f.business().user.role = 'owner';
  payment.tokenConfigured = false;
  await f.ui.refresh(false);
  assert.doesNotMatch(render(), deploy);
  delete payment.escrowAllowlist;
  await f.ui.refresh(false);
  assert(render().includes('Escrow configuration unavailable'));
  assert.doesNotMatch(render(), deploy);
});

test('an open deployment form rechecks current server configuration before accessing the wallet', async tc => {
  const f = fixture(tc);
  const payment = f.operations.config.payment;
  const address = payment.escrowAllowlist[0];
  Object.assign(payment, {configured: false, escrowAllowlist: []});
  await f.ui.refresh(false);
  await f.click('deploy');
  assert.equal(f.dialogs.length, 1);
  Object.assign(payment, {configured: true, escrowAllowlist: [address]});
  let walletCalls = 0;
  globalThis.ethereum.request = () => { walletCalls++; throw Error('unexpected wallet request'); };
  const form = new FormData();
  form.set('releaseDelay','3600');
  form.dataset = {opsForm:'deploy'};
  form.querySelector = () => null;
  tc.mock.method(globalThis, 'FormData', function() { return form; });
  await f.listeners.get('submit')({target:{closest:()=>form},preventDefault() {}});
  assert.equal(walletCalls, 0);
  assert.equal(f.dialogs.length, 1);
  assert.equal(f.calls.filter(call=>call.url==='/api/operations').length, 2);
  assert.doesNotMatch(f.ui.renderPayments(), /data-ops="deploy"/);
});

test('TFT workcell gives the current blocking reason and resumes with only missing vectors', async tc => {
 const f = fixture(tc), d = f.device;
 setLanguage('zh-CN'); clearMissingTranslations();
 f.business().orders[0].status = 'running';
 f.business().orders[0].batches = [];
 f.operations.jobs.splice(6);
 const now = Date.now();
 d.revision = 0;
 d.localState = {connected:true, revision:0, panelReady:false, panelCapabilities:{ready:true, hardwareRevision:8, bootId:'board-a'}, outputsEnabled:false, writesLeft:0, armedUntil:0};
 const check = async (text, runEnabled, importEnabled=false) => {
  await f.ui.refresh(false);
  const markup = f.ui.renderDevices();
  assert(markup.includes(text),text);
  for (const [action,enabled] of [['panel-run',runEnabled],['panel-import',importEnabled]]) {
   const button = markup.match(new RegExp('<button[^>]*data-ops="'+action+'"[^>]*>'))[0];
   assert.equal(!button.includes(' disabled'),enabled,action);
  }
 };
 await check('板上修订为 8，按网关记录应为 0',false);
 const beforeReads=f.calls.length;
 await Promise.all([f.ui.refresh(false),f.click('panel-run',d.id)]);
 assert.equal(f.calls.length,beforeReads+2,'the manual run must await an in-flight status read');
 assert.match(f.toasts.at(-1)[0],/板上修订/);
 assert(f.calls.every(call=>!call.options));
 d.localState.panelBinding = {hardwareBaseRevision:8,bootId:'prior-boot'};
 await check('绑定记录与本次启动不符',false);
 d.localState.panelBinding.bootId = 'board-a';
 d.localState.panelReady = true;
 await check('网关处于只读模式',false);
 d.localState.outputsEnabled=true; d.armedUntil=now-1;
 await check('点击下方「短期放行」',false);
 d.armedUntil=now+60000; d.localState.armedUntil=now+60000; d.localState.writesLeft=1;
 await check('至少允许剩余 2 次显示写入',false);
 d.localState.writesLeft=2;
 await check('已就绪，可以运行剩余向量',true);
 d.lastSeen=now-31000;
 await check('等待本地网关连接测试板并上报心跳',false);
 d.lastSeen=now; d.localState.revision=1;
 await check('等待网关上报最新设备修订',false);
 d.localState.revision=0; d.localState.panelCapabilities.ready=false;
 await check('等待测试板通过 GRAM 黑白参考读回',false);
 // An older gateway has no binding or outputsEnabled flag. Its legacy equal revisions remain valid.
 delete d.localState.panelBinding; delete d.localState.outputsEnabled;
 d.localState.panelCapabilities={hardwareRevision:0,bootId:'board-a'};
 await check('已就绪，可以运行剩余向量',true);
 for(const value of [6,7]) f.operations.jobs.push({...f.operations.jobs[0],id:'extra-'+value,payload:{signal:'panel_vector',value}});
 d.armedUntil=0;
 await check('8 组读回已齐全，可以提交验收',false,true);
 setLanguage('en');
 await check('All 8 readbacks are ready to submit for review.',false,true);
 assert.deepEqual(getMissingTranslations(),[]);
});

test('resuming vectors waits for the next heartbeat after each acknowledgement', async tc => {
 const values = [], now = Date.now();
 let pendingHeartbeat;
 const f = fixture(tc, {
  beforeRead(ops) {
   if (!pendingHeartbeat) return;
   if (pendingHeartbeat.wait-- > 0) return;
   Object.assign(ops.devices[0].localState, {revision:pendingHeartbeat.revision, writesLeft:pendingHeartbeat.writes});
   ops.devices[0].localState.panelCapabilities.hardwareRevision = pendingHeartbeat.revision + 8;
   pendingHeartbeat = null;
  },
  onCommand(body,ops) {
   const d = ops.devices[0], {signal,value,expectedDeviceRevision} = body.payload;
   assert.equal(body.type,'job.submit'); assert.equal(signal,'panel_vector');
   assert.equal(expectedDeviceRevision,d.revision); assert.equal(d.localState.revision,d.revision);
   values.push(value); d.revision++; ops.revision++;
   const jobId = 'resumed-'+value;
   ops.jobs.push({id:jobId,deviceId:d.id,state:'succeeded',payload:{signal,value},result:{revision:d.revision}});
   pendingHeartbeat = {wait:1,revision:d.revision,writes:8-values.length-6};
   return {...structuredClone(ops), jobId};
  }
 });
 const d = f.device;
 f.business().orders[0].status = 'running'; f.business().orders[0].batches = [];
 f.operations.jobs.splice(6);
 d.revision=6;
 d.localState={connected:true,revision:6,armedUntil:now+60000,writesLeft:2,panelReady:true,ready:true,outputsEnabled:true,
  panelBinding:{bootId:'board-a',hardwareBaseRevision:8},panelCapabilities:{bootId:'board-a',hardwareRevision:14,ready:true}};
 await f.ui.refresh(false);
 await f.click('panel-run',d.id);
 assert.deepEqual(values,[6,7]);
 assert.match(f.toasts.at(-1)[0],/8 组实际读回已收集/);
});

test('English diagnostics retain explicit uncertainty, current sampling metadata and escaped untrusted replies', () => {
  try {
    setLanguage('en'); const markup = displayDiagnosticsMarkup({ enabled: true, controller: '<script>', width: 320, height: 240, rawControllerId: '0x41009341', controllerIdAvailable: true, initStatus: 'driver-begin-returned', sampleScope: 'current-display-query', readRegisterHz: 1000000, registerSampledAtTickMs: 12345, receivedAt: '<unsafe>' }, h);
    assert.match(markup, /Physical image unverified/); assert.match(markup, /this DISPLAY query · 1 MHz · device tick 12345 ms/); assert.match(markup, /does not verify screen visibility/); assert.match(markup, /Record photographs or human confirmation separately/);
    assert(markup.includes('0x41009341')); assert(!markup.includes('<script>')); assert(!chinese(markup));
    assert.match(displayDiagnosticsMarkup({ enabled: false }, h), /no TFT driver enabled/);
  } finally { setLanguage('zh-CN'); }
});

test('registration, local configuration, firmware, independent review and five-recipient dialogs use English without commands', async tc => {
  const f = fixture(tc); setLanguage('en'); await f.ui.refresh(false); const reads = f.calls.length; clearMissingTranslations();
  await f.click('register', 's3-panel'); assert.match(f.dialogs.at(-1).title, /Register TFT display test workcell/); assert.match(f.dialogs.at(-1).body, /Allowed signals and ranges/); assert(f.dialogs.at(-1).body.includes('panel_vector'));
  await f.click('device-config', f.device.id); assert.match(f.dialogs.at(-1).body, /Actual COM \/ dev path/); assert.match(f.dialogs.at(-1).body, /Enter actual connection settings/); // Explicit local settings, never server-initiated IO.
  await f.click('firmware-guide', f.device.id); const wiring = f.dialogs.at(-1).body; assert.match(wiring, /Panel|panel/); assert.match(wiring, /Do not add a GPIO6 jumper/); assert.match(wiring, /All GPIO signals are 3.3V/); assert(wiring.includes('/firmware/esp32-s3-panel/firmware.bin')); assert(!chinese(wiring));
  await f.click('panel-review', 'TC-PANEL-I18N'); const review = f.dialogs.at(-1).body; assert.match(review, /Expected Y/); assert.match(review, /independently reviewed/); assert(review.includes('用户原始来源，不翻译')); assert(review.includes('measurement-7'));
  await f.click('payment-new'); const plan = f.dialogs.at(-1).body; assert.match(plan, /Supplier A fulfillment/); assert.match(plan, /Design and maintenance/); assert.match(plan, /all five addresses must differ/); assert.match(plan, /up to 8 decimal places/); assert(!chinese(plan));
  assert.equal(f.calls.length, reads); assert.deepEqual(getMissingTranslations(), []);
});

test('language switching is blocked during wallet preflight without approving, submitting or changing financial scope', async tc => {
  const f = fixture(tc); setLanguage('zh-CN'); await f.ui.refresh(false); const requests = []; let resolveAccounts;
  globalThis.ethereum = { request(request) { requests.push(request.method); if (request.method === 'eth_requestAccounts') return new Promise(resolve => { resolveAccounts = resolve; }); if (request.method === 'eth_chainId') return Promise.resolve('0xc4'); throw Error('Signing is forbidden'); } };
  const pending = f.click('wallet'); assert.equal(f.ui.isBusy(), true); assert.equal(setLanguage('en'), false); assert.equal(getLanguage(), 'zh-CN'); assert.match(f.toasts.at(-1)[0], /完成当前设备或钱包操作/);
  resolveAccounts(['0x' + '1'.repeat(40)]); await pending; assert.equal(f.ui.isBusy(), false); assert.equal(setLanguage('en'), true);
  assert.deepEqual(requests, ['eth_requestAccounts', 'eth_chainId']); assert(f.calls.every(call => !call.options)); assert.equal(f.ui.getState().revision, 5);
});
