import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import test from 'node:test';
import { Store } from '../lib/store.mjs';
import { listFactoryTemplates } from '../lib/factory-templates.mjs';

test('a factory can withdraw a public rule and another factory keeps its editable copy', t => {
  const store = new Store(':memory:');
  t.after(() => store.close());
  store.setup({ email: 'owner@example.test', password: 'local-test-password', setupToken: 'test' }, 'test');
  function factory(email) {
    return store.session(store.signup({ email, password: 'local-test-password' }).secret);
  }
  function command(actor, type, payload) {
    return store.command(actor, {
      type, payload, requestId: randomUUID(), expectedRevision: store.state(actor).revision
    });
  }
  const publisher = factory('publisher@example.test');
  const consumer = factory('consumer@example.test');
  const list = () => listFactoryTemplates(store.db, consumer, new URLSearchParams({ q: 'Optics' })).templates;
  const spec = command(publisher, 'spec.create', { name: 'Optical gate', expression: 'C && E' }).specs.at(-1);
  assert.deepEqual(list(), []);
  command(publisher, 'template.publish', { specId: spec.id, specVersion: spec.version, publisher: 'Optics' });
  const [publication] = list();
  assert.equal(publication.expression, spec.expression);
  assert.equal(publication.owned, false);
  assert.equal(publication.sourceSpecId, undefined);
  assert.throws(() => command(consumer, 'template.withdraw', { templateId: publication.id }));
  const use = () => command(consumer, 'template.import', { templateId: publication.id });
  const ownCopy = use().specs.find(row => row.templateSource?.id === publication.id);
  assert.notEqual(ownCopy.id, spec.id);
  assert.equal(use().specs.filter(row => row.templateSource?.id === publication.id).length, 1);
  command(publisher, 'template.withdraw', { templateId: publication.id });
  assert.deepEqual(list(), []);
  assert.throws(use);
  command(consumer, 'spec.update', { specId: ownCopy.id, expression: 'M && E' });
  assert.equal(store.state(consumer).specs.find(row => row.id === ownCopy.id).expression, 'M && E');
  assert.equal(store.state(publisher).specs.find(row => row.id === spec.id).expression, 'C && E');
});
