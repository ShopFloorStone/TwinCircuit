import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { Store } from '../lib/store.mjs';
import { Operations, acceptedSnapshot } from '../lib/operations.mjs';
import { ESCROW_BUILD, ESCROW_ABI, ESCROW_EVENT_TOPICS, encodeEscrowCall, dealIdFor } from '../public/payments.mjs';
import { selector } from '../public/keccak.mjs';

function fixture(t, options = {}) {
  const store = new Store(options.dbPath ?? ':memory:'); t.after(() => store.close());
  const session = store.setup({ name: 'Owner A', email: 'owner-a@example.com', password: 'a secure operations password', setupToken: 'setup' }, 'setup');
  const owner = store.session(session.secret);
  const invite = store.command(owner, { type: 'member.invite', payload: { email: 'owner-b@example.com', role: 'owner' }, expectedRevision: store.state(owner).revision });
  const secondSession = store.register({ token: invite.invitation.token, name: 'Owner B', email: 'owner-b@example.com', password: 'another secure operations password' });
  const second = store.session(secondSession.secret);
  let clock = 1_800_000_000_000;
  const ops = new Operations(store, { ...options, now: () => clock });
  const command = (type, payload, actor = owner, overrides = {}) => ops.command(actor, { type, payload, requestId: randomUUID(), expectedRevision: ops.bootstrap(actor).revision, ...overrides });
  return { store, ops, owner, second, command, now: () => clock, advance: ms => { clock += ms; } };
}
const registration = { name: 'S3 bench LED', protocol: 'esp32-serial', endpoint: 'local gateway / user-selected COM port', signals: [{ name: 'led', type: 'boolean', critical: true }, { name: 'cme_vector', type: 'number', min: 0, max: 7, critical: true }] };
const edgeState = (f, revision = 0) => ({ revision, armedUntil: f.now() + 60000, blocked: false, connected: true, physicalArmed: true, physicalPermit: true });

test('device secrets are one-time, critical jobs require another owner, gateway ACK is idempotent and no fake fulfillment is generated', async t => {
  const f = fixture(t), registered = await f.command('device.register', registration);
  const { deviceId, deviceToken } = registered; assert.match(deviceToken, /^tc_device_/);
  assert.ok(!JSON.stringify(f.ops.bootstrap(f.owner)).includes(deviceToken));
  assert.notEqual(f.store.db.prepare('SELECT token_hash FROM ops_devices WHERE id=?').get(deviceId).token_hash, deviceToken);
  await f.command('device.arm', { deviceId, seconds: 120, reason: 'Operator present at low-voltage test bench' });
  const submitted = await f.command('job.submit', { deviceId, signal: 'led', value: true, expectedDeviceRevision: 0 });
  const jobId = submitted.jobId;
  assert.equal(f.ops.pull(deviceToken, { deviceId, state: edgeState(f) }).job, null);
  await assert.rejects(f.command('job.approve', { jobId, reason: 'Self approval must fail' }), e => e.code === 'SELF_APPROVAL');
  await f.command('job.approve', { jobId, reason: 'Owner B physically reviewed the command' }, f.second);
  assert.equal(f.ops.pull(deviceToken, { deviceId, state: { ...edgeState(f), physicalArmed: false } }).job, null);
  const delivery = f.ops.pull(deviceToken, { deviceId, state: edgeState(f) }); assert.equal(delivery.job.state, 'claimed');
  assert.equal(f.ops.pull(deviceToken, { deviceId, state: edgeState(f) }).job.nonce, delivery.job.nonce);
  const ack = { deviceId, jobId, nonce: delivery.job.nonce, status: 'succeeded', result: { executed: true, revision: 1, signal: 'led', requestedValue: true, evidence: { quality: 'GPIO_READBACK', readback: true } } };
  assert.equal(f.ops.result(deviceToken, ack).job.state, 'succeeded');
  assert.equal(f.ops.result(deviceToken, ack).replayed, true);
  assert.throws(() => f.ops.result(deviceToken, { ...ack, result: { ...ack.result, requestedValue: false } }), e => e.code === 'RESULT_CONFLICT');
  assert.equal(f.store.state(f.owner).orders[0].batches.length, 0);
  await f.command('device.revoke', { deviceId, reason: 'End of supervised bench test' });
  assert.throws(() => f.ops.pull(deviceToken, { deviceId, state: edgeState(f, 1) }), e => e.code === 'DEVICE_AUTH_REQUIRED');
});

test('expired claims become uncertain, late ACK cannot restore success and queued expiry does not pretend execution', async t => {
  const f = fixture(t), { deviceId, deviceToken } = await f.command('device.register', registration);
  await f.command('device.arm', { deviceId, seconds: 120, reason: 'Supervised experiment' });
  let queued = await f.command('job.submit', { deviceId, signal: 'led', value: false, expectedDeviceRevision: 0, expiresInSeconds: 1 });
  f.advance(1001); assert.equal(f.ops.bootstrap(f.owner).jobs.find(j => j.id === queued.jobId).state, 'expired');
  queued = await f.command('job.submit', { deviceId, signal: 'led', value: true, expectedDeviceRevision: 0, expiresInSeconds: 1 });
  await f.command('job.approve', { jobId: queued.jobId, reason: 'Reviewed separately' }, f.second);
  const delivery = f.ops.pull(deviceToken, { deviceId, state: edgeState(f) }); f.advance(1001);
  assert.equal(f.ops.bootstrap(f.owner).devices[0].status, 'uncertain');
  const ack = f.ops.result(deviceToken, { deviceId, jobId: delivery.job.id, nonce: delivery.job.nonce, status: 'succeeded', result: { executed: true, revision: 1 } });
  assert.equal(ack.job.state, 'uncertain');
  await assert.rejects(f.command('device.arm', { deviceId, seconds: 60, reason: 'Must remain blocked' }), /uncertain/);
  await f.command('device.clearUncertain', { deviceId, reason: 'Owner inspected device and reset local gateway journal' });
  assert.equal(f.ops.bootstrap(f.owner).devices[0].armedUntil, 0);
});

test('guest workspaces, viewer actions and cross-device tokens cannot operate live devices', async t => {
  const f = fixture(t), guest = f.store.session(f.store.demo().secret);
  assert.throws(() => f.ops.bootstrap(guest), e => e.code === 'LIVE_DEMO_FORBIDDEN');
  const invite = f.store.command(f.owner, { type: 'member.invite', payload: { email: 'viewer@example.com', role: 'viewer' }, expectedRevision: f.store.state(f.owner).revision });
  const viewer = f.store.session(f.store.register({ token: invite.invitation.token, name: 'Viewer', email: 'viewer@example.com', password: 'a secure viewer role password' }).secret);
  await assert.rejects(f.command('device.register', registration, viewer), e => e.code === 'FORBIDDEN');
  const a = await f.command('device.register', registration), b = await f.command('device.register', { ...registration, name: 'Other bench' });
  assert.throws(() => f.ops.pull(a.deviceToken, { deviceId: b.deviceId, state: edgeState(f) }), e => e.status === 401);
  const revision = f.ops.bootstrap(f.owner).revision;
  await assert.rejects(f.command('device.arm', { deviceId: a.deviceId, seconds: 60, reason: 'Stale UI' }, f.owner, { expectedRevision: revision - 1 }), e => e.code === 'REVISION_CONFLICT');
});

test('SQLite persistence retains token hashes and jobs across a process store restart', async t => {
  const dir = await mkdtemp(join(tmpdir(), 'tc-operations-'));
  const dbPath = join(dir, 'data.sqlite'), first = new Store(dbPath);
  const s = first.setup({ setupToken: 'setup', name: 'Owner', email: 'owner@example.com', password: 'a secure persistence password' }, 'setup'), actor = first.session(s.secret), ops = new Operations(first);
  const result = await ops.command(actor, { type: 'device.register', payload: registration, requestId: 'persistent-device', expectedRevision: 0 });
  await ops.command(actor, { type: 'device.arm', payload: { deviceId: result.deviceId, seconds: 120, reason: 'Persistence test, no hardware connection' }, requestId: 'persistent-arm', expectedRevision: 1 });
  const queued = await ops.command(actor, { type: 'job.submit', payload: { deviceId: result.deviceId, signal: 'led', value: true, expectedDeviceRevision: 0 }, requestId: 'persistent-job', expectedRevision: 2 }); first.close();
  const second = new Store(dbPath); t.after(async () => { second.close(); await rm(dir, { recursive: true, force: true }); }); const reopened = new Operations(second), sameActor = second.session(s.secret);
  assert.equal(reopened.bootstrap(sameActor).devices[0].id, result.deviceId);
  assert.equal(reopened.bootstrap(sameActor).jobs[0].id, queued.jobId);
  assert.equal(reopened.bootstrap(sameActor).jobs[0].state, 'queued');
  assert.equal(reopened.gateway(result.deviceToken, result.deviceId).id, result.deviceId);
  const replay = await reopened.command(sameActor, { type: 'device.register', payload: registration, requestId: 'persistent-device', expectedRevision: 0 }); assert.equal(replay.deviceToken, undefined); assert.equal(replay.replayed, true);
});

test('eight one-use hardware measurements produce external evidence atomically and cannot be copied into another unit', async t => {
  const f = fixture(t), { deviceId, deviceToken } = await f.command('device.register', registration);
  let s = f.store.state(f.owner), o = s.orders[0]; o.quantity = 2; o.status = 'running'; s.suppliers.push({ id: 'hardware', name: 'Actual S3 bench', mode: 'external', capacity: 2, capabilities: ['TC-IO/0.1'], status: 'available' });
  o.reservations = [{ id: 'external-reservation', supplierId: 'hardware', quantity: 2, cancelledQuantity: 0, completedQuantity: 0, status: 'confirmed', providerConfirmed: true, history: [] }]; f.store.save(f.owner.workspaceId, s);
  const jobIds = [];
  for (let vector = 0; vector < 8; vector++) {
    await f.command('device.arm', { deviceId, seconds: 60, reason: 'Physical arm pressed for this vector' });
    const j = await f.command('job.submit', { deviceId, signal: 'cme_vector', value: vector, expectedDeviceRevision: vector }); await f.command('job.approve', { jobId: j.jobId, reason: 'Second owner approved this GPIO test' }, f.second);
    const delivery = f.ops.pull(deviceToken, { deviceId, state: edgeState(f, vector) }).job, inputs = { C: Boolean(vector & 4), M: Boolean(vector & 2), E: Boolean(vector & 1) }, actualY = inputs.E && (inputs.C || inputs.M);
    f.ops.result(deviceToken, { deviceId, jobId: delivery.id, nonce: delivery.nonce, status: 'succeeded', result: { executed: true, revision: vector + 1, evidence: { vectorIndex: vector, inputs, actualY, readback: actualY, quality: 'GPIO_READBACK', protocol: 'serial', source: 'esp32-s3-test-fixture' } } }); jobIds.push(delivery.id);
  }
  const payload = { deviceId, orderId: 'TC-024', reservationId: 'external-reservation', unit: 0, jobIds, expectedBusinessRevision: f.store.state(f.owner).revision };
  await assert.rejects(f.command('evidence.fromJobs', { ...payload, expectedBusinessRevision: payload.expectedBusinessRevision + 1 }), e => e.code === 'REVISION_CONFLICT');
  assert.equal(f.store.db.prepare('SELECT count(*) AS n FROM ops_job_evidence').get().n, 0);
  const imported = await f.command('evidence.fromJobs', payload); assert.equal(imported.business.orders[0].batches[0].evidenceStatus, 'external/unverified'); assert.equal(imported.business.orders[0].batches[0].records[0].tests.length, 8);
  assert.ok(imported.jobs.filter(j => jobIds.includes(j.id)).every(j => j.evidenceUsed === true));
  await assert.rejects(f.command('evidence.fromJobs', { ...payload, unit: 1, expectedBusinessRevision: imported.business.revision }), e => e.code === 'MEASUREMENT_REUSE');
  assert.equal(f.store.state(f.owner).orders[0].completedQuantity, 1);
});

function acceptedExternal(f) { const state = f.store.state(f.owner), o = state.orders[0]; o.quantity = 1; o.status = 'accepted'; o.acceptedQuantity = 1; o.completedQuantity = 1; o.batches = [{ id: 'external-batch', supplierId: 'external', mode: 'external', status: 'accepted', submittedBy: f.owner.id, submittedAt: '2026-11-12T00:00:00Z', review: { by: f.second.id, scope: 'Submitted GPIO digital evidence only' }, records: [{ unit: 0, source: 'test-fixture://external-gpio', tests: o.specSnapshot.vectors.map(v => ({ ...structuredClone(v), actual: structuredClone(v.expected) })) }] }]; f.store.save(f.owner.workspaceId, state); }
const A = n => `0x${String(n).padStart(40, '0')}`;
const W = v => BigInt(v).toString(16).padStart(64, '0'), AW = a => a.slice(2).padStart(64, '0');
const stringABI = s => `0x${W(32)}${W(Buffer.byteLength(s))}${Buffer.from(s).toString('hex').padEnd(64, '0')}`;
function eventLog(name, args, escrow) { const abi = ESCROW_ABI.find(e => e.type === 'event' && e.name === name), topics = [ESCROW_EVENT_TOPICS[name]], data = []; for (const field of abi.inputs) { const value = args[field.name]; const encode = (type, v) => type === 'address' ? AW(v) : type === 'bytes32' ? v.slice(2) : W(v); const encoded = field.type.endsWith('[5]') ? value.map(v => encode(field.type.slice(0, -3), v)).join('') : encode(field.type, value); if (field.indexed) topics.push(`0x${encoded}`); else data.push(encoded); } return { address: escrow, topics, data: `0x${data.join('')}` }; }

test('payment plans require external accepted evidence and verify real-format receipt, sender, contract runtime, terms and chain state', async t => {
  let plan, dealState = 1, wrongSender = false, proofAction = 'fund', otherBuyer = false, proofSender = null, txHash = `0x${'ab'.repeat(32)}`;
  const token = A(100), escrow = A(200), buyer = A(300), verifier = A(400), blockHash = `0x${'cd'.repeat(32)}`;
  const env = { PAYMENT_CHAIN_ID: '196', PAYMENT_TOKEN_ADDRESS: token, PAYMENT_TOKEN_DECIMALS: '8', PAYMENT_ESCROW_ALLOWLIST: escrow, PAYMENT_CONFIRMATIONS: '3', XLAYER_RPC_URL: 'https://configured-rpc.example' };
  const fetchImpl = async (url, options) => {
    const q = JSON.parse(options.body); let result;
    const actualBuyer = otherBuyer ? A(999) : buyer, eventDealId = plan ? dealIdFor(actualBuyer, plan.orderKey) : null;
    const sender = proofSender ?? (proofAction === 'fund' ? wrongSender ? A(999) : buyer : verifier);
    if (q.method === 'eth_chainId') result = '0xc4';
    else if (q.method === 'eth_getCode') result = q.params[0] === escrow ? ESCROW_BUILD.deployedBytecode : '0x6001';
    else if (q.method === 'eth_blockNumber') result = '0x100';
    else if (q.method === 'eth_getBlockByNumber') result = { hash: blockHash };
    else if (q.method === 'eth_getTransactionByHash') {
      const args = proofAction === 'fund' ? [plan.orderKey, plan.termsHash, plan.evidenceHash, verifier, plan.recipients.map(r => r.address), plan.recipients.map(r => r.amount), plan.amount, plan.refundAfter] : proofAction === 'accept' ? [eventDealId, plan.termsHash, plan.evidenceHash] : proofAction === 'consentRefund' ? [eventDealId, plan.termsHash] : [eventDealId];
      result = { hash: txHash, from: sender, to: escrow, blockHash, chainId: '0xc4', input: encodeEscrowCall(proofAction, args) };
    } else if (q.method === 'eth_getTransactionReceipt') {
      const name = { fund: 'DealFunded', accept: 'DealAccepted', consentRefund: 'RefundConsent', revokeRefundConsent: 'RefundConsentRevoked', timeoutRefund: 'DealRefunded' }[proofAction];
      const args = { dealId: eventDealId, orderKey: plan.orderKey, buyer: actualBuyer, by: sender, approvals: dealState === 5 ? 3 : 1, token, termsHash: plan.termsHash, evidenceHash: plan.evidenceHash, verifier, amount: plan.amount, refundAfter: plan.refundAfter, releaseAfter: Math.floor(f.now() / 1000) + 60, recipients: plan.recipients.map(r => r.address), amounts: plan.recipients.map(r => r.amount), timedOut: 1 };
      result = { transactionHash: txHash, from: sender, to: escrow, blockHash, blockNumber: '0xfe', status: '0x1', logs: [eventLog(name, args, escrow)] };
    }
    else if (q.method === 'eth_call') { const sig = q.params[0].data.slice(0, 10); if (sig === '0x313ce567') result = `0x${W(8)}`; else if (sig === '0x95d89b41') result = stringABI('BEM'); else if (sig === selector('token()')) result = `0x${AW(token)}`; else if (sig === selector('deploymentChainId()')) result = `0x${W(196)}`; else if (sig === selector('releaseDelay()')) result = `0x${W(60)}`; else if (sig === selector('getDeal(bytes32)')) result = '0x' + [AW(actualBuyer), AW(verifier), plan.orderKey.slice(2), plan.termsHash.slice(2), plan.evidenceHash.slice(2), W(plan.amount), W(plan.refundAfter), W(0), W(dealState), W(0), ...plan.recipients.map(r => AW(r.address)), ...plan.recipients.map(r => W(r.amount))].join(''); else throw Error(`Unknown call ${sig}`); }
    else throw Error(`Unexpected RPC ${q.method}`);
    return { ok: true, text: async () => JSON.stringify({ jsonrpc: '2.0', id: 1, result }) };
  };
  const f = fixture(t, { env, fetchImpl }), p = { orderId: 'TC-024', escrowAddress: escrow, amount: '100000000', claimedBuyer: buyer, verifierAddress: verifier, refundAfter: Math.floor(f.now() / 1000) + 7200, recipients: [1, 2, 3, 4, 5].map(n => ({ address: A(n), amount: '20000000' })) };
  await assert.rejects(f.command('payment.plan', p), e => e.code === 'EVIDENCE_REQUIRED');
  acceptedExternal(f); plan = (await f.command('payment.plan', p)).paymentPlan; assert.equal(plan.tokenDecimals, 8); assert.equal(plan.amount, p.amount); assert.equal(plan.noUsdConversion, true);
  wrongSender = true; await assert.rejects(f.command('payment.verify', { planId: plan.id, transactionHash: txHash, action: 'fund' }), e => e.code === 'BUYER_MISMATCH'); wrongSender = false;
  const verified = await f.command('payment.verify', { planId: plan.id, transactionHash: txHash, action: 'fund' }); assert.equal(verified.paymentPlans[0].status, 'funded'); assert.equal(verified.paymentPlans[0].verifiedBuyer, buyer); assert.equal(f.store.state(f.owner).ledger.length, 0);
  proofAction = 'accept'; otherBuyer = true; dealState = 2;
  await assert.rejects(f.command('payment.verify', { planId: plan.id, transactionHash: txHash, action: 'accept' }), e => e.code === 'BUYER_MISMATCH');
  otherBuyer = false;
  for (const [i, action, state] of [[1, 'consentRefund', 3], [2, 'revokeRefundConsent', 3], [3, 'consentRefund', 5]]) {
    txHash = `0x${W(i)}`; proofAction = action; dealState = state;
    const proof = await f.command('payment.verify', { planId: plan.id, transactionHash: txHash, action }); assert.equal(proof.paymentProof.fundsState, state === 5 ? 'refunded' : 'disputed');
  }
  txHash = `0x${W(4)}`; proofAction = 'timeoutRefund'; dealState = 5; proofSender = verifier;
  await assert.rejects(f.command('payment.verify', { planId: plan.id, transactionHash: txHash, action: 'timeoutRefund' }), e => e.code === 'BUYER_MISMATCH');
  proofSender = buyer;
  const timedOut = await f.command('payment.verify', { planId: plan.id, transactionHash: txHash, action: 'timeoutRefund' }); assert.equal(timedOut.paymentProof.fundsState, 'refunded');
  const fakeState = f.store.state(f.owner); fakeState.orders[0].batches[0].mode = 'virtual'; assert.throws(() => acceptedSnapshot(fakeState, 'TC-024'), e => e.code === 'EXTERNAL_EVIDENCE_REQUIRED');
});
