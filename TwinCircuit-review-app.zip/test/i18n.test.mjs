import test from 'node:test';
import assert from 'node:assert/strict';
import { t, getLanguage, getLocale, setLanguage, errorMessage, languageSwitcher, clearMissingTranslations, getMissingTranslations, LANGUAGE_KEY } from '../public/i18n.mjs';

test('language selection defaults to Chinese, switches without changing parameter bytes and refuses unsupported values', () => {
  setLanguage('zh-CN');
  assert.equal(getLanguage(),'zh-CN'); assert.equal(getLocale(),'zh-CN');
  assert.equal(t('正在连接工作区…'),'正在连接工作区…');
  assert.equal(setLanguage('en'),true); assert.equal(getLocale(),'en-US');
  assert.equal(t('正在连接工作区…'),'Connecting to your workspace…');
  const literal={address:'0x20095383dd4d40f9b135aa46790af9c8213cb2c0',amount:'0.00000001',name:'用户设备 <A>'};
  assert.equal(t('{address} · {amount} · {name}',literal),`${literal.address} · ${literal.amount} · ${literal.name}`);
  assert.equal(setLanguage('fr'),false);assert.equal(getLanguage(),'en');
  assert.match(languageSwitcher(),/data-language="en"[^>]*aria-pressed="true"/);
  setLanguage('zh-CN');
});

test('storage failures remain usable and a canceled language switch writes no preference or event', () => {
  setLanguage('zh-CN');
  const saved={window:globalThis.window,localStorage:globalThis.localStorage};
  const target=new EventTarget(),writes=[];let changed=0;
  globalThis.window=target;globalThis.localStorage={getItem(){throw Error('blocked');},setItem(...args){writes.push(args);throw Error('blocked');}};
  const cancel=event=>event.preventDefault();target.addEventListener('twincircuit:beforelanguagechange',cancel);target.addEventListener('twincircuit:languagechange',()=>changed++);
  try {
    assert.equal(setLanguage('en'),false);assert.equal(getLanguage(),'zh-CN');assert.deepEqual(writes,[]);assert.equal(changed,0);
    target.removeEventListener('twincircuit:beforelanguagechange',cancel);
    assert.equal(setLanguage('en'),true);assert.equal(getLanguage(),'en');assert.deepEqual(writes,[[LANGUAGE_KEY,'en']]);assert.equal(changed,1);
  } finally {if(saved.window===undefined)delete globalThis.window;else globalThis.window=saved.window;if(saved.localStorage===undefined)delete globalThis.localStorage;else globalThis.localStorage=saved.localStorage;setLanguage('zh-CN');}
});

test('known API errors are translated only for presentation and dynamic fields are preserved', () => {
  const error=Object.assign(new Error('Email or password is incorrect'),{code:'AUTH_FAILED'});
  setLanguage('zh-CN');assert.equal(errorMessage(error),'邮箱或密码不正确');
  assert.equal(error.message,'Email or password is incorrect');assert.equal(error.code,'AUTH_FAILED');
  assert.equal(errorMessage('Expected text of at most 100 characters'),'文字长度不能超过 100 个字符');
  assert.equal(errorMessage('quantity must be an integer between 1 and 1000'),'quantity 必须是 1 到 1000 之间的整数');
  setLanguage('en');assert.equal(errorMessage(error),'Email or password is incorrect');
  assert.equal(errorMessage('文字长度不能超过 100 个字符'),'Expected text of at most 100 characters');
  clearMissingTranslations();assert.equal(t('未收录测试文案'),'未收录测试文案');assert.deepEqual(getMissingTranslations(),['未收录测试文案']);
  setLanguage('zh-CN');
});
