import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createApp } from '../server.mjs';

async function fixture(t, dbPath = ':memory:', options = {}) {
  const app = createApp({ dbPath, setupToken: 'test-setup-secret', log() {}, ...options });
  await new Promise(resolve => app.server.listen(0, '127.0.0.1', resolve));
  const origin = `http://127.0.0.1:${app.server.address().port}`; t.after(() => app.close());
  function client() {
    let cookie = '', csrf = ''; let state;
    return {
      get state() { return state; }, get cookie() { return cookie; }, get csrf() { return csrf; },
      async request(path, { method = 'GET', body, headers = {} } = {}) {
        const res = await fetch(origin + path, { method, headers: { ...(cookie ? { cookie } : {}), ...(method === 'POST' ? { Origin: options.appOrigin ?? origin, 'Content-Type': 'application/json', 'x-csrf-token': csrf } : {}), ...headers }, body: body === undefined ? undefined : JSON.stringify(body) });
        if (res.headers.get('set-cookie')) cookie = res.headers.get('set-cookie').split(';')[0];
        const content = res.headers.get('content-type')?.includes('json') ? await res.json() : await res.text();
        if (res.ok && content.csrfToken) csrf = content.csrfToken;
        if (res.ok && content.workspace) state = content;
        return { status: res.status, body: content, headers: res.headers };
      },
      async command(type, payload = {}, overrides = {}) { return this.request('/api/command', { method: 'POST', body: { type, payload, expectedRevision: state.revision, ...overrides } }); },
      async setup() { return this.request('/api/auth/setup', { method: 'POST', body: { setupToken: 'test-setup-secret', name: 'Owner', email: 'owner@example.com', password: 'a secure test password' } }); },
      async demo() { return this.request('/api/auth/demo', { method: 'POST', body: {} }); }
    };
  }
  return { app, client, origin };
}

test('HTTP authentication, secure cookie, CSRF, authorization and isolated guest workspaces', async t => {
  const { client } = await fixture(t), owner = client(), guest = client(), another = client();
  assert.equal((await owner.request('/api/bootstrap')).status, 401);
  assert.equal((await owner.request('/api/auth/setup', { method: 'POST', body: { setupToken: 'wrong', email: 'owner@example.com', password: 'a secure password' } })).status, 403);
  const setup = await owner.setup(); assert.equal(setup.status, 200); assert.match(setup.headers.get('set-cookie'), /HttpOnly/); assert.match(setup.headers.get('set-cookie'), /SameSite=Strict/);
  assert.equal(setup.body.user.role, 'owner'); assert.equal(setup.body.user.isDemo, false);
  assert.equal((await owner.request('/api/auth/setup', { method: 'POST', body: {} })).status, 409);
  assert.equal((await owner.request('/api/command', { method: 'POST', body: { type: 'order.start', payload: { orderId: 'TC-024' }, expectedRevision: 0 }, headers: { 'x-csrf-token': '' } })).status, 403);
  assert.equal((await owner.request('/api/command', { method: 'POST', body: {}, headers: { Origin: 'https://attacker.invalid' } })).status, 403);
  await guest.demo(); await another.demo(); assert.notEqual(guest.state.workspace.id, another.state.workspace.id);
  assert.equal((await guest.command('supplier.create', { name: 'Private to guest', capacity: 3, mode: 'virtual' })).status, 200);
  assert.equal((await another.request('/api/bootstrap')).body.suppliers.length, 2);
  assert.equal((await owner.command('workspace.select', { workspaceId: guest.state.workspace.id })).status, 404);
  assert.equal((await guest.command('workspace.reset', { confirmation: 'wrong' })).status, 400);
  assert.equal((await guest.command('workspace.reset', { confirmation: 'RESET DEMO' })).status, 200);
  assert.equal(guest.state.suppliers.length, 2);
  assert.equal((await owner.command('workspace.reset', { confirmation: 'RESET DEMO' })).status, 403);
  assert.equal((await owner.request('/api/auth/password', { method: 'POST', body: { currentPassword: 'a secure test password', newPassword: 'short' } })).status, 400);
  assert.equal((await owner.request('/api/auth/logout', { method: 'POST', body: {} })).status, 200);
  assert.equal((await owner.request('/api/bootstrap')).status, 401);
});

test('HTTP full transaction, optimistic conflicts, idempotency and audit exports', async t => {
  const { client } = await fixture(t), c = client(); await c.demo();
  const cmd = async (type, payload, overrides) => { const result = await c.command(type, payload, overrides); assert.equal(result.status, 200, JSON.stringify(result.body)); return result.body; };
  await cmd('reservation.create', { orderId: 'TC-024', supplierId: 'supplier_a', quantity: 60 }, { requestId: 'allocate-a' });
  assert.equal((await c.command('reservation.create', { orderId: 'TC-024', supplierId: 'supplier_a', quantity: 60 }, { expectedRevision: 0, requestId: 'allocate-a' })).status, 200);
  assert.equal(c.state.orders[0].reservations.length, 1);
  assert.equal((await c.command('reservation.create', { orderId: 'TC-024', supplierId: 'supplier_a', quantity: 1 }, { requestId: 'allocate-a' })).status, 409);
  assert.equal((await c.command('reservation.create', { orderId: 'TC-024', supplierId: 'supplier_b', quantity: 40 }, { expectedRevision: 0 })).body.error.code, 'REVISION_CONFLICT');
  await cmd('reservation.create', { orderId: 'TC-024', supplierId: 'supplier_b', quantity: 40 });
  for (const r of c.state.orders[0].reservations) await cmd('reservation.confirm', { orderId: 'TC-024', reservationId: r.id });
  await cmd('order.confirm', { orderId: 'TC-024' }); await cmd('order.start', { orderId: 'TC-024' });
  const a = c.state.orders[0].reservations[0].id, b = c.state.orders[0].reservations[1].id;
  await cmd('execution.advance', { orderId: 'TC-024', reservationId: a, count: 40 }); await cmd('order.fault', { orderId: 'TC-024', reservationId: a, cancelRemaining: true });
  await cmd('reservation.reassign', { orderId: 'TC-024', reservationId: a, supplierId: 'supplier_b', quantity: 20 }); const replacement = c.state.orders[0].reservations[2].id;
  await cmd('reservation.confirm', { orderId: 'TC-024', reservationId: replacement }); await cmd('order.start', { orderId: 'TC-024' });
  await cmd('execution.advance', { orderId: 'TC-024', reservationId: b, count: 40 }); await cmd('execution.advance', { orderId: 'TC-024', reservationId: replacement, count: 20 });
  assert.equal((await c.command('order.accept', { orderId: 'TC-024' })).status, 409);
  for (const batch of c.state.orders[0].batches) await cmd('batch.accept', { orderId: 'TC-024', batchId: batch.id, note: 'Explicit owner simulation review' });
  await cmd('order.accept', { orderId: 'TC-024' }); await cmd('order.settle', { orderId: 'TC-024' }, { requestId: 'settle' }); await cmd('order.settle', { orderId: 'TC-024' });
  assert.equal(c.state.ledger.length, 1); assert.deepEqual(c.state.orders[0].settlement.entries.map(e => e.amountCents), [2800, 4200, 1500, 1000, 500]);
  const exported = await c.request('/api/export?format=json'); assert.equal(exported.status, 200); assert.ok(exported.body.events.length > 15); assert.equal(exported.body.user, undefined);
  const csv = await c.request('/api/export?format=csv&orderId=TC-024'); assert.equal(csv.status, 200); assert.equal(csv.body.split('\r\n').length, 801);
  const report = await c.request('/api/export?format=report&orderId=TC-024'); assert.equal(report.body.order.status, 'settled');
  assert.equal((await c.command('workspace.import', { data: exported.body })).status, 400);
});

test('single-use invitations and team roles are enforced over HTTP', async t => {
  const { client } = await fixture(t), owner = client(), viewer = client(), verifier = client(); await owner.setup();
  const invite = await owner.command('member.invite', { email: 'viewer@example.com', role: 'viewer' }); assert.equal(invite.status, 200); const key = invite.body.invitation.token;
  const account = { email: 'viewer@example.com', name: 'Viewer', token: key };
  for (const password of ['', 'v'.repeat(257)]) {
    const invalid = await viewer.request('/api/auth/register', { method: 'POST', body: { ...account, password } });
    assert.equal(invalid.status, 400);
    assert.equal(invalid.body.error.message, 'Password must contain 1 to 256 characters');
  }
  const registered = await viewer.request('/api/auth/register', { method: 'POST', body: { ...account, password: 'v' } });
  assert.equal(registered.status, 200); assert.equal(registered.body.user.role, 'viewer'); assert.equal((await viewer.command('supplier.create', { name: 'Bad', capacity: 1 })).status, 403);
  const login = await client().request('/api/auth/login', { method: 'POST', body: { email: account.email, password: 'v' } });
  assert.equal(login.status, 200);
  assert.equal(login.body.user.id, registered.body.user.id);
  const replay = await verifier.request('/api/auth/register', { method: 'POST', body: { email: 'viewer@example.com', name: 'Other', token: key, password: 'yet another password' } }); assert.equal(replay.status, 403);
  await owner.request('/api/bootstrap'); assert.equal(owner.state.members.length, 2); assert.equal(owner.state.invites[0].usedAt > 0, true);
  const userExport = await viewer.request('/api/export?format=json'); assert.equal(userExport.status, 200); assert.equal(JSON.stringify(userExport.body).includes(key), false);
  const created = await owner.command('workspace.create', { name: 'Second workspace' }, { requestId: 'workspace-create-once' }); assert.equal(created.status, 200);
  const secondId = created.body.workspace.id;
  const repeated = await owner.command('workspace.create', { name: 'Second workspace' }, { requestId: 'workspace-create-once' }); assert.equal(repeated.status, 200); assert.equal(repeated.body.workspace.id, secondId); assert.equal(repeated.body.workspaces.length, 2);
  assert.equal((await viewer.command('workspace.select', { workspaceId: secondId })).status, 404);
});

test('SQLite persists accounts, revisions and reservations across app restarts', async t => {
  const dir = await mkdtemp(join(tmpdir(), 'twincircuit-api-')); const db = join(dir, 'test.sqlite');
  const first = await fixture(t, db), c = first.client(); await c.setup(); await c.command('reservation.create', { orderId: 'TC-024', supplierId: 'supplier_a', quantity: 10 }); const workspaceId = c.state.workspace.id; await first.app.close();
  const second = await fixture(t, db), login = second.client(); const result = await login.request('/api/auth/login', { method: 'POST', body: { email: 'owner@example.com', password: 'a secure test password' } });
  t.after(async () => { await second.app.close(); await rm(dir, { recursive: true, force: true }); });
  assert.equal(result.status, 200); assert.equal(result.body.workspace.id, workspaceId); assert.equal(result.body.revision, 1); assert.equal(result.body.orders[0].reservations[0].quantity, 10);
});

test('public signup preserves setup, gives a private workspace, and joins a team only by invitation', async t => {
  const { client } = await fixture(t);
  const admin = client(), member = client();
  const email = 'new-user@example.com', password = 'nine-char';
  const signup = (body, headers) => member.request('/api/auth/signup', { method: 'POST', body, headers });
  assert.equal((await signup({ email, password })).body.error.code, 'SETUP_REQUIRED');
  assert.equal((await admin.request('/api/session')).body.setupRequired, true);
  await admin.setup();
  const teamId = admin.state.workspace.id;
  const invitation = (await admin.command('member.invite', { email, role: 'viewer' })).body.invitation;
  await admin.command('supplier.create', { name: 'Private supplier', capacity: 3, mode: 'virtual' });
  const device = await admin.request('/api/operations/command', {
    method: 'POST', body: { type: 'device.register', expectedRevision: 0, requestId: 'signup-scope-fixture',
      payload: { name: 'Private fixture', protocol: 'esp32-serial', endpoint: 'Local bench', signals: [{ name: 'led', type: 'boolean', critical: true }] } },
  });
  assert.equal(device.status, 200);
  assert.equal((await signup({ email, password }, { Origin: 'https://other.example' })).body.error.code, 'ORIGIN_REJECTED');
  assert.equal((await signup({ email: 'invalid', password })).status, 400);
  for (const invalidPassword of ['', 'x'.repeat(257)]) {
    const invalid = await signup({ email, password: invalidPassword });
    assert.equal(invalid.status, 400);
    assert.equal(invalid.body.error.message, 'Password must contain 1 to 256 characters');
  }
  const result = await signup({ email: ' NEW-USER@example.com ', password });
  assert.equal(result.status, 200);
  assert.equal(result.body.user.email, email);
  assert.equal(result.body.user.name, 'new-user');
  assert.equal(result.body.user.role, 'owner');
  assert.equal(result.body.user.isDemo, false);
  assert.deepEqual(result.body.workspaces.map(w => w.id), [result.body.workspace.id]);
  assert.notEqual(result.body.workspace.id, teamId);
  assert.deepEqual(result.body.members.map(m => m.email), [email]);
  assert.ok(!result.body.suppliers.some(s => s.name === 'Private supplier'));
  assert.equal((await member.request('/api/operations')).body.devices.length, 0);
  assert.equal((await member.command('workspace.select', { workspaceId: teamId })).status, 404);
  const adminState = (await admin.request('/api/bootstrap')).body;
  assert.equal(adminState.members.length, 1);
  assert.equal(adminState.invites[0].usedAt, null);
  await member.request('/api/auth/logout', { method: 'POST', body: {} });
  const login = await member.request('/api/auth/login', { method: 'POST', body: { email, password } });
  assert.equal(login.status, 200);
  assert.equal(login.body.workspace.id, result.body.workspace.id);
  const changed = await member.request('/api/auth/password', { method: 'POST', body: { currentPassword: password, newPassword: 'valid replacement password' } });
  assert.equal(changed.status, 200);
  const joined = await member.command('member.join', { token: invitation.token });
  assert.equal(joined.body.workspace.id, teamId);
  assert.equal(joined.body.user.role, 'viewer');
});

test('public signup accepts both password length endpoints', async t => {
  const { client } = await fixture(t);
  await client().setup();
  for (const length of [1, 256]) {
    const body = { email: `length-${length}@example.com`, password: 'x'.repeat(length) };
    const signup = await client().request('/api/auth/signup', { method: 'POST', body });
    assert.equal(signup.status, 200);
    const login = await client().request('/api/auth/login', { method: 'POST', body });
    assert.equal(login.status, 200);
    assert.equal(login.body.workspace.id, signup.body.workspace.id);
  }
});

test('simultaneous public signups create one account, membership and workspace for a normalized email', async t => {
  const { app, client } = await fixture(t);
  await client().setup();
  const password = 'an independent private password';
  const attempts = await Promise.all(['first@example.com', 'First@EXAMPLE.com'].map(email =>
    client().request('/api/auth/signup', { method: 'POST', body: { email, password } })));
  assert.deepEqual(attempts.map(r => r.status).sort(), [200, 409]);
  const rejected = attempts.find(r => r.status === 409);
  assert.equal(rejected.body.error.code, 'EMAIL_REGISTERED');
  assert.equal(rejected.headers.get('set-cookie'), null);
  for (const table of ['users', 'workspaces', 'members']) {
    assert.equal(app.store.db.prepare(`SELECT count(*) AS total FROM ${table}`).get().total, 2);
  }
});

test('public signup throttles independently of login and separates clients behind the HTTPS loopback proxy', async t => {
  for (const appOrigin of [undefined, 'https://app.example']) {
    const { client } = await fixture(t, ':memory:', { appOrigin });
    const user = client();
    await user.setup();
    const signup = address => user.request('/api/auth/signup', { method: 'POST', body: {}, headers: { 'X-Forwarded-For': address } });
    for (let i = 0; i < 12; i++) assert.equal((await signup(`192.0.2.${i}, 198.51.100.40`)).status, 400);
    assert.equal((await signup('198.51.100.40')).body.error.code, 'RATE_LIMITED');
    assert.equal((await signup('198.51.100.41')).status, appOrigin ? 400 : 429);
    assert.equal((await user.request('/api/auth/login', { method: 'POST', body: { email: 'owner@example.com', password: 'a secure test password' } })).status, 200);
  }
});
