import test from 'node:test';
import assert from 'node:assert/strict';
import {validateReceipt,testSerialCircuit} from '../public/serial.mjs';
import {compileCME1,evaluate} from '../public/engine.mjs';
test('serial replies must match sequence, input echo and strict output bits',()=>{
 const expected={seq:42,inputs:[1,0,1],output:1};
 assert.equal(validateReceipt({seq:42,inputs:[1,0,1],output:1},expected),true);
 for(const bad of [{seq:43,inputs:[1,0,1],output:1},{seq:42,inputs:[0,0,1],output:1},{seq:42,inputs:[1,0,1],output:0},{seq:42,inputs:[1,0,1],output:'1'},{seq:42,inputs:[1,0],output:1},{seq:42,output:1}])assert.equal(validateReceipt(bad,expected),false);
});
test('a complete serial run validates eight firmware-shaped replies and returns a resolved hash',async()=>{
 const circuit=compileCME1();
 for(const corrupt of [false,true]){
  let receiver,closed=false,writes=0;
  const port={readable:new ReadableStream({start(c){receiver=c;}}),writable:new WritableStream({write(bytes){const [,C,M,E,seq]=new TextDecoder().decode(bytes).trim().split(',');const inputs=[C,M,E].map(Number);const message={seq:Number(seq),inputs:inputs.slice(),output:Number(evaluate(circuit,inputs.map(Boolean)))};if(corrupt&&writes===0)message.inputs[0]=1-message.inputs[0];writes++;receiver.enqueue(new TextEncoder().encode(JSON.stringify(message)+'\n'));}}),async open(options){assert.equal(options.baudRate,115200);},async close(){closed=true;}};
  const result=await testSerialCircuit(circuit,{serial:{requestPort:async()=>port},timeoutMs:1000});
  assert.equal(writes,8);assert.equal(result.total,8);assert.equal(result.passed,corrupt?7:8);assert.equal(result.ok,!corrupt);assert.match(result.circuitHash,/^0x[0-9a-f]{64}$/);assert.equal(closed,true);
 }
});
