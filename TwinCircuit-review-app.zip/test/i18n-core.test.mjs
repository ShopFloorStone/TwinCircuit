import test from 'node:test';
import assert from 'node:assert/strict';
import {t,errorMessage,setLanguage,getLanguage,LANGUAGE_KEY} from '../public/i18n.mjs';
import core from '../public/locales/core.mjs';
import apiErrors from '../public/locales/api-errors.mjs';
import * as engine from '../public/engine.mjs';
import {encodeCall} from '../public/chain.mjs';
import {encodeEscrowCall} from '../public/payments.mjs';
import {TwinCircuitClient} from '../public/sdk.mjs';

const address=n=>'0x'+String(n).padStart(40,'0');
const restoreGlobal=(key,descriptor)=>descriptor?Object.defineProperty(globalThis,key,descriptor):delete globalThis[key];

test('known complete core positional errors translate to English without a Chinese formatter tail',()=>{
  setLanguage('en');
  try{
    assert.throws(()=>engine.parseExpression('C &&\n Q'),{name:'SpecError',message:'Line 2, column 2: Unknown variable or missing operand: Q',line:2,column:2});
    assert.throws(()=>engine.parseNetlist('0x',99,1),{message:'Line 1, column 1: Input count is outside 0–8.'});
    assert.equal(t('Invalid expression: 第 2 行，第 2 列：未知变量或缺少操作数：Q'),'Invalid expression: line 2, column 2: Unknown variable or missing operand: Q');
    const params={line:2,column:3,message:'Unknown template.',name:'Q',value:'Q',character:'"?"',count:3,min:0,max:8,offset:0,opcode:2};
    for(const key of Object.keys(core).filter(k=>k.startsWith('第 {line}')||k.startsWith('Invalid expression: 第 {line}'))){
      const result=t(key,params);assert.doesNotMatch(result,/[\u3400-\u9fff]/u,key);assert.ok(!result.includes('undefined'),key);
    }
  }finally{setLanguage('zh-CN');}
});

test('known template interpolation preserves address, HTML-like text, dollar signs, braces and Chinese user bytes',()=>{
  setLanguage('en');
  const addressValue='0xAbCdEf0123456789aBcDEf0123456789abcdef01';
  const userValue='用户设备 <img src=x onerror=alert(1)> & "$&" {min}\u0000\r\n尾部';
  const documentDescriptor=Object.getOwnPropertyDescriptor(globalThis,'document');
  Object.defineProperty(globalThis,'document',{configurable:true,value:new Proxy({}, {get(){throw Error('Translation must not access or rewrite DOM content');}})});
  try{
    for(const value of [addressValue,userValue]){
      assert.equal(t('未知变量 {name}',{name:value}),'Unknown variable '+value);
      assert.equal(t('未知变量 '+value),'Unknown variable '+value);
      assert.equal(t('第 9 行，第 4 列：未知变量 '+value),'Line 9, column 4: Unknown variable '+value);
    }
    const source=Object.freeze({message:userValue+' must be an integer between 1 and 10',code:'UNCHANGED_CODE',status:400});
    assert.equal(errorMessage(source),source.message);
  }finally{restoreGlobal('document',documentDescriptor);setLanguage('zh-CN');}
  setLanguage('zh-CN');
  const raw=Object.freeze({message:userValue+' must be an integer between 1 and 10',code:'UNCHANGED_CODE'});
  assert.equal(errorMessage(raw),userValue+' 必须是 1 到 10 之间的整数');
  assert.equal(raw.message,userValue+' must be an integer between 1 and 10');assert.equal(raw.code,'UNCHANGED_CODE');
});

test('canceled language switch leaves preference, document, data and post-change events untouched',()=>{
  setLanguage('zh-CN');
  const saved=Object.fromEntries(['window','document','localStorage'].map(k=>[k,Object.getOwnPropertyDescriptor(globalThis,k)]));
  const events=new EventTarget(),writes=[],meta={content:'original description'},loading={textContent:'原始加载内容'};
  const doc={documentElement:{lang:'zh-CN'},title:'original title',querySelector:s=>s==='meta[name="description"]'?meta:s==='#app > .loading-screen p'?loading:null};
  Object.defineProperty(globalThis,'window',{configurable:true,value:events});
  Object.defineProperty(globalThis,'document',{configurable:true,value:doc});
  Object.defineProperty(globalThis,'localStorage',{configurable:true,value:{getItem:()=>null,setItem:(...args)=>writes.push(args)}});
  const state=Object.freeze({name:'用户记录',expression:'E && (C || M)',evidenceHash:'0x'+'ab'.repeat(32)}),before=JSON.stringify({doc,state});
  let changed=0;
  const cancel=event=>{assert.equal(event.cancelable,true);assert.equal(getLanguage(),'zh-CN');event.preventDefault();};
  events.addEventListener('twincircuit:beforelanguagechange',cancel);events.addEventListener('twincircuit:languagechange',()=>changed++);
  try{
    assert.equal(setLanguage('en'),false);assert.equal(getLanguage(),'zh-CN');assert.deepEqual(writes,[]);assert.equal(changed,0);assert.equal(JSON.stringify({doc,state}),before);
    events.removeEventListener('twincircuit:beforelanguagechange',cancel);
    assert.equal(setLanguage('en'),true);assert.equal(changed,1);assert.deepEqual(writes,[[LANGUAGE_KEY,'en']]);assert.equal(doc.documentElement.lang,'en');
    assert.equal(state.name,'用户记录');assert.equal(state.evidenceHash,'0x'+'ab'.repeat(32));
  }finally{for(const [key,descriptor]of Object.entries(saved))restoreGlobal(key,descriptor);setLanguage('zh-CN');}
});

test('Node without a window starts in Chinese even if a storage implementation contains English',async()=>{
  const saved=Object.fromEntries(['window','localStorage'].map(k=>[k,Object.getOwnPropertyDescriptor(globalThis,k)]));
  delete globalThis.window;
  Object.defineProperty(globalThis,'localStorage',{configurable:true,value:{getItem:()=> 'en',setItem(){throw Error('Import must not write storage');}}});
  try{
    const fresh=await import('../public/i18n.mjs?node-default-isolation');
    assert.equal(fresh.getLanguage(),'zh-CN');assert.equal(fresh.getLocale(),'zh-CN');
  }finally{for(const [key,descriptor]of Object.entries(saved))restoreGlobal(key,descriptor);}
});

test('switching language preserves user circuit metadata, hash, wire exports and transaction calldata',async()=>{
  const options={title:'用户电路 <A>',inputNames:['用户 C','用户 M','用户 E']};
  const data=()=>{const c=engine.compileCME1(options);return{c,st:engine.exportST(c),csv:engine.truthCSV(c),firmware:engine.firmware(c),tapeout:encodeCall('tapeout(bytes,uint32,uint32)',[c.netlistHex,3,1]),fund:encodeEscrowCall('fund',['0x'+'11'.repeat(32),'0x'+'22'.repeat(32),'0x'+'33'.repeat(32),address(7),[1,2,3,4,5].map(address),['1','2','3','4','5'],'15',1800000000])};};
  setLanguage('zh-CN');const zh=data(),hash=await engine.circuitHash(zh.c);
  try{setLanguage('en');const en=data();assert.deepEqual(en,zh);assert.equal(await engine.circuitHash(en.c),hash);assert.equal(en.c.title,options.title);assert.deepEqual(en.c.inputNames,options.inputNames);}finally{setLanguage('zh-CN');}
});

test('SDK error presentation leaves original status and machine code intact',async()=>{
  const client=new TwinCircuitClient({baseURL:'https://example.invalid',fetchImpl:async()=>new Response(JSON.stringify({error:{message:'Email or password is incorrect',code:'AUTH_FAILED'}}),{status:401})});
  let error;try{await client.session();}catch(e){error=e;}
  assert.ok(error);const before={message:error.message,code:error.code,status:error.status};
  try{setLanguage('zh-CN');assert.equal(errorMessage(error),'邮箱或密码不正确');setLanguage('en');assert.equal(errorMessage(error),'Email or password is incorrect');assert.deepEqual({message:error.message,code:error.code,status:error.status},before);}finally{setLanguage('zh-CN');}
});

test('API catalog contains valid copy and applies dynamic labels without recursive value translation',()=>{
  for(const [source,target]of Object.entries(apiErrors)){assert.ok(source.length);assert.equal(typeof target,'string');assert.ok(target.length);}
  setLanguage('zh-CN');
  const value='用户标识 <A> {min} $&';
  assert.equal(errorMessage(value+' must be an integer between 1 and 1000'),value+' 必须是 1 到 1000 之间的整数');
  assert.equal(errorMessage(value+' not found'),'未找到 '+value);
  assert.equal(errorMessage('Missing import array: suppliers'),'导入数据缺少数组：suppliers');
});
