import assert from 'node:assert/strict';
import test from 'node:test';
import { Store } from '../lib/store.mjs';
import { listFactoryTemplates } from '../lib/factory-templates.mjs';

function scenario(t) {
  const store = new Store(':memory:');
  t.after(() => store.close());
  const [a,b,c,d] = Array.from({ length:4 }, () => store.session(store.demo().secret));
  const add = store.db.prepare(`INSERT INTO factory_templates
    (sequence,id,workspace_id,spec_id,version,publisher,name,description,profile,expression,published_at,listed)
    VALUES(?,?,?,?,1,?,?,'factory text','TC-IO/0.1','C','2026-01-01',?)`);
  function insert(sequence, actor, name, publisher = name, listed = 1) {
    add.run(sequence, 't'+sequence, actor.workspaceId, 's'+sequence, publisher, name, listed);
  }
  store.transaction(() => {
    for (let i=1; i<=2400; i++) {
      const owner = i % 251 === 0 ? c : i % 3 === 0 ? b : a;
      const title = i % 113 === 0 ? 'Panel_%! Rare' : i % 97 === 0 ? '控制面板' : 'Panel '+i;
      const publisher = i % 89 === 0 ? 'Panel_%! Factory' : i % 11 === 0 ? 'Électronique' : 'PANEL group';
      insert(i, owner, title, publisher, i % 7 === 0 ? 0 : 1);
    }
  });
  return { db: store.db, a,b,c,d, insert };
}

function expected(db, actor, params) {
  const filter = ['listed=1'], args = [];
  if (params.get('owned') === '1') { filter.push('workspace_id=?'); args.push(actor.workspaceId); }
  if (params.has('cursor')) { filter.push('sequence<?'); args.push(Number(params.get('cursor'))); }
  const prefix = (params.get('q') || '').trim().replace(/[!%_]/g, '!$&') + '%';
  filter.push("(name LIKE ? ESCAPE '!' OR publisher LIKE ? ESCAPE '!')");
  const limit = Number(params.get('limit') ?? '18');
  const rows = db.prepare(`SELECT * FROM factory_templates WHERE ${filter.join(' AND ')} ORDER BY sequence DESC LIMIT ?`).all(...args, prefix, prefix, limit + 1);
  const nextCursor = rows.length > limit ? String(rows[limit - 1].sequence) : null;
  const templates = rows.slice(0,limit).map(r => {
    const owned = r.workspace_id === actor.workspaceId;
    return {
      id:r.id,name:r.name,description:r.description,profile:r.profile,expression:r.expression,
      publisher:r.publisher,version:r.version,publishedAt:r.published_at,owned,
      ...(owned ? { sourceSpecId:r.spec_id } : {}),
    };
  });
  return { templates, nextCursor };
}

test('ordered search pages equal the reference with names, publishers, ownership, cursor, case and literal wildcards', t => {
  const {db, a,b,c,d} = scenario(t);
  for (const actor of [a,b,c,d]) {
    for (const owned of ['0','1']) {
      for (const q of [' panel ', 'PANEL_%!', 'PaNeL_%! Factory', '控制', 'Élect', 'élect', 'missing', '%', '_', '!']) {
        for (const limit of ['1','18','50']) {
          const params = new URLSearchParams({ q, owned, limit, cursor:'2199' });
          const seen = new Set();
          for (let i=0; i<3; i++) {
            const page = listFactoryTemplates(db, actor, params);
            assert.deepEqual(page, expected(db, actor, params), JSON.stringify(Object.fromEntries(params)));
            for (const row of page.templates) {
              assert.ok(!seen.has(row.id));
              seen.add(row.id);
            }
            if (!page.nextCursor) break;
            params.set('cursor',page.nextCursor);
          }
        }
      }
    }
  }
});

test('withdrawn rows immediately leave both the fast and fallback searches, including owner search', t => {
  const {db,a,insert} = scenario(t);
  insert(2401, a, 'Revocable visible');
  insert(2402, a, 'Panel late row');
  for (const owned of ['0','1']) {
    for (const q of ['Revocable','Panel']) {
      const params = new URLSearchParams({q,owned});
      const before = listFactoryTemplates(db,a,params);
      assert.deepEqual(before, expected(db,a,params));
    }
  }
  db.prepare('UPDATE factory_templates SET listed=0 WHERE sequence IN (2401,2402)').run();
  for (const owned of ['0','1']) {
    for (const q of ['Revocable','Panel']) {
      const params = new URLSearchParams({q,owned});
      const after = listFactoryTemplates(db,a,params);
      assert.deepEqual(after, expected(db,a,params));
      assert.ok(after.templates.every(row => !['t2401','t2402'].includes(row.id)));
    }
  }
});

test('a sparse search uses only the final snapshot if a publish and withdrawal occur between statements', t => {
  const { db, a, insert } = scenario(t);
  insert(2401, a, 'Sparse changing');
  let probes = 0;
  const concurrent = {
    prepare(sql) {
      if (++probes === 2) {
        db.exec('BEGIN');
        insert(2402, a, 'Sparse new');
        db.prepare('UPDATE factory_templates SET listed=0 WHERE sequence=2401').run();
        db.exec('COMMIT');
      }
      return db.prepare(sql);
    },
  };
  const params = new URLSearchParams({ q:'Sparse', limit:'7' });
  const page = listFactoryTemplates(concurrent,a,params);
  assert.equal(probes, 2);
  assert.deepEqual(page, expected(db,a,params));
  assert.deepEqual(page.templates.map(row=>row.id), ['t2402']);
});
