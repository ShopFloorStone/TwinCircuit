import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import * as standard from '../public/industrial-standard.mjs';
import { importNetlist, evaluate, packBits } from '../public/engine.mjs';

test('the four standard profiles are TapeOut-compatible and every published bit vector replays', () => {
  const manifest = standard.getConformanceVectors();
  assert.equal(manifest.version, 'TC-IC/0.1');
  assert.equal(Object.keys(manifest.circuits).length, 4);
  for (const { profile, vectors } of Object.values(manifest.circuits)) {
    const circuit = importNetlist({ netlistHex: profile.netlistHex, nIn: profile.nIn, nOut: profile.nOut });
    assert.equal(vectors.length, 2 ** profile.nIn);
    for (const row of vectors) {
      assert.equal(row.inputHex, packBits(row.inputBits));
      assert.equal(row.output, evaluate(circuit, row.inputBits));
      assert.equal(row.outputHex, packBits([row.output]));
    }
  }
});

test('typed facts yield the documented first article, measurement and license decisions', async () => {
  for (const v of standard.STANDARD_VECTORS.firstArticle) {
    const result = standard.evaluateFirstArticle(v.input);
    assert.equal(result.decision, v.decision);
    assert.equal(result.circuit.output, v.decision === 'ready');
  }
  for (const v of standard.STANDARD_VECTORS.acceptance) {
    const result = standard.evaluateAcceptance(v.spec, v.evidence);
    assert.equal(result.decision, v.decision);
    assert.equal(result.circuit.pass.output, v.decision === 'accept');
    assert.equal(result.circuit.reject.output, v.decision === 'reject');
  }
  for (const v of standard.STANDARD_VECTORS.license) {
    const result = standard.evaluateLicense(v.grant, v.use);
    assert.equal(result.decision, v.decision);
    assert.equal(result.feeMinor, v.feeMinor);
  }
  assert.match(await standard.getConformanceDigest(), /^sha256:[0-9a-f]{64}$/);
  const acceptanceSpec = standard.STANDARD_VECTORS.acceptance[0].spec;
  const envelope = standard.getSpecEnvelope('acceptance', acceptanceSpec);
  assert.deepEqual(Object.keys(envelope), [
    'standardVersion', 'lowerMicrometers', 'upperMicrometers', 'requireIndependentMeasurement',
  ]);
  assert.equal(
    await standard.getSpecDigest('acceptance', acceptanceSpec),
    createHash('sha256').update(JSON.stringify(envelope)).digest('hex'),
  );
});

test('missing provenance, expired use and unsafe numeric inputs cannot silently pass', () => {
  const accepted = standard.STANDARD_VECTORS.acceptance[0];
  assert.equal(standard.evaluateAcceptance(accepted.spec, { ...accepted.evidence, identityVerified: false }).decision, 'review');
  assert.equal(standard.evaluateAcceptance(accepted.spec, { ...accepted.evidence, calibrationValid: false }).decision, 'review');
  assert.equal(standard.evaluateAcceptance(accepted.spec, { ...accepted.evidence, independentMeasurement: false }).decision, 'review');
  assert.throws(() => standard.evaluateAcceptance(accepted.spec, { ...accepted.evidence, uncertaintyMicrometers: -1 }));
  assert.throws(() => standard.evaluateAcceptance(accepted.spec, { ...accepted.evidence, unitId: '' }));
  const paid = standard.STANDARD_VECTORS.license[0];
  assert.equal(standard.evaluateLicense(paid.grant, { ...paid.use, occurredAt: '2027-01-01T00:00:00Z' }).feeMinor, '0');
  assert.equal(standard.evaluateLicense({ ...paid.grant, usedUnits: 99 }, paid.use).decision, 'not-payable');
  assert.throws(() => standard.evaluateLicense(paid.grant, { ...paid.use, occurredAt: '2026-02-30T00:00:00Z' }));
  assert.throws(() => standard.evaluateFirstArticle({ ...standard.STANDARD_VECTORS.firstArticle[1].input, committedBudgetMinor: '01' }));
});
