import test from 'node:test';
import assert from 'node:assert/strict';
import { integrationStatus, rpcRequest, assistSpec } from '../lib/integrations.mjs';
import * as c from '../public/chain.mjs';
import { compileCME1, compileTemplate, evaluate, stepCircuit, packBits } from '../public/engine.mjs';
const W = n => BigInt(n).toString(16).padStart(64,'0');
const bytes = hex => W(32)+W((hex.length-2)/2)+hex.slice(2).padEnd(Math.ceil((hex.length-2)/64)*64,'0');
const addr='0x1111111111111111111111111111111111111111',sender='0x2222222222222222222222222222222222222222',token='0x3333333333333333333333333333333333333333';
function fetchRPC(overrides={}) { const calls=[];const fn=async(url,options)=>{calls.push({url,options});const p=JSON.parse(options.body);const result=p.method==='eth_chainId'?'0xc4':overrides[p.method]??'0x123';return new Response(JSON.stringify({jsonrpc:'2.0',id:p.id,result}),{status:200,headers:{'Content-Type':'application/json'}});};fn.calls=calls;return fn; }
test('server status never exposes keys and no-key assistance explicitly uses rules', async()=>{
  const status=integrationStatus({MODEL_API_KEY:'key-never-in-json-98765',MODEL_NAME:'model'});assert.ok(!JSON.stringify(status).includes('key-never-in-json-98765'));
  const spec=await assistSpec({prompt:'温室通风控制'});assert.equal(spec.mode,'rule');assert.equal(spec.ai,false);assert.equal(spec.supported,true);
  assert.equal((await assistSpec({prompt:'设计无线射频芯片'})).supported,false);
});
test('RPC proxy pins configured destination and rejects method/selector/URL/state override abuse',async()=>{
  const f=fetchRPC();let result=await rpcRequest({jsonrpc:'2.0',id:1,method:'eth_blockNumber',params:[]},{},{fetchImpl:f});assert.equal(result.result,'0x123');assert.equal(f.calls[0].url,'https://rpc.xlayer.tech/');
  for(const p of [
    {method:'eth_sendTransaction',params:[]},
    {method:'eth_call',params:[{to:addr,data:'0xdeadbeef'},'latest']},
    {method:'eth_call',params:[{to:addr,data:c.ABI['TAPEOUT_FEE()']},'latest',{}]},
    {method:'eth_call',params:[{to:addr,data:c.ABI['TAPEOUT_FEE()'],url:'http://127.0.0.1'},'latest']},
    {method:'eth_getCode',params:['http://127.0.0.1','latest']},
  ]) await assert.rejects(()=>rpcRequest({jsonrpc:'2.0',id:1,...p},{},{fetchImpl:f}));
  await assert.rejects(()=>rpcRequest({jsonrpc:'2.0',id:1,method:'eth_chainId',params:[]},{XLAYER_RPC_URL:'file:///etc/passwd'},{fetchImpl:f}));
  const wrong=async(url,o)=>new Response(JSON.stringify({jsonrpc:'2.0',id:JSON.parse(o.body).id,result:'0x1'}));
  await assert.rejects(()=>rpcRequest({jsonrpc:'2.0',id:1,method:'eth_blockNumber',params:[]},{},{fetchImpl:wrong}),/196/);
});
test('model suggestion must parse as safe DSL before it can be returned',async()=>{
  const env={MODEL_API_KEY:'server-secret',MODEL_NAME:'model',MODEL_BASE_URL:'https://model.example/v1'};let seen;
  const model=expression=>async(url,options)=>{seen={url,options};return new Response(JSON.stringify({choices:[{message:{content:JSON.stringify({supported:true,expression,message:'suggestion'})}}]}));};
  const result=await assistSpec({prompt:'enable only with manual'},env,{fetchImpl:model('E && M')});assert.equal(result.mode,'model');assert.equal(result.expression,'E && M');assert.equal(result.reviewRequired,true);assert.equal(seen.url,'https://model.example/v1/chat/completions');assert.equal(seen.options.headers.Authorization,'Bearer server-secret');assert.ok(!JSON.stringify(result).includes('server-secret'));
  await assert.rejects(()=>assistSpec({prompt:'test'},env,{fetchImpl:model('process.exit()')}));
});
test('ABI encode/decode fixed and dynamic values, malformed lengths fail closed',()=>{
  assert.equal(c.encodeCall('eval(uint256,bytes)',[2,'0x03']),c.ABI['eval(uint256,bytes)']+W(2)+W(64)+W(1)+'03'.padEnd(64,'0'));
  assert.equal(c.decodeBytes('0x'+bytes('0x0102')),'0x0102');
  assert.throws(()=>c.decodeBytes('0x'+W(9999)+W(1)));
  assert.throws(()=>c.requireAddress('0x0000000000000000000000000000000000000000'));
});
function chainStub(circuit=compileCME1(), {balance=10n,mismatch=false,chain='0xc4'}={}) {
  const calls=[];const fn=async p=>{
    calls.push(p);if(p.method==='eth_chainId')return chain;if(p.method==='eth_blockNumber')return '0x123';if(p.method==='eth_getCode')return '0x6000';if(p.method==='eth_estimateGas')return '0x50000';
    const data=p.params?.[0]?.data,sig=data?.slice(0,10);
    if(sig===c.ABI['isCPU(address)'])return '0x'+W(1);
    if(sig===c.ABI['circuitInfo(uint256)'])return '0x'+[circuit.nIn,circuit.nOut,circuit.nState,circuit.gateCount].map(W).join('');
    if(sig===c.ABI['netlist(uint256)'])return '0x'+bytes(circuit.netlistHex);
    if(sig===c.ABI['TAPEOUT_FEE()'])return '0x'+W(12345);
    if(sig===c.ABI['transistors()'])return '0x'+token.slice(2).padStart(64,'0');
    if(sig===c.ABI['NAND()'])return '0x'+W(0);
    if(sig===c.ABI['LATCH()'])return '0x'+W(1);
    if(sig===c.ABI['balanceOf(address,uint256)'])return '0x'+W(balance);
    if(sig===c.ABI['eval(uint256,bytes)']){const args='0x'+data.slice(10);const input=c.decodeBytes(args,1);const value=stepCircuit(circuit,[],input).outputsHex;return '0x'+bytes(mismatch?'0xff':value);}
    if(sig===c.ABI['step(uint256,bytes,bytes)']){const args='0x'+data.slice(10),state=c.decodeBytes(args,1),input=c.decodeBytes(args,2);const r=stepCircuit(circuit,state,input);const a=bytes(r.stateHex).slice(64),b=bytes(r.outputsHex).slice(64);return '0x'+W(64)+W(64+a.length/2)+a+b;}
    throw new Error(`Unexpected ${p.method} ${sig}`);
  };fn.calls=calls;return fn;
}
test('chain read is pinned and returns real comparison status, not invented equivalence',async()=>{
  const rpc=chainStub();const r=await c.readCircuit({address:addr,id:1,inputs:[true,false,true],rpc});assert.equal(r.comparison.match,true);assert.equal(r.circuit.nIn,3);assert.equal(r.evidence.block,'0x123');assert.equal(r.evidence.verification,'single-configured-rpc');
  assert.ok(rpc.calls.filter(x=>x.method==='eth_call').every(x=>x.params[1]==='0x123'));
  assert.equal((await c.readCircuit({address:addr,id:1,inputs:[false,false,false],rpc:chainStub(compileCME1(),{mismatch:true})})).comparison.match,false);
  await assert.rejects(()=>c.readCircuit({address:addr,id:1,rpc:chainStub(compileCME1(),{chain:'0x1'})}),/196/);
});
test('on-chain step comparison independently checks state and output bytes',async()=>{
  const circuit=compileTemplate('sequence');const r=await c.readCircuit({address:addr,id:1,inputs:[true,false,false,false],state:[false,false],rpc:chainStub(circuit)});assert.equal(r.comparison.match,true);assert.deepEqual(r.comparison.chainState,[true,false]);
});
test('complete imported circuit comparison checks all eight vectors at one pinned block',async()=>{
  const rpc=chainStub();const r=await c.compareCircuitVectors({address:addr,id:1,rpc});assert.equal(r.ok,true);assert.equal(r.total,8);assert.equal(r.rows[3].inputs.map(Number).join(''),'011');assert.equal(r.rows[3].chainOutputs[0],true);
  assert.equal(rpc.calls.filter(p=>p.params?.[0]?.data?.startsWith(c.ABI['circuitInfo(uint256)'])).length,1);
  assert.ok(rpc.calls.filter(p=>p.method==='eth_call').every(p=>p.params[1]===r.evidence.block));
});
function wallet(){const calls=[];const p={calls,request:async q=>{calls.push(q);if(q.method==='eth_accounts'||q.method==='eth_requestAccounts')return [sender];if(q.method==='eth_chainId')return '0xc4';if(q.method==='eth_sendTransaction')return '0x'+'a'.repeat(64);if(q.method==='wallet_switchEthereumChain')return null;throw Error(q.method);}};return p;}
test('publishing reads live fee and burns, requires explicit review, mock wallet only',async()=>{
  const circuit=compileCME1(), provider=wallet(),rpc=chainStub();const opts={address:addr,netlistHex:circuit.netlistHex,nIn:3,nOut:1,provider,rpc};
  const cancel=await c.publishExistingCPU({...opts,onReview:()=>false});assert.equal(cancel.submitted,false);assert.equal(provider.calls.some(q=>q.method==='eth_sendTransaction'),false);
  let review;const sent=await c.publishExistingCPU({...opts,onReview:r=>{review=r;return true;}});assert.equal(sent.submitted,true);assert.equal(sent.confirmed,false);assert.equal(review.feeWei,'12345');assert.equal(review.transaction.value,'0x3039');assert.deepEqual(review.tokenConsumption,{NAND:5,LATCH:0});assert.equal(review.transaction.to,addr);
  await assert.rejects(()=>c.publishExistingCPU({...opts,rpc:chainStub(circuit,{balance:0n}),onReview:()=>true}),/余额不足/);
});
test('receipt hash is not success; poll handles pending, revert and matching successful receipt',async()=>{
  const hash='0x'+'a'.repeat(64);
  assert.equal((await c.waitForReceipt(hash,{rpc:async()=>null,attempts:1,intervalMs:0})).pending,true);
  await assert.rejects(()=>c.waitForReceipt(hash,{rpc:async()=>({status:'0x0',transactionHash:hash}),attempts:1}),/失败/);
  assert.equal((await c.waitForReceipt(hash,{rpc:async()=>({status:'0x1',transactionHash:hash}),attempts:1})).confirmed,true);
});
test('publication ID is accepted only from a matching processor mint to the reviewed author',()=>{
  const topic='0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef';
  const receipt={logs:[{address:addr,topics:[topic,'0x'+W(0),'0x'+sender.slice(2).padStart(64,'0'),'0x'+W(7)]}]};
  assert.equal(c.findPublishedCircuitId(receipt,addr,sender),'7');
  assert.throws(()=>c.findPublishedCircuitId(receipt,addr,token),/未找到/);
});
