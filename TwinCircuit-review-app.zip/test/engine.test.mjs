import test from 'node:test';
import assert from 'node:assert/strict';
import * as e from '../public/engine.mjs';
import { keccak256, selector } from '../public/keccak.mjs';

test('CME1: five NAND, complete independent truth table in C/M/E display order', () => {
  const c = e.compileCME1(); assert.equal(c.gateCount, 5); assert.equal(c.nState, 0);
  assert.deepEqual(e.truthTable(c).map(r => r.inputs.map(Number).join('')), ['000','001','010','011','100','101','110','111']);
  assert.deepEqual(e.truthTable(c).map(r => Number(r.output)), [0,0,0,1,0,1,0,1]);
  assert.equal(e.verify(c).passed, 8); assert.equal(e.verify(c).equivalent, true);
  assert.equal(c.netlistHex, '0x0000000200000200000003000003000000050000060000000400000700000008000008');
});
test('DSL parser precedence and synthesis agree exhaustively for independent AST evaluator', () => {
  for (const source of ['C','!C','C ^ M','E && (C || M)','!(C && M) || E','C || M && !E','0','1','Y = (C ^ M) && !E;','C && C']) {
    const circuit = e.compileExpression(source); assert.equal(e.verify(circuit).ok, true, source);
    for (const row of e.truthTable(circuit)) assert.equal(e.evaluateAST(circuit.ast, row.inputs, circuit.variables), row.output);
  }
  const custom = e.compileExpression('A ^ B && D', {variables:['A','B','D']}); assert.equal(e.verify(custom).passed,8);
});
test('DSL rejects injection, unknown identifiers, malformed input and deep recursion with positions', () => {
  for (const text of ['C; process.exit()','C.constructor','C[0]','C ? M : E','C & M','C + M','fetch(1)','C = M','C &&','C M','C ** M','2']) assert.throws(() => e.compileExpression(text), e.SpecError, text);
  try { e.parseExpression('C &&\n Q'); assert.fail(); } catch (err) { assert.equal(err.line,2); assert.equal(err.column,2); }
  assert.throws(() => e.compileExpression('!'.repeat(100)+'C'), /嵌套/);
  assert.throws(() => e.compileExpression('A',{variables:Array.from({length:9},(_,i)=>`V${i}`)}));
});
test('verification produces actual-vs-rule counterexample for changed, structurally valid netlist', () => {
  const c=e.compileCME1(); const gates=c.elements.map(g=>({...g})); gates.at(-1).a=0;
  const changed=e.importNetlist({netlistHex:e.encodeNetlist(gates),nIn:3,nOut:1,variables:['C','M','E'],expression:e.CME1_EXPRESSION});
  const report=e.verify(changed);assert.equal(report.ok,false);assert.ok(report.counterexample);assert.notEqual(report.counterexample.output,report.counterexample.expected);
  assert.equal(e.verify(e.importNetlist({netlistHex:c.netlistHex,nIn:3,nOut:1})).equivalent,null);
});
test('NAND/LATCH decoder checks record length, future NAND, state bounds and unsupported REF', () => {
  for (const hex of ['0x','0x00','0x00000002000003','0x010000ff','0x02','0x03','0xzz','0x0']) assert.throws(()=>e.importNetlist({netlistHex:hex,nIn:0,nOut:1}),hex);
  assert.throws(()=>e.importNetlist({netlistHex:'0x00000003000002',nIn:1,nOut:1}),/前向/);
});
test('LATCH one-beat feedback, packed LSB state and lenient bytes match TAP-02 semantics', () => {
  // zero-input T toggle: latch Q points forward to NOT Q; final output is NOT Q.
  const c=e.importNetlist({netlistHex:'0x0100000300000002000002',nIn:0,nOut:1});
  assert.equal(c.nState,1);assert.throws(()=>e.evaluate(c,[]),/stepCircuit/);
  const a=e.stepCircuit(c,'0x','0x');assert.deepEqual(a.newState,[true]);assert.deepEqual(a.outputs,[true]);
  const b=e.stepCircuit(c,a.newState,[]);assert.deepEqual(b.newState,[false]);
  assert.deepEqual(e.unpackBits('0x03',9),[true,true,false,false,false,false,false,false,false]);
  assert.equal(e.packBits([true,false,true]),'0x05');
});
test('sequence A then B opens one beat later; reset/alarm close and all 64 combinations verify', () => {
  const c=e.compileTemplate('sequence');assert.equal(e.verify(c).total,64);assert.equal(e.verify(c).ok,true);
  let state=[false,false];
  let r=e.stepCircuit(c,state,[false,true,false,false]);assert.equal(r.output,false);state=r.newState;
  r=e.stepCircuit(c,state,[true,false,false,false]);state=r.newState;
  r=e.stepCircuit(c,state,[false,true,false,false]);assert.equal(r.output,false);state=r.newState;
  r=e.stepCircuit(c,state,[false,false,false,false]);assert.equal(r.output,true);
  r=e.stepCircuit(c,r.newState,[false,false,true,false]);assert.equal(r.output,false);assert.deepEqual(r.newState,[false,false]);
});
test('inspection and sanitization reject contradictory arrays and discard arbitrary metadata', () => {
  const c=e.compileCME1(); c.extra='<script>';const sanitized=e.sanitizeCircuit(c);assert.equal(sanitized.extra,undefined);
  c.elements[0].a=999;assert.equal(e.inspectCircuit(c).valid,false);
  assert.throws(()=>e.evaluate(e.compileCME1(),['0',0,1]));
});
test('hash deterministic, port signature included, ST/CSV/firmware preserve real subset', async () => {
  const c=e.compileCME1();assert.equal(await e.circuitHash(c),await e.circuitHash(e.compileCME1()));
  assert.match(await e.circuitHash(c),/^0x[0-9a-f]{64}$/);
  const st=e.exportST(c);assert.match(st,/FUNCTION_BLOCK/);assert.equal((st.match(/:= NOT/g)||[]).length,5);
  assert.match(e.truthCSV(c),/^C,M,E,Y,expected,match\r\n0,0,0,0,0,true/);
  const fw=e.firmware(c);assert.match(fw,/TC,0,0,1,42/);assert.match(fw,/OUT_PIN=14/);assert.match(fw,/UINT32_MAX-d/);assert.ok(!fw.includes('analogRead'));
  assert.throws(()=>e.firmware(e.compileTemplate('sequence')));
});
test('limited templates identify non-AI mode and do not invent unsupported physical designs',()=>{
  assert.equal(e.parsePrompt('温室温度高于 31°C').threshold,31);
  assert.equal(e.parsePrompt('C ^ M').supported,true);
  assert.equal(e.parsePrompt('设计一块 PCB').supported,false);
  assert.equal(e.parsePrompt('温室温度低于 10 度开风扇').supported,false);
});
test('Ethereum Keccak known vectors and ABI selectors',()=>{
  assert.equal(keccak256(''),'0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470');
  assert.equal(keccak256('abc'),'0x4e03657aea45a94fc7d47ba826c8d667c0d1e6e33a64a036ec44f58fa12d6c45');
  assert.equal(selector('tapeout(bytes,uint32,uint32)'),'0x7bd3ac1d');
  assert.equal(selector('eval(uint256,bytes)'),'0x934d06ea');
});
