import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { applyCommand, seedWorkspace, validateImport } from '../lib/domain.mjs';
import { createApp } from '../server.mjs';
import { acceptedSnapshot } from '../lib/operations.mjs';

const PROFILE = 'TC-PANEL/0.1', owner = { id: 'owner', role: 'owner', name: 'Owner' };
test('panel profiles are frozen, separate from GPIO capacity, carry no fiat budget and survive draft-template export/import', () => {
  let state = seedWorkspace('Panel test fixture');
  const command = (type, payload) => { state = applyCommand(state, type, payload, owner); return state; };
  command('spec.create', { name: 'GRAM eight-vector workcell', profile: PROFILE }); const specId = state.specs.at(-1).id;
  assert.equal(state.specs.at(-1).circuit.profile, PROFILE);
  assert.throws(() => command('spec.update', { specId, profile: 'TC-IO/0.1' }), /immutable/);
  assert.throws(() => command('spec.update', { specId, expression: 'C && M' }), /frozen CME/);
  command('spec.publish', { specId });
  assert.throws(() => command('order.create', { specId, quantity: 1, budgetCents: 1 }), /no simulated fiat budget/);
  command('order.create', { specId, quantity: 1, budgetCents: 0 }); const orderId = state.orders.at(-1).id;
  assert.equal(state.orders.at(-1).currency, 'NONE'); assert.equal(state.orders.at(-1).budgetCents, 0);
  assert.throws(() => command('order.settle', { orderId }), /not simulated settlement/);
  assert.throws(() => command('reservation.create', { orderId, supplierId: 'supplier_a', quantity: 1 }), /profile/);
  command('supplier.create', { name: 'Real display workcell', mode: 'external', capacity: 1, capabilities: [PROFILE] }); const supplierId = state.suppliers.at(-1).id;
  const imported = validateImport(state, seedWorkspace('destination'), owner);
  assert.equal(imported.specs.at(-1).profile, PROFILE); assert.deepEqual(imported.suppliers.at(-1).capabilities, [PROFILE]);
  assert.equal(imported.orders.at(-1).currency, 'NONE');
  command('reservation.create', { orderId, supplierId, quantity: 1 });
  const reservationId = state.orders.at(-1).reservations[0].id;
  command('reservation.confirm', { orderId, reservationId, confirmationRef: 'Owner confirmed a single supervised TFT test; fixture only' });
  command('order.confirm', { orderId }); command('order.start', { orderId });
  assert.throws(() => command('execution.advance', { orderId, reservationId, count: 1 }), /External suppliers/);
  assert.equal(state.orders.at(-1).completedQuantity, 0);
});

async function httpFixture(t) {
  const app = createApp({ dbPath: ':memory:', setupToken: 'panel-http-fixture', env: {}, log() {} });
  await new Promise(resolve => app.server.listen(0, '127.0.0.1', resolve)); t.after(() => app.close()); const origin = `http://127.0.0.1:${app.server.address().port}`;
  function client() { let cookie = '', csrf; return {
    async request(path, { method = 'GET', body, headers = {} } = {}) {
      const response = await fetch(origin + path, { method, headers: { ...(cookie ? { cookie } : {}), ...(method === 'POST' ? { Origin: origin, 'Content-Type': 'application/json', ...(csrf ? { 'X-CSRF-Token': csrf } : {}) } : {}), ...headers }, body: body === undefined ? undefined : JSON.stringify(body) });
      const setCookie = response.headers.get('set-cookie'); if (setCookie) cookie = setCookie.split(';')[0]; const data = await response.json(); if (data.csrfToken) csrf = data.csrfToken; return { status: response.status, data };
    },
    async op(type, payload) { const state = await this.request('/api/operations'); return this.request('/api/operations/command', { method: 'POST', body: { type, payload, expectedRevision: state.data.revision, requestId: randomUUID() } }); },
    async command(type, payload) { const state = await this.request('/api/bootstrap'); return this.request('/api/command', { method: 'POST', body: { type, payload, expectedRevision: state.data.revision, requestId: randomUUID() } }); }
  }; }
  const a = client(); await a.request('/api/auth/setup', { method: 'POST', body: { setupToken: 'panel-http-fixture', name: 'Owner fixture', email: 'panel-owner@example.invalid', password: 'isolated panel HTTP fixture password' } });
  const gateway = async (token, path, body) => { const response = await fetch(origin + path, { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify(body) }); return { status: response.status, data: await response.json() }; };
  return { app, a, client, gateway };
}

test('HTTP display-only capability cannot register GPIO signals or bypass legacy physical ARM/permit', async t => {
  const { a, gateway } = await httpFixture(t), signals = [{ name: 'panel_vector', type: 'number', min: 0, max: 7, critical: false }];
  for (const supplied of [[...signals, { name: 'led', type: 'boolean' }], [{ ...signals[0], max: 8 }], [{ name: 'cme_vector', type: 'number', min: 0, max: 7 }]]) assert.equal((await a.op('device.register', { name: 'Rejected panel fixture', protocol: 'esp32-tft', signals: supplied })).status, 400);
  assert.equal((await a.op('device.register', { name: 'Rejected GPIO fixture', protocol: 'esp32-serial', signals })).status, 400);
  const registration = await a.op('device.register', { name: 'Display fixture only', protocol: 'esp32-tft', signals }); assert.equal(registration.status, 200); const { deviceId, deviceToken } = registration.data;
  assert.equal(registration.data.devices[0].capability, 'tft-panel');
  await a.op('device.arm', { deviceId, seconds: 60, reason: 'Display-only local test fixture; no GPIO work' });
  assert.equal((await a.op('job.submit', { deviceId, signal: 'panel_vector', value: 0.5, expectedDeviceRevision: 0 })).status, 400);
  assert.equal((await a.op('job.submit', { deviceId, signal: 'led', value: true, expectedDeviceRevision: 0 })).status, 400);
  const job = await a.op('job.submit', { deviceId, signal: 'panel_vector', value: 0, expectedDeviceRevision: 0 }); assert.equal(job.status, 200);
  const state = { revision: 0, armedUntil: Date.now() + 30000, blocked: false, connected: true, physicalArmed: false, physicalPermit: false };
  assert.equal((await gateway(deviceToken, '/api/gateway/pull', { deviceId, state })).data.job, null);
  assert.equal((await gateway(deviceToken, '/api/gateway/pull', { deviceId, state: { ...state, panelReady: true } })).data.job.id, job.data.jobId);
  const legacy = await a.op('device.register', { name: 'Legacy GPIO fixture', protocol: 'esp32-serial', signals: [{ name: 'led', type: 'boolean', critical: false }] });
  await a.op('device.arm', { deviceId: legacy.data.deviceId, seconds: 60, reason: 'Legacy gate must stay present' });
  await a.op('job.submit', { deviceId: legacy.data.deviceId, signal: 'led', value: true, expectedDeviceRevision: 0 });
  const denied = await gateway(legacy.data.deviceToken, '/api/gateway/pull', { deviceId: legacy.data.deviceId, state: { ...state, panelReady: true } });
  assert.equal(denied.data.job, null); assert.equal(denied.data.device.protocol, 'esp32-serial');
});

test('one-click panel preparation is atomic, revision checked and reuses unfinished work instead of duplicating capacity', async t => {
  const { app, a } = await httpFixture(t), registration = await a.op('device.register', { name: 'Atomic fixture', protocol: 'esp32-tft', signals: [{ name: 'panel_vector', type: 'number', min: 0, max: 7, critical: false }] });
  const before = (await a.request('/api/bootstrap')).data, payload = { deviceId: registration.data.deviceId, name: 'One display test', confirmationRef: 'Owner confirmed display-only test fixture, not industrial capacity', expectedBusinessRevision: before.revision };
  assert.equal((await a.op('panel.workcell.create', { ...payload, expectedBusinessRevision: before.revision + 1 })).data.error.code, 'REVISION_CONFLICT');
  const original = app.store.command.bind(app.store); app.store.command = (actor, body) => { if (body.type === 'spec.publish') throw new Error('Injected fixture failure after intermediate business commands'); return original(actor, body); };
  assert.equal((await a.op('panel.workcell.create', payload)).status, 500); app.store.command = original;
  assert.deepEqual((await a.request('/api/bootstrap')).data.orders, before.orders); assert.equal(app.store.db.prepare('SELECT count(*) AS n FROM ops_workcells').get().n, 0);
  const created = await a.op('panel.workcell.create', payload); assert.equal(created.status, 200); assert.equal(created.data.business.orders.at(-1).completedQuantity, 0); assert.equal(created.data.workcells.length, 1);
  const reused = await a.op('panel.workcell.create', { ...payload, expectedBusinessRevision: created.data.business.revision }); assert.equal(reused.data.existingWorkcell, true); assert.equal(reused.data.workcell.orderId, created.data.workcell.orderId);
  assert.equal(reused.data.business.orders.length, before.orders.length + 1); assert.equal(reused.data.business.suppliers.length, before.suppliers.length + 1); assert.equal(reused.data.jobs.length, 0);
});

function gramEvidence(index, actualY = Boolean((index & 1) && (index & 6))) {
  const rawRGB = actualY ? [252, 252, 252] : [0, 0, 0];
  return { protocol: 'serial', source: 'esp32-s3-panel-testcell', profile: PROFILE, quality: 'DISPLAY_PIXEL_READBACK', readbackQuality: 'DISPLAY_PIXEL_READBACK', scope: 'controller-GRAM-only', ok: true, error: null, vectorIndex: index, inputs: { C: Boolean(index & 4), M: Boolean(index & 2), E: Boolean(index & 1) }, actualY, readback: actualY, hardwareRevision: index + 1, deviceTimestamp: { bootId: 'a'.repeat(32), tickMs: 1000 + index }, receivedAt: new Date().toISOString(), pixel: { x: 260, y: 116, actualColor: actualY ? 0xffffff : 0, rawRGB, format: 'RGB888' }, references: { white: { x: 20, y: 200, actualColor: 0xffffff, rawRGB: [252, 252, 252] }, black: { x: 44, y: 200, actualColor: 0, rawRGB: [0, 0, 0] } }, readRegister: '0x2E', readRegisterHz: 1000000, rotation: 1 };
}

test('a valid GRAM counterexample remains the measured false bit rather than the CME expected true bit', async t => {
  const { a, gateway } = await httpFixture(t), registered = await a.op('device.register', { name: 'Counterexample fixture', protocol: 'esp32-tft', signals: [{ name: 'panel_vector', type: 'number', min: 0, max: 7, critical: false }] }), { deviceId, deviceToken } = registered.data;
  await a.op('device.arm', { deviceId, seconds: 60, reason: 'Fixture must preserve a measured failing vector' }); await a.op('job.submit', { deviceId, signal: 'panel_vector', value: 3, expectedDeviceRevision: 0 });
  const pulled = await gateway(deviceToken, '/api/gateway/pull', { deviceId, state: { revision: 0, armedUntil: Date.now() + 60000, connected: true, blocked: false, panelReady: true, physicalArmed: false, physicalPermit: false } });
  const e = gramEvidence(3, false); e.hardwareRevision = 1;
  const response = await gateway(deviceToken, '/api/gateway/result', { deviceId, jobId: pulled.data.job.id, nonce: pulled.data.job.nonce, status: 'succeeded', result: { executed: true, revision: 1, evidence: e } });
  assert.equal(response.status, 200); assert.equal(response.data.job.result.evidence.actualY, false); assert.equal(response.data.job.result.evidence.pixel.actualColor, 0);
  assert.equal(response.data.job.result.evidence.inputs.E && (response.data.job.result.evidence.inputs.C || response.data.job.result.evidence.inputs.M), true);
});
async function runningPanel(a) {
  const madeSpec = await a.command('spec.create', { name: 'GRAM hardware fixture profile', profile: PROFILE }); assert.equal(madeSpec.status, 200); const specId = madeSpec.data.specs.at(-1).id;
  await a.command('spec.publish', { specId }); const madeSupplier = await a.command('supplier.create', { name: 'External display fixture', mode: 'external', capacity: 1, capabilities: [PROFILE] }); const supplierId = madeSupplier.data.suppliers.at(-1).id;
  const madeOrder = await a.command('order.create', { specId, name: 'One GRAM readback unit', quantity: 1, budgetCents: 0 }); const orderId = madeOrder.data.orders.at(-1).id;
  const reserved = await a.command('reservation.create', { orderId, supplierId, quantity: 1 }); const reservationId = reserved.data.orders.at(-1).reservations[0].id;
  await a.command('reservation.confirm', { orderId, reservationId, confirmationRef: 'Fixture owner confirmed display-only testing, not a GPIO or industrial load' }); await a.command('order.confirm', { orderId }); await a.command('order.start', { orderId });
  return { orderId, reservationId };
}

test('real HTTP panel workflow retains eight GRAM reads, rejects fake quality/colors, requires independent review and cannot mint payment provenance', async t => {
  const { app, a, client, gateway } = await httpFixture(t), { orderId, reservationId } = await runningPanel(a);
  const invitation = await a.command('member.invite', { email: 'panel-verifier@example.invalid', role: 'verifier' }); const verifier = client();
  await verifier.request('/api/auth/register', { method: 'POST', body: { token: invitation.data.invitation.token, name: 'Independent fixture reviewer', email: 'panel-verifier@example.invalid', password: 'isolated independent review password' } });
  const registration = await a.op('device.register', { name: 'Panel-only fixture', protocol: 'esp32-tft', signals: [{ name: 'panel_vector', type: 'number', min: 0, max: 7, critical: false }] }); const { deviceId, deviceToken } = registration.data;
  await a.op('device.arm', { deviceId, seconds: 120, reason: 'Owner-authorized display-memory test fixture only' }); const jobIds = [];
  for (let index = 0; index < 8; index++) {
    const submitted = await a.op('job.submit', { deviceId, signal: 'panel_vector', value: index, expectedDeviceRevision: index }); assert.equal(submitted.status, 200);
    const delivery = await gateway(deviceToken, '/api/gateway/pull', { deviceId, state: { revision: index, armedUntil: Date.now() + 60000, connected: true, blocked: false, panelReady: true, physicalArmed: false, physicalPermit: false } });
    const job = delivery.data.job; assert.equal(job.payload.signal, 'panel_vector'); jobIds.push(job.id);
    const body = { deviceId, jobId: job.id, nonce: job.nonce, status: 'succeeded', result: { executed: true, revision: index + 1, evidence: gramEvidence(index) } };
    if (index === 0) {
      for (const change of [e => { e.quality = 'GPIO_READBACK'; }, e => { e.pixel.actualColor = 0xffffff; }, e => { e.references.white.rawRGB = [0, 0, 0]; }, e => { e.pixel.x = 300; }]) {
        const bad = structuredClone(body); change(bad.result.evidence); assert.equal((await gateway(deviceToken, '/api/gateway/result', bad)).status, 400);
      }
    }
    assert.equal((await gateway(deviceToken, '/api/gateway/result', body)).status, 200);
  }
  let business = (await a.request('/api/bootstrap')).data;
  const payload = { deviceId, orderId, reservationId, unit: 0, jobIds, expectedBusinessRevision: business.revision };
  assert.equal((await a.op('evidence.fromJobs', { ...payload, orderId: 'TC-024' })).data.error.code, 'MEASUREMENT_PROFILE_MISMATCH');
  const imported = await a.op('evidence.fromJobs', payload); assert.equal(imported.status, 200); assert.match(imported.data.measurementScope, /GRAM/);
  const order = imported.data.business.orders.find(o => o.id === orderId), batch = order.batches[0];
  assert.equal(order.currency, 'NONE'); assert.equal(order.status, 'awaiting_verification'); assert.equal(batch.mode, 'external');
  assert.equal(batch.records[0].provenance.scope, 'controller-GRAM-only'); assert.equal(batch.records[0].provenance.measurements.length, 8);
  assert.equal(batch.records[0].provenance.measurements[3].evidence.pixel.actualColor, 0xffffff); assert.equal(imported.data.jobs.filter(j => jobIds.includes(j.id) && j.evidenceUsed).length, 8);
  assert.equal((await a.command('batch.accept', { orderId, batchId: batch.id, note: 'Own measurement cannot be independently verified' })).data.error.code, 'SELF_VERIFICATION');
  assert.equal((await verifier.command('batch.accept', { orderId, batchId: batch.id, note: 'Reviewed eight controller GRAM samples and black/white references; not optical or GPIO proof' })).status, 200);
  assert.equal((await verifier.command('order.accept', { orderId })).status, 200);
  business = (await a.request('/api/bootstrap')).data; const accepted = business.orders.find(o => o.id === orderId), actor = { id: business.user.id, workspaceId: business.workspace.id, role: 'owner' };
  const snapshot = acceptedSnapshot(business, orderId); assert.equal(snapshot.measurementScope, 'controller-GRAM-only'); assert.equal(snapshot.specProfile, PROFILE);
  assert.doesNotThrow(() => app.operations.assertPanelOrigin(actor, accepted));
  const forged = structuredClone(accepted); forged.batches[0].records[0].provenance.measurements[0].evidence.pixel.actualColor = 0xffffff;
  assert.throws(() => app.operations.assertPanelOrigin(actor, forged), e => e.code === 'PANEL_JOB_EVIDENCE_REQUIRED');
  assert.equal((await a.command('order.settle', { orderId })).status, 409); assert.equal(business.ledger.length, 0);
});
