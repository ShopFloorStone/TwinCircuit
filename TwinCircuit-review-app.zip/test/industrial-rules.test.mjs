import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createApp } from '../server.mjs';
import { getSpecDigest } from '../public/industrial-standard.mjs';

async function start(dbPath) {
  const app = createApp({ dbPath, setupToken: 'industrial-test-token', log() {} });
  await new Promise(resolve => app.server.listen(0, '127.0.0.1', resolve));
  return { app, origin: 'http://127.0.0.1:' + app.server.address().port };
}

function client(origin) {
  let cookie = '', csrf = '', state, rules;
  const request = async (path, method = 'GET', data) => {
    const response = await fetch(origin + path, {
      method,
      headers: {
        ...(cookie ? { cookie } : {}),
        ...(method === 'POST' ? { Origin: origin, 'Content-Type': 'application/json', 'x-csrf-token': csrf } : {}),
      },
      body: data === undefined ? undefined : JSON.stringify(data),
    });
    if (response.headers.get('set-cookie')) cookie = response.headers.get('set-cookie').split(';')[0];
    const body = await response.json();
    if (response.ok && body.csrfToken) csrf = body.csrfToken;
    if (response.ok && body.workspace) state = body;
    if (response.ok && body.rules) rules = body;
    return { status: response.status, body };
  };
  return {
    request,
    get state() { return state; },
    get rules() { return rules; },
    get cookie() { return cookie; },
    get csrf() { return csrf; },
    bootstrap: () => request('/api/bootstrap'),
    loadRules: () => request('/api/industrial-rules'),
    command(type, payload, options = {}) {
      return request('/api/command', 'POST', { type, payload, expectedRevision: state.revision, ...options });
    },
    industrial(type, payload, options = {}) {
      return request('/api/industrial-rules/command', 'POST', { type, payload, expectedRevision: rules.revision, ...options });
    },
    setup: () => request('/api/auth/setup', 'POST', {
      setupToken: 'industrial-test-token', name: 'Owner', email: 'owner@example.test', password: 'A secure test password',
    }),
    register(email, roleToken) {
      return request('/api/auth/register', 'POST', {
        email, name: email.split('@')[0], token: roleToken, password: 'Another secure password',
      });
    },
    login: () => request('/api/auth/login', 'POST', {
      email: 'owner@example.test', password: 'A secure test password',
    }),
  };
}

test('industrial rules persist a three-decision flow with independent review and exact unpaid fee', async t => {
  const folder = await mkdtemp(join(tmpdir(), 'tc-industrial-'));
  const dbPath = join(folder, 'workspace.sqlite');
  let { app, origin } = await start(dbPath);
  t.after(async () => {
    app.server.closeAllConnections();
    await app.close();
    await rm(folder, { recursive: true, force: true });
  });
  const owner = client(origin), operator = client(origin), verifier = client(origin);
  assert.equal((await owner.setup()).status, 200);
  const originalWorkspace = owner.state.workspace.id;
  assert.equal((await owner.loadRules()).body.revision, 0);
  assert.equal(owner.rules.catalog.firstArticle.nIn, 5);
  assert.equal((await owner.request('/api/industrial-rules/command', 'POST', {
    type: 'industrial.first.create', payload: { title: 'Blocked' }, expectedRevision: 0,
  })).status, 400);
  const operatorInvite = await owner.command('member.invite', { email: 'operator@example.test', role: 'operator' });
  const verifierInvite = await owner.command('member.invite', { email: 'verifier@example.test', role: 'verifier' });
  assert.equal((await operator.register('operator@example.test', operatorInvite.body.invitation.token)).status, 200);
  assert.equal((await verifier.register('verifier@example.test', verifierInvite.body.invitation.token)).status, 200);
  await operator.loadRules(); await verifier.loadRules();

  const created = await owner.industrial('industrial.first.create', {
    title: 'Pump base first article', requiredDemandUnits: 30, requiredBudgetMinor: '1000',
  });
  assert.equal(created.status, 200);
  const firstId = owner.rules.rules.firstArticles[0].id;
  assert.equal(owner.rules.rules.firstArticles[0].digest, await getSpecDigest('firstArticle', owner.rules.rules.firstArticles[0]));
  assert.equal(owner.rules.rules.firstArticles[0].decision.decision, 'pending');
  await owner.industrial('industrial.first.pledge', { firstArticleId: firstId, demandUnits: 30, budgetMinor: '1000' });
  await operator.loadRules();
  await operator.industrial('industrial.first.commit', {
    firstArticleId: firstId, kind: 'capability', assetId: 'workstation-01',
    qualificationRef: 'fixture-qualification-01', statement: 'Our workstation can accept the quoted first article.',
  });
  await owner.loadRules();
  await owner.industrial('industrial.first.commit', {
    firstArticleId: firstId, kind: 'rights', statement: 'The workcell drawing rights are cleared for this order.',
  });
  assert.equal(owner.rules.rules.firstArticles[0].decision.decision, 'pending');
  await verifier.loadRules();
  await verifier.industrial('industrial.first.commit', {
    firstArticleId: firstId, kind: 'verifier', statement: 'Independent inspection capacity is reserved.',
  });
  assert.equal(verifier.rules.rules.firstArticles[0].decision.decision, 'ready');
  assert.deepEqual(verifier.rules.rules.firstArticles[0].decision.circuit.inputBits, [true, true, true, true, true]);

  await owner.bootstrap();
  const supplier = await owner.command('supplier.create', {
    name: 'External workshop', code: 'EXT', mode: 'external',
    capacity: 50, capabilities: ['TC-IO/0.1'],
  });
  assert.equal(supplier.status, 200);
  const supplierId = supplier.body.suppliers.at(-1).id;
  await owner.loadRules();
  const specResult = await owner.industrial('industrial.acceptance.spec', {
    title: 'Bore diameter', lowerMicrometers: 9900, upperMicrometers: 10100,
    requireIndependentMeasurement: true,
  });
  assert.equal(specResult.status, 200);
  const spec = owner.rules.rules.acceptanceSpecs[0];
  assert.match(spec.digest, /^[0-9a-f]{64}$/);
  assert.equal(spec.digest, await getSpecDigest('acceptance', spec));
  await operator.loadRules();
  const submitted = await operator.industrial('industrial.acceptance.submit', {
    orderId: firstId, specId: spec.id, unitId: 'piece-01', supplierId,
    measuredMicrometers: 10030, uncertaintyMicrometers: 20,
    calibrationValid: true, identityVerified: true, independentMeasurement: true,
    source: 'Instrument file 2026-11-19/01', calibrationRef: 'calibration-01',
  });
  assert.equal(submitted.status, 200);
  const evidence = operator.rules.rules.evidence[0];
  assert.equal(evidence.decision.decision, 'accept');
  assert.equal(evidence.reviewStatus, 'pending');
  assert.match(evidence.evidenceDigest, /^[0-9a-f]{64}$/);
  assert.equal((await operator.industrial('industrial.acceptance.submit', {
    orderId: firstId, specId: spec.id, unitId: 'piece-01', supplierId,
    measuredMicrometers: 10030, uncertaintyMicrometers: 20,
    calibrationValid: true, identityVerified: true, independentMeasurement: true,
    source: 'Repeat', calibrationRef: 'calibration-01',
  })).status, 409);
  assert.equal((await operator.industrial('industrial.acceptance.review', {
    evidenceId: evidence.id, approved: true, note: 'Self review',
  })).status, 403);
  await verifier.loadRules();
  assert.equal((await verifier.industrial('industrial.acceptance.review', {
    evidenceId: evidence.id, approved: true, note: 'Independently reviewed instrument data and unit identity.',
  })).status, 200);
  assert.equal(verifier.rules.rules.evidence[0].reviewStatus, 'accepted');

  await owner.loadRules();
  const grant = await owner.industrial('industrial.license.grant', {
    title: 'Fixture drawing license', licenseeId: operator.state.user.id,
    profileDigest: spec.digest,
    validFrom: '2026-01-01T00:00:00Z', validUntil: '2027-01-01T00:00:00Z',
    rateMinor: '25', maxUnits: 10, assetSymbol: 'BEM',
  });
  assert.equal(grant.status, 200);
  const grantId = owner.rules.rules.licenseGrants[0].id;
  assert.equal(owner.rules.rules.licenseGrants[0].digest, await getSpecDigest('license', owner.rules.rules.licenseGrants[0]));
  await owner.industrial('industrial.first.create', {
    title: 'Second first article', requiredDemandUnits: 1, requiredBudgetMinor: '1',
  });
  const secondOrderId = owner.rules.rules.firstArticles.at(-1).id;
  await owner.industrial('industrial.first.pledge', {
    firstArticleId: secondOrderId, demandUnits: 1, budgetMinor: '1',
  });
  await operator.loadRules();
  await operator.industrial('industrial.first.commit', {
    firstArticleId: secondOrderId, kind: 'capability', assetId: 'workstation-01',
    qualificationRef: 'fixture-qualification-01', statement: 'Second first article capacity confirmed.',
  });
  await owner.loadRules();
  await owner.industrial('industrial.first.commit', {
    firstArticleId: secondOrderId, kind: 'rights', statement: 'Second drawing rights cleared.',
  });
  await verifier.loadRules();
  await verifier.industrial('industrial.first.commit', {
    firstArticleId: secondOrderId, kind: 'verifier', statement: 'Second independent test reserved.',
  });
  assert.equal(verifier.rules.rules.firstArticles.at(-1).decision.decision, 'ready');
  await operator.loadRules();
  assert.equal((await operator.industrial('industrial.acceptance.submit', {
    orderId: secondOrderId, specId: spec.id, unitId: 'piece-01', supplierId,
    measuredMicrometers: 10030, uncertaintyMicrometers: 20,
    calibrationValid: true, identityVerified: true, independentMeasurement: true,
    source: 'Cross-order duplicate', calibrationRef: 'calibration-01',
  })).status, 409);
  const alternateSupplier = await owner.command('supplier.create', {
    name: 'Second external workshop', code: 'EXT2', mode: 'external',
    capacity: 50, capabilities: ['TC-IO/0.1'],
  });
  assert.equal(alternateSupplier.status, 200);
  assert.equal((await operator.industrial('industrial.acceptance.submit', {
    orderId: firstId, specId: spec.id, unitId: 'piece-01',
    supplierId: alternateSupplier.body.suppliers.at(-1).id,
    measuredMicrometers: 10030, uncertaintyMicrometers: 20,
    calibrationValid: true, identityVerified: true, independentMeasurement: true,
    source: 'Cross-supplier duplicate', calibrationRef: 'calibration-01',
  })).status, 409);
  const usage = {
    grantId, orderId: firstId, unitId: 'piece-01',
    licenseeId: operator.state.user.id, profileDigest: spec.digest, quantity: 1,
  };
  assert.equal((await operator.industrial('industrial.license.use', {
    ...usage, orderId: 'nonexistent-order',
  })).status, 404);
  assert.equal((await operator.industrial('industrial.license.use', {
    ...usage, orderId: secondOrderId,
  })).status, 409);
  const used = await operator.industrial('industrial.license.use', usage, { requestId: 'use-once' });
  assert.equal(used.status, 200);
  assert.equal(operator.rules.rules.licenseUses[0].feeMinor, '25');
  assert.equal(operator.rules.rules.licenseUses[0].paymentStatus, 'unpaid');
  assert.equal(operator.rules.rules.licenseGrants[0].usedUnits, 1);
  const retry = await operator.industrial('industrial.license.use', usage, {
    requestId: 'use-once', expectedRevision: 0,
  });
  assert.equal(retry.status, 200);
  assert.equal(retry.body.rules.licenseUses.length, 1);
  assert.equal((await operator.industrial('industrial.license.use', usage)).status, 409);
  await owner.loadRules();
  const secondGrant = await owner.industrial('industrial.license.grant', {
    title: 'Duplicate rights grant', licenseeId: operator.state.user.id,
    profileDigest: spec.digest,
    validFrom: '2026-01-01T00:00:00Z', validUntil: '2027-01-01T00:00:00Z',
    rateMinor: '25', maxUnits: 10, assetSymbol: 'BEM',
  });
  assert.equal(secondGrant.status, 200);
  const secondGrantId = owner.rules.rules.licenseGrants.at(-1).id;
  await operator.loadRules();
  assert.equal((await operator.industrial('industrial.license.use', {
    ...usage, grantId: secondGrantId,
  })).status, 409);
  await owner.loadRules();
  assert.equal((await owner.industrial('industrial.first.pledge.withdraw', { firstArticleId: firstId })).status, 200);
  assert.equal(owner.rules.rules.firstArticles[0].decision.decision, 'pending');
  assert.equal((await owner.industrial('industrial.first.pledge', {
    firstArticleId: firstId, demandUnits: 30, budgetMinor: '1000',
  })).status, 200);
  assert.equal(owner.rules.rules.firstArticles[0].decision.decision, 'ready');
  const secondEvidence = await operator.industrial('industrial.acceptance.submit', {
    orderId: firstId, specId: spec.id, unitId: 'piece-02', supplierId,
    measuredMicrometers: 10040, uncertaintyMicrometers: 20,
    calibrationValid: true, identityVerified: true, independentMeasurement: true,
    source: 'Instrument file 2026-11-19/02', calibrationRef: 'calibration-01',
  }, { expectedRevision: owner.rules.revision });
  assert.equal(secondEvidence.status, 200);
  const secondEvidenceId = operator.rules.rules.evidence.at(-1).id;
  await verifier.loadRules();
  assert.equal((await verifier.industrial('industrial.acceptance.review', {
    evidenceId: secondEvidenceId, approved: true, note: 'Second workpiece independently reviewed.',
  })).status, 200);
  await owner.loadRules();
  assert.equal((await owner.industrial('industrial.license.revoke', {
    grantId, reason: 'New drawing revision supersedes this license.',
  })).status, 200);
  await operator.loadRules();
  assert.equal((await operator.industrial('industrial.license.use', {
    ...usage, unitId: 'piece-02',
  })).status, 409);
  const ledger = await owner.bootstrap();
  assert.equal(ledger.body.ledger.length, 0);
  assert.equal((await owner.loadRules()).body.rules.licenseUses.length, 1);

  await app.close();
  ({ app, origin } = await start(dbPath));
  const reopened = client(origin);
  await reopened.login();
  assert.equal((await reopened.loadRules()).body.rules.licenseUses.length, 1);
  assert.equal(reopened.rules.rules.firstArticles[0].decision.decision, 'ready');
  assert.equal(reopened.rules.rules.events.length > 7, true);
  const second = await reopened.command('workspace.create', { name: 'Separate factory' });
  assert.equal(second.status, 200);
  assert.notEqual(reopened.state.workspace.id, originalWorkspace);
  assert.equal((await reopened.loadRules()).body.rules.licenseUses.length, 0);
  await reopened.bootstrap();
  assert.equal((await reopened.command('workspace.select', { workspaceId: originalWorkspace })).status, 200);
  assert.equal((await reopened.loadRules()).body.rules.licenseUses.length, 1);
});
