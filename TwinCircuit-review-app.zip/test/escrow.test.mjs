import test from 'node:test';
import assert from 'node:assert/strict';
import ganache from 'ganache';
import {BrowserProvider,ContractFactory,Contract,keccak256,toUtf8Bytes} from 'ethers';
import {compilePayments} from '../scripts/compile-payments.mjs';
import {createPaymentsClient,decodeReceipt,decodeDealResult,encodeEscrowCall,dealIdFor,escrowRuntimeMatches} from '../public/payments.mjs';

const hash=text=>keccak256(toUtf8Bytes(text));
const AMOUNTS=[40n,20n,15n,15n,10n];
let artifacts;
async function fixture({adversarial=false}={}) {
  artifacts??=await compilePayments({write:false});
  const eip=ganache.provider({chain:{chainId:1337,hardfork:'shanghai'},wallet:{totalAccounts:12},logging:{quiet:true}});
  const provider=new BrowserProvider(eip);provider.pollingInterval=10;
  const signers=await Promise.all(Array.from({length:10},(_,i)=>provider.getSigner(i)));
  const addresses=await Promise.all(signers.map(s=>s.getAddress()));
  const tokenArtifact=artifacts[adversarial?'AdversarialMockToken':'MockToken'];
  const token=await new ContractFactory(tokenArtifact.abi,tokenArtifact.bytecode,signers[0]).deploy(...(adversarial?[]:[8]));await token.waitForDeployment();
  const escrow=await new ContractFactory(artifacts.TwinCircuitEscrow.abi,artifacts.TwinCircuitEscrow.bytecode,signers[0]).deploy(await token.getAddress(),60);await escrow.waitForDeployment();
  await (await token.mint(addresses[0],1000000n)).wait();
  const now=Number((await provider.getBlock('latest')).timestamp);
  const plan={orderKey:hash('order-'+Math.random()),termsHash:hash('frozen-terms'),evidenceHash:hash('accepted-external-evidence'),verifier:addresses[1],recipients:addresses.slice(2,7),amounts:AMOUNTS,amount:100n,refundAfter:now+7200};
  const id=await escrow.dealIdFor(addresses[0],plan.orderKey);
  const args=p=>[p.orderKey,p.termsHash,p.evidenceHash,p.verifier,p.recipients,p.amounts,p.amount,p.refundAfter];
  const fund=async(p=plan)=>{await(await token.approve(await escrow.getAddress(),p.amount)).wait();return (await escrow.fund(...args(p))).wait();};
  const advance=async seconds=>{await eip.request({method:'evm_increaseTime',params:[seconds]});await eip.request({method:'evm_mine',params:[]});};
  return {eip,provider,signers,addresses,token,escrow,plan,id,args,fund,advance,close:async()=>{provider.destroy();await eip.disconnect();}};
}
test('real local EVM: frozen terms, verifier acceptance, delayed atomic five-way release and no double payout',async()=>{
  const f=await fixture();try{
    const receipt=await f.fund();const events=decodeReceipt(receipt,{address:await f.escrow.getAddress()});assert.equal(events[0].event,'DealFunded');assert.equal(events[0].args.amount,'100');assert.equal(events[0].args.evidenceHash,f.plan.evidenceHash);assert.equal(dealIdFor(f.addresses[0],f.plan.orderKey),f.id);
    assert.equal(await f.escrow.totalLocked(),100n);assert.equal(await f.token.balanceOf(await f.escrow.getAddress()),100n);
    const raw=await f.eip.request({method:'eth_call',params:[{to:await f.escrow.getAddress(),data:encodeEscrowCall('getDeal',[f.id])},'latest']});const d=decodeDealResult(raw);assert.equal(d.stateName,'Funded');assert.deepEqual(d.amounts,['40','20','15','15','10']);
    await assert.rejects(()=>f.escrow.release(f.id));await assert.rejects(()=>f.escrow.accept(f.id,f.plan.termsHash,f.plan.evidenceHash));
    await assert.rejects(()=>f.escrow.connect(f.signers[1]).accept(f.id,hash('wrong'),f.plan.evidenceHash));
    await assert.rejects(()=>f.escrow.connect(f.signers[1]).accept(f.id,f.plan.termsHash,hash('swapped evidence')));
    await(await f.escrow.connect(f.signers[1]).accept(f.id,f.plan.termsHash,f.plan.evidenceHash)).wait();await assert.rejects(()=>f.escrow.release(f.id));
    await f.advance(61);const paid=await(await f.escrow.connect(f.signers[8]).release(f.id,{gasLimit:1000000})).wait();assert.ok(decodeReceipt(paid).some(e=>e.event==='DealReleased'));
    for(let i=0;i<5;i++)assert.equal(await f.token.balanceOf(f.plan.recipients[i]),AMOUNTS[i]);
    assert.equal(await f.escrow.totalLocked(),0n);assert.equal((await f.escrow.getDeal(f.id)).state,4n);await assert.rejects(()=>f.escrow.release(f.id));await assert.rejects(()=>f.escrow.timeoutRefund(f.id));
    assert.equal(escrowRuntimeMatches(await f.provider.getCode(await f.escrow.getAddress())),true);
  }finally{await f.close();}
});
test('real EVM rejects wrong sum, duplicate recipients, same buyer/verifier, missing hash, expired deadline and repeated funding',async()=>{
  const f=await fixture();try{await(await f.token.approve(await f.escrow.getAddress(),1000n)).wait();
    for(const p of [{...f.plan,amount:101n},{...f.plan,verifier:f.addresses[0]},{...f.plan,recipients:Array(5).fill(f.addresses[2])},{...f.plan,evidenceHash:'0x'+'0'.repeat(64)},{...f.plan,refundAfter:1}])await assert.rejects(()=>f.escrow.fund(...f.args(p)));
    await f.fund();await assert.rejects(()=>f.escrow.fund(...f.args(f.plan)));assert.equal(await f.token.balanceOf(await f.escrow.getAddress()),100n);
  }finally{await f.close();}
});
test('real EVM dispute freezes accepted payouts and requires both parties for a full refund; consent can be revoked',async()=>{
  const f=await fixture();try{const initial=await f.token.balanceOf(f.addresses[0]);await f.fund();await(await f.escrow.connect(f.signers[1]).accept(f.id,f.plan.termsHash,f.plan.evidenceHash)).wait();await(await f.escrow.dispute(f.id,hash('measurement disputed'))).wait();
    await f.advance(10000);await assert.rejects(()=>f.escrow.release(f.id));await assert.rejects(()=>f.escrow.timeoutRefund(f.id));await assert.rejects(()=>f.escrow.connect(f.signers[8]).consentRefund(f.id,f.plan.termsHash));
    await(await f.escrow.consentRefund(f.id,f.plan.termsHash)).wait();assert.equal((await f.escrow.getDeal(f.id)).state,3n);
    await(await f.escrow.revokeRefundConsent(f.id)).wait();assert.equal((await f.escrow.getDeal(f.id)).refundApprovals,0n);
    await(await f.escrow.connect(f.signers[1]).consentRefund(f.id,f.plan.termsHash)).wait();assert.equal((await f.escrow.getDeal(f.id)).state,3n);
    const refunded=await(await f.escrow.consentRefund(f.id,f.plan.termsHash)).wait();assert.ok(decodeReceipt(refunded).some(e=>e.event==='DealRefunded'&&!e.args.timedOut));assert.equal(await f.token.balanceOf(f.addresses[0]),initial);assert.equal((await f.escrow.getDeal(f.id)).state,5n);assert.equal(await f.escrow.totalLocked(),0n);await assert.rejects(()=>f.escrow.consentRefund(f.id,f.plan.termsHash));
  }finally{await f.close();}
});
test('real EVM timeout refunds only original buyer on unaccepted undisputed deal',async()=>{
  const f=await fixture();try{await f.fund();await assert.rejects(()=>f.escrow.timeoutRefund(f.id));await f.advance(7201);await assert.rejects(()=>f.escrow.connect(f.signers[1]).accept(f.id,f.plan.termsHash,f.plan.evidenceHash));await assert.rejects(()=>f.escrow.connect(f.signers[8]).timeoutRefund(f.id));const r=await(await f.escrow.timeoutRefund(f.id,{gasLimit:500000})).wait();assert.ok(decodeReceipt(r).some(e=>e.event==='DealRefunded'&&e.args.timedOut));assert.equal(await f.escrow.totalLocked(),0n);
  }finally{await f.close();}
});
test('real EVM rejects fee-on-transfer deposits and atomically rolls back a taxed or blocked five-way payout',async()=>{
  const f=await fixture({adversarial:true});try{await(await f.token.setTax(1000)).wait();await assert.rejects(()=>f.fund());assert.equal((await f.escrow.getDeal(f.id)).state,0n);assert.equal(await f.escrow.totalLocked(),0n);
    await(await f.token.setTax(0)).wait();await f.fund();await(await f.escrow.connect(f.signers[1]).accept(f.id,f.plan.termsHash,f.plan.evidenceHash)).wait();await f.advance(61);
    await(await f.token.setBlocked(f.plan.recipients[2])).wait();await assert.rejects(async()=>{await(await f.escrow.release(f.id,{gasLimit:1000000})).wait();});for(const a of f.plan.recipients)assert.equal(await f.token.balanceOf(a),0n);assert.equal((await f.escrow.getDeal(f.id)).state,2n);assert.equal(await f.escrow.totalLocked(),100n);
    await(await f.token.setBlocked('0x0000000000000000000000000000000000000000')).wait();await(await f.token.setTax(1000)).wait();await assert.rejects(async()=>{await(await f.escrow.release(f.id,{gasLimit:1000000})).wait();});assert.equal(await f.token.balanceOf(f.plan.recipients[0]),0n);assert.equal(await f.escrow.totalLocked(),100n);
  }finally{await f.close();}
});
test('real EVM token callback is blocked by ReentrancyGuard and cannot double-release',async()=>{
  const f=await fixture({adversarial:true});try{await(await f.token.setCallback(await f.escrow.getAddress(),f.escrow.interface.encodeFunctionData('release',[f.id]))).wait();await f.fund();assert.equal(await f.token.callbackAttempted(),true);assert.equal(await f.token.callbackSucceeded(),false);assert.equal(await f.token.callbackResult(),hash('ReentrancyGuardReentrantCall()').slice(0,10));
    await(await f.escrow.connect(f.signers[1]).accept(f.id,f.plan.termsHash,f.plan.evidenceHash)).wait();await f.advance(61);await(await f.escrow.release(f.id,{gasLimit:1000000})).wait();for(let i=0;i<5;i++)assert.equal(await f.token.balanceOf(f.plan.recipients[i]),AMOUNTS[i]);assert.equal(await f.escrow.totalLocked(),0n);
  }finally{await f.close();}
});

function walletAdapter(eip,accounts){let current=accounts[0];const listeners=new Map();return {on:(e,fn)=>{const set=listeners.get(e)||new Set();set.add(fn);listeners.set(e,set);},removeListener:(e,fn)=>listeners.get(e)?.delete(fn),select(address){current=address;for(const fn of listeners.get('accountsChanged')||[])fn([current]);},request:q=>q.method==='eth_accounts'?Promise.resolve([current]):eip.request(q)};}
test('actual EIP-1193 client deploys locally, exact approval/fund/accept/release receipts and frozen events verified',async()=>{
  const f=await fixture();const clients=[];try{const wallet=walletAdapter(f.eip,f.addresses),config={chainId:1337,tokenAddress:await f.token.getAddress(),tokenDecimals:8,expectedSymbol:'TEST',confirmations:1};const reviews=[];const opts={provider:wallet,onReview:async r=>{assert.ok(Object.isFrozen(r)&&Object.isFrozen(r.transaction));assert.throws(()=>{r.transaction.value='0x1';},TypeError);reviews.push(r);return true;},pollMs:1,timeoutMs:5000};let client=createPaymentsClient(config,opts);clients.push(client);
    const deployed=await client.deployEscrow({releaseDelay:60,onSubmitted:async()=>{throw new Error('notification service unavailable');}});assert.equal(deployed.confirmed,true);assert.equal(deployed.runtimeVerified,true);assert.equal(deployed.notificationError,'notification service unavailable');assert.equal(reviews[0].action,'deploy-escrow');assert.ok(reviews[0].transaction.data.length>10000);assert.match(reviews[0].warning,/无限期冻结/);assert.match(reviews[0].warning,/未通过独立安全审计/);
    client=createPaymentsClient({...config,escrowAddress:deployed.escrowAddress},opts);clients.push(client);const plan={...f.plan,claimedBuyer:f.addresses[0],amount:'100',recipients:f.plan.recipients.map((address,i)=>({address,amount:String(AMOUNTS[i])})),tokenAddress:config.tokenAddress,tokenDecimals:8,escrowAddress:deployed.escrowAddress,chainId:1337};
    await(await f.token.approve(deployed.escrowAddress,999n)).wait();const approval=await client.approveExact({amount:'100'});assert.equal(approval.confirmed,true);assert.deepEqual(reviews.slice(-2).map(r=>r.action),['clear-allowance','approve-exact']);assert.equal(await f.token.allowance(f.addresses[0],deployed.escrowAddress),100n);
    const funded=await client.fund(plan);assert.equal(funded.confirmed,true);assert.equal(funded.deal.stateName,'Funded');assert.equal(await f.token.allowance(f.addresses[0],deployed.escrowAddress),0n);
    wallet.select(f.addresses[1]);const accepted=await client.accept({dealId:funded.dealId,termsHash:plan.termsHash,evidenceHash:plan.evidenceHash});assert.equal(accepted.deal.stateName,'Accepted');
    await f.advance(61);const released=await client.release({dealId:funded.dealId});assert.equal(released.deal.stateName,'Released');assert.ok(released.events.some(e=>e.event==='DealReleased'&&e.args.evidenceHash===plan.evidenceHash));
    for(let i=0;i<5;i++)assert.equal(await f.token.balanceOf(plan.recipients[i].address),AMOUNTS[i]);
  }finally{clients.forEach(c=>c.dispose());await f.close();}
});
test('client cannot use wrong decimals/chain; rejection and review account changes send no transaction',async()=>{
  const f=await fixture();const clients=[];try{const wallet=walletAdapter(f.eip,f.addresses),config={chainId:1337,tokenAddress:await f.token.getAddress(),escrowAddress:await f.escrow.getAddress(),tokenDecimals:8,confirmations:1};
    let bad=createPaymentsClient({...config,tokenDecimals:18},{provider:wallet});clients.push(bad);await assert.rejects(()=>bad.readConfiguration(),/decimals/);
    bad=createPaymentsClient({...config,chainId:196},{provider:wallet});clients.push(bad);await assert.rejects(()=>bad.readConfiguration(),/chain/);
    let client=createPaymentsClient(config,{provider:wallet,onReview:async()=>false});clients.push(client);const cancelled=await client.approveExact({amount:'100'});assert.equal(cancelled.cancelled,true);assert.equal(await f.token.allowance(f.addresses[0],config.escrowAddress),0n);
    client=createPaymentsClient(config,{provider:wallet,onReview:async()=>{wallet.select(f.addresses[1]);return true;}});clients.push(client);await assert.rejects(()=>client.approveExact({amount:'100'}),/changed after review/);assert.equal(await f.token.allowance(f.addresses[0],config.escrowAddress),0n);
  }finally{clients.forEach(c=>c.dispose());await f.close();}
});
test('fund binds the server claimedBuyer and original preflight wallet snapshot before any signature',async()=>{
  const f=await fixture();const clients=[];try{
    const wallet=walletAdapter(f.eip,f.addresses),config={chainId:1337,tokenAddress:await f.token.getAddress(),escrowAddress:await f.escrow.getAddress(),tokenDecimals:8,confirmations:1};
    const plan={...f.plan,claimedBuyer:f.addresses[0],amount:'100',recipients:f.plan.recipients.map((address,i)=>({address,amount:String(AMOUNTS[i])})),...config};
    await(await f.token.approve(config.escrowAddress,100n)).wait();await(await f.token.mint(f.addresses[8],100n)).wait();await(await f.token.connect(f.signers[8]).approve(config.escrowAddress,100n)).wait();
    let reviewed=0,sent=0,trigger=false;const originalRequest=wallet.request;
    wallet.request=async q=>{if(q.method==='eth_sendTransaction')sent++;const result=await originalRequest(q);if(trigger&&q.method==='eth_call'&&q.params[0].data.startsWith(encodeEscrowCall('getDeal',[f.id]).slice(0,10))){trigger=false;wallet.select(f.addresses[8]);}return result;};
    const client=createPaymentsClient(config,{provider:wallet,onReview:async()=>{reviewed++;return true;}});clients.push(client);
    wallet.select(f.addresses[8]);await assert.rejects(()=>client.fund(plan),/Buyer differs/);assert.equal(sent,0);assert.equal(reviewed,0);
    wallet.select(f.addresses[0]);trigger=true;await assert.rejects(()=>client.fund(plan),/changed after review/);assert.equal(sent,0);assert.equal(reviewed,0);
    assert.equal((await f.escrow.getDeal(f.id)).state,0n);assert.equal(await f.token.balanceOf(config.escrowAddress),0n);assert.equal(await f.token.allowance(f.addresses[0],config.escrowAddress),100n);assert.equal(await f.token.allowance(f.addresses[8],config.escrowAddress),100n);
    wallet.select(f.addresses[0]);await assert.rejects(()=>client.fund({...plan,claimedBuyer:undefined}),/must name the claimed buyer/);
  }finally{clients.forEach(c=>c.dispose());await f.close();}
});
test('fund receipt remains successful if the verifier accepts during its confirmation window',async()=>{
  const f=await fixture();let client;try{
    const wallet=walletAdapter(f.eip,f.addresses),config={chainId:1337,tokenAddress:await f.token.getAddress(),escrowAddress:await f.escrow.getAddress(),tokenDecimals:8,confirmations:1};
    const plan={...f.plan,claimedBuyer:f.addresses[0],amount:'100',recipients:f.plan.recipients.map((address,i)=>({address,amount:String(AMOUNTS[i])})),...config};
    await(await f.token.approve(config.escrowAddress,100n)).wait();
    client=createPaymentsClient(config,{provider:wallet,onReview:async()=>true,pollMs:1,timeoutMs:5000});
    const result=await client.fund(plan,{onSubmitted:async()=>{await(await f.escrow.connect(f.signers[1]).accept(f.id,plan.termsHash,plan.evidenceHash)).wait();}});
    assert.equal(result.confirmed,true);assert.equal(result.fundingEventVerified,true);assert.equal(result.currentState,'Accepted');assert.equal(result.deal.stateName,'Accepted');assert.equal(await f.token.balanceOf(config.escrowAddress),100n);
    await assert.rejects(()=>client.fund(plan),/Approve exactly|already funded/);
  }finally{client?.dispose();await f.close();}
});
