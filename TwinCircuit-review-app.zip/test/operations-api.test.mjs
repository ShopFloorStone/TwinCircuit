import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { createApp } from '../server.mjs';

test('live operations HTTP enforces formal sessions, CSRF, separate owner approval and scoped revocable gateway tokens', async t => {
  const app = createApp({ dbPath: ':memory:', setupToken: 'operations-http-setup', env: {}, log() {} });
  await new Promise(resolve => app.server.listen(0, '127.0.0.1', resolve)); t.after(() => app.close()); const origin = `http://127.0.0.1:${app.server.address().port}`;
  function client() { let cookie = '', csrf; return { async request(path, { method = 'GET', body, headers = {} } = {}) { const response = await fetch(origin + path, { method, headers: { ...(cookie ? { cookie } : {}), ...(method === 'POST' ? { Origin: origin, 'Content-Type': 'application/json', ...(csrf ? { 'X-CSRF-Token': csrf } : {}) } : {}), ...headers }, body: body === undefined ? undefined : JSON.stringify(body) }); const setCookie = response.headers.get('set-cookie'); if (setCookie) cookie = setCookie.split(';')[0]; const data = await response.json(); if (data.csrfToken) csrf = data.csrfToken; return { status: response.status, data }; }, async op(type, payload) { const state = await this.request('/api/operations'); return this.request('/api/operations/command', { method: 'POST', body: { type, payload, expectedRevision: state.data.revision, requestId: randomUUID() } }); } }; }
  const a = client(), b = client(), guest = client();
  assert.equal((await a.request('/api/operations')).status, 401);
  await guest.request('/api/auth/demo', { method: 'POST', body: {} }); assert.equal((await guest.request('/api/operations')).data.error.code, 'LIVE_DEMO_FORBIDDEN');
  await a.request('/api/auth/setup', { method: 'POST', body: { setupToken: 'operations-http-setup', name: 'Owner A', email: 'http-a@example.com', password: 'a secure HTTP owner password' } });
  let state = (await a.request('/api/bootstrap')).data;
  const invite = (await a.request('/api/command', { method: 'POST', body: { type: 'member.invite', payload: { email: 'http-b@example.com', role: 'owner' }, expectedRevision: state.revision, requestId: randomUUID() } })).data;
  await b.request('/api/auth/register', { method: 'POST', body: { token: invite.invitation.token, name: 'Owner B', email: 'http-b@example.com', password: 'another secure HTTP owner password' } });
  const forbidden = await a.request('/api/operations/command', { method: 'POST', body: { type: 'device.register', payload: {}, expectedRevision: 0, requestId: randomUUID() }, headers: { 'X-CSRF-Token': 'wrong' } }); assert.equal(forbidden.data.error.code, 'CSRF_REJECTED');
  const registration = await a.op('device.register', { name: 'S3 LED', protocol: 'esp32-serial', endpoint: 'Gateway-local COM allowlist', signals: [{ name: 'led', type: 'boolean', critical: true }] }); assert.equal(registration.status, 200); const { deviceId, deviceToken } = registration.data;
  await a.op('device.arm', { deviceId, seconds: 120, reason: 'Owner present at bench' }); const submitted = await a.op('job.submit', { deviceId, signal: 'led', value: true, expectedDeviceRevision: 0 }); const jobId = submitted.data.jobId;
  assert.equal((await a.op('job.approve', { jobId, reason: 'Self approve' })).data.error.code, 'SELF_APPROVAL'); assert.equal((await b.op('job.approve', { jobId, reason: 'Second owner supervised approval' })).status, 200);
  const gateway = (path, body, token = deviceToken) => fetch(origin + path, { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const pull = await gateway('/api/gateway/pull', { deviceId, state: { revision: 0, armedUntil: Date.now() + 60000, blocked: false, connected: true, physicalArmed: true, physicalPermit: true } }); assert.equal(pull.status, 200); const delivery = (await pull.json()).job; assert.equal(delivery.state, 'claimed');
  const result = { deviceId, jobId, nonce: delivery.nonce, status: 'succeeded', result: { executed: true, revision: 1, signal: 'led', evidence: { quality: 'GPIO_READBACK', readback: true } } };
  assert.equal((await gateway('/api/gateway/result', result)).status, 200); assert.equal((await gateway('/api/gateway/result', result)).status, 200);
  const accountAttempt = await fetch(origin + '/api/bootstrap', { headers: { Authorization: `Bearer ${deviceToken}` } }); assert.equal(accountAttempt.status, 401);
  await a.op('device.revoke', { deviceId, reason: 'Test finished and hardware disconnected' }); assert.equal((await gateway('/api/gateway/pull', { deviceId, state: { revision: 1, armedUntil: 0, blocked: false, connected: false } })).status, 401);
  state = (await a.request('/api/bootstrap')).data; assert.equal(state.orders[0].batches.length, 0); assert.equal(state.ledger.length, 0);
});
