// SPDX-License-Identifier: MIT
pragma solidity 0.8.38;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

/// @notice Non-upgradeable escrow for ONE explicitly selected standard ERC-20.
/// @dev No owner, proxy, mint, arbitrary call, rescue or hidden withdrawal path.
/// Acceptance records the designated verifier's decision; it proves no physical fact.
/// Disputed funds can remain locked indefinitely unless buyer and verifier agree to refund.
contract TwinCircuitEscrow is ReentrancyGuard {
    using SafeERC20 for IERC20;

    enum State { None, Funded, Accepted, Disputed, Released, Refunded }
    struct Deal {
        address buyer;
        address verifier;
        bytes32 orderKey;
        bytes32 termsHash;
        bytes32 evidenceHash;
        uint256 amount;
        uint64 refundAfter;
        uint64 releaseAfter;
        State state;
        uint8 refundApprovals;
        address[5] recipients;
        uint256[5] amounts;
    }
    IERC20 public immutable token;
    uint256 public immutable deploymentChainId;
    uint64 public immutable releaseDelay;
    uint256 public totalLocked;
    mapping(bytes32 => Deal) private _deals;

    error InvalidConfiguration();
    error InvalidTerms();
    error InvalidParty();
    error InvalidAmount();
    error InvalidDeadline();
    error DealAlreadyExists();
    error UnknownDeal();
    error WrongState();
    error NotBuyer();
    error NotVerifier();
    error NotParty();
    error TermsMismatch();
    error DeadlineNotReached();
    error DeadlinePassed();
    error TokenAmountMismatch();
    error Insolvent();

    event DealFunded(bytes32 indexed dealId, bytes32 indexed orderKey, address indexed buyer,
        address token, bytes32 termsHash, bytes32 evidenceHash, address verifier, uint256 amount,
        uint64 refundAfter, address[5] recipients, uint256[5] amounts);
    event DealAccepted(bytes32 indexed dealId, address indexed verifier, bytes32 indexed termsHash,
        bytes32 evidenceHash, uint64 releaseAfter);
    event DealDisputed(bytes32 indexed dealId, address indexed by, bytes32 indexed reasonHash);
    event RefundConsent(bytes32 indexed dealId, address indexed by, uint8 approvals);
    event RefundConsentRevoked(bytes32 indexed dealId, address indexed by, uint8 approvals);
    event DealReleased(bytes32 indexed dealId, bytes32 indexed termsHash, address indexed token,
        bytes32 evidenceHash, uint256 amount);
    event DealRefunded(bytes32 indexed dealId, bytes32 indexed termsHash, address indexed token,
        address buyer, uint256 amount, bool timedOut);

    constructor(address tokenAddress, uint64 releaseDelaySeconds) {
        if (tokenAddress == address(0) || tokenAddress.code.length == 0 ||
            releaseDelaySeconds < 60 || releaseDelaySeconds > 7 days) revert InvalidConfiguration();
        token = IERC20(tokenAddress);
        releaseDelay = releaseDelaySeconds;
        deploymentChainId = block.chainid;
    }

    function dealIdFor(address buyer, bytes32 orderKey) public pure returns (bytes32) {
        return keccak256(abi.encode(buyer, orderKey));
    }

    function getDeal(bytes32 dealId) external view returns (Deal memory) { return _deals[dealId]; }

    /// @notice Pull exactly amount from the caller and freeze all financial terms.
    /// @dev Caller first approves this contract for the exact amount in a separate wallet transaction.
    function fund(bytes32 orderKey, bytes32 termsHash, bytes32 evidenceHash, address verifier,
        address[5] calldata recipients, uint256[5] calldata amounts,
        uint256 amount, uint64 refundAfter) external nonReentrant returns (bytes32 dealId)
    {
        if (orderKey == bytes32(0) || termsHash == bytes32(0) || evidenceHash == bytes32(0)) revert InvalidTerms();
        if (msg.sender == address(token) || verifier == address(0) || verifier == msg.sender ||
            verifier == address(this) || verifier == address(token)) revert InvalidParty();
        if (amount == 0) revert InvalidAmount();
        if (refundAfter < block.timestamp + 1 hours || refundAfter > block.timestamp + 365 days) revert InvalidDeadline();
        uint256 sum;
        for (uint256 i; i < 5; ++i) {
            if (recipients[i] == address(0) || recipients[i] == address(this) || recipients[i] == address(token)) revert InvalidParty();
            for (uint256 j; j < i; ++j) if (recipients[i] == recipients[j]) revert InvalidParty();
            sum += amounts[i];
        }
        if (sum != amount) revert InvalidAmount();
        dealId = dealIdFor(msg.sender, orderKey);
        if (_deals[dealId].state != State.None) revert DealAlreadyExists();
        _assertSolvent();
        _deals[dealId] = Deal({buyer: msg.sender, verifier: verifier, orderKey: orderKey,
            termsHash: termsHash, evidenceHash: evidenceHash, amount: amount,
            refundAfter: refundAfter, releaseAfter: 0, state: State.Funded,
            refundApprovals: 0, recipients: recipients, amounts: amounts});
        totalLocked += amount;
        uint256 escrowBefore = token.balanceOf(address(this));
        uint256 buyerBefore = token.balanceOf(msg.sender);
        token.safeTransferFrom(msg.sender, address(this), amount);
        if (token.balanceOf(address(this)) != escrowBefore + amount ||
            token.balanceOf(msg.sender) + amount != buyerBefore) revert TokenAmountMismatch();
        _assertSolvent();
        emit DealFunded(dealId, orderKey, msg.sender, address(token), termsHash, evidenceHash, verifier,
            amount, refundAfter, recipients, amounts);
    }

    /// @notice Only the independently named verifier can accept this exact terms/evidence pair.
    function accept(bytes32 dealId, bytes32 termsHash, bytes32 evidenceHash) external nonReentrant {
        Deal storage d = _deal(dealId);
        if (msg.sender != d.verifier) revert NotVerifier();
        if (d.state != State.Funded) revert WrongState();
        if (d.termsHash != termsHash) revert TermsMismatch();
        if (evidenceHash != d.evidenceHash) revert TermsMismatch();
        if (block.timestamp >= d.refundAfter) revert DeadlinePassed();
        d.releaseAfter = uint64(block.timestamp + releaseDelay);
        d.state = State.Accepted;
        emit DealAccepted(dealId, msg.sender, termsHash, evidenceHash, d.releaseAfter);
    }

    /// @notice Either principal can freeze a pending/accepted deal before release executes.
    /// @dev There is no administrative override or automatic timeout in the disputed state.
    function dispute(bytes32 dealId, bytes32 reasonHash) external nonReentrant {
        Deal storage d = _deal(dealId);
        _party(d);
        if (d.state != State.Funded && d.state != State.Accepted) revert WrongState();
        if (reasonHash == bytes32(0)) revert InvalidTerms();
        d.state = State.Disputed;
        emit DealDisputed(dealId, msg.sender, reasonHash);
    }

    /// @notice Anyone may execute the already frozen allocation after verifier acceptance + delay.
    function release(bytes32 dealId) external nonReentrant {
        Deal storage d = _deal(dealId);
        if (d.state != State.Accepted) revert WrongState();
        if (block.timestamp < d.releaseAfter) revert DeadlineNotReached();
        _assertSolvent();
        d.state = State.Released;
        totalLocked -= d.amount;
        for (uint256 i; i < 5; ++i) if (d.amounts[i] != 0) _exactTransfer(d.recipients[i], d.amounts[i]);
        _assertSolvent();
        emit DealReleased(dealId, d.termsHash, address(token), d.evidenceHash, d.amount);
    }

    /// @notice A disputed deal is refunded in full only when BOTH buyer and verifier consent.
    /// @dev The second consent and token refund happen atomically. No partial/custom payout exists.
    function consentRefund(bytes32 dealId, bytes32 termsHash) external nonReentrant {
        Deal storage d = _deal(dealId);
        _party(d);
        if (d.state != State.Disputed) revert WrongState();
        if (d.termsHash != termsHash) revert TermsMismatch();
        d.refundApprovals |= msg.sender == d.buyer ? 1 : 2;
        emit RefundConsent(dealId, msg.sender, d.refundApprovals);
        if (d.refundApprovals == 3) _refund(dealId, d, false);
    }

    function revokeRefundConsent(bytes32 dealId) external nonReentrant {
        Deal storage d = _deal(dealId);
        _party(d);
        if (d.state != State.Disputed) revert WrongState();
        d.refundApprovals &= msg.sender == d.buyer ? 2 : 1;
        emit RefundConsentRevoked(dealId, msg.sender, d.refundApprovals);
    }

    /// @notice Only unaccepted AND undisputed funds can time out to their original buyer.
    function timeoutRefund(bytes32 dealId) external nonReentrant {
        Deal storage d = _deal(dealId);
        if (msg.sender != d.buyer) revert NotBuyer();
        if (d.state != State.Funded) revert WrongState();
        if (block.timestamp < d.refundAfter) revert DeadlineNotReached();
        _refund(dealId, d, true);
    }

    function _refund(bytes32 dealId, Deal storage d, bool timedOut) private {
        _assertSolvent();
        d.state = State.Refunded;
        totalLocked -= d.amount;
        _exactTransfer(d.buyer, d.amount);
        _assertSolvent();
        emit DealRefunded(dealId, d.termsHash, address(token), d.buyer, d.amount, timedOut);
    }
    function _exactTransfer(address recipient, uint256 amount) private {
        uint256 beforeEscrow = token.balanceOf(address(this));
        uint256 beforeRecipient = token.balanceOf(recipient);
        token.safeTransfer(recipient, amount);
        if (token.balanceOf(address(this)) + amount != beforeEscrow ||
            token.balanceOf(recipient) != beforeRecipient + amount) revert TokenAmountMismatch();
    }
    function _assertSolvent() private view { if (token.balanceOf(address(this)) < totalLocked) revert Insolvent(); }
    function _deal(bytes32 id) private view returns (Deal storage d) { d = _deals[id]; if (d.state == State.None) revert UnknownDeal(); }
    function _party(Deal storage d) private view { if (msg.sender != d.buyer && msg.sender != d.verifier) revert NotParty(); }
}
