# TwinCircuit 验收后 ERC-20 托管结算

`TwinCircuitEscrow.sol` 是本项目的独立、不可升级结算合约，不是 TapeOut 上游电路合约。它只有一个构造时冻结的 ERC-20 地址、一条部署链和一个释放等待期，没有管理员、代理、救援提款或任意调用入口。当前代码及测试**未通过独立安全审计**。

应用先完成外部真实批次提交和不同身份的审阅；已验收订单才生成付款计划。最终规格、订单、验收证据、五方地址和原子单位金额在入金时冻结。本模式提供验收后的托管结算，不能作为生产前的预付款资金保障，也不能证明实物质量或设备数据真实。

## 资产和部署配置

- 网络：X Layer 主网，chain ID `196`。
- 用户选择的资产：BEM，地址 `0x60e62efa9405d6873c5deabd4e6cc91c25363952`。
- 实际链上读取的 `symbol()` 为 `BEM`，`decimals()` 为 **8**。不得回退到 18，也不得按旧模拟 USDT 预算换算。金额输入为十进制原子单位字符串；`10000` 原子单位等于 `0.0001 BEM`。
- 本仓库没有预填主网 escrow 地址。实际部署必须经连接钱包逐笔审阅并签名，随后由服务器运营者核验部署并加入地址 allowlist。测试文件里的本地合约地址不是主网地址。
- 浏览器每次操作均核对钱包/read RPC 链 ID、token code、symbol、decimals 和服务器 pin；现有 escrow runtime 必须匹配本地编译结果，并核对不可变 token、部署 chain ID 和等待期。

`public/payments.mjs` 的 `prepareDeploy()` 只准备数据，`deployEscrow()` 显示完整审阅后才调用 EIP-1193 钱包部署。它不会自动授权、入金或分账。任何交易都要求审阅回调明确返回 `true`。部署回执确认后仍需服务器 allowlist，不能仅凭交易 hash 宣称部署成功。

## 冻结条款与状态

订单键为 `dealId = keccak256(abi.encode(buyer, orderKey))`，同一买方和订单键永久不能重复入金。`fund` 冻结 `orderKey`、`termsHash`、`evidenceHash`、独立 `verifier`、总额、退款截止时间以及恰好五个不同收款人的地址和金额。五方金额之和必须等于总额，个别金额可为零。买方必须与验证者不同。不存在修改金额、收款人或证据哈希的方法。

| 状态 | 允许的后续动作 |
| --- | --- |
| Funded | 冻结验证者以相同 terms/evidence 验收；买方或验证者发起争议；超时后买方退款 |
| Accepted | 等待期结束后任何人执行冻结分账；买方或验证者在分账执行前发起争议 |
| Disputed | 买方与验证者分别同意全额退款；任一方可在退款前撤销自己的同意 |
| Released / Refunded | 终态，不可重复执行 |

退款截止时间在入金时必须位于当前时间后 1 小时至 365 天之间。验收必须发生在截止前。释放等待期构造时固定，范围为 60 秒至 7 天，验收后才开始计算。

**争议后没有管理员裁决、自动解冻或单方超时退款。只有买方和验证者双方同意，才把全额原路退回买方；如果双方不再合作，资金可能无限期冻结。** 已验收但未争议的订单不能单方退款；等待期结束后任何人可以执行已冻结分账。链上交易存在先后顺序，争议必须先于释放交易执行才生效。钱包审阅会明确显示这些规则。

## 金额与交易检查

客户端先把现有不同额度 allowance 归零，再授权精确总额；从不授权无限金额。付款计划必须有 `claimedBuyer`，它只是待核实地址声明，入金钱包必须与其一致；客户端贯穿同一账户/网络快照，预检或审阅期间切换账户都必须重新开始。合约使用 OpenZeppelin `SafeERC20` 和 storage `ReentrancyGuard`，入金、每笔出账、退款都检查发送和接收余额的精确增减。收费转账、rebase 等不符合这些余额约束的 token 不受支持。五方分账在一笔交易中执行；第三方收款失败会回滚前两方转账及状态变更。未来代币政策、冻结或管理员行为仍可能令转账无法执行。任何人绕过 `fund` 直接把 token 转入合约，都不会创建订单余额，且没有 rescue 取回入口。

客户端核对成功回执、指定确认数、回执块哈希及实际交易 sender/to/calldata/value，再解码事件并读回合约状态。确认期间若验证者已经验收，成功的入金仍保留其 funding event 证明并返回最新状态，不会误报未入金或自动再次入金。确认数只表示配置的区块确认，不代表绝对经济终局。提交 hash 后超时会返回 pending；失败不记作已支付。后端须独立从配置的 RPC 核对交易、事件、冻结计划和合约状态，不能信任客户端报告。

## 编译和实际 EVM 测试

锁定开发依赖为 Solidity `0.8.38`、OpenZeppelin `5.6.1`、ethers `6.17.0`、Ganache `7.9.2`。编译设置 `optimizer runs=200`、`viaIR=true`、`evmVersion=shanghai`。ABI、创建字节码、runtime 和 immutable offsets 由编译脚本生成。

```sh
pnpm install --frozen-lockfile
pnpm contracts:compile
pnpm test:payments
pnpm contracts:local
node scripts/test-bem-fork.mjs
```

`contracts:local` 只使用进程内开发链和开发 token，结束后开发链即销毁，不接收外部私钥。`MockToken.sol` 的 mint 是开发辅助功能，不可作为真实资产部署。

`test/escrow.test.mjs` 在真实本地 EVM 中编译、部署并执行，覆盖错误金额/重复收款人、买方验证者分离、固定证据、等待期、五方实际余额、重复付款、争议双方退款、撤销同意、超时规则、收费 token 拒收、部分转账回滚、重入尝试以及完整 EIP-1193 部署/精确授权/验收/释放。另检查钱包网络/账户变化、拒绝签名前审阅、metadata pin 和审阅对象不可变。

2026-11-12 额外完成实际 BEM 的只读主网 fork 测试：主网块 `75717294`（`0x4835aae`），BEM 代码 13138 bytes，代码 hash `0xa5cf939c36147adb96885cd1cb73c6baf88490f175e91bb04a30d3600cc520b1`。测试真实读取候选持币账户余额后，将主网代码及 storage fork 到本地 Ganache；BEM 字节码和 BEM storage 不作人为注入。为模拟池账户出金，仅在本地清除了候选持币合约自身的 code，并赋予本地 gas；这不代表持有或获授权操作该账户。

在该本地状态中，实际 BEM 完成 `10000` 原子单位转账、授权、托管入金、独立验收和释放，五方实际增加 `4000/2000/1500/1500/1000` 原子单位，escrow token 余额及 `totalLocked` 归零。上游 64 次 RPC 全是读取，外部 relay 拒绝任何写方法；**主网交易为零**。随包提供[脱敏验证报告](../docs/validation/bem-fork.json)，保留来源报告哈希和本地测试边界。这验证一个固定快照下的基本 ERC-20 转账路径，不能保证未来 token 政策、所有 token 行为或实物验收可信。

## 一手标准依据

- [ERC-20](https://eips.ethereum.org/EIPS/eip-20)：allowance、transfer/transferFrom、可选 metadata。
- [EIP-1193](https://eips.ethereum.org/EIPS/eip-1193)：钱包 request 接口及账户/链变化事件。
- [OpenZeppelin ERC-20 / SafeERC20](https://docs.openzeppelin.com/contracts/5.x/api/token/erc20)：安全调用返回值处理和精确 allowance 操作。
- [OpenZeppelin ReentrancyGuard](https://docs.openzeppelin.com/contracts/5.x/api/utils)：重入保护；本项目使用 storage 版。
- [Solidity 安全事项](https://docs.soliditylang.org/en/latest/security-considerations.html)：外部调用、重入与检查/更新/交互顺序。

上述标准不能代替对本项目的独立合约审计、主网部署验证或工业设备安全认证。
