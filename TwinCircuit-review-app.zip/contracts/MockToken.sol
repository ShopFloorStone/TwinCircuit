// SPDX-License-Identifier: MIT
pragma solidity 0.8.38;
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";

/// @notice DEVELOPMENT ONLY. Unrestricted faucet; never represents BEM or a real asset.
contract MockToken is ERC20 {
    uint8 private immutable _precision;
    constructor(uint8 precision) ERC20("TwinCircuit Local Test Token", "TEST") { _precision = precision; }
    function decimals() public view override returns (uint8) { return _precision; }
    function mint(address to, uint256 amount) external { _mint(to, amount); }
}

/// @dev Test fixture: configurable transfer tax, pause/failure, and reentrant callback.
contract AdversarialMockToken is MockToken {
    uint256 public taxBps;
    address public blockedRecipient;
    address public callbackTarget;
    bytes public callbackData;
    bool public callbackAttempted;
    bool public callbackSucceeded;
    bytes public callbackResult;
    bool private _calling;
    constructor() MockToken(6) {}
    function setTax(uint256 bps) external { require(bps <= 10000); taxBps = bps; }
    function setBlocked(address recipient) external { blockedRecipient = recipient; }
    function setCallback(address target, bytes calldata data) external { callbackTarget = target; callbackData = data; callbackAttempted = false; callbackSucceeded = false; }
    function _update(address from, address to, uint256 value) internal override {
        require(to == address(0) || to != blockedRecipient, "recipient blocked");
        if (from != address(0) && to != address(0) && taxBps != 0) {
            uint256 fee = value * taxBps / 10000;
            super._update(from, address(0), fee);
            super._update(from, to, value - fee);
        } else super._update(from, to, value);
        if (!_calling && callbackTarget != address(0) && from != address(0) && to != address(0)) {
            _calling = true;
            callbackAttempted = true;
            (bool ok, bytes memory returned) = callbackTarget.call(callbackData);
            callbackSucceeded = ok;
            callbackResult = returned;
            _calling = false;
        }
    }
}
