# 界面语言 / Interface language

## 中文：使用

TwinCircuit 1.4 提供中文和 English 网站界面。登录页和应用页头均有「中文 / EN」按钮，不需要退出账号或重新加载页面。

- 首次使用默认中文；点击 **EN** 切换英文，点击 **中文** 切回。
- 选择保存在当前浏览器、当前网站来源的 `localStorage`，键名为 `tc.language`，值为 `zh-CN` 或 `en`。重新加载仍使用已保存的选择；清除网站存储后恢复默认中文。若浏览器禁止存储，本次页面仍可切换，但不能保证重载后保留。
- 切换保留当前页面、筛选、所选订单和未提交的页面输入。登录输入仅在当前页面的内存中保留，以便切换语言；成功登录或退出时清除，不将密码或初始化令牌写入语言存储。
- 打开对话框，或正在保存、测试设备、运行任务、处理钱包操作时，会暂时阻止切换并显示提示。先完成操作或关闭对话框，再切换。
- 切换只更新显示，不创建业务命令、设备任务或钱包签名，不改变订单、规格、验收结果或付款计划。

系统文案覆盖登录、能力目录、规格工坊、订单与预约、履约监控、验收与结算、工具与 API、产线接入目录、设备与实际控制、BEM 付款，以及对应的表单、弹窗、状态、错误提示和无障碍标签。日期和界面数字按所选语言的地区格式显示。

用户填写的姓名、工作区名称、供应商或规格描述、来源说明和审阅备注保持原文。地址、标识符、代码、金额、原始 JSON、导出数据和证据也保持原值。英文页面出现这些中文业务内容属于正常情况。钱包扩展和第三方设备软件使用各自的语言设置；本功能不会自动翻译本项目文档、历史记录或证据文件。

1.4 的语言功能不扩大测试证据范围。1.3 的真实 panel 八向量记录仅覆盖 ILI9341 控制器 GRAM 读回，人类独立审阅仍按当时记录单独处理，不能由界面语言切换变成验收。见 [显示工作台](PANEL_WORKCELL.md)、[验证记录](VALIDATION.md) 和 [能力边界](LIMITATIONS.md)。

## English: usage

TwinCircuit 1.4 provides Chinese and English website interfaces. Use **中文 / EN** on the sign-in page or in the application header. You do not need to sign out or reload.

- Chinese is the default. Choose **EN** for English or **中文** for Chinese.
- The choice is stored for this website origin in this browser under the `localStorage` key `tc.language`, with value `zh-CN` or `en`. Reloading keeps the choice; clearing site storage restores the default. If browser storage is blocked, switching still works for the current page, but may not persist after a reload.
- Switching preserves the page, filters, selected order, and unsaved page inputs. Sign-in drafts remain only in page memory while switching language and are cleared after successful sign-in or sign-out. Passwords and setup tokens are not written to language storage.
- A dialog or an active save, device test, task run, or wallet operation temporarily blocks switching. Finish the operation or close the dialog first.
- Switching changes presentation only. It does not create business commands, device tasks, or wallet signatures, or change orders, specifications, acceptance results, or payment plans.

System copy covers sign-in, all nine application pages, tools, forms, dialogs, statuses, error messages, and accessibility labels. Dates and interface numbers use the selected locale.

User-entered names, workspace names, supplier and specification descriptions, source notes, and review comments retain their original language. Addresses, identifiers, code, amounts, raw JSON, exports, and evidence remain unchanged. Chinese business content can therefore appear in an English interface. Wallet extensions and third-party device tools have their own language settings. Project documents, historical records, and evidence files are not automatically translated.

Language support does not expand the scope of hardware validation. The 1.3 physical panel record covers ILI9341 controller GRAM readback; independent human review remains a separate step. Switching language cannot turn evidence into acceptance. See the [panel workcell guide](PANEL_WORKCELL.md), [validation record](VALIDATION.md), and [limitations](LIMITATIONS.md).

## 维护约定 / Maintenance

语言入口为 [`public/i18n.mjs`](../public/i18n.mjs)，静态目录位于 [`public/locales/`](../public/locales/)。目录导出普通对象；中文系统文案作为键，英文作为值。业务对象不存翻译结果。

The entry point is [`public/i18n.mjs`](../public/i18n.mjs), with static catalogs in [`public/locales/`](../public/locales/). Catalogs export plain objects mapping Chinese system copy to English. Do not store translated display text in business objects.

```js
import {t, getLocale, errorMessage} from './i18n.mjs';

// Use a complete message and preserve its interpolation parameters.
const label = t('已预约 {p0} / {p1} 次', {p0: reserved, p1: total});
const date = new Date(timestamp).toLocaleString(getLocale());
const displayedError = errorMessage(error);
```

- 新增可见文案时显式调用 `t()` 并补齐目录。动态文案用完整句子和 `{参数}`，两种语言保留同一组占位参数；不要拼接翻译后的零碎词语。状态、导航和步骤在渲染时翻译，避免加载时缓存为某一种语言。
- 仅翻译已知系统文案，不遍历替换 DOM、业务对象或用户输入。`t()` 不负责 HTML 转义；把用户数据插入 HTML 时仍须按上下文转义。错误仅在显示时用 `errorMessage()`，保留原始错误和业务错误码。
- `setLanguage()` 在改变设置前发出可取消的 `twincircuit:beforelanguagechange`；被阻止时设置完全不变。成功后发出 `twincircuit:languagechange` 以重绘。语言监听器不得调用业务写接口、设备输出或钱包交易。
- 使用 `getMissingTranslations()` 检查英文缺项，并为目录参数、切换后的状态保留和操作期间的阻止逻辑补回归。业务原文和历史 JSON 不应被误当作缺失翻译。

Add every new visible system message to a catalog and call `t()` explicitly. Use complete messages with matching `{parameters}`; translate statuses and navigation at render time. Never bulk-translate user input, DOM content, or business objects. Escape user values for their HTML context; `t()` is not an HTML sanitizer. Use `errorMessage()` only for presentation and retain the original error and code.

`setLanguage()` first emits the cancelable `twincircuit:beforelanguagechange`; cancellation leaves the setting unchanged. A successful change emits `twincircuit:languagechange` for rendering. Language listeners must not issue business writes, device outputs, or wallet transactions. Use `getMissingTranslations()` and regression checks for catalog parameters, preserved inputs, and switching guards; do not classify business text or historical JSON as missing translations.
