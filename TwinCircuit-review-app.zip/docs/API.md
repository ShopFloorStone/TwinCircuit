# API、证据格式与浏览器 SDK（1.3）

本文以本包的 `server.mjs`、`lib/store.mjs`、`lib/domain.mjs`、`lib/operations.mjs` 和 `public/sdk.mjs` 为准。业务与设备/付款各有独立修订号；SDK不能跳过角色、现场许可、证据审核或钱包确认。

## 会话与请求约定

- 浏览器API位于站点同源 `/api/`，使用Cookie会话，无跨域CORS。唯一Bearer例外是设备专用 `/api/gateway/pull` 和 `/api/gateway/result`，不接受管理员Cookie作为现场设备凭据。
- 所有 POST 请求要求 `Content-Type: application/json`，请求体必须是 JSON 对象，最大 1 MiB。实际可提交批次数还受序列化后的 1 MiB 限制。
- 登录、首管理员设置、邀请注册和访客入口要求正确的 `Origin`。浏览器登录后的写请求还须 `X-CSRF-Token`；设备Bearer路由不使用Cookie/CSRF，仅允许绑定设备拉任务/回执。
- Cookie 为 `tc_session`，设置 `HttpOnly; SameSite=Strict`；HTTPS 配置还会设置 `Secure`。浏览器不能读取 Cookie 内容。
- `GET /api/session` 返回 CSRF token；`GET /api/bootstrap` 返回当前工作区、修订号、成员和用户信息。不要把这些响应公开发布。

错误响应：

```json
{ "error": { "code": "REVISION_CONFLICT", "message": "Workspace changed. Refresh before trying again." } }
```

常见状态包括：400 参数无效，401 未登录，403 权限/来源/CSRF 拒绝，404 记录不存在，409 状态/容量/修订冲突，413 超过请求大小，415 请求类型错误，429 限流，502 外部服务失败。

## HTTP 路由

| 方法与路径 | 请求 / 返回 |
| --- | --- |
| `GET /api/session` | 无需登录；返回 `user`、`csrfToken`、`setupRequired`、`workspaceId` |
| `POST /api/auth/setup` | `{setupToken,name,email,password}`；仅在尚无正式账号时允许 |
| `POST /api/auth/login` | `{email,password}` |
| `POST /api/auth/demo` | `{}`；创建隔离的四小时访客工作区 |
| `POST /api/auth/register` | `{token,name,email,password}`；邮箱必须匹配未使用的有效邀请 |
| `POST /api/auth/logout` | `{}`；需要已登录会话与 CSRF |
| `POST /api/auth/password` | `{currentPassword,newPassword}`；仅正式账号；其他旧会话失效 |
| `GET /api/bootstrap` | 已登录；返回当前工作区与成员信息、`revision`、`csrfToken` |
| `POST /api/command` | 见下方统一命令格式；通常返回更新后的 bootstrap |
| `GET /api/export` | 业务导出；三种 format 的范围见下方 |
| `GET /api/integrations` | 已登录；返回服务端 RPC/模型配置状态，不返回密钥 |
| `POST /api/assist` | `{prompt,currentId?,variables?}`；viewer 不可调用；返回建议或不支持原因 |
| `POST /api/rpc` | 受限 JSON-RPC 2.0；需要会话、来源和 CSRF；上游由部署者配置 |
| `GET /api/operations` | 正式成员；返回独立revision、devices/jobs/paymentPlans/events及无密钥配置 |
| `POST /api/operations/command` | 正式owner/operator按命令授权；独立revision与必填requestId |
| `POST /api/gateway/pull` | 设备Bearer token；现场状态与待执行任务，不能创建或审批任务 |
| `POST /api/gateway/result` | 相同设备Bearer token；固定job/nonce结果，重复相同结果返回ACK |

密码要求 12–256 个字符。正式会话最长 12 小时，访客会话最多四小时。邀请有效期七天，由所有者安全分享；应用不会自动发邮件。

## 统一命令格式

```json
{
  "type": "reservation.create",
  "payload": { "orderId": "TC-024", "supplierId": "supplier_a", "quantity": 60 },
  "expectedRevision": 0,
  "requestId": "replace-with-a-unique-id"
}
```

`expectedRevision` 是必填的安全整数，必须等于最新工作区修订号。发生 `REVISION_CONFLICT` 后应重新读取并检查状态，不能盲目覆盖。

`requestId` 可选，建议每次新操作使用 UUID；允许 1–100 个英文字母、数字、`_`、`-`。同一用户重发同一 ID 和同一 `type/payload` 不会再次执行；换了内容会返回 `IDEMPOTENCY_CONFLICT`。同一用户跨工作区也应使用全新 ID。网络结果不确定时，保留原 requestId 与原请求内容重试；不要为同一笔操作重新生成 ID。

SDK 会保留最新修订号。多个命令应 `await` 顺序执行；API 不支持将数组当作事务批量提交。

### 工作区与团队命令

| `type` | `payload` | 权限与条件 |
| --- | --- | --- |
| `workspace.create` | `{name}` | 正式账号；创建并切换到新工作区，调用者为 owner |
| `workspace.select` | `{workspaceId}` | 必须已是目标工作区成员 |
| `member.invite` | `{email,role}` | 正式 owner；role 为 `owner` / `operator` / `verifier` / `viewer`；响应额外含一次性 `invitation.token` |
| `member.join` | `{token}` | 正式账号；邮箱须匹配邀请；切换到目标工作区 |
| `workspace.import` | `{data}` | owner；仅接受未履约的草稿模板，不能导入交付、验收、账本或伪造事件 |
| `workspace.reset` | `{confirmation:"RESET DEMO"}` | 仅访客演示工作区 owner；清空演示变更并保留事件历史 |

导入不是灾备恢复：订单必须为 `draft`、预约与批次为空，完成与验收数量为 0，reports/ledger 为空；供应商、规格、订单各最多 100 条。已履约导出不会被当作可覆盖历史导入。数据库恢复见 [部署手册](DEPLOYMENT.md)。

### 业务命令

以下 O 表示 owner，P 表示 operator，V 表示 verifier。

| `type` | `payload` | 角色与关键前提 |
| --- | --- | --- |
| `supplier.create` | `{name,capacity,mode?,code?,description?,capabilities?}` | O/P；capacity 1–100000；默认 external；capabilities 为 `TC-IO/0.1` / `TC-PANEL/0.1` 非空子集，默认仅 IO |
| `supplier.update` | `{supplierId,name?,capacity?,status?,code?,description?}` | O/P；status `available` / `paused`；容量不能小于已有占用；不能改变 mode |
| `spec.create` | `{name,description?,expression?,variables?,profile?}` | O/P；默认 `TC-IO/0.1`；可选独立 `TC-PANEL/0.1`；variables 若提供须严格为 `["C","M","E"]`；生成 draft |
| `spec.update` | `{specId,name?,description?,expression?,variables?}` | O/P；版本加一并回到 draft；不改变已有订单快照 |
| `spec.publish` | `{specId}` | O/P；仅 draft；登记状态为 `local-only`，不会发链上交易 |
| `order.create` | `{specId,name?,quantity,budgetCents,fees?}` | O/P；规格须已本地发布；quantity 1–1000；budgetCents 1–100000000 |
| `reservation.create` | `{orderId,supplierId,quantity}` | O/P；订单 draft；不超过订单缺口与供应商可用额度 |
| `reservation.confirm` | `{orderId,reservationId,confirmationRef?}` | O/P；预约 pending；外部供应商必须提供确认引用，状态仍标为来源未独立验证 |
| `order.confirm` | `{orderId}` | O/P；有效预约数恰等于订单数量，全部供应商已确认 |
| `order.start` | `{orderId}` | O/P；订单 confirmed 或 paused；全部剩余任务已有确认预约 |
| `execution.advance` | `{orderId,reservationId,count}` | O/P；仅虚拟供应商、running 订单、confirmed 预约；生成模拟数字证据 |
| `order.fault` | `{orderId,reservationId,reason?,cancelRemaining?}` | O/P；暂停运行中的预约；`cancelRemaining:true` 取消未执行额度 |
| `reservation.reassign` | `{orderId,reservationId,supplierId,quantity?}` | O/P；paused 订单与 faulted 原预约；接替供应商须不同；新预约仍需确认 |
| `evidence.submit` | `{orderId,reservationId,records,sourceNote?}` | O/P；仅外部供应商的 running / confirmed 预约，见证据格式 |
| `batch.accept` | `{orderId,batchId,note?}` | O/V；批次 pending，全部实际输出匹配；外部证据需不同提交者且 note 至少 10 字符 |
| `batch.reject` | `{orderId,batchId,note}` | O/V；批次 pending；note 至少 10 字符；外部证据需不同提交者 |
| `order.accept` | `{orderId}` | O/V；全部有效交付足量、所有有效批次已审核通过 |
| `order.settle` | `{orderId}` | O；订单 accepted；生成 `mode:simulation` 内部账本，无实际转账 |

`fees` 若提供，必须恰含 `fulfillment`、`verification`、`design`、`platform` 四个非负整数，其和必须等于 `budgetCents`。显示单位为示例 USDT，`10000` 表示 `100.00`。不传 fees 时按 70% / 15% / 10% 和余数分配；这是内部记账规则。

显示专用 `TC-PANEL/0.1` 例外：固定 CME 表达式 `E && (C || M)`，profile 不可通过更新改变；订单 `budgetCents` 只能为 0（可省略），自动 `currency:"NONE"`、四项 fees 为 0，禁止 `order.settle` 内部模拟分账。真实 BEM 金额在独立付款计划里手动确定，不由零预算推导。供应者能力必须匹配订单快照；GPIO 供应者不能承接 panel profile。

规格表达式由服务器重新编译，最大 300 字符。可选的 `netlistHex` / `circuit` 也必须与服务器从表达式编译的结果一致，不能用上传网表绕过规则。业务 Profile 0.1 固定为三个布尔输入和一个无状态布尔输出；电路工具支持的更广范围不自动成为订单规格。

## 正式设备与付款命令

`GET /api/operations` 返回：

```json
{
  "revision": 0,
  "devices": [], "jobs": [], "paymentPlans": [], "events": [],
  "config": {
    "gateway": { "mode": "outbound-pull", "serverConnectsToDevice": false, "deviceFeedbackIsPhysicalCertification": false },
    "payment": { "configured": false, "chainId": 196, "tokenAddress": "由服务器配置", "decimals": 8, "escrowAllowlist": [], "metadataVerified": false }
  }
}
```

这是结构示意，config还包含其他公开状态，不能作为真实已核验资产响应。演示工作区不能访问live operations；正式viewer/verifier可读，写权限如下。所有operations命令使用同一信封，但 **expectedRevision来自operations，不是业务bootstrap**，requestId必填：

```json
{
  "type": "job.submit",
  "payload": { "deviceId": "实际设备ID", "signal": "led", "value": true, "expectedDeviceRevision": 0 },
  "expectedRevision": 3,
  "requestId": "operation-unique-id"
}
```

每个新操作用新的UUID；相同用户/工作区/requestId与相同type/payload重发只重放，不再次执行；不同内容409。登记设备的重放**不重新展示token**。遇到修订冲突应重新读取和审阅，不能自动覆盖。

| type | payload | 权限与条件 |
| --- | --- | --- |
| `device.register` | `{name,protocol,endpoint?,signals:[{name,type,critical?,min?,max?}]}` | owner；协议 `esp32-serial`（可传serial别名）/`esp32-tft`/`modbus-tcp`/`mqtt`/`opcua`；TFT仅允许一个 `panel_vector:number,min:0,max:7`；critical默认true |
| `panel.workcell.create` | `{deviceId,name?,confirmationRef,expectedBusinessRevision}` | owner；TFT设备且未撤销；原子创建固定panel规格、external工作台、数量1/零预算订单及确认预约，开始等待测量；不发设备任务 |
| `device.arm` | `{deviceId,seconds,reason}` | owner；1–300秒，非uncertain/非revoked；仅网站许可，还需现场许可 |
| `device.disarm` | `{deviceId,reason}` | owner；撤销网站许可；queued过期，已claimed变uncertain |
| `device.revoke` | `{deviceId,reason}` | owner；永久撤销该token，后续拉取/回执拒绝，不代表已发动作被撤回 |
| `device.clearUncertain` | `{deviceId,reason}` | owner；不得有claimed任务；必须现场人工检查，清锁不自动arm、不重置已知revision |
| `job.submit` | `{deviceId,signal,value,expectedDeviceRevision,expiresInSeconds?}` | owner/operator；网站已arm，固定信号与值范围；有效期1–300秒且不越过网站arm；每设备最多一个queued/claimed |
| `job.approve` | `{jobId,reason}` | 另一名owner；不能批准自己提交的任务；critical任务需批准后才能领取 |
| `job.cancel` | `{jobId,reason}` | owner/operator；仅queued，不能把claimed说成未执行而取消 |
| `evidence.fromJobs` | `{deviceId,orderId,reservationId,unit,jobIds,expectedBusinessRevision}` | owner/operator；8个同设备、向量0..7且未消费的成功任务；IO用cme_vector/GPIO_READBACK，panel用panel_vector/DISPLAY_PIXEL_READBACK；不允许跨profile |
| `payment.refreshConfig` | `{}` | owner；从配置RPC核对token元数据，不发送交易 |
| `payment.plan` | `{orderId,escrowAddress,amount,claimedBuyer,verifierAddress,refundAfter,recipients:[{address,amount,label?}]}` | owner；已独立验收外部订单且尚未内部模拟settle；escrow须allowlist并匹配runtime/token/chain/等待期 |
| `payment.verify` | `{planId,transactionHash,action}` | owner；从RPC独立核对成功回执/事件/冻结条款/账户/确认块及合约状态，不信客户端“已支付” |

device.register响应额外含一次性 `deviceId/deviceToken`。服务器仅保存token哈希；bootstrap不返回原token。endpoint是说明文字，服务器不会按它触网；实际地址/COM/寄存器/主题/NodeId/证书映射在现场网关配置。低压S3模板可明确用critical:false；不会把客户端提交的job critical标记当审批依据。

`evidence.fromJobs` 暂仅支持冻结表达式 `E&&(C||M)`。`unit`从0开始；`expectedBusinessRevision`来自业务bootstrap。每个任务须含向量回显、布尔actualY/readback相同、质量GPIO_READBACK及输出尝试记录。实际Y保留设备回传值，expected由订单快照独立生成；失败向量不能通过业务验收。导入成功额外返回 `business`（更新后的业务bootstrap），原始job单次消费；仍是 `external/unverified`，需不同提交者独立审核。

### 显示专用 TFT 工作单

`GET /api/operations` 另返回 `workcells:[{orderId,deviceId,supplierId,specId,reservationId,createdAt}]`。`panel.workcell.create` 成功另含 `workcell` 和 `business`；同设备已有未完成工作单时复用它，返回 `existingWorkcell:true`。这不会增加已完成数量或伪造设备在线。操作与业务修订号仍分别检查；刷新后再发新命令。

登记示例（仅在获准的正式工作区使用）：

```json
{"name":"TFT 显示测试工作台","protocol":"esp32-tft","signals":[{"name":"panel_vector","type":"number","min":0,"max":7,"critical":false}]}
```

现场网关选择独立 `esp32-tft` / `tft-panel` 能力和 panel 专用固件，只有 `panel_vector`，不使用 GPIO4/5/6。服务端 owner 短期放行、本地网关 ARM/写入预算、nonce、期限、修订号、真实双色参考自检仍生效；仅显示任务不依赖 GPIO 物理按钮/许可线。普通 ESP32 GPIO 与工业任务的许可条件保持原样。设备 `state.panelReady:true` 仅是现场自检报告，不是光学验收；服务端须看到同一设备有效许可才能交付任务。

`DISPLAY_PIXEL_READBACK` 的成功证据要求 `profile:"TC-PANEL/0.1"`、`scope:"controller-GRAM-only"`、`protocol:"serial"`、`source:"esp32-s3-panel-testcell"`、相同 readbackQuality、`ok:true/error:null`、布尔 inputs/actualY/readback、硬件 revision 与 bootId/tickMs/receivedAt。`pixel` 固定坐标 `(260,116)`，含 `format:"RGB888"`、`actualColor` uint24 和 `rawRGB` 三个 uint8；每次实际读回的 `references.white` 为 `(20,200)`、`references.black` 为 `(44,200)`，须分别为白 `0xFFFFFF`、黑 `0`。

原始通道按 `(raw & 0xFC) | ((raw & 0xFC) >> 6)` 扩展为8位后重建 RGB888。`actualY` 只能从主像素实际黑/白分类；不从规则预期复制。RAMRD=`0x2E`、读频1MHz、rotation=1。白黑参考不符、位置错、质量伪称GPIO或颜色与原始字节不符均不能记作成功读回；有效但不符规则的布尔结果须保留，独立审核会判失败。

导入保留全部测量原文和八个任务引用。真实 panel 付款还会将记录逐项与服务器不可变、已消费的同订单/件号任务核对；手填外部记录不能冒充此来源。另一身份完成 batch 与 order 验收后，才能创建付款计划。GRAM 读回不证明人眼画面、光学像素、GPIO、负载动作、工厂或工业认证。通用 Modbus/OPC UA/MQTT 回执不能伪装成 IO/panel 八向量履约；新工艺须实现专用 profile 和证据适配。

付款amount/各recipient.amount是**uint256十进制原子单位字符串**，不能传浮点数。BEM精度8，10000原子单位=0.0001 BEM，不按示例USDT预算兑换。恰好五个不同收款地址，不得为token或escrow，五项和精确等于总额；verifier须不同于claimedBuyer/token/escrow；refundAfter是未来1小时至365天的Unix秒。计划冻结哈希及地址金额，已验收资料变化会拒绝验证。`claimedBuyer`只是声明，fund证明核对sender后标记verified，并不证明站内账号拥有该钱包。

`payment.verify.action` 可为 `fund`、`accept`、`release`、`refund`、`dispute`、`consentRefund`、`revokeRefundConsent`、`timeoutRefund`，另保留 `resolve` 作为consentRefund别名。同一交易不能冒充另一动作。服务端接口只验真，不签名或广播；钱包侧操作在 `/payments.mjs`，部署、精确allowance、验收/等待/争议规则见 [ESCROW.md](../contracts/ESCROW.md) 和 [真实接入](REAL_INTEGRATION.md)。

## 现场设备队列协议

设备进程使用 `Authorization: Bearer tc_device_...`；token绑定一个workspace/device。不要复制管理员Cookie或使用首管理员setup token。现场客户端在 [lib/device-client.mjs](../lib/device-client.mjs)，完整适配器契约见 [网关文档](../gateway/README.md)。

pull请求：

```json
{
  "deviceId": "实际设备ID", "agentId": "edge-local",
  "state": {
    "revision": 0, "armedUntil": 1794487200000,
    "blocked": false, "connected": true,
    "physicalArmed": true, "physicalPermit": true
  }
}
```

armedUntil为毫秒时间戳，未arm为0。示例时间只说明格式，不是当前有效许可。pull当前立即返回 `{device,job:null|job}`，网关间隔轮询；waitMs不提供长轮询保证。仅服务器arm、本地arm、设备连接且无blocked、critical已独立批准时返回任务；serial还须physicalArmed/Permit。claimed可重复交付相同身份，不能重复输出。

job包含 `{id,deviceId,nonce,command:'write',payload:{signal,value},expiresAt,revision,idempotencyKey,critical,...}`；expiresAt是毫秒，revision为**预期gateway journal序号**。固件hardwareRevision是另一套序号，不得自动追平。服务器发现gateway序号回退或无claim的异常前跳会返回 `reconciliationRequired:true` 并锁定。

result请求为 `{deviceId,jobId,nonce,status,result,error?}`，status是succeeded/failed/uncertain，result至少包含 `{executed:boolean,revision,evidence}`。executed表示输出尝试已开始，不证明物理动作；未尝试revision不变，attempt后无论成功/拒绝/不确定都为expected+1。serial evidence中的actualY来自固件GPIO读回，不可用网站expected填充。

服务器只在核对后返回 `{ok:true,job}`；同内容重传 `{ok:true,replayed:true,job}`，冲突内容409。网关只有ok:true才持久ACK；ACK丢失重传结果，绝不重发输出。不确定/过期claim及晚到ACK不能恢复可信成功；设备需现场检查、两边人工reconciliation与重新arm。job结果不自动变成商业验收或付款。

1.2可选TFT遥测仅对serial设备显式 `displayTelemetry:true` 开启，默认false不发送新命令。HELLO后另发只读 `TC1|DISPLAY|nonce`，返回 `TC1|DISPLAYSTATE|nonce|JSON`（均追加CRC32）；JSON最多2KiB。原始四字节、driver begin、SPI参数与尺寸原样作为诊断，`visibleVerified`必须false，不能由设备自证实体画面。坏JSON/超时不破坏HELLO，也不改变输出许可。

网关pull的 `state.display` 可含上述诊断或 `{diagnosticStatus:'error',visibleVerified:false,...}`；服务器device.localState.display留存，网页以实际上报字段展示。控制器原始ID非全0/FF仅表示可用响应，不等于验证型号；本地HELLO年龄不证明网络或付款在线。用户照片的人工可见确认另存报告，不能修改设备自报字段。详见 [TFT.md](TFT.md)。

## 外部证据 schema

外部供应商需要先登记、预约、提供确认引用并开始订单。`execution.advance` 不能给外部供应商生成履约；应使用实际采集器生成记录，再提交 `evidence.submit`。

单条记录表示一次交付；每条都包含八组有序测试向量：

```json
{
  "orderId": "TC-024",
  "reservationId": "替换为该订单已确认的外部预约ID",
  "sourceNote": "实际设备、测试环境、操作者、采集批次、证据文件引用与审核范围",
  "records": [
    {
      "unit": 0,
      "source": "替换为实际采集来源引用",
      "tests": [
        { "inputs": { "C": false, "M": false, "E": false }, "expected": { "Y": false }, "actual": { "Y": false } }
      ]
    }
  ]
}
```

上面为结构片段，只有一组 tests，**不能直接提交**。完整八组格式见 [external-evidence.json](../examples/external-evidence.json)。该文件带 `exampleOnly` 和独立 `payload` 包装，所有 actual 值均为讲解占位，不是实际设备证据；不能把它当作生产交付证明。

字段约束：

- `records` 为 1 到订单数量条记录，总量不能超过预约未完成数。
- `unit` 是 0 到 `order.quantity - 1` 的整数；同订单所有未拒绝批次中不能重复。批次被拒绝后可补交对应件号。
- `source` 为 3–500 个字符的来源引用；系统不自动访问或认证该引用。
- `tests` 必须恰含 8 项，顺序与订单冻结规格的 `vectors` 一致。
- `inputs` 恰含 C、M、E；`expected` / `actual` 恰含 Y；所有值必须是 JSON `true` / `false`，字符串或 0/1 不可替代。
- `inputs` 和 `expected` 必须与**订单快照**完全一致。不要假设后来编辑的规格仍适用于旧订单。
- `actual.Y` 应来自实际测量。允许提交不匹配值以保留失败记录，但这种批次不能通过 `batch.accept`。

种子 CME 规格的顺序与预期值：

| C | M | E | Y |
| --- | --- | --- | --- |
| false | false | false | false |
| false | false | true | false |
| false | true | false | false |
| false | true | true | true |
| true | false | false | false |
| true | false | true | true |
| true | true | false | false |
| true | true | true | true |

### 独立验收规则

外部记录入库后仍标记 `external/unverified`，审核状态为 pending。提交者不能审核自己提交的外部批次，即使提交者是 owner。由另一名 owner 或 verifier 检查数字证据并写至少 10 字符的具体审核说明后，才能接受或拒绝。

虚拟演示允许 owner 审核自己生成的虚拟批次，记录 `ownerDemoReview:true`；这不是独立第三方验证。拒绝批次会释放对应已完成数，允许补证；订单已 accepted/settled 后不能回改批次。所有有效交付足量且批次已接受后，才可完成订单验收与内部结算。

数字审核不证明设备身份、测量校准、数据物理来源或工业认证。外部 source、审核说明和采集责任需要应用外的制度与证据支持。

## 导出 format 的真实范围

| URL | 内容与范围 |
| --- | --- |
| `/api/export?format=json` | 整个工作区业务 state 与 `exportedAt`；不含账号密码、会话、团队权限备份 |
| `/api/export?format=json&orderId=TC-024` | 仍是**完整工作区**；orderId 仅校验该订单存在，不会过滤 |
| `/api/export?format=report&orderId=TC-024` | 指定 order、该订单 reports / ledger，以及**整个工作区 events**；需提供有效 orderId |
| `/api/export?format=csv` | 工作区全部批次测试行，包括待审和被拒绝记录，可用 review_status 区分 |
| `/api/export?format=csv&orderId=TC-024` | 指定订单的全部测试行；每件八行 |

CSV 列依次为：`order,supplier,batch,unit,evidence_mode,review_status,C,M,E,expected_Y,actual_Y,submitted_at`。文件使用 UTF-8 BOM；单元格转义以减少公式执行风险。CSV 的布尔值导出为 `true` / `false` 文本。

report 可能包含其他订单的事件。对外分享前检查事件范围与来源引用；它不是自动脱敏的供应商专属报告。业务导出不能代替 SQLite 备份，已履约 JSON 也不支持直接导入回放。

## SDK 导入与使用

SDK 是同源浏览器 ES Module，文件为 `/sdk.mjs`，类名 `TwinCircuitClient`。它不内置登录凭据、不管理 Node.js Cookie jar，也不提供无头设备认证。

在本站已登录的页面代码或开发者控制台中：

```js
const { TwinCircuitClient } = await import('/sdk.mjs');
const client = new TwinCircuitClient();
let state = await client.bootstrap();
console.log(state.workspace.name, state.revision);

// 示例会改变当前工作区；仅在测试工作区执行。
state = await client.command('supplier.create', {
  name: '测试外部采集站', code: 'EXT-01',
  mode: 'external', capacity: 10,
  description: '测试接入口；尚未证明物理设备来源'
}, { requestId: crypto.randomUUID() });
```

方法包括 `session()`、`bootstrap()`、`command(type,payload,options)`、`operations()`、`operationsCommand(type,payload,options)`、`assist(prompt)`、`rpc(payload)`、`exportJSON()`、`report(orderId)` 和通用 JSON `request(path,options)`。业务命令前先bootstrap，设备/付款命令前先operations；SDK维护 `revision` 与 `operationsRevision`，不会自动重试409，也不自动广播钱包交易。

```js
const business = await client.bootstrap();
const live = await client.operations(); // 正式成员；演示访客会被拒绝
console.log(client.revision, client.operationsRevision);

// 仅在正式测试工作区执行：登记记录，不会触网或驱动设备。
const registered = await client.operationsCommand('device.register', {
  name: '低压 LED 测试夹具', protocol: 'esp32-serial',
  signals: [{ name: 'led', type: 'boolean', critical: false }]
}, { requestId: crypto.randomUUID() });
// registered.deviceToken只展示一次，应转移到受保护的现场环境变量，勿写日志。
```

两类command的options均支持 `{requestId,expectedRevision}`，默认使用对应revision。`evidence.fromJobs`额外的payload.expectedBusinessRevision须使用业务revision；响应business成功后SDK同步更新业务revision。一个workspace.select后应再次operations刷新目标工作区状态，禁止复用上个工作区的设备ID或修订号。

读取单订单报告应明确使用 report：

```js
const report = await client.report('TC-024');
const wholeWorkspace = await client.exportJSON();

// CSV 不是 JSON，不能用 client.request() / exportJSON() 解析。
const response = await fetch('/api/export?format=csv&orderId=TC-024', {
  credentials: 'same-origin'
});
if (!response.ok) throw new Error(`HTTP ${response.status}`);
const csv = await response.text();
```

本地编译器与链读取可直接导入，均无需第三方包：

```js
const { compileExpression, truthTable, inspectCircuit } = await import('/engine.mjs');
const circuit = compileExpression('E && (C || M)', {
  variables: ['C', 'M', 'E']
});
console.log(inspectCircuit(circuit));
console.table(truthTable(circuit));

const { checkReferenceNand } = await import('/chain.mjs');
const reference = await checkReferenceNand({ rpc: body => client.rpc(body) });
// 只读现有 NAND 参考；不是本项目新部署的 CME 五门电路。
console.log(reference.scope, reference.ok);
```

## RPC 与可选模型

RPC 允许 `eth_chainId`、`eth_blockNumber`、`eth_getCode`、`eth_call`、`eth_estimateGas`、`eth_getTransactionReceipt`、`eth_getBalance`；参数和 TapeOut 函数 selector 受到服务端约束，不是任意节点代理。每次转发前核对 chain ID 196。上游 URL 只能由服务器环境变量配置。

`eth_estimateGas` 仅允许经过约束的 tapeout 估算；服务器不接受 `eth_sendTransaction` 或私钥。浏览器的钱包发布适配器另行要求用户审阅和签名，交易哈希不能等同已部署且验证完成。

模型未配置时 `assist` 使用规则解析；配置后也只返回受限表达式建议并运行编译检查。用户应确认语义，建议结果不证明需求正确或设备可靠。

## 接入与部署限制

此SDK面向当前登录浏览器。现场设备使用已提供的独立网关和device-scoped Bearer客户端，不复制管理员Cookie，也不能把首管理员token当API key。网关默认设备/输出关闭，须由用户确认真实端口、白名单和现场许可后启用；网站不会自动部署网关或连接真实产线。

当前限流以应用 socket IP 为键，不信任 `X-Forwarded-For`。Caddy 后方的用户会共享代理来源限额；适合小团队试运行，面向大量公开用户时需另行设计可信代理与共享限流。配置、备份和恢复见 [部署手册](DEPLOYMENT.md)。
