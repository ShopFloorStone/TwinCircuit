import http from 'node:http';
import { isIP } from 'node:net';
import { randomBytes } from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { resolve, dirname, extname, sep } from 'node:path';
import { stat } from 'node:fs/promises';
import { gzipSync } from 'node:zlib';
import { Store } from './lib/store.mjs';
import { DomainError } from './lib/domain.mjs';
import { Operations } from './lib/operations.mjs';
import { listFactoryTemplates } from './lib/factory-templates.mjs';
import { createAssetReader, acceptsGzip } from './lib/static-assets.mjs';

const ROOT = dirname(fileURLToPath(import.meta.url));
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.pdf': 'application/pdf', '.webp': 'image/webp', '.txt': 'text/plain; charset=utf-8' };
const cookieSecret = req => { const entry = (req.headers.cookie ?? '').split(';').map(s => s.trim()).find(s => s.startsWith('tc_session=')); return entry?.slice(11); };
const publicUser = a => a ? { id: a.id, name: a.name, email: a.email, role: a.role, isDemo: a.isDemo } : null;
const csvCell = x => { let s = String(x ?? ''); if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`; return `"${s.replaceAll('"', '""')}"`; };

function clientAddress(req, appOrigin) {
  const peer = (req.socket.remoteAddress ?? 'unknown').replace(/^::ffff:/, '');
  // The site's HTTPS proxy connects to the loopback-only HTTP listener and appends the client address.
  if (appOrigin?.startsWith('https://') && !req.socket.encrypted && (peer === '127.0.0.1' || peer === '::1')) {
    const client = String(req.headers['x-forwarded-for'] ?? '').split(',').at(-1).trim();
    if (isIP(client)) return client;
  }
  return peer;
}

export function createApp({ dbPath = resolve(process.env.DATA_DIR ?? resolve(ROOT, 'data'), 'twincircuit.sqlite'), setupToken = process.env.SETUP_TOKEN, publicDir = resolve(ROOT, 'public'), appOrigin = process.env.PUBLIC_ORIGIN ?? process.env.APP_ORIGIN, env = process.env, log = console.log, operationsOptions = {} } = {}) {
  const store = new Store(dbPath);
  const operations = new Operations(store, { env, ...operationsOptions });
  const initialSetupToken = setupToken || randomBytes(24).toString('base64url');
  if (!setupToken && store.setupRequired()) log(`TwinCircuit first administrator setup token: ${initialSetupToken}`);
  const rates = new Map();
  const readAsset = createAssetReader();
  let nextRateSweepAt = 0;
  const rate = (key, limit, windowMs) => {
    const now = Date.now();
    let bucket = rates.get(key);
    if (!bucket || bucket.until < now) {
      bucket = { count: 0, until: now + windowMs };
      rates.set(key, bucket);
    }
    bucket.count++;
    if (rates.size > 5000 && now >= nextRateSweepAt) {
      // Expiration is checked on access above. A sweep only reclaims idle buckets.
      nextRateSweepAt = now + 60_000;
      for (const [id, entry] of rates) {
        if (entry.until < now) rates.delete(id);
      }
    }
    if (bucket.count > limit) throw new DomainError('Too many requests. Try again later.', 429, 'RATE_LIMITED');
  };
  const baseHeaders = res => {
    res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('X-Frame-Options', 'DENY'); res.setHeader('Referrer-Policy', 'same-origin'); res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
  };
  function send(req, res, status, data, type = 'application/json; charset=utf-8', encoded = false) {
    let body = Buffer.isBuffer(data) ? data : Buffer.from(type.startsWith('application/json') ? JSON.stringify(data) : data);
    res.statusCode = status; res.setHeader('Content-Type', type); res.setHeader('Vary', 'Accept-Encoding');
    if (encoded) res.setHeader('Content-Encoding', 'gzip');
    else if (body.length > 1024 && acceptsGzip(req.headers['accept-encoding']) && /^(?:text\/|application\/json|image\/svg)/.test(type)) {
      body = gzipSync(body, { level: 1 });
      res.setHeader('Content-Encoding', 'gzip');
    }
    res.setHeader('Content-Length', body.length); res.end(req.method === 'HEAD' ? undefined : body);
  }
  async function bodyOf(req) {
    if (!/^application\/json(?:\s*;|$)/i.test(req.headers['content-type'] ?? '')) throw new DomainError('Content-Type must be application/json', 415);
    if (Number(req.headers['content-length'] ?? 0) > 1048576) throw new DomainError('Request body is larger than 1 MB', 413);
    const chunks = []; let size = 0;
    for await (const chunk of req) { size += chunk.length; if (size > 1048576) throw new DomainError('Request body is larger than 1 MB', 413); chunks.push(chunk); }
    try { const data = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'); if (!data || typeof data !== 'object' || Array.isArray(data)) throw Error(); return data; } catch { throw new DomainError('Invalid JSON object', 400, 'INVALID_JSON'); }
  }
  function originCheck(req) {
    const expected = appOrigin ? new URL(appOrigin).origin : `${req.socket.encrypted ? 'https' : 'http'}://${req.headers.host}`;
    if (req.headers.origin !== expected || req.headers['sec-fetch-site'] === 'cross-site') throw new DomainError('A same-origin request is required', 403, 'ORIGIN_REJECTED');
  }
  function csrfCheck(req, actor) { originCheck(req); if (req.headers['x-csrf-token'] !== actor.csrfToken) throw new DomainError('CSRF token is missing or invalid', 403, 'CSRF_REJECTED'); }
  function setCookie(res, session) { const secure = env.COOKIE_SECURE === 'true' || appOrigin?.startsWith('https:'); res.setHeader('Set-Cookie', `tc_session=${session.secret}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${Math.floor((session.expiresAt - Date.now()) / 1000)}${secure ? '; Secure' : ''}`); }
  async function integrationModule() { try { return await import('./lib/integrations.mjs'); } catch (e) { if (e.code === 'ERR_MODULE_NOT_FOUND') return null; throw e; } }
  const server = http.createServer(async (req, res) => {
    baseHeaders(res);
    try {
      const url = new URL(req.url, 'http://localhost');
      if (url.pathname.startsWith('/api/')) {
        res.setHeader('Cache-Control', 'no-store');
        const ip = clientAddress(req, appOrigin);
        const actor = store.session(cookieSecret(req));
        // Verified accounts behind the same reverse proxy or factory NAT
        // each retain their own quota, shared across all of their sessions.
        rate(actor && !actor.isDemo ? `user:${actor.id}` : `ip:${ip}`, 3000, 900000);
        if (req.method === 'POST' && ['/api/gateway/pull', '/api/gateway/result'].includes(url.pathname)) {
          rate(`gateway:${ip}`, 3000, 900000);
          const match = /^Bearer (tc_device_[A-Za-z0-9_-]{43})$/.exec(req.headers.authorization ?? '');
          if (!match) throw new DomainError('Device bearer credentials required', 401, 'DEVICE_AUTH_REQUIRED');
          const body = await bodyOf(req);
          const data = url.pathname.endsWith('/pull') ? operations.pull(match[1], body) : operations.result(match[1], body);
          send(req, res, 200, data); return;
        }
        if (req.method === 'GET' && url.pathname === '/api/session') { send(req, res, 200, { user: publicUser(actor), csrfToken: actor?.csrfToken ?? null, setupRequired: store.setupRequired(), workspaceId: actor?.workspaceId ?? null }); return; }
        if (req.method === 'POST' && ['/api/auth/setup', '/api/auth/login', '/api/auth/demo', '/api/auth/register', '/api/auth/signup'].includes(url.pathname)) {
          originCheck(req);
          if (url.pathname === '/api/auth/signup') rate(`signup:${ip}`, 12, 900000);
          else if (url.pathname === '/api/auth/demo') rate(`demo:${ip}`, 20, 3600000);
          else rate(`auth:${ip}`, 12, 900000);
          const body = await bodyOf(req); let session;
          if (url.pathname.endsWith('/setup')) session = store.setup(body, initialSetupToken);
          else if (url.pathname.endsWith('/login')) session = store.login(body);
          else if (url.pathname.endsWith('/register')) session = store.register(body);
          else if (url.pathname.endsWith('/signup')) session = store.signup(body);
          else session = store.demo();
          if (actor) store.logout(actor);
          setCookie(res, session); const signedIn = store.session(session.secret); send(req, res, 200, { ...store.bootstrap(signedIn), setupRequired: false }); return;
        }
        if (!actor) throw new DomainError('Sign in to continue', 401, 'AUTH_REQUIRED');
        if (actor.isDemo) rate(`guest:${actor.id}`, 1000, 900000);
        if (req.method === 'GET' && url.pathname === '/api/bootstrap') { send(req, res, 200, store.bootstrap(actor)); return; }
        if (req.method === 'GET' && url.pathname === '/api/factory-templates') { send(req, res, 200, listFactoryTemplates(store.db, actor, url.searchParams)); return; }
        if (req.method === 'GET' && url.pathname === '/api/industrial-rules') { send(req, res, 200, store.industrialRules(actor)); return; }
        if (req.method === 'GET' && url.pathname === '/api/operations') { send(req, res, 200, operations.bootstrap(actor)); return; }
        if (req.method === 'GET' && url.pathname === '/api/export') {
          const state = store.state(actor), format = url.searchParams.get('format') ?? 'json', orderId = url.searchParams.get('orderId');
          if (orderId && !state.orders.some(o => o.id === orderId)) throw new DomainError('Order not found', 404);
          if (format === 'json') { res.setHeader('Content-Disposition', 'attachment; filename="twincircuit-workspace.json"'); send(req, res, 200, { ...state, exportedAt: new Date().toISOString() }); return; }
          if (format === 'report') { const order = state.orders.find(o => o.id === orderId); if (!order) throw new DomainError('orderId is required', 400); res.setHeader('Content-Disposition', 'attachment; filename="twincircuit-order-report.json"'); send(req, res, 200, { schemaVersion: 1, disclaimer: state.workspace.disclaimer, order, reports: state.reports.filter(r => r.orderId === orderId), events: state.events, ledger: state.ledger.filter(r => r.orderId === orderId) }); return; }
          if (format !== 'csv') throw new DomainError('Supported export formats: json, csv, report', 400);
          const rows = [['order', 'supplier', 'batch', 'unit', 'evidence_mode', 'review_status', 'C', 'M', 'E', 'expected_Y', 'actual_Y', 'submitted_at']];
          for (const o of state.orders.filter(o => !orderId || o.id === orderId)) for (const b of o.batches) for (const r of b.records) for (const test of r.tests) rows.push([o.id, b.supplierId, b.id, r.unit, b.evidenceStatus, b.status, test.inputs.C, test.inputs.M, test.inputs.E, test.expected.Y, test.actual.Y, b.submittedAt]);
          res.setHeader('Content-Disposition', 'attachment; filename="twincircuit-evidence.csv"'); send(req, res, 200, '\uFEFF' + rows.map(r => r.map(csvCell).join(',')).join('\r\n'), 'text/csv; charset=utf-8'); return;
        }
        if (req.method === 'GET' && url.pathname === '/api/integrations') { const m = await integrationModule(); send(req, res, 200, m?.integrationStatus ? m.integrationStatus(env) : { rpc: { configured: false }, ai: { configured: false } }); return; }
        if (req.method !== 'POST') throw new DomainError('API route not found', 404);
        csrfCheck(req, actor); const body = await bodyOf(req);
        if (url.pathname === '/api/auth/logout') { store.logout(actor); res.setHeader('Set-Cookie', 'tc_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0'); send(req, res, 200, { ok: true }); return; }
        if (url.pathname === '/api/auth/password') { store.changePassword(actor, body); send(req, res, 200, { ok: true }); return; }
        if (url.pathname === '/api/command') { send(req, res, 200, store.command(actor, body)); return; }
        if (url.pathname === '/api/industrial-rules/command') { send(req, res, 200, store.industrialCommand(actor, body)); return; }
        if (url.pathname === '/api/operations/command') { send(req, res, 200, await operations.command(actor, body)); return; }
        if (url.pathname === '/api/rpc' || url.pathname === '/api/assist') {
          if (actor.role === 'viewer' && url.pathname === '/api/assist') throw new DomainError('Your role cannot request AI drafts', 403);
          const m = await integrationModule(); if (!m) throw new DomainError('Integration module is not configured', 503);
          const result = url.pathname === '/api/rpc' ? await m.rpcRequest(body, env) : await m.assistSpec(body, env); send(req, res, 200, result); return;
        }
        throw new DomainError('API route not found', 404);
      }
      if (!['GET', 'HEAD'].includes(req.method)) throw new DomainError('Method not allowed', 405);
      let pathname; try { pathname = decodeURIComponent(url.pathname); } catch { throw new DomainError('Invalid path', 400); }
      if (pathname.includes('\0') || pathname.includes('\\') || pathname.split('/').some(p => p.startsWith('.'))) throw new DomainError('Path not found', 404);
      let file = resolve(publicDir, `.${pathname}`); const publicRoot = resolve(publicDir);
      if (file !== publicRoot && !file.startsWith(publicRoot + sep)) throw new DomainError('Path not found', 404);
      let info;
      try { info = await stat(file); if (info.isDirectory()) { file = resolve(file, 'index.html'); info = undefined; } }
      catch { if (extname(pathname)) throw new DomainError('File not found', 404); file = resolve(publicDir, 'index.html'); }
      let asset;
      try { asset = await readAsset(file, info ?? await stat(file), acceptsGzip(req.headers['accept-encoding'])); }
      catch { if (file.endsWith('index.html')) { send(req, res, 200, '<!doctype html><html lang="zh"><meta charset="utf-8"><title>TwinCircuit</title><h1>TwinCircuit</h1><p>Application assets are being prepared.</p></html>', MIME['.html']); return; } throw new DomainError('File not found', 404); }
      res.setHeader('Cache-Control', extname(file) === '.html' ? 'no-cache' : 'public, max-age=300');
      send(req, res, 200, asset.body, MIME[extname(file)] ?? 'application/octet-stream', asset.encoded);
    } catch (err) {
      if (res.headersSent) { res.destroy(); return; }
      const safe = err instanceof DomainError || Number.isInteger(err.status) && err.status >= 400 && err.status < 600;
      send(req, res, safe ? err.status : 500, { error: { code: err.code ?? (safe ? 'REQUEST_REJECTED' : 'INTERNAL_ERROR'), message: safe ? err.message : 'An internal error occurred' } });
    }
  });
  server.requestTimeout = 30000; server.headersTimeout = 15000;
  const cleanup = setInterval(() => store.cleanup(), 600000); cleanup.unref();
  let closed = false;
  return { server, store, operations, async close() { if (closed) return; closed = true; clearInterval(cleanup); server.closeIdleConnections(); if (server.listening) await new Promise((resolve, reject) => server.close(e => e ? reject(e) : resolve())); store.close(); } };
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  const app = createApp(); const host = process.env.HOST ?? '127.0.0.1', port = Number(process.env.PORT ?? 4173);
  app.server.listen(port, host, () => console.log(`TwinCircuit listening on http://${host}:${port}`));
  for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, async () => { await app.close(); process.exit(0); });
}
