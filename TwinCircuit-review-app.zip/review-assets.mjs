import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const files = JSON.parse(await readFile(new URL('./review-assets.json', import.meta.url), 'utf8'));
const origin = 'https://twincircuit.online/';
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');

for (const { path, digest } of files) {
  assert.match(path, /^(?:[A-Za-z0-9_-]+\/)+[A-Za-z0-9_-]+\.[a-z0-9]+$/);
  const destination = fileURLToPath(new URL('./public/' + path, import.meta.url));
  let present;
  try {
    present = await readFile(destination);
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
  if (present) {
    assert.equal(sha256(present), digest, 'Existing file differs: ' + path);
    continue;
  }

  const response = await fetch(new URL(path, origin), {
    redirect: 'error',
    signal: AbortSignal.timeout(20_000),
  });
  if (!response.ok) throw new Error(path + ' returned HTTP ' + response.status);
  const bytes = Buffer.from(await response.arrayBuffer());
  assert.equal(sha256(bytes), digest, 'Downloaded file differs: ' + path);
  await mkdir(dirname(destination), { recursive: true });
  await writeFile(destination, bytes, { flag: 'wx' });
}
console.log('Verified ' + files.length + ' optional public assets.');
