@echo off
cd /d "%~dp0"
node --version >nul 2>&1
if errorlevel 1 (
  echo Please install Node.js 24 or newer, then run this file again.
  pause
  exit /b 1
)
if exist ".env" (
  node --env-file=.env server.mjs
) else (
  node server.mjs
)
pause
