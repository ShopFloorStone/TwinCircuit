#pragma once
// Optional local-only ILI9341 status panel. It never writes fixture GPIO4/5/6,
// grants permission, sends a job, or asserts Internet/payment/physical quality.
// The driver selection is a hypothesis until the actual module is identified.
// Pinned upstream APIs:
// https://github.com/adafruit/Adafruit_ILI9341/tree/1.7.0
// https://github.com/adafruit/Adafruit-GFX-Library/tree/1.12.6
// https://github.com/adafruit/Adafruit_BusIO/tree/1.17.4
#include <Arduino.h>

#ifndef TC_ENABLE_ILI9341
#define TC_ENABLE_ILI9341 0
#endif

#if TC_ENABLE_ILI9341
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ILI9341.h>
#ifndef TC_TFT_SCK
#define TC_TFT_SCK 12
#endif
#ifndef TC_TFT_MOSI
#define TC_TFT_MOSI 11
#endif
#ifndef TC_TFT_MISO
#define TC_TFT_MISO 13
#endif
#ifndef TC_TFT_CS
#define TC_TFT_CS 10
#endif
#ifndef TC_TFT_DC
#define TC_TFT_DC 9
#endif
#ifndef TC_TFT_RST
#define TC_TFT_RST 14
#endif
#ifndef TC_TFT_SPI_HZ
#define TC_TFT_SPI_HZ 10000000
#endif

namespace tc_display {
constexpr int pins[] = {TC_TFT_SCK, TC_TFT_MOSI, TC_TFT_MISO, TC_TFT_CS, TC_TFT_DC, TC_TFT_RST};
#ifdef TC_LED_PIN
constexpr int fixtureLedPin = TC_LED_PIN;
#else
constexpr int fixtureLedPin = 4;
#endif
#ifdef TC_ARM_PIN
constexpr int fixtureArmPin = TC_ARM_PIN;
#else
constexpr int fixtureArmPin = 5;
#endif
#ifdef TC_PERMIT_PIN
constexpr int fixturePermitPin = TC_PERMIT_PIN;
#else
constexpr int fixturePermitPin = 6;
#endif
constexpr bool validPins() {
  for (size_t i = 0; i < sizeof(pins) / sizeof(pins[0]); ++i) {
    const int pin = pins[i];
    // ESP32-S3: 22..25 are absent; this N16R8 profile reserves 26..37 for
    // Flash/PSRAM, 19/20 for native USB and 0/3/45/46 as strapping pins.
    if (pin < 0 || pin > 48 || (pin >= 22 && pin <= 37) || pin == 19 || pin == 20 || pin == 0 || pin == 3 || pin == 45 || pin == 46) return false;
    if (pin == fixtureLedPin || pin == fixtureArmPin || pin == fixturePermitPin) return false;
    for (size_t j = 0; j < i; ++j) if (pins[i] == pins[j]) return false;
  }
  return true;
}
static_assert(validPins(), "TFT pins must be distinct usable S3 pins; cannot overlap fixture, Flash/PSRAM, USB or strapping pins");
static_assert(TC_TFT_SPI_HZ >= 1000000 && TC_TFT_SPI_HZ <= 20000000, "Initial TFT SPI must be 1..20 MHz");
// This is a dedicated SPI object, with explicit pins. No SD or touch driver.
static SPIClass bus(FSPI);
static Adafruit_ILI9341 screen(&bus, TC_TFT_DC, TC_TFT_CS, TC_TFT_RST);
static bool initialized = false, helloSeen = false, firstFrame = true, resultDirty = true;
static uint32_t helloAt = 0, lastTick = 0, lastSecond = UINT32_MAX, previousRevision = UINT32_MAX;
static bool previousArmed = false, previousPermit = false, previousBlocked = false, previousReadback = false;
static uint8_t controllerBytes[4] = {0, 0, 0, 0};
static uint8_t powerMode = 0;
static uint32_t registerSampledAtTickMs = 0;
constexpr uint32_t readRegisterHz = 1000000u;
static int8_t lastVector = -1;
static char lastJob[15] = "", lastResult[18] = "NONE";
constexpr uint16_t rgb(uint8_t r, uint8_t g, uint8_t b) { return ((r & 0xf8) << 8) | ((g & 0xfc) << 3) | (b >> 3); }
constexpr uint16_t BG = rgb(9,20,35), PANEL = rgb(15,32,51), BORDER = rgb(32,52,72);
constexpr uint16_t INK = rgb(231,238,240), MUTED = rgb(139,160,178), SAGE = rgb(171,207,179), AMBER = rgb(235,190,109), CORAL = rgb(238,123,113);

static void text(int x, int y, const char *value, uint16_t color = INK, uint8_t size = 1, uint16_t bg = PANEL) {
  screen.setTextSize(size); screen.setTextColor(color, bg); screen.setCursor(x, y); screen.print(value);
}
static void frame(int x, int y, int w, int h) { screen.fillRoundRect(x, y, w, h, 7, PANEL); screen.drawRoundRect(x, y, w, h, 7, BORDER); }
static void card(int x, const char *label, const char *value, uint16_t color) {
  frame(x, 91, 94, 57); text(x + 10, 102, label, MUTED); text(x + 10, 122, value, color, 2);
}
static void copyLabel(char *target, size_t length, const char *input) {
  size_t i = 0;
  if (input) for (; input[i] && i + 1 < length; ++i) {
    const char c = input[i]; target[i] = isalnum(static_cast<unsigned char>(c)) || c == '_' || c == '-' ? c : '_';
  }
  target[i] = '\0';
}
static bool idAvailable() {
  bool allZero = true, allFF = true;
  for (uint8_t byte : controllerBytes) { allZero &= byte == 0; allFF &= byte == 0xff; }
  return !allZero && !allFF;
}
static bool heartbeatFresh(uint32_t now) { return helloSeen && uint32_t(now - helloAt) <= 5000u; }
// Refresh observations only: no display begin/reset, framebuffer write or retry.
// All callers run on the firmware loop; each library read owns its transaction.
static void sampleRegisters() {
  if (!initialized) return;
  uint8_t sample[4];
  screen.setSPISpeed(readRegisterHz);
  for (uint8_t i = 0; i < 4; ++i) sample[i] = screen.readcommand8(0xd3, i);
  const uint8_t sampledPowerMode = screen.readcommand8(ILI9341_RDMODE);
  screen.setSPISpeed(TC_TFT_SPI_HZ);
  for (uint8_t i = 0; i < 4; ++i) controllerBytes[i] = sample[i];
  powerMode = sampledPowerMode;
  registerSampledAtTickMs = millis();
}
}

inline void tcDisplayBegin() {
  using namespace tc_display;
  if (initialized) return;
  bus.begin(TC_TFT_SCK, TC_TFT_MISO, TC_TFT_MOSI, TC_TFT_CS);
  screen.begin(TC_TFT_SPI_HZ); screen.setRotation(1); screen.setTextWrap(false);
  // Raw 0xD3 bytes are diagnostics only. MISO absent/unsupported can yield 0/FF;
  // a driver begin() returning and nontrivial bytes do not prove visible pixels.
  initialized = true;
  sampleRegisters();
  screen.fillScreen(BG);
  screen.fillRoundRect(12, 12, 5, 27, 2, SAGE);
  text(25, 11, "TwinCircuit", INK, 2, BG);
  text(25, 34, "DIGITAL I/O  /  LOCAL DEVICE", MUTED, 1, BG);
  screen.fillRoundRect(254, 13, 54, 21, 5, SAGE);
  text(266, 20, "S3", BG, 1, SAGE);
  screen.drawFastHLine(12, 48, 296, BORDER);
  frame(12, 157, 296, 45);
  text(22, 168, "REV", MUTED); text(151, 168, "UPTIME", MUTED);
  text(12, 230, "TC1 only / GPIO readback / not safety", MUTED, 1, BG);
}

// Hook ONLY a valid TC1 HELLO. This is not evidence of website or Internet state.
inline void tcDisplayHello() { tc_display::helloSeen = true; tc_display::helloAt = millis(); }

// Hook an actual RESULT, not an intended/expected result from an order.
inline void tcDisplayResult(const String &jobId, const char *status, int vectorIndex = -1) {
  using namespace tc_display;
  copyLabel(lastJob, sizeof(lastJob), jobId.c_str()); copyLabel(lastResult, sizeof(lastResult), status);
  lastVector = vectorIndex >= 0 && vectorIndex <= 7 ? vectorIndex : -1; resultDirty = true;
}

inline void tcDisplayTick(uint32_t revision, bool isArmed, bool hasPermit, bool isBlocked, bool readback, const String &bootId) {
  using namespace tc_display;
  if (!initialized) return;
  const uint32_t now = millis();
  if (!firstFrame && uint32_t(now - lastTick) < 250u) return;
  lastTick = now;
  const uint32_t second = now / 1000u;
  if (firstFrame || second != lastSecond) {
    screen.fillRect(12, 57, 296, 25, BG);
    screen.fillCircle(18, 66, 3, heartbeatFresh(now) ? SAGE : AMBER);
    text(28, 58, "SERIAL HELLO", MUTED, 1, BG);
    char age[27];
    if (!helloSeen) snprintf(age, sizeof(age), "WAITING");
    else snprintf(age, sizeof(age), "%s %lus", heartbeatFresh(now) ? "RECENT" : "STALE", static_cast<unsigned long>(uint32_t(now - helloAt) / 1000u));
    text(184, 58, age, heartbeatFresh(now) ? SAGE : AMBER, 1, BG);
    screen.fillRect(197, 168, 99, 12, PANEL);
    char uptime[18]; snprintf(uptime, sizeof(uptime), "%lus", static_cast<unsigned long>(second)); text(197, 168, uptime);
    screen.fillRect(22, 187, 276, 9, PANEL);
    String boot = bootId.substring(0, 8);
    char detail[47]; snprintf(detail, sizeof(detail), "BOOT %s  /  %s", boot.c_str(), isBlocked ? "RECONCILE REQUIRED" : "LOCAL STATUS");
    text(22, 187, detail, isBlocked ? CORAL : MUTED);
    lastSecond = second;
  }
  if (firstFrame || isArmed != previousArmed || isBlocked != previousBlocked) card(12, "PHYSICAL ARM", isBlocked ? "LOCKED" : isArmed ? "READY" : "HOLD", isBlocked ? CORAL : isArmed ? SAGE : MUTED);
  if (firstFrame || hasPermit != previousPermit) card(113, "PERMIT PIN", hasPermit ? "CLOSED" : "OPEN", hasPermit ? SAGE : AMBER);
  if (firstFrame || readback != previousReadback) card(214, "GPIO4 READ", readback ? "HIGH" : "LOW", readback ? AMBER : SAGE);
  if (firstFrame || revision != previousRevision) {
    screen.fillRect(49, 168, 88, 12, PANEL);
    char rev[12]; snprintf(rev, sizeof(rev), "%lu", static_cast<unsigned long>(revision)); text(49, 168, rev);
  }
  if (firstFrame || resultDirty) {
    screen.fillRect(12, 209, 296, 13, BG);
    char result[48];
    if (lastVector < 0) snprintf(result, sizeof(result), "LAST %s  %s", lastResult, lastJob);
    else snprintf(result, sizeof(result), "VEC %d  %s  %s", lastVector, lastResult, lastJob);
    text(12, 210, result, strcmp(lastResult, "OK") == 0 ? SAGE : MUTED, 1, BG); resultDirty = false;
  }
  previousRevision = revision; previousArmed = isArmed; previousPermit = hasPermit; previousBlocked = isBlocked; previousReadback = readback; firstFrame = false;
}

inline String tcDisplayDiagnosticJSON() {
  using namespace tc_display;
  sampleRegisters();
  char id[11]; snprintf(id, sizeof(id), "0x%02x%02x%02x%02x", controllerBytes[0], controllerBytes[1], controllerBytes[2], controllerBytes[3]);
  String out; out.reserve(850);
  out = "{\"enabled\":true,\"controller\":\"ILI9341\",\"controllerAssumed\":true,\"rawControllerId\":\""; out += id;
  out += "\",\"rawControllerIdBytes\":[";
  for (uint8_t i = 0; i < 4; ++i) { if (i) out += ','; out += String(controllerBytes[i]); }
  out += "],\"controllerIdAvailable\":"; out += idAvailable() ? "true" : "false";
  out += ",\"readRegister\":\"0xD3\",\"readRegisterHz\":"; out += String(readRegisterHz);
  out += ",\"registerSampledAtTickMs\":"; out += String(registerSampledAtTickMs);
  out += ",\"sampleScope\":\"current-display-query\",\"powerMode\":"; out += String(powerMode);
  out += ",\"width\":320,\"height\":240,\"nativeWidth\":240,\"nativeHeight\":320,\"rotation\":1,\"mode\":\"hardware-spi\",\"visibleVerified\":false,\"initStatus\":\"";
  out += initialized ? "driver-begin-returned" : "not-started";
  out += "\",\"gatewayHelloAgeMs\":"; out += helloSeen ? String(uint32_t(millis() - helloAt)) : String("null");
  out += ",\"serialHeartbeatFresh\":"; out += heartbeatFresh(millis()) ? "true" : "false";
  out += ",\"touchEnabled\":false,\"sdEnabled\":false,\"spiHz\":"; out += String(TC_TFT_SPI_HZ);
  out += ",\"pins\":{\"sck\":"; out += String(TC_TFT_SCK); out += ",\"mosi\":"; out += String(TC_TFT_MOSI);
  out += ",\"miso\":"; out += String(TC_TFT_MISO); out += ",\"cs\":"; out += String(TC_TFT_CS);
  out += ",\"dc\":"; out += String(TC_TFT_DC); out += ",\"rst\":"; out += String(TC_TFT_RST); out += "}}";
  return out;
}
#else
// Existing profiles compile and run without any display library or SPI init.
inline void tcDisplayBegin() {}
inline void tcDisplayHello() {}
inline void tcDisplayResult(const String &, const char *, int = -1) {}
inline void tcDisplayTick(uint32_t, bool, bool, bool, bool, const String &) {}
inline String tcDisplayDiagnosticJSON() { return String("{\"enabled\":false,\"controller\":null,\"rawControllerId\":null,\"width\":0,\"height\":0,\"rotation\":0,\"visibleVerified\":false,\"initStatus\":\"disabled\",\"touchEnabled\":false,\"sdEnabled\":false}"); }
#endif
