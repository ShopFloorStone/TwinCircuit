/* TwinCircuit S3 gateway fixture. External low-voltage LED only.
   NOT an emergency stop, safety PLC, motor driver, or certified interlock.
   GPIO4 -> 330 ohm resistor -> LED -> GND. GPIO5 button -> GND.
   GPIO6 permit jumper -> GND (open/disconnected means inhibit).
   NVS and serial CRC provide crash/replay handling, not cryptographic identity. */
#include <Arduino.h>
#include <Preferences.h>
#include <esp_system.h>

#ifndef TC_PANEL_ONLY
#define TC_PANEL_ONLY 0
#endif

#ifndef TC_LED_PIN
#define TC_LED_PIN 4
#endif
#ifndef TC_ARM_PIN
#define TC_ARM_PIN 5
#endif
#ifndef TC_PERMIT_PIN
#define TC_PERMIT_PIN 6
#endif
static_assert(TC_LED_PIN != TC_ARM_PIN && TC_LED_PIN != TC_PERMIT_PIN && TC_ARM_PIN != TC_PERMIT_PIN, "Pins must differ");
#include "tc_display.h"
#include "tc_panel.h"
constexpr uint32_t ARM_MS = 60000, MAX_LEASE_MS = 5000;
Preferences prefs;
String bootId, lastKey, lastCommand, lastResult;
uint32_t revision = 0, armedUntil = 0, pressedAt = 0;
bool blocked = true, inflight = false, nvsGood = false, buttonHandled = false;
bool panelReadback = false;
char inputLine[900]; size_t used = 0; bool overflow = false;

uint32_t crc32(const char *data, size_t length) { uint32_t crc = 0xffffffffu; for (size_t i = 0; i < length; i++) { crc ^= uint8_t(data[i]); for (int b = 0; b < 8; b++) crc = (crc >> 1) ^ ((crc & 1) ? 0xedb88320u : 0u); } return ~crc; }
void sendLine(const String &body) { char crc[9]; snprintf(crc, sizeof(crc), "%08lx", (unsigned long)crc32(body.c_str(), body.length())); Serial.print(body); Serial.print('|'); Serial.println(crc); }
bool safeId(const String &s, size_t maxLength = 100) { if (!s.length() || s.length() > maxLength) return false; for (size_t i = 0; i < s.length(); i++) if (!isalnum((unsigned char)s[i]) && s[i] != '_' && s[i] != '-') return false; return true; }
bool uintValue(const String &s, uint32_t &out) { if (!s.length() || s.length() > 10) return false; uint64_t n = 0; for (size_t i = 0; i < s.length(); i++) { if (s[i] < '0' || s[i] > '9') return false; n = n * 10 + s[i] - '0'; if (n > UINT32_MAX) return false; } out = uint32_t(n); return true; }
bool permit() {
#if TC_PANEL_ONLY
  return false;
#else
  return digitalRead(TC_PERMIT_PIN) == LOW;
#endif
}
bool currentReadback() {
#if TC_PANEL_ONLY
  return panelReadback;
#else
  return digitalRead(TC_LED_PIN) == HIGH;
#endif
}
bool armed() { return nvsGood && !blocked && permit() && armedUntil && int32_t(armedUntil - millis()) > 0; }
void storageFault() { nvsGood = false; blocked = true; armedUntil = 0;
#if !TC_PANEL_ONLY
  digitalWrite(TC_LED_PIN, LOW);
#endif
}
String panelResult(const String &job, const String &nonce, const String &key, const char *status, const char *error, const TCPanelMeasurement *measurement = nullptr) {
  String json = String("{\"status\":\"") + status + "\",\"hardwareRevision\":" + String(revision) + ",\"tickMs\":" + String(millis());
  if (measurement) json += "," + tcPanelMeasurementJSON(*measurement).substring(1);
  else json += String(",\"error\":\"") + error + "\"}";
  return String("TC1|PANELRESULT|") + job + "|" + nonce + "|" + key + "|" + json;
}
#if TC_PANEL_ONLY
void handlePanelWrite(const String fields[], const String &body) {
  const String &job = fields[2], &nonce = fields[3], &key = fields[4];
  uint32_t expectedRevision, deadline, vector;
  if (!safeId(job) || !safeId(nonce) || !safeId(key) || !uintValue(fields[6], expectedRevision) || !uintValue(fields[7], deadline)) return;
  if (key == lastKey) {
    if (body == lastCommand && lastResult.length() && !inflight) sendLine(lastResult);
    else sendLine(panelResult(job, nonce, key, "FAILED", "KEY_CONFLICT_OR_UNCERTAIN"));
    return;
  }
  const char *reason = nullptr;
  if (!nvsGood) reason = "NVS_UNAVAILABLE";
  else if (blocked || inflight) reason = "MANUAL_RECONCILIATION_REQUIRED";
  else if (fields[5] != bootId) reason = "BOOT_CHANGED";
  else if (expectedRevision != revision) reason = "REVISION_CONFLICT";
  else if (revision == UINT32_MAX) reason = "REVISION_EXHAUSTED";
  else if (int32_t(deadline - millis()) <= 0 || uint32_t(deadline - millis()) > MAX_LEASE_MS) reason = "LEASE_EXPIRED_OR_TOO_LONG";
  else if (fields[8] != "panel_vector" || !uintValue(fields[9], vector) || vector > 7 || fields[10] != "PANEL_ONLY") reason = "SIGNAL_NOT_ALLOWED";
  else if (!tcPanelReady()) reason = "PANEL_REFERENCE_CALIBRATION_REQUIRED";
  if (reason) { sendLine(panelResult(job, nonce, key, "FAILED", reason)); return; }

  // Commit an intent before display mutation. An interrupted result is never
  // retried automatically. The panel namespace is isolated from fixture GPIO.
  inflight = true;
  if (prefs.putBool("inflight", true) != sizeof(bool)) { storageFault(); sendLine(panelResult(job, nonce, key, "UNCERTAIN", "NVS_INTENT_FAILED")); return; }
  revision++;
  bool committed = prefs.putUInt("revision", revision) == sizeof(uint32_t);
  committed = prefs.putString("lastKey", key) == key.length() && committed;
  committed = prefs.putString("lastCommand", body) == body.length() && committed;
  lastKey = key; lastCommand = body;
  if (!committed || int32_t(deadline - millis()) <= 0) {
    blocked = true; prefs.putBool("blocked", true);
    lastResult = panelResult(job, nonce, key, "UNCERTAIN", "PREWRITE_ABORT_RECONCILE"); sendLine(lastResult); return;
  }
  TCPanelMeasurement m = tcPanelExecute(uint8_t(vector), job);
  if (m.ok) panelReadback = m.actualY;
  else {
    blocked = true;
    if (prefs.putBool("blocked", true) != sizeof(bool)) {
      storageFault(); sendLine(panelResult(job, nonce, key, "UNCERTAIN", "NVS_BLOCK_FAILED")); return;
    }
  }
  lastResult = panelResult(job, nonce, key, m.ok ? "OK" : "UNCERTAIN", nullptr, &m);
  if (prefs.putString("lastResult", lastResult) != lastResult.length() || prefs.putBool("inflight", false) != sizeof(bool)) {
    blocked = true; prefs.putBool("blocked", true); sendLine(panelResult(job, nonce, key, "UNCERTAIN", "NVS_RESULT_FAILED")); return;
  }
  inflight = false; sendLine(lastResult);
}
#endif
String resultBody(const String &job, const String &nonce, const String &key, const char *status, const char *quality, const char *reason, int vectorIndex = -1) { tcDisplayResult(job, status, vectorIndex); return String("TC1|RESULT|") + job + "|" + nonce + "|" + key + "|" + status + "|" + String(revision) + "|" + String(millis()) + "|" + String(digitalRead(TC_LED_PIN) == HIGH ? 1 : 0) + "|" + quality + "|" + reason + "|" + String(vectorIndex) + "|" + String(vectorIndex < 0 ? -1 : (vectorIndex >> 2) & 1) + "|" + String(vectorIndex < 0 ? -1 : (vectorIndex >> 1) & 1) + "|" + String(vectorIndex < 0 ? -1 : vectorIndex & 1); }
void handleLine(char *line) {
  String full(line); const int crcSeparator = full.lastIndexOf('|'); if (crcSeparator < 0) return;
  String body = full.substring(0, crcSeparator), crcText = full.substring(crcSeparator + 1); if (crcText.length() != 8) return;
  for (size_t i = 0; i < crcText.length(); i++) if (!isxdigit((unsigned char)crcText[i])) return;
  if (strtoul(crcText.c_str(), nullptr, 16) != crc32(body.c_str(), body.length())) return;
  String fields[14]; int count = 0, begin = 0; for (int i = 0; i <= (int)body.length(); i++) if (i == (int)body.length() || body[i] == '|') { if (count >= 14) return; fields[count++] = body.substring(begin, i); begin = i + 1; }
  if (count < 3 || fields[0] != "TC1") return;
  if (fields[1] == "HELLO" && count == 3 && safeId(fields[2])) { tcDisplayHello(); sendLine(String("TC1|STATE|") + fields[2] + "|" + bootId + "|" + String(revision) + "|" + String(millis()) + "|" + String(armed() ? 1 : 0) + "|" + String(permit() ? 1 : 0) + "|" + String(blocked ? 1 : 0) + "|" + String(currentReadback() ? 1 : 0)); return; }
  if (fields[1] == "DISPLAY" && count == 3 && safeId(fields[2])) { sendLine(String("TC1|DISPLAYSTATE|") + fields[2] + "|" + tcDisplayDiagnosticJSON()); return; }
#if TC_PANEL_ONLY
  if (fields[1] == "PANELRECONCILE" && count == 6 && safeId(fields[2])) {
    uint32_t expectedRevision;
    const char *error = nullptr;
    if (!nvsGood) error = "NVS_UNAVAILABLE";
    else if (fields[3] != bootId) error = "BOOT_CHANGED";
    else if (!uintValue(fields[4], expectedRevision) || expectedRevision != revision) error = "REVISION_CONFLICT";
    else if (fields[5] != "PANEL_ONLY") error = "SCOPE_MISMATCH";
    uint32_t reconciles = nvsGood ? prefs.getUInt("reconciles", 0) : 0;
    if (!error && reconciles == UINT32_MAX) error = "RECONCILE_COUNTER_EXHAUSTED";
    if (!error) {
      // Explicit operator recovery only. Preserve the consumed HW revision.
      // Clearing this journal performs no display test or fixture GPIO I/O.
      // Write a recovery intent first. Short circuit every later operation on
      // failure; inflight is the very last persistent flag cleared on success.
      bool saved = prefs.putBool("inflight", true) == sizeof(bool);
      saved = saved && prefs.putUInt("reconciles", ++reconciles) == sizeof(uint32_t);
      saved = saved && (!prefs.isKey("lastKey") || prefs.remove("lastKey"));
      saved = saved && (!prefs.isKey("lastCommand") || prefs.remove("lastCommand"));
      saved = saved && (!prefs.isKey("lastResult") || prefs.remove("lastResult"));
      saved = saved && prefs.putBool("blocked", false) == sizeof(bool);
      saved = saved && prefs.putBool("inflight", false) == sizeof(bool);
      if (!saved) { storageFault(); prefs.putBool("blocked", true); error = "NVS_RECONCILE_FAILED"; }
      else { lastKey = ""; lastCommand = ""; lastResult = ""; inflight = false; blocked = false; }
    }
    String json = String("{\"status\":\"") + (error ? "FAILED" : "OK") + "\",\"bootId\":\"" + bootId + "\",\"hardwareRevision\":" + String(revision) + ",\"blocked\":" + (blocked ? "true" : "false") + ",\"tickMs\":" + String(millis()) + ",\"operation\":\"panel-reconcile\",\"gpioOutputsEnabled\":false,\"panelOnly\":true,\"reconcileCount\":" + String(reconciles) + ",\"error\":" + (error ? String("\"") + error + "\"" : "null") + "}";
    sendLine(String("TC1|PANELRECONCILED|") + fields[2] + "|" + json); return;
  }
  if (fields[1] == "PANEL" && count == 3 && safeId(fields[2])) {
    const bool ready = tcPanelSelftest() && nvsGood && !blocked && !inflight;
    String json = String("{\"enabled\":true,\"capability\":\"tft-panel\",\"panelOnly\":true,\"gpioOutputsEnabled\":false,\"signal\":\"panel_vector\",\"ready\":") + (ready ? "true" : "false") + ",\"bootId\":\"" + bootId + "\",\"hardwareRevision\":" + String(revision) + ",\"tickMs\":" + String(millis()) + ",\"pixel\":{\"x\":260,\"y\":116},\"falseColor\":0,\"trueColor\":16777215,\"pixelFormat\":\"RGB888\",\"readback\":\"ILI9341_GRAM_RGB888\",\"references\":" + tcPanelReferencesJSON() + ",\"sampledAtTickMs\":" + String(tcPanelReferencesSampledAtTickMs()) + "}";
    sendLine(String("TC1|PANELSTATE|") + fields[2] + "|" + json); return;
  }
  if (fields[1] == "PANELWRITE" && count == 11) { handlePanelWrite(fields, body); return; }
  // The panel image has no ordinary GPIO WRITE implementation.
  return;
#else
  if (fields[1] != "WRITE" || count != 11 || !safeId(fields[2]) || !safeId(fields[3]) || !safeId(fields[4])) return;
  const String &job = fields[2], &nonce = fields[3], &key = fields[4]; uint32_t expectedRevision, deadline;
  if (!uintValue(fields[6], expectedRevision) || !uintValue(fields[7], deadline)) return;
  if (key == lastKey) { if (body == lastCommand && lastResult.length() && !inflight) sendLine(lastResult); else sendLine(resultBody(job, nonce, key, "FAILED", "NONE", "KEY_CONFLICT_OR_UNCERTAIN")); return; }
  uint32_t rawValue = 0; const bool valueValid = uintValue(fields[9], rawValue); const bool isVector = fields[8] == "cme_vector"; const int vectorIndex = isVector && valueValid && rawValue <= 7 ? int(rawValue) : -1;
  const char *reason = nullptr;
  if (!nvsGood) reason = "NVS_UNAVAILABLE";
  else if (blocked || inflight) reason = "MANUAL_RECONCILIATION_REQUIRED";
  else if (fields[5] != bootId) reason = "BOOT_CHANGED";
  else if (expectedRevision != revision) reason = "REVISION_CONFLICT";
  else if (revision == UINT32_MAX) reason = "REVISION_EXHAUSTED";
  else if (!armed()) reason = "PHYSICAL_ARM_OR_PERMIT_REQUIRED";
  else if (int32_t(deadline - millis()) <= 0 || uint32_t(deadline - millis()) > MAX_LEASE_MS) reason = "LEASE_EXPIRED_OR_TOO_LONG";
  else if (!valueValid || (isVector ? rawValue > 7 : fields[8] != "led" || rawValue > 1) || fields[10] != "GPIO_ONLY") reason = "SIGNAL_NOT_ALLOWED";
  if (reason) { sendLine(resultBody(job, nonce, key, "FAILED", "NONE", reason)); return; }
  // Commit uncertainty before touching the output. No retry of a consumed revision.
  armedUntil = 0; inflight = true;
  if (prefs.putBool("inflight", true) != sizeof(bool)) { nvsGood = false; blocked = true; sendLine(resultBody(job, nonce, key, "UNCERTAIN", "NONE", "NVS_INTENT_FAILED")); return; }
  revision++; bool committed = prefs.putUInt("revision", revision) == sizeof(uint32_t);
  committed = prefs.putString("lastKey", key) == key.length() && committed;
  committed = prefs.putString("lastCommand", body) == body.length() && committed;
  lastKey = key; lastCommand = body;
  if (!committed || !permit() || int32_t(deadline - millis()) <= 0) { blocked = true; lastResult = resultBody(job, nonce, key, "UNCERTAIN", "NONE", "PREWRITE_ABORT_RECONCILE"); prefs.putBool("blocked", true); sendLine(lastResult); return; }
  // Compute on the board; never receive the expected Y from the website/gateway.
  const bool y = isVector ? ((rawValue & 1u) && ((rawValue & 4u) || (rawValue & 2u))) : rawValue == 1;
  digitalWrite(TC_LED_PIN, y ? HIGH : LOW);
  lastResult = resultBody(job, nonce, key, "OK", "GPIO_READBACK", "LOW_VOLTAGE_LED_ONLY", vectorIndex);
  if (prefs.putString("lastResult", lastResult) != lastResult.length() || prefs.putBool("inflight", false) != sizeof(bool)) { blocked = true; prefs.putBool("blocked", true); sendLine(resultBody(job, nonce, key, "UNCERTAIN", "NONE", "NVS_RESULT_FAILED")); return; }
  inflight = false; sendLine(lastResult);
#endif
}
void setup() {
  Serial.begin(115200);
#if !TC_PANEL_ONLY
  pinMode(TC_LED_PIN, OUTPUT); digitalWrite(TC_LED_PIN, LOW); pinMode(TC_ARM_PIN, INPUT_PULLUP); pinMode(TC_PERMIT_PIN, INPUT_PULLUP);
#endif
  nvsGood = prefs.begin(TC_PANEL_ONLY ? "tc-panel" : "twincircuit", false); if (nvsGood) { revision = prefs.getUInt("revision", 0); inflight = prefs.getBool("inflight", false); blocked = prefs.getBool("blocked", false) || inflight; lastKey = prefs.getString("lastKey", ""); lastCommand = prefs.getString("lastCommand", ""); lastResult = prefs.getString("lastResult", ""); }
  char boot[33]; snprintf(boot, sizeof(boot), "%08lx%08lx%08lx%08lx", (unsigned long)esp_random(), (unsigned long)esp_random(), (unsigned long)esp_random(), (unsigned long)esp_random()); bootId = boot;
  tcDisplayBegin();
#if TC_PANEL_ONLY
  tcPanelBegin();
#endif
}
void loop() {
#if !TC_PANEL_ONLY
  const uint32_t t = millis();
  if (!permit()) { armedUntil = 0; if (digitalRead(TC_LED_PIN) == HIGH) { digitalWrite(TC_LED_PIN, LOW); if (nvsGood && revision < UINT32_MAX) { revision++; if (prefs.putUInt("revision", revision) != sizeof(uint32_t)) storageFault(); } blocked = true; if (nvsGood && prefs.putBool("blocked", true) != sizeof(bool)) storageFault(); } }
  if (digitalRead(TC_ARM_PIN) == LOW) { if (!pressedAt) pressedAt = t ? t : 1; const uint32_t hold = t - pressedAt;
    if (!buttonHandled && nvsGood && permit() && hold >= (blocked ? 3000u : 1000u)) { buttonHandled = true; if (blocked) { digitalWrite(TC_LED_PIN, LOW); if (revision == UINT32_MAX) { storageFault(); return; } revision++;
      // Clear recovery state only when every persistent write succeeds.
      bool saved = prefs.putUInt("revision", revision) == sizeof(uint32_t);
      saved = prefs.putString("lastKey", "") == 0 && saved;
      saved = prefs.putBool("inflight", false) == sizeof(bool) && saved;
      saved = prefs.putBool("blocked", false) == sizeof(bool) && saved;
      if (!saved) { storageFault(); return; }
      inflight = false; blocked = false; lastKey = ""; lastCommand = ""; lastResult = "";
    } armedUntil = millis() + ARM_MS; }
  } else { pressedAt = 0; buttonHandled = false; }
#endif
  while (Serial.available()) { const char c = (char)Serial.read(); if (c == '\r') continue; if (c == '\n') { if (!overflow) { inputLine[used] = 0; handleLine(inputLine); } used = 0; overflow = false; } else if (!overflow && used + 1 < sizeof(inputLine)) inputLine[used++] = c; else overflow = true; }
#if TC_PANEL_ONLY
  tcPanelTick(bootId);
#else
  tcDisplayTick(revision, armed(), permit(), blocked, digitalRead(TC_LED_PIN) == HIGH, bootId);
#endif
  delay(1);
}
