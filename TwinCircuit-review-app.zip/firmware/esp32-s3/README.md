# ESP32-S3 低压 I/O 与可选 TFT 固件

**1.3 当前实机使用显示专用 `esp32-s3-16mb-panel` 配置。** 网站经真实 COM4 网关已完成八组显示控制器 GRAM 读回，结果 `0,0,0,1,0,1,0,1`；人工独立审核尚待用户操作。该配置保留现有 TFT 九线，完全不访问 GPIO4/5/6，不需要额外跳线或 GPIO ARM 按钮。操作见 [TFT 工作台](../../docs/PANEL_WORKCELL.md)，原始证据见 [实机八向量](../../docs/validation/physical-panel.json)。

下文的 GPIO 夹具与旧 TFT 状态屏是独立兼容配置，其 GPIO/外部负载仍未实测，不能套用显示专用流程来放行。

旧 GPIO 配置是 TwinCircuit 现场网关的 **GPIO 夹具**，设计仅驱动低压限流LED。2026-11-12曾对用户ESP32-S3完成该配置烧录/三文件校验、真实TC1状态读取、网关及网页心跳；这条 GPIO 路径尚未接线验证外部LED、发送GPIO输出任务或完成GPIO八向量。见[历史硬件报告](../../docs/validation/hardware.json)。

## 接线

| ESP32-S3 | 外部连接 | 行为 |
| --- | --- | --- |
| GPIO4 | 330Ω 限流电阻 → LED 正极，LED 负极 → GND | 低压指示输出；默认为 LOW |
| GPIO5 | 瞬时按键 → GND，输入上拉 | 按住1秒后松开，授予60秒、一次写的物理 ARM；恢复锁定需按住3秒 |
| GPIO6 | 可拔跳线 → GND，输入上拉 | 闭合才允许；断开撤销 ARM 并将输出置低，曾为高时锁定等待人工恢复 |
| GND | 上述低压器件公共地 | 不连接市电/电机/继电器 |

不要将 GPIO 直接接 LED 而省略限流电阻。USB 供电；本设计不驱动板载可编程 RGB LED。不同 S3 开发板引脚可用性不同，烧录前核对型号原理图。可通过 `TC_LED_PIN/TC_ARM_PIN/TC_PERMIT_PIN` 编译宏更改，三个引脚必须不同。ARM/permit 只是普通 GPIO 流程保护，不具备独立硬件安全功能。

## 编译和烧录

当前设备为ESP32-S3 rev0.2，16MB Flash、8MB内置PSRAM。1.1无TFT配置 `esp32-s3-16mb` 和1.2标准 `esp32-s3-16mb-tft` 曾烧录验证；1.3当前使用 `esp32-s3-16mb-panel`。均DIO80MHz、USB CDC、PSRAM未使用，沿用8MB分区；无TFT配置仅用Arduino core依赖，TFT另锁定下述Adafruit库。

本次实际构建使用锁定的PlatformIO/espressif32 8.0.0、Arduino ESP32 3.3.12、Xtensa14.2。项目根目录：

```powershell
pio run -d firmware/esp32-s3 -e esp32-s3-16mb
```

| 目录/环境 | 用途 | 验证 |
| --- | --- | --- |
| `firmware/esp32-s3` / `esp32-s3-16mb` | 无TFT基础配置 | 已编译、烧录、三文件digest校验、只读TC1及网关心跳 |
| `firmware/releases/esp32-s3-16mb` | 无TFT二进制+manifest | bootloader/partitions/firmware及SHA-256 |
| `public/firmware/esp32-s3` | 网站默认无TFT下载 | 16MB基础副本，独立于TFT下载 |
| `esp32-s3-16mb-tft` / `firmware/releases/esp32-s3-16mb-tft` | 当前标准TFT配置/产物 | 已编译、烧录校验、原始SPI诊断及用户实物照片 |
| `firmware/releases/esp32-s3-devkitc-1` / 同名构建环境 | 旧N8、8MB、无PSRAM配置 | 仅编译，未对该型号进行实机测试 |

三文件偏移分别为bootloader `0x0`、partitions `0x8000`、firmware `0x10000`；二进制来源、大小和SHA-256以对应manifest为准。RAM23,344/327,680字节、程序334,578字节，应用镜像文件342,064字节。不要混用8MB旧包和16MB当前包。刷机前先核对芯片/Flash/接线并备份原始Flash；本次完整16MB原始备份私有保存，不随发布包或网站提供。

本次实机端口为COM4，BOOT/EN进入下载模式前后端口可能变化；不要假设所有用户设备端口相同。刷机后释放BOOT并正常复位，退出下载模式再连接网关；本次首次运行额外复位后才收到TC1。其他构建工具必须显式匹配16MB/DIO80MHz/USB CDC；本包实际验证的是上述PlatformIO配置。**烧录成功和只读心跳不等于GPIO负载、八向量功能或电气验收通过。**

烧录后关闭 Serial Monitor，将同一个端口配置给 [网关](../../gateway/README.md)。端口打开可能导致复位，等待网关收到 STATE 后再按物理 ARM。固件无 Wi-Fi、无 MQTT、无远程更新，只接受本地串口 TC1 白名单协议。

## 控制范围

当前九线TFT接法未连接GPIO4/5/6，输出关闭，以下输出功能尚未做实体负载/八向量验收。标准TFT仍使用GPIO5 ARM；独立BOOT-ARM配置仅较早版本编译，不是当前已刷入固件，不应据此更换按钮或许可接线。

- `led:boolean`：0或1写 GPIO4，并读回 GPIO4。
- `cme_vector:integer 0..7`：C为bit2、M为bit1、E为bit0；板上计算 `Y = E && (C || M)`，再写 GPIO4并读回。返回 actualY 来自 `digitalRead`，不是收到的期望值。每个向量单独消耗物理 ARM。
- 上电输出 LOW，ARM 不跨重启。网站与网关各自的短期许可、revision、lease、幂等检查之外，固件还检查自身物理 ARM、permit、bootId、硬件 revision 和最多5秒 lease。

## 可选TFT

`tc_display.h`实现ILI9341驱动假设下的320×240横屏：本地HELLO年龄、ARM、permit、GPIO4读值、revision/uptime与最近实际结果。锁定ILI9341 1.7.0、GFX1.12.6、BusIO1.17.4；SPI10MHz，引脚12/11/13/10/9/14，触摸与SD关闭。源码/API、供电/J1边界及九线表见 [TFT.md](../../docs/TFT.md)。

最终标准TFT已刷写校验；每次DISPLAY以1MHz实时读取D3/powerMode，绘图10MHz不变。同一启动8次D3均0x41009341，采样tick严格增加；不宣称跨启动稳定。此前用户照片确认同布局可见，照片不对应最终采样补丁二进制。恢复事件及人工观察单独记录；设备visibleVerified永远false，不用ID或驱动返回代替画面证据。当前没有GPIO输出任务或外部负载测试。

## TC1 协议

115200 baud，ASCII，一行一帧，`<body>|<CRC32八位小写hex>\n`；CRC32 IEEE。帧最多899字节，超长帧/CRC错误直接丢弃，不执行。标识只允许英文字母、数字、下划线和短横线。

```text
TC1|HELLO|nonce
TC1|STATE|nonce|bootId|hardwareRevision|tickMs|armed|permit|blocked|gpioReadback
TC1|WRITE|jobId|nonce|idempotencyKey|bootId|expectedHardwareRevision|deadlineTickMs|signal|value|GPIO_ONLY
TC1|RESULT|jobId|nonce|key|OK_or_FAILED_or_UNCERTAIN|hardwareRevision|tickMs|gpioReadback|GPIO_READBACK_or_NONE|reason|vectorIndex|C|M|E
```

以上各行发送时均须追加 `|CRC32\n`。bit用0/1，led响应的vectorIndex/C/M/E为-1。`bootId` 每次启动重新随机生成；`tickMs` 是 unsigned 32-bit millis，不是 UTC。网关先 HELLO，再将短期 lease 转换成当前启动的 deadline；固件以支持计数回绕的差值检查最多5秒。禁止将网站 wall clock 直接当 millis。

## 持久化与不确定状态

NVS Preferences namespace `twincircuit` 保存硬件 revision、最后幂等 key/命令/结果以及 intent 标志。**先持久化 intent，再增加并保存硬件序号，再输出。** 成功反馈仅在读回并持久化结果后发送；存储失败、掉电中断等会阻止继续输出。相同最后命令可返回历史结果，不重复写；旧 revision、不同内容重复key、未知信号、过期与不同boot都拒绝。

若 intent 后重启、permit 拉低中断高输出或写入状态不明，保持输出 LOW、blocked。现场确认后闭合 permit、按住 ARM 三秒恢复；恢复会增加硬件 revision，清掉旧许可。仍需网关与网站各自人工 reconciliation，再重新 arm。

不要通过擦除 NVS、降低 revision 或自动重试规避不确定状态。NVS/CRC 不提供抵抗恶意 USB 主机的硬件可信执行或设备身份认证。GPIO读回只能说明引脚电平，不证明外部负载动作、线路质量或生产认证。

旧1.1发布包各自保留匹配原二进制的 `source/esp32-s3.ino` 与 `source/platformio.ini` 快照；不要把当前含TFT的1.2源码当成旧二进制的构建来源。文件哈希以各manifest为准。
