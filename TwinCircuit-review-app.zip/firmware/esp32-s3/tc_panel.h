#pragma once
// Display-only capability. RAMRD observes controller GRAM, not emitted light,
// a motor, PLC, safety interlock, manufacturing quality or industrial approval.
// No fixture GPIO is read or written in this module. The caller must disable
// all fixture setup/commands when TC_PANEL_ONLY is selected.
#include <Arduino.h>
#include "tc_display.h"

struct TCPanelMeasurement {
  bool ok = false;
  bool actualY = false;
  uint8_t vectorIndex = 0;
  uint16_t rgb565 = 0, white565 = 0, black565 = 0;
  uint8_t rgb[3] = {0, 0, 0}, whiteRgb[3] = {0, 0, 0}, blackRgb[3] = {0, 0, 0};
  uint32_t actualColor = 0, whiteColor = 0, blackColor = 0;
  uint32_t sampledAtTickMs = 0;
  const char *error = "panel-not-ready";
};

#if TC_ENABLE_ILI9341
namespace tc_panel {
constexpr int16_t sampleX = 260, sampleY = 116;
constexpr int16_t whiteX = 20, whiteY = 200, blackX = 44, blackY = 200;
constexpr uint32_t readHz = 1000000u;
static bool initialized = false, calibrated = false;
static TCPanelMeasurement lastReferences;
static uint32_t lastSecond = UINT32_MAX;
static char lastJob[33] = "NONE";
static const char *lastStatus = "NOT TESTED";

static uint8_t normalize(uint8_t raw) {
  const uint8_t upper = raw & 0xfc;
  return upper | (upper >> 6);
}
static uint32_t color888(const uint8_t raw[3]) {
  return (uint32_t(normalize(raw[0])) << 16) |
         (uint32_t(normalize(raw[1])) << 8) | normalize(raw[2]);
}
static uint16_t color565(const uint8_t raw[3]) {
  return (uint16_t(raw[0] & 0xf8) << 8) |
         (uint16_t(raw[1] & 0xfc) << 3) | (raw[2] >> 3);
}

// ILI9341 RAMRD: one dummy byte, then RGB bytes (six meaningful upper bits).
// Use the driver's setAddrWindow rather than writing CASET/PASET directly:
// Adafruit_ILI9341 caches that address, so bypassing it corrupts later draws.
// Rotation 1 coordinates are already mapped by MADCTL; do not rotate twice.
// Source: ILI9341 datasheet RAMRD 0x2e; pinned Adafruit ILI9341 1.7.0 /
// Adafruit GFX 1.12.6 public startWrite/setAddrWindow/writeCommand/spiRead API.
static bool readPixel(int16_t x, int16_t y, uint8_t raw[3]) {
  using tc_display::screen;
  if (!tc_display::initialized || x < 0 || y < 0 || x >= screen.width() || y >= screen.height()) return false;
  screen.setSPISpeed(readHz);
  screen.startWrite();
  screen.setAddrWindow(x, y, 1, 1);
  screen.writeCommand(ILI9341_RAMRD);
  (void)screen.spiRead();
  raw[0] = screen.spiRead();
  raw[1] = screen.spiRead();
  raw[2] = screen.spiRead();
  screen.endWrite();
  screen.setSPISpeed(TC_TFT_SPI_HZ);
  return true;
}

static void paintReferences() {
  tc_display::screen.fillRect(whiteX - 6, whiteY - 6, 13, 13, ILI9341_WHITE);
  tc_display::screen.fillRect(blackX - 6, blackY - 6, 13, 13, ILI9341_BLACK);
}
static bool readReferences(TCPanelMeasurement &m) {
  const bool whiteRead = readPixel(whiteX, whiteY, m.whiteRgb);
  const bool blackRead = readPixel(blackX, blackY, m.blackRgb);
  m.whiteColor = color888(m.whiteRgb); m.blackColor = color888(m.blackRgb);
  m.white565 = color565(m.whiteRgb); m.black565 = color565(m.blackRgb);
  m.sampledAtTickMs = millis();
  lastReferences = m;
  return whiteRead && blackRead && m.whiteColor == 0xffffffu && m.blackColor == 0;
}
static void status(const char *value, uint16_t color) {
  tc_display::screen.fillRect(12, 169, 296, 13, tc_display::BG);
  tc_display::text(12, 171, value, color, 1, tc_display::BG);
}
static void drawFrame() {
  using namespace tc_display;
  screen.fillScreen(BG);
  screen.fillRoundRect(12, 12, 5, 27, 2, SAGE);
  text(25, 11, "TwinCircuit", INK, 2, BG);
  text(25, 34, "TFT PANEL / CONTROLLER GRAM", MUTED, 1, BG);
  screen.drawFastHLine(12, 48, 296, BORDER);
  text(12, 78, "Y = E && (C || M)", SAGE, 1, BG);
  frame(12, 91, 60, 57); frame(80, 91, 60, 57); frame(148, 91, 60, 57);
  text(22, 100, "C", MUTED); text(90, 100, "M", MUTED); text(158, 100, "E", MUTED);
  text(229, 78, "GRAM CELL", MUTED, 1, BG);
  // No label may overlap sample (260,116).
  screen.fillRect(224, 91, 73, 57, ILI9341_BLACK);
  screen.drawRect(223, 90, 75, 59, BORDER);
  text(12, 155, "JOB NONE", MUTED, 1, BG);
  paintReferences();
  text(61, 196, "LIVE WHITE / BLACK REFERENCES", MUTED, 1, BG);
  text(12, 226, "GRAM readback only / no actuator I/O", MUTED, 1, BG);
}
}

inline bool tcPanelSelftest() {
  using namespace tc_panel;
  calibrated = false;
  if (!initialized || !tc_display::initialized) return false;
  paintReferences();
  TCPanelMeasurement probe;
  calibrated = readReferences(probe);
  lastStatus = calibrated ? "READY / REFERENCES VERIFIED" : "FAILED / REFERENCE READBACK";
  status(lastStatus, calibrated ? tc_display::SAGE : tc_display::CORAL);
  return calibrated;
}

inline bool tcPanelBegin() {
  using namespace tc_panel;
  if (initialized) return calibrated;
  tcDisplayBegin();
  if (!tc_display::initialized) return false;
  tc_display::screen.setRotation(1);
  tc_display::screen.setTextWrap(false);
  initialized = true;
  drawFrame();
  return tcPanelSelftest();
}

inline bool tcPanelReady() { return tc_panel::initialized && tc_panel::calibrated; }

inline TCPanelMeasurement tcPanelExecute(uint8_t vector, const String &jobId) {
  using namespace tc_panel;
  TCPanelMeasurement m;
  m.vectorIndex = vector;
  if (vector > 7) { m.error = "invalid-vector"; m.sampledAtTickMs = millis(); return m; }
  if (!tcPanelReady()) { m.sampledAtTickMs = millis(); return m; }
  const bool C = (vector & 4) != 0, M = (vector & 2) != 0, E = (vector & 1) != 0;
  const bool desired = E && (C || M);
  tc_display::copyLabel(lastJob, sizeof(lastJob), jobId.c_str());
  const bool inputs[3] = {C, M, E};
  for (uint8_t i = 0; i < 3; ++i) {
    tc_display::screen.fillRect(22 + 68 * i, 119, 35, 20, tc_display::PANEL);
    tc_display::text(22 + 68 * i, 121, inputs[i] ? "1" : "0", tc_display::INK, 2);
  }
  tc_display::screen.fillRect(224, 91, 73, 57, desired ? ILI9341_WHITE : ILI9341_BLACK);
  tc_display::screen.fillRect(12, 154, 296, 12, tc_display::BG);
  char jobLine[40]; snprintf(jobLine, sizeof(jobLine), "JOB %s", lastJob);
  tc_display::text(12, 155, jobLine, tc_display::MUTED, 1, tc_display::BG);
  // Both calibration references are freshly written AND independently read for
  // each job. No cached reference or computed Y can substitute for a RAM read.
  paintReferences();
  const bool refsOK = readReferences(m);
  const bool pixelRead = readPixel(sampleX, sampleY, m.rgb);
  m.actualColor = color888(m.rgb); m.rgb565 = color565(m.rgb);
  m.sampledAtTickMs = millis();
  if (!refsOK) {
    m.error = "reference-readback-failed";
    calibrated = false;
  } else if (!pixelRead) {
    m.error = "pixel-readback-failed";
    calibrated = false;
  } else if (m.actualColor != 0 && m.actualColor != 0xffffffu) {
    m.error = "pixel-not-black-or-white";
    calibrated = false;
  } else {
    m.ok = true; m.actualY = m.actualColor == 0xffffffu; m.error = nullptr;
  }
  // A correctly classified physical RAM value is preserved even if it differs
  // from desired. The independent verifier must compare rule vs actual value.
  lastStatus = !m.ok ? "FAILED / READBACK INVALID" : m.actualY ? "ACTUAL GRAM Y = 1" : "ACTUAL GRAM Y = 0";
  status(lastStatus, m.ok ? tc_display::SAGE : tc_display::CORAL);
  return m;
}

inline void tcPanelTick(const String &bootId) {
  using namespace tc_panel;
  using tc_display::screen;
  if (!initialized) return;
  const uint32_t now = millis(), second = now / 1000u;
  if (second == lastSecond) return;
  lastSecond = second;
  screen.fillRect(12, 56, 296, 14, tc_display::BG);
  screen.fillCircle(17, 62, 3, tc_display::heartbeatFresh(now) ? tc_display::SAGE : tc_display::AMBER);
  char line[45], boot[9]; tc_display::copyLabel(boot, sizeof(boot), bootId.c_str());
  snprintf(line, sizeof(line), "HELLO %s  UP %lus  BOOT %s", tc_display::heartbeatFresh(now) ? "LIVE" : "WAIT", static_cast<unsigned long>(second), boot);
  tc_display::text(27, 58, line, tc_display::MUTED, 1, tc_display::BG);
}
#else
inline bool tcPanelBegin() { return false; }
inline bool tcPanelSelftest() { return false; }
inline bool tcPanelReady() { return false; }
inline TCPanelMeasurement tcPanelExecute(uint8_t vector, const String &) {
  TCPanelMeasurement m; m.vectorIndex = vector; m.error = "panel-disabled"; m.sampledAtTickMs = millis(); return m;
}
inline void tcPanelTick(const String &) {}
#endif

namespace tc_panel_json {
static void rgb(String &out, const uint8_t raw[3]) {
  out += '['; out += String(raw[0]); out += ','; out += String(raw[1]); out += ','; out += String(raw[2]); out += ']';
}
static void pixel(String &out, int x, int y, uint32_t color, const uint8_t raw[3], uint16_t rgb565) {
  out += "{\"x\":"; out += String(x); out += ",\"y\":"; out += String(y);
  out += ",\"actualColor\":"; out += String(color); out += ",\"format\":\"RGB888\",\"rawRGB\":"; rgb(out, raw);
  out += ",\"rgb565\":"; out += String(rgb565); out += '}';
}
}

// Cached observations from the most recent actual calibration/job read. This
// accessor never samples or paints; sampledAtTickMs is not a fresh timestamp.
inline uint32_t tcPanelReferencesSampledAtTickMs() {
#if TC_ENABLE_ILI9341
  return tc_panel::lastReferences.sampledAtTickMs;
#else
  return 0;
#endif
}
inline String tcPanelReferencesJSON() {
  String out; out.reserve(350);
#if TC_ENABLE_ILI9341
  const TCPanelMeasurement &m = tc_panel::lastReferences;
  out = "{\"white\":"; tc_panel_json::pixel(out, 20, 200, m.whiteColor, m.whiteRgb, m.white565);
  out += ",\"black\":"; tc_panel_json::pixel(out, 44, 200, m.blackColor, m.blackRgb, m.black565); out += '}';
#else
  out = "null";
#endif
  return out;
}

inline String tcPanelMeasurementJSON(const TCPanelMeasurement &m) {
  String out; out.reserve(1150);
  out = "{\"profile\":\"TC-PANEL/0.1\",\"quality\":\"DISPLAY_PIXEL_READBACK\",\"scope\":\"controller-GRAM-only\",\"ok\":";
  out += m.ok ? "true" : "false";
  out += ",\"vectorIndex\":"; out += String(m.vectorIndex);
  out += ",\"inputs\":{\"C\":"; out += (m.vectorIndex & 4) ? "true" : "false";
  out += ",\"M\":"; out += (m.vectorIndex & 2) ? "true" : "false";
  out += ",\"E\":"; out += (m.vectorIndex & 1) ? "true" : "false";
  out += "},\"actualY\":"; out += m.ok ? (m.actualY ? "true" : "false") : "null";
  out += ",\"pixel\":"; tc_panel_json::pixel(out, 260, 116, m.actualColor, m.rgb, m.rgb565);
  out += ",\"references\":{\"white\":"; tc_panel_json::pixel(out, 20, 200, m.whiteColor, m.whiteRgb, m.white565);
  out += ",\"black\":"; tc_panel_json::pixel(out, 44, 200, m.blackColor, m.blackRgb, m.black565);
  out += "},\"rgb565\":"; out += String(m.rgb565); out += ",\"rgb\":"; tc_panel_json::rgb(out, m.rgb);
  out += ",\"white565\":"; out += String(m.white565); out += ",\"black565\":"; out += String(m.black565);
  out += ",\"whiteRgb\":"; tc_panel_json::rgb(out, m.whiteRgb); out += ",\"blackRgb\":"; tc_panel_json::rgb(out, m.blackRgb);
  out += ",\"readRegister\":\"0x2E\",\"readRegisterHz\":1000000,\"rotation\":1,\"sampledAtTickMs\":";
  out += String(m.sampledAtTickMs); out += ",\"visibleVerified\":false,\"error\":";
  if (m.error) { out += '"'; out += m.error; out += '"'; } else out += "null";
  out += '}';
  return out;
}
