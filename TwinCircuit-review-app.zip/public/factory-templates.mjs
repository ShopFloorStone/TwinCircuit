/** Publish saved specification versions and take editable copies into a workspace. */
export function createFactoryTemplates({
  api, command, modal, closeModal, toast, h, icon, when, getLocale, errorMessage,
  state, spec, circuit, draft, clearDraft, selectSpec
}) {
  const tr = (zh, en) => getLocale() === 'en-US' ? en : zh;
  const errors = {
    'Specification changed. Review the saved version before publishing.': '规格已更新，请关闭并重新核对要发布的版本。',
    'Enter a public factory name of 1 to 100 characters': '请填写 1 至 100 个字符的公开工厂名称。',
    'This template version is frozen. Save a new specification version to publish changes.': '此版本已发布。请先保存新版本，再发布更改。',
    'A permanent workspace owner or operator is required': '请以正式工作区所有者或操作者身份执行此操作。',
    'Template not found': '此模板已撤下或不存在，请刷新模板库。'
  };
  const messageFor = error => getLocale() === 'zh-CN' && Object.hasOwn(errors, error?.message)
    ? errors[error.message] : errorMessage(error);
  const canManage = () => {
    const s = state();
    return !!s && !s.workspace.demo && !s.user.isDemo && ['owner', 'operator'].includes(s.user.role);
  };
  const scope = () => state() ? `${state().workspace.id}/${state().user.id}` : null;
  const copyOf = id => state()?.specs.find(s => s.templateSource?.id === id);
  const readOnlyReason = () => state()?.workspace.demo || state()?.user.isDemo
    ? tr('登录正式工厂工作区即可发布和使用模板。', 'Use a factory workspace to publish or use templates.')
    : tr('工作区所有者和操作者可以发布和使用模板。', 'Workspace owners and operators can publish and use templates.');
  const viewChanged = () => new Error(tr('工作区或规格已更新，请重新打开模板。', 'The workspace or specification changed. Reopen the template.'));
  const libraryButton = () => `<button type="button" class="btn-secondary" data-action="factory-template-library">${icon('book')}${tr('模板库', 'Template library')}</button>`;
  function entry() {
    const own = spec()?.templateSource;
    return `<section class="ft-entry" aria-label="${tr('工厂模板', 'Factory templates')}">
      <div class="ft-intro">${icon('book')}<div><strong>${tr('工厂模板', 'Factory templates')}</strong>
      <small>${own ? h(tr('来源工厂', 'Source factory')+' · '+own.publisher+' · v'+own.version) :
        canManage() ? tr('公开分享已保存的规则，或选用其他工厂的模板。', 'Share a rule or use a template published by another factory.') : readOnlyReason()}</small></div></div>
      <div class="ft-actions">${libraryButton()}
      ${canManage() ? `<button type="button" class="btn-primary" data-action="factory-template-publish">${icon('upload')}${tr('发布为模板', 'Publish as template')}</button>` : ''}</div></section>`;
  }
  function details(s) {
    return `<div class="ft-preview"><div class="ft-preview-title"><strong>${h(s.name)}</strong><span class="ft-version">v${h(s.version)}</span></div>
      ${s.description ? `<p class="ft-description">${h(s.description)}</p>` : ''}
      <div class="ft-rule"><span>${h(s.profile)}</span><code>${h(s.expression)}</code></div></div>`;
  }
  function openPublication() {
    if (!canManage()) throw new Error(readOnlyReason());
    const current = spec();
    const selectedScope = scope();
    const compiled = circuit();
    let version = current.version;
    let needsSave = draft()?.expression !== undefined && draft().expression !== current.expression;
    const preview = {...current, version: version + (needsSave ? 1 : 0), expression: compiled.expression};
    modal(tr('发布工厂模板', 'Publish factory template'), `<form class="ft-publish" id="ft-publication">
      <p class="ft-guidance">${tr('其他工作区将看到以下内容，并可复制此版本。', 'Other workspaces will be able to view these details and copy this version.')}</p>
      ${details(preview)}
      <label class="form-field"><span>${tr('公开工厂名称', 'Public factory name')}</span>
        <input name="publisher" required maxlength="100" autocomplete="organization" placeholder="${tr('填写展示在模板库的工厂名称', 'Name to display in the template library')}"></label>
      <p class="field-help">${tr('在网站发布免费，无需钱包签名。', 'Publishing to the website is free and requires no wallet signature.')}</p>
      <div class="ft-message" role="alert"></div><div class="ft-footer">
      <button type="button" class="btn-secondary" data-action="close-dialog">${tr('取消', 'Cancel')}</button>
      <button type="submit" class="btn-primary">${icon('upload')}${needsSave ? tr('保存并发布', 'Save and publish') : tr('发布到模板库', 'Publish to library')}</button></div></form>`);
    const form = document.getElementById('ft-publication');
    const publisher = form.elements.publisher;
    const submit = form.querySelector('[type=submit]');
    const message = form.querySelector('[role=alert]');
    let edited = false;
    publisher.addEventListener('input', () => { edited = true; });
    api('/api/factory-templates?owned=1&limit=1').then(result => {
      if (form.isConnected && selectedScope === scope() && !edited && !publisher.value)
        publisher.value = result.templates[0]?.publisher || '';
    }).catch(() => {});
    const saveRequest = crypto.randomUUID();
    let requestId, lastPublisher;
    form.addEventListener('submit', async event => {
      event.preventDefault();
      if (submit.disabled) return;
      const name = publisher.value.trim();
      if (!name) { publisher.focus(); message.textContent = tr('请输入公开工厂名称。', 'Enter a public factory name.'); return; }
      message.textContent = '';
      submit.disabled = publisher.disabled = true;
      try {
        if (!canManage() || scope() !== selectedScope || spec()?.id !== current.id || spec().version !== version) throw viewChanged();
        if (needsSave) {
          await command('spec.update', {specId: current.id, expression: compiled.expression, variables: compiled.variables, netlistHex: compiled.netlistHex}, saveRequest);
          needsSave = false;
          if (scope() !== selectedScope || spec()?.id !== current.id || spec().version !== version + 1 || spec().expression !== compiled.expression) throw viewChanged();
          version = spec().version;
          clearDraft();
          if (!form.isConnected) return;
        }
        if (name !== lastPublisher) { requestId = crypto.randomUUID(); lastPublisher = name; }
        await command('template.publish', {specId: current.id, specVersion: version, publisher: name}, requestId);
        if (!form.isConnected || scope() !== selectedScope) return;
        toast(tr('模板已发布到模板库。', 'Template published to the library.'));
        openLibrary(true);
      } catch (error) {
        message.textContent = messageFor(error);
      } finally { submit.disabled = publisher.disabled = false; }
    });
  }
  function openLibrary(initialMine = false) {
    const selectedScope = scope();
    let mine = initialMine;
    modal(tr('工厂模板库', 'Factory template library'), `<div class="ft-library">
      <div class="ft-filters"><button type="button" class="btn-secondary" data-ft-filter="all">${tr('全部模板', 'All templates')}</button>
      <button type="button" class="btn-secondary" data-ft-filter="mine">${tr('本厂发布', 'Our publications')}</button></div>
      <form class="ft-search" role="search"><input type="search" maxlength="100" aria-label="${tr('搜索模板或工厂名称', 'Search template or factory name')}" placeholder="${tr('输入模板或工厂名称的开头', 'Search by the start of a template or factory name')}">
      <button type="submit" class="btn-secondary">${icon('search')}${tr('搜索', 'Search')}</button></form>
      ${canManage() ? '' : `<p class="field-help">${readOnlyReason()}</p>`}
      <div class="ft-status" role="status" aria-live="polite"></div>
      <div class="ft-list"></div><button type="button" class="btn-secondary ft-more" hidden>${tr('加载更多', 'Load more')}</button></div>`);
    const root = document.querySelector('.dialog .ft-library');
    const search = root.querySelector('input');
    const list = root.querySelector('.ft-list');
    const status = root.querySelector('.ft-status');
    const more = root.querySelector('.ft-more');
    let rows = new Map(), cursor = null, sequence = 0, timer, loading = false, mutating = false;
    const active = () => root.isConnected && scope() === selectedScope;
    const queryLimit = 18;
    function renderRows() {
      list.innerHTML = Array.from(rows.values(), item => {
        const copy = copyOf(item.id);
        return `<article class="ft-card"><div class="ft-card-header"><strong>${h(item.name)}</strong><span class="ft-version">v${h(item.version)}</span></div>
          <div class="ft-by">${icon('factory')}<span>${h(item.publisher)}</span><time>${h(when(item.publishedAt))}</time></div>
          ${item.description ? `<p class="ft-description">${h(item.description)}</p>` : ''}
          <div class="ft-card-footer"><details><summary>${tr('查看规则', 'View rule')}</summary><div class="ft-rule"><span>${h(item.profile)}</span><code>${h(item.expression)}</code></div></details>
          <div class="ft-actions">${mine && item.owned && canManage() ? `<button type="button" class="btn-ghost btn-small" data-ft-withdraw="${h(item.id)}">${tr('撤下', 'Withdraw')}</button>` : ''}
          ${canManage() || copy ? `<button type="button" class="btn-secondary btn-small" data-ft-use="${h(item.id)}">${icon(copy ? 'arrow' : 'copy')}${copy ? tr('打开副本', 'Open copy') : tr('使用模板', 'Use template')}</button>` : ''}</div></div></article>`;
      }).join('');
    }
    async function load(append = false) {
      if (!active() || (append && (loading || !cursor))) return;
      const turn = ++sequence;
      const params = new URLSearchParams({limit: String(queryLimit)});
      if (search.value.trim()) params.set('q', search.value.trim());
      if (mine) params.set('owned', '1');
      if (append) params.set('cursor', cursor);
      else { rows = new Map(); cursor = null; list.replaceChildren(); }
      loading = true;
      list.setAttribute('aria-busy', 'true');
      more.hidden = true;
      status.textContent = tr('正在读取模板…', 'Loading templates…');
      for (const filter of root.querySelectorAll('[data-ft-filter]')) filter.setAttribute('aria-pressed', String((filter.dataset.ftFilter === 'mine') === mine));
      try {
        const result = await api('/api/factory-templates?' + params);
        if (!active() || turn !== sequence) return;
        for (const item of result.templates) rows.set(item.id, item);
        cursor = result.nextCursor || null;
        renderRows();
        status.textContent = rows.size ? '' : search.value.trim() ? tr('没有找到匹配的模板。', 'No matching templates.') : mine ? tr('本厂还没有公开模板。', 'Your factory has no published templates.') : tr('模板库中还没有公开模板。', 'The library has no published templates yet.');
      } catch (error) {
        if (!active() || turn !== sequence) return;
        status.textContent = messageFor(error);
      } finally {
        if (active() && turn === sequence) {
          loading = false;
          list.setAttribute('aria-busy', 'false');
          more.hidden = !cursor;
        }
      }
    }
    root.querySelector('.ft-search').addEventListener('submit', event => { event.preventDefault(); clearTimeout(timer); load(); });
    search.addEventListener('input', () => { clearTimeout(timer); ++sequence; timer = setTimeout(() => load(), 250); });
    more.addEventListener('click', () => load(true));
    root.addEventListener('click', async event => {
      const button = event.target.closest('button');
      if (!button || !active() || mutating) return;
      if (button.dataset.ftFilter) {
        clearTimeout(timer); mine = button.dataset.ftFilter === 'mine'; load(); return;
      }
      const id = button.dataset.ftUse || button.dataset.ftWithdraw;
      const item = rows.get(id);
      if (!item) return;
      if (button.dataset.ftWithdraw) {
        openWithdrawal(item, selectedScope); return;
      }
      const existing = copyOf(id);
      if (existing && existing.id === spec()?.id) { closeModal(); selectSpec(existing.id); return; }
      if (!existing && !canManage()) return;
      const importCopy = async () => {
        if (!active() || mutating) return;
        if (existing) { closeModal(); selectSpec(existing.id); return; }
        mutating = true;
        button.disabled = true;
        try {
          await command('template.import', {templateId: id});
          if (!active()) return;
          const copy = copyOf(id);
          if (!copy) throw viewChanged();
          closeModal(); selectSpec(copy.id);
          toast(tr('已打开本工作区的可编辑副本。', 'Opened the editable copy in your workspace.'));
        } catch (error) { if (active()) status.textContent = messageFor(error); }
        finally { mutating = false; button.disabled = false; }
      };
      if (draft()?.expression !== undefined && draft().expression !== spec()?.expression) {
        status.innerHTML = `${tr('当前规格有未保存的修改。', 'The current specification has unsaved changes.')}
          <button type="button" class="btn-secondary btn-small">${tr('放弃修改并打开副本', 'Discard edits and open copy')}</button>`;
        status.querySelector('button').addEventListener('click', importCopy, {once:true});
      } else await importCopy();
    });
    load();
  }
  function openWithdrawal(item, selectedScope) {
    modal(tr('撤下工厂模板', 'Withdraw factory template'), `<div id="ft-withdraw">${details(item)}
      <p>${tr('撤下后，其他工厂将无法从目录选用此版本。已导入的副本可继续使用。', 'Withdrawing this version removes it from the library. Factories can keep using copies they already imported.')}</p>
      <div role="alert" class="ft-message"></div><div class="ft-footer">
      <button type="button" class="btn-secondary" data-ft-back>${tr('返回模板库', 'Back to library')}</button>
      <button type="button" class="btn-primary" data-ft-confirm>${tr('确认撤下', 'Confirm withdrawal')}</button></div></div>`);
    const box = document.getElementById('ft-withdraw');
    const back = box.querySelector('[data-ft-back]'), confirm = box.querySelector('[data-ft-confirm]');
    back.addEventListener('click', () => openLibrary(true));
    const requestId = crypto.randomUUID();
    confirm.addEventListener('click', async () => {
      if (scope() !== selectedScope || confirm.disabled) return;
      confirm.disabled = back.disabled = true;
      try {
        await command('template.withdraw', {templateId: item.id}, requestId);
        if (!box.isConnected || scope() !== selectedScope) return;
        toast(tr('模板已撤下。', 'Template withdrawn.')); openLibrary(true);
      } catch (error) { box.querySelector('[role=alert]').textContent = messageFor(error); }
      finally { confirm.disabled = back.disabled = false; }
    });
  }
  return {entry, libraryButton, openLibrary, openPublication};
}
