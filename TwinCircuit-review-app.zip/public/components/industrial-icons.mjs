// The 20-unit master drawings use half-unit rails and at least two units
// between adjacent traces. Each entry is one unfilled SVG path.
const drawings = Object.freeze({
  // Navigation, stations and assurance.
  chipMatrix: 'M2.5 2.5h6v6h-6z M12.5 2.5h5v6h-5z M2.5 12.5h6v5h-6z M12.5 12.5h5v5h-5z M5.5 8.5v4 M8.5 5.5h4',
  blueprint: 'M2.5 2.5h15v15h-15z M5.5 2.5v3 M9.5 2.5v2 M13.5 2.5v3 M6.5 8.5v5h7 M6.5 11.5h3v2',
  batchSlots: 'M2.5 4.5h15v12h-15z M2.5 8.5h15 M6.5 2.5v4 M13.5 2.5v4 M5.5 12.5h4 M12.5 12.5h2',
  scopePulse: 'M2.5 3.5h15v12h-15z M4.5 11.5h3v-5h4v5h4 M7.5 17.5h5',
  verifyGate: 'M2.5 6.5h3 M2.5 12.5h3 M5.5 3.5h5a6 6 0 0 1 6 6 M5.5 3.5v12h3 M11 13l2.5 2.5 5-6',
  terminalPins: 'M2.5 3.5h15v12h-15z M5.5 6.5l3 3-3 3 M10.5 12.5h4 M5.5 15.5v2 M10.5 15.5v2 M15.5 15.5v2',
  busTopology: 'M2.5 2.5h5v5h-5z M12.5 12.5h5v5h-5z M2.5 13.5h4v4h-4z M5 7.5v6 M5 10.5h10v2',
  chip: 'M4.5 4.5h11v11h-11z M7.5 1.5v3 M12.5 1.5v3 M7.5 15.5v3 M12.5 15.5v3 M1.5 7.5h3 M1.5 12.5h3 M15.5 7.5h3 M15.5 12.5h3 M7.5 8.5v-1h2',
  settlementNodes: 'M2.5 3.5h9v5h-9z M8.5 11.5h9v5h-9z M11.5 5.5h4v3 M8.5 14.5h-4v-3',
  batchCounter: 'M2.5 4.5h15v10h-15z M5.5 11.5v-3 M8.5 11.5v-3 M11.5 11.5v-3 M14.5 11.5v-3 M5.5 16.5h9',
  specStack: 'M3.5 2.5h9l3 3v8h-12z M12.5 2.5v3h3 M6.5 7.5h3v3h3 M6.5 16.5h12v-8',
  factory: 'M2.5 16.5v-8l5-3v4l5-3v3l2-1v-6h3v14z M5.5 13.5h1 M9.5 13.5h1 M13.5 13.5h1',
  capacityGauge: 'M2.5 6.5v9h15v-9 M3.5 3.5h13 M5.5 9.5v3 M9.5 8.5v4 M13.5 7.5v5',
  protocolCard: 'M2.5 4.5h12l3 3v7h-15z M5.5 7.5h4 M5.5 11.5h2 M11.5 11.5v5 M14.5 11.5v5',
  fixturePlug: 'M4.5 7.5h11v4l-3 3h-5l-3-3z M7.5 3.5v4 M12.5 3.5v4 M8.5 14.5v3 M11.5 14.5v3',
  inspectReticle: 'M2.5 7.5v-5h5 M12.5 2.5h5v5 M17.5 12.5v5h-5 M7.5 17.5h-5v-5 M7.5 10h5 M10 7.5v5',
  ioPorts: 'M6.5 4.5h7v11h-7z M2.5 7.5h4 M2.5 12.5h4 M13.5 7.5h4 M13.5 12.5h4 M9.5 7.5v5',
  logicGate: 'M6.5 4.5h3a5.5 5.5 0 0 1 0 11h-3z M2 7.5h4.5 M2 12.5h4.5 M15 10h3',
  vectorCheck: 'M1.5 10.5h4v-6h4v6h4 M9.5 14l3 3 5.5-6',
  batchRedeem: 'M2.5 4.5h15v4 M2.5 4.5v11h6 M2.5 8.5h9 M7.5 4.5v4 M12.5 12.5l2 2 3.5-4',
  tapeoutAnchor: 'M3.5 3.5h10l3 3v10h-13z M6.5 7.5h6 M9.5 7.5v6 M13.5 2v2 M2 13.5h2',
  sdk: 'M2.5 5.5h15v9h-15z M6.5 8l-2 2 2 2 M13.5 8l2 2-2 2 M10.5 7.5l-1 5 M6.5 14.5v3 M13.5 14.5v3',

  // Controls, records and workspace utilities.
  search: 'M13.5 8.5a5 5 0 1 1-10 0 5 5 0 1 1 10 0z M12.5 12.5l5 5',
  grid: 'M2.5 2.5h6v6h-6z M11.5 2.5h6v6h-6z M2.5 11.5h6v6h-6z M11.5 11.5h6v6h-6z',
  calendar: 'M2.5 4.5h15v12h-15z M2.5 8.5h15 M6.5 2v4 M13.5 2v4 M6.5 12.5h5',
  chart: 'M2.5 2.5v14h15 M5.5 12.5l4-4 3 2 4-6',
  checkfile: 'M3.5 2.5h9l4 4v11h-13z M12.5 2.5v4h4 M6.5 12l2.5 2.5 4-5',
  tool: 'M15.5 2.5l-3.5 3.5 2 2 3.5-3.5v4l-3 3h-4l-6 6-2-2 6-6v-4l3-3z',
  code: 'M6 6l-4 4 4 4 M14 6l4 4-4 4 M11.5 3.5l-3 13',
  layers: 'M2.5 6.5l7.5-4 7.5 4-7.5 4z M2.5 10.5l7.5 4 7.5-4 M2.5 14.5l7.5 4 7.5-4',
  user: 'M13.5 6a3.5 3.5 0 1 1-7 0 3.5 3.5 0 1 1 7 0z M3.5 17.5v-3l3-2.5h7l3 2.5v3',
  chevron: 'M7.5 4.5l5.5 5.5-5.5 5.5',
  arrow: 'M2.5 10.5h14 M12 5.5l5 5-5 5',
  connectorArrow: 'M1.5 7.5h6l4 4h6 M14 8l3.5 3.5L14 15',
  foldRail: 'M3.5 3.5v13 M15.5 5.5l-5 4.5 5 4.5 M10.5 10h7',
  home: 'M2 9l8-6.5L18 9 M4.5 7.5v10h4v-5h3v5h4v-10',
  file: 'M3.5 2.5h9l4 4v11h-13z M12.5 2.5v4h4 M6.5 10h6 M6.5 13.5h4',
  database: 'M3.5 3.5h13v13h-13z M3.5 7.5h13 M3.5 12.5h13 M6.5 5.5h2 M6.5 10h2 M6.5 14.5h2',
  clock: 'M10 2.5a7.5 7.5 0 1 1 0 15 7.5 7.5 0 1 1 0-15z M10 5.5V10l3.5 2',
  users: 'M10.5 6.5a3 3 0 1 1-6 0 3 3 0 1 1 6 0z M2 17v-3l2.5-2h6l2.5 2v3 M13 3.5a3 3 0 0 1 0 6 M14.5 12l3 2v3',
  check: 'M3.5 10.5l4.5 4.5 8.5-10',
  checkcircle: 'M6 2.5h8L17.5 6v8L14 17.5H6L2.5 14V6z M6 10l3 3 5-6',
  close: 'M4.5 4.5l11 11 M15.5 4.5l-11 11',
  alert: 'M10 2.5l8 14.5H2z M10 7.5v4 M10 14.5h.1',
  info: 'M3.5 2.5h10l3 3v12h-13z M10 6v.5 M10 9.5v4',
  eye: 'M2.5 10l3-4h9l3 4-3 4h-9z M12 10a2 2 0 1 1-4 0 2 2 0 1 1 4 0z',
  download: 'M10 2.5v10 M6.5 9l3.5 3.5L13.5 9 M3.5 13.5v3h13v-3',
  upload: 'M10 13V3.5 M6.5 7l3.5-3.5L13.5 7 M3.5 13.5v3h13v-3',
  cube: 'M2.5 6.5l7.5-4 7.5 4v7.5L10 18l-7.5-4z M2.5 6.5l7.5 4 7.5-4 M10 10.5V18',
  target: 'M15.5 10a5.5 5.5 0 1 1-11 0 5.5 5.5 0 1 1 11 0z M10 1.5v5 M10 13.5v5 M1.5 10h5 M13.5 10h5',
  refresh: 'M16.5 8l-1.5-3-3-1.5h-5L3.5 7 M16.5 3.5v4.5H12 M3.5 12l1.5 3 3 1.5h5l3.5-3.5 M3.5 16.5V12H8',
  pause: 'M4.5 3.5h3v13h-3z M12.5 3.5h3v13h-3z',
  play: 'M5.5 3.5l11 6.5-11 6.5z',
  stop: 'M4.5 4.5h11v11h-11z',
  shield: 'M10 2l6.5 2.5v6L15 14l-5 3.5L5 14l-1.5-3.5v-6z M7 9.5l2.5 2.5 4-5',
  network: 'M7.5 2.5h5v4h-5z M2 13.5h5v4H2z M13 13.5h5v4h-5z M10 6.5v3.5 M4.5 13.5V10h11v3.5',
  settings: 'M3.5 5.5h4 M11.5 5.5h5 M7.5 3h4v5h-4z M3.5 13.5h8 M15.5 13.5h1 M11.5 11h4v5h-4z',
  copy: 'M6.5 6.5h10v11h-10z M3.5 13.5v-11h9',
  wallet: 'M2.5 5.5l11-3v3 M2.5 5.5h15v11h-15z M17.5 9.5h-5v3h5',
  external: 'M11.5 3.5h5v5 M16.5 3.5l-8 8 M8.5 4.5h-5v12h12v-5',
  arrowUpRight: 'M4 16L16 4 M5.5 4H16v10.5',
  plus: 'M10 3.5v13 M3.5 10h13',
  logout: 'M8.5 2.5h-5v15h5 M7.5 10h10 M13.5 6l4 4-4 4',
  menu: 'M2.5 4.5h15 M2.5 10h15 M2.5 15.5h15',
  save: 'M3 2.5h11l3.5 3.5v11.5h-15v-15z M6 2.5v5h7v-5 M6 17.5v-6h8v6',
  lock: 'M3.5 8.5h13v9h-13z M6.5 8.5v-3a3.5 3.5 0 0 1 7 0v3 M10 12v2.5',
  sparkles: 'M2.5 10.5h4l2-7 3 13 2.5-6h4',
  book: 'M2.5 3.5h5L10 5l2.5-1.5h5v12h-5L10 17l-2.5-1.5h-5z M10 5v12',
  mail: 'M2.5 4.5h15v11h-15z M2.5 5l7.5 6 7.5-6',
  link: 'M8 6l3.5-3.5H15l2.5 2.5v3.5L14 12 M12 14l-3.5 3.5H5L2.5 15v-3.5L6 8 M6.5 13.5l7-7'
});

// At very small sizes, omit secondary pads and use native 16-unit coordinates.
const microDrawings = Object.freeze({
  arrow: 'M1.5 8h12 M9.5 4l4 4-4 4',
  connectorArrow: 'M1.5 5.5h3.5L9 9.5h5 M11 6.5l3 3-3 3',
  foldRail: 'M2.5 2.5v11 M11.5 4.5L8 8l3.5 3.5 M8 8h6',
  chevron: 'M5.5 3.5L10 8l-4.5 4.5',
  play: 'M4.5 2.5l9 5.5-9 5.5z',
  capacityGauge: 'M2 4.5v8h12v-8 M5 7.5v2.5 M8 6.5V10 M11 5.5V10',
  protocolCard: 'M1.5 3.5h10l3 3v5h-13z M4 6.5h4 M9.5 9.5v4 M12.5 9.5v4',
  fixturePlug: 'M3.5 6.5h9v3l-2.5 2.5H6L3.5 9.5z M5.5 2.5v4 M10.5 2.5v4 M8 12v2',
  inspectReticle: 'M2 5.5V2h3.5 M10.5 2H14v3.5 M14 10.5V14h-3.5 M5.5 14H2v-3.5 M6 8h4 M8 6v4',
  external: 'M9.5 2.5h4v4 M13.5 2.5l-6 6 M6.5 3.5h-4v10h10v-4',
  download: 'M8 2v8 M5 7l3 3 3-3 M2.5 10.5v3h11v-3',
  close: 'M3.5 3.5l9 9 M12.5 3.5l-9 9',
  check: 'M2.5 8l3.5 3.5 7.5-8',
  home: 'M1.5 7.5L8 2l6.5 5.5 M3.5 6v7.5h9V6',
  tapeoutAnchor: 'M2.5 2.5h8l3 3v8h-11z M5 6h6 M8 6v5'
});

// Fill the instrument casing only; leads, traces and indicators stay hollow.
const casings = Object.freeze({
  chipMatrix: 'M2.5 2.5h6v6h-6z M12.5 12.5h5v5h-5z',
  blueprint: 'M2.5 2.5h15v15h-15z',
  batchSlots: 'M2.5 4.5h15v4h-15z',
  scopePulse: 'M2.5 3.5h15v12h-15z',
  verifyGate: 'M5.5 3.5h5a6 6 0 0 1 6 6 6 6 0 0 1-6 6h-5z',
  terminalPins: 'M2.5 3.5h15v12h-15z',
  busTopology: 'M2.5 2.5h5v5h-5z M12.5 12.5h5v5h-5z M2.5 13.5h4v4h-4z',
  chip: 'M4.5 4.5h11v11h-11z',
  settlementNodes: 'M2.5 3.5h9v5h-9z M8.5 11.5h9v5h-9z',
  batchCounter: 'M2.5 4.5h15v10h-15z',
  specStack: 'M3.5 2.5h9l3 3v8h-12z',
  factory: 'M2.5 16.5v-8l5-3v4l5-3v3l2-1v-6h3v14z',
  protocolCard: 'M2.5 4.5h12l3 3v7h-15z',
  fixturePlug: 'M4.5 7.5h11v4l-3 3h-5l-3-3z',
  ioPorts: 'M6.5 4.5h7v11h-7z',
  logicGate: 'M6.5 4.5h3a5.5 5.5 0 0 1 0 11h-3z',
  tapeoutAnchor: 'M3.5 3.5h10l3 3v10h-13z',
  sdk: 'M2.5 5.5h15v9h-15z'
});
const microCasings = Object.freeze({
  protocolCard: 'M1.5 3.5h10l3 3v5h-13z',
  fixturePlug: 'M3.5 6.5h9v3l-2.5 2.5H6L3.5 9.5z',
  tapeoutAnchor: 'M2.5 2.5h8l3 3v8h-11z'
});

/** Decorative by design: its button, link or adjacent text names the action. */
export function icon(name, cls = '') {
  const small = cls.split(/\s+/).includes('micro');
  const smallPath = small && Object.hasOwn(microDrawings, name) ? microDrawings[name] : null;
  const path = smallPath || (Object.hasOwn(drawings, name) ? drawings[name] : drawings.cube);
  const box = smallPath ? 16 : 20;
  const plates = smallPath ? microCasings : casings;
  const underlay = Object.hasOwn(plates, name)
    ? `<path class="icon-casing" d="${plates[name]}" stroke="none" fill="currentColor" fill-opacity="0.10"/>`
    : '';
  return `<svg class="icon ${cls}" viewBox="0 0 ${box} ${box}" fill="none" stroke="currentColor" stroke-width="${small ? 1.6 : 1.5}" stroke-linecap="square" stroke-linejoin="miter" aria-hidden="true" focusable="false">${underlay}<path d="${path}"/></svg>`;
}
