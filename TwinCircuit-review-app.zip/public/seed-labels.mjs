import {t} from './i18n.mjs';

// Stable seed IDs distinguish the starter records from lookalike user records.
const originals = new Map([
  ['supplier_a', {name:'虚拟工厂 A', description:'通用数字 I/O 虚拟测试夹具，支持 8 组向量；不代表现实产能。'}],
  ['supplier_b', {name:'虚拟工厂 B', description:'兼容同一规格的独立虚拟工作站，可承接重新预约的测试任务。'}],
  ['spec_io_v1', {name:'数字 I/O 功能检测', description:'许可开启，且条件或手动成立时输出为 1；否则输出为 0。'}],
  ['TC-024', {name:'数字 I/O 检测服务 · 100 次'}],
]);

// An imported template can intentionally reuse a seed ID. A customized field
// can also be changed back to the original words. Keep both as authored text.
const historyByEvents = new WeakMap();
function historyFor(events) {
  let history = historyByEvents.get(events);
  if (history) return history;
  history = {imported:false, edited:new Set()};
  for (const event of events) {
    if (event.type === 'workspace.import' || event.type === 'workspace.reset') {
      history.imported = event.type === 'workspace.import';
      history.edited.clear();
      continue;
    }
    if (event.type !== 'supplier.update' && event.type !== 'spec.update') continue;
    const details = event.details || {};
    const id = details.supplierId ?? details.specId;
    const defaults = originals.get(id);
    if (!defaults) continue;
    for (const [field, original] of Object.entries(defaults)) {
      if (Object.hasOwn(details,field) && details[field] !== original) history.edited.add(id+'.'+field);
    }
  }
  historyByEvents.set(events,history);
  return history;
}

export function seededText(state,record,field='name') {
  const value = record?.[field] ?? '';
  if (!value || originals.get(record.id)?.[field] !== value) return value;
  const history = state?.events && historyFor(state.events);
  if (history?.imported || history?.edited.has(record.id+'.'+field)) return value;
  return t(value);
}

export function memberDisplayName(record,currentUser) {
  const member = record?.user ?? record;
  const name = member?.name || member?.email || '';
  return currentUser?.isDemo && member?.id === currentUser.id && name === '演示访客'
    ? t('演示访客') : name;
}
