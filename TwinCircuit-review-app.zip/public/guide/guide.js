const chapterMenu = document.querySelector('.rail-menu');
if (chapterMenu) {
  const desktop = window.matchMedia('(min-width: 721px)');
  const fitMenu = () => { chapterMenu.open = desktop.matches; };
  fitMenu();
  desktop.addEventListener('change', fitMenu);
}

const switcher = document.querySelector('[data-lang-link]');
if (switcher) {
  const otherChapter = switcher.getAttribute('href');
  const sections = [...document.querySelectorAll('.reader :is(.topic, #overview)')];
  function updateLanguageTarget() {
    let id = '';
    if (sections.length) {
      const target = sections.find(section => '#' + section.id === location.hash);
      const box = target?.getBoundingClientRect();
      const readingLine = Math.min(200,window.innerHeight * .33);
      if (box && box.top < window.innerHeight * .55 && box.bottom > readingLine) id = target.id;
      else for (const section of sections) {
        if (section.getBoundingClientRect().top > readingLine) break;
        id = section.id;
      }
    } else if (location.hash && document.getElementById(location.hash.slice(1))) {
      id = location.hash.slice(1);
    }
    switcher.href = otherChapter + (id ? '#' + id : '');
  }
  let pending = false;
  function schedule() {
    if (pending) return;
    pending = true;
    requestAnimationFrame(() => { pending = false; updateLanguageTarget(); });
  }
  addEventListener('scroll', schedule, {passive:true});
  addEventListener('hashchange', schedule);
  addEventListener('pageshow', schedule);
  switcher.addEventListener('focus', updateLanguageTarget);
  switcher.addEventListener('pointerdown', updateLanguageTarget);
  schedule();
}

const search = document.querySelector('.search');
if (search) {
  search.hidden = false;
  const input = search.querySelector('input');
  const empty = document.querySelector('.no-results');
  const cards = [...document.querySelectorAll('.chapter-card')];
  const before = new Map();
  function filter() {
    const term = input.value.trim().toLocaleLowerCase();
    let count = 0;
    for (const card of cards) {
      const list = card.querySelector('details');
      if (term && !before.has(card)) before.set(card, list.open);
      const match = [card.querySelector('h3'),card.querySelector('p')].some(el => el.textContent.toLocaleLowerCase().includes(term));
      let hit = false;
      for (const li of list.querySelectorAll('li')) {
        const found = li.textContent.toLocaleLowerCase().includes(term);
        li.hidden = Boolean(term) && !match && !found;
        hit ||= found;
      }
      card.hidden = Boolean(term) && !match && !hit;
      if (!card.hidden) count++;
      if (term) list.open = !card.hidden;
      else if (before.has(card)) {list.open = before.get(card);before.delete(card);}
    }
    empty.hidden = count !== 0;
  }
  input.addEventListener('input',filter);
  addEventListener('pageshow', filter);
}
