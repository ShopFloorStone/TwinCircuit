const entities = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const escapeText = value => String(value ?? '').replace(/[&<>"']/g, c => entities[c]);

export function techToken(value, {chip = false} = {}) {
  return `<span class="tech-token${chip ? ' tech-chip' : ''}">${escapeText(value)}</span>`;
}

// Match in plain display text. Never rewrite an HTML string, input value or data attribute.
const technical = /(?<![A-Za-z0-9_])(?:0x[0-9a-fA-F]+|(?:TC|TAP|ESP32)[-A-Za-z0-9]*(?:\/[\d.]+)?|(?:TwinCircuit|Profile|Chain ID|Revision|修订)\s+\d+(?:\.\d+)*|v\d+(?:\.\d+)*|X Layer|TapeOut|Modbus(?: TCP)?|OPC UA|I\/O|[A-Z]\d+(?:\s*\/\s*[A-Z]\d+)?|[A-Z]{2,}[0-9]*(?:[-_][A-Z0-9]+)*|\d+(?:[,.]\d+)*(?:\s*\/\s*\d+)?)(?![A-Za-z0-9_])/g;
export function techText(value) {
  const text = String(value ?? '');
  let result = '', start = 0;
  for (const match of text.matchAll(technical)) {
    result += escapeText(text.slice(start, match.index)) + techToken(match[0]);
    start = match.index + match[0].length;
  }
  return result + escapeText(text.slice(start));
}

export function metricValue(value, unit = '') {
  const suffix = unit ? ` <span class="metric-unit">${escapeText(unit)}</span>` : '';
  return `<span class="metric-value"><span class="metric-number">${escapeText(value)}</span>${suffix}</span>`;
}

export function statusLed() {
  return '<span class="status-led" aria-hidden="true"></span>';
}
