/** TwinCircuit browser SDK. Uses the current authenticated same-origin session. */
export class TwinCircuitClient {
  constructor({baseURL=globalThis.location?.origin,fetchImpl=globalThis.fetch}={}) {
    if(!baseURL||typeof fetchImpl!=='function')throw new TypeError('baseURL and fetch are required');
    this.baseURL=new URL(baseURL).origin;this.fetch=fetchImpl.bind(globalThis);this.csrfToken=null;this.revision=null;this.operationsRevision=null;
  }
  async request(path,{method='GET',body}={}) {
    const url=new URL(path,this.baseURL);if(url.origin!==this.baseURL)throw new Error('Cross-origin URL is forbidden');
    const headers={};if(body!==undefined)headers['Content-Type']='application/json';
    if(method!=='GET'&&this.csrfToken)headers['X-CSRF-Token']=this.csrfToken;
    const response=await this.fetch(url,{method,credentials:'same-origin',headers,body:body===undefined?undefined:JSON.stringify(body)});
    const data=await response.json();if(!response.ok){const error=new Error(data.error?.message||data.error||`HTTP ${response.status}`);error.status=response.status;error.code=data.error?.code;throw error;}
    if(data.csrfToken)this.csrfToken=data.csrfToken;
    if(Number.isInteger(data.revision)){if(url.pathname==='/api/operations'||url.pathname==='/api/operations/command')this.operationsRevision=data.revision;else this.revision=data.revision;}
    if(Number.isInteger(data.business?.revision))this.revision=data.business.revision;
    return data;
  }
  async session(){return this.request('/api/session');}
  async bootstrap(){await this.session();return this.request('/api/bootstrap');}
  async command(type,payload,{requestId=globalThis.crypto.randomUUID(),expectedRevision=this.revision}={}) {
    if(!Number.isInteger(expectedRevision))throw new Error('Call bootstrap() before issuing a command');
    // A 409 is deliberately not retried: read and review the changed state first.
    return this.request('/api/command',{method:'POST',body:{type,payload,expectedRevision,requestId}});
  }
  async operations(){await this.session();return this.request('/api/operations');}
  async operationsCommand(type,payload,{requestId=globalThis.crypto.randomUUID(),expectedRevision=this.operationsRevision}={}) {
    if(!Number.isInteger(expectedRevision))throw new Error('Call operations() before issuing an operations command');
    return this.request('/api/operations/command',{method:'POST',body:{type,payload,expectedRevision,requestId}});
  }
  async assist(prompt){return this.request('/api/assist',{method:'POST',body:{prompt}});}
  async rpc(payload){return this.request('/api/rpc',{method:'POST',body:payload});}
  async exportJSON(){return this.request('/api/export?format=json');}
  async report(orderId){if(!orderId)throw new TypeError('orderId is required');return this.request('/api/export?format=report&orderId='+encodeURIComponent(orderId));}
}
