/** Integration blueprints, not claims of connected factories or available real capacity. */
import {t} from './i18n.mjs';
export const LINE_TEMPLATES=Object.freeze([
 {id:'s3-panel',name:'TFT 显示测试工作台',subtitle:'ESP32-S3 + SPI TFT · 单件真实测试',protocol:'esp32-tft',icon:'chip',color:'green',kind:'显示专用接入',description:'开发板计算八组 CME 向量，写入黑白像素并读取显示控制器 GRAM；每次保留黑白参考读回，独立验收后另建 BEM 付款计划。',signals:[{name:'panel_vector',type:'number',min:0,max:7,critical:false}],stages:['板端求值','像素写入','GRAM读回','独立验收'],endpoint:'本地 USB 串口，独立 tft-panel 能力；不连接 GPIO4/5/6',equipment:'ESP32-S3 16MB + 已确认接线的 SPI TFT（9 根线）',metric:'8 组控制器 GRAM 测量；不证明光学输出',gateway:'serial'},
 {id:'s3-io',name:'数字 I/O 检测线',subtitle:'ESP32-S3 · 第一条实体接入',protocol:'esp32-serial',icon:'chip',color:'green',kind:'首选接入',description:'将 C / M / E 八组向量交给开发板，记录固件实际输出与 GPIO 读回，再提交独立验收。',signals:[{name:'led',type:'boolean',critical:false},{name:'cme_vector',type:'number',min:0,max:7,critical:false}],stages:['向量下发','板端求值','GPIO 读回','证据验收'],endpoint:'本地 USB 串口，COM 端口在边缘网关配置',equipment:'ESP32-S3 + 低压 LED 夹具',metric:'8 组数字向量',gateway:'serial'},
 {id:'pcba',name:'PCBA 工装测试线',subtitle:'Modbus TCP · 工业测试夹具',protocol:'modbus-tcp',icon:'factory',color:'blue',kind:'协议模板',description:'按本地信号映射连接测试夹具，配置允许的布尔线圈与数值范围，保留写入和读回。',signals:[{name:'fixture_enable',type:'boolean',critical:true},{name:'test_mode',type:'number',min:0,max:3,critical:true}],stages:['装夹确认','夹具使能','功能检测','结果归档'],endpoint:'测试夹具地址只在本地网关配置',equipment:'带 Modbus TCP 的 PLC / 测试夹具',metric:'线圈与寄存器白名单',gateway:'modbus'},
 {id:'assembly',name:'精密装配工作站',subtitle:'OPC UA · 工序协同',protocol:'opcua',icon:'tool',color:'amber',kind:'协议模板',description:'通过已配置的 OPC UA NodeId 接入工位信号。实际机械动作保留现场控制器和互锁决定。',signals:[{name:'station_request',type:'boolean',critical:true},{name:'recipe_index',type:'number',min:0,max:9,critical:true}],stages:['工单到位','配方确认','工序请求','工位读回'],endpoint:'OPC UA 证书与 NodeId 映射在本地网关配置',equipment:'支持 OPC UA 的工位控制器',metric:'具备质量字段的节点读回',gateway:'opcua'},
 {id:'sorting',name:'检测与分拣工作站',subtitle:'MQTT · 边缘消息链路',protocol:'mqtt',icon:'layers',color:'purple',kind:'协议模板',description:'使用指定主题与命令关联 ID 发送分拣请求，只接受匹配当前任务的设备回执。',signals:[{name:'sort_request',type:'boolean',critical:true},{name:'bin_index',type:'number',min:0,max:3,critical:true}],stages:['检测事件','分拣请求','匹配回执','批次记录'],endpoint:'MQTT Broker、TLS 和主题在本地网关配置',equipment:'具备命令回执的边缘控制器',metric:'任务 ID 与时间关联',gateway:'mqtt'},
 {id:'packaging',name:'包装与追溯工位',subtitle:'Modbus TCP · 包装流程',protocol:'modbus-tcp',icon:'cube',color:'teal',kind:'协议模板',description:'连接包装工位的允许信号。任务仅请求已定义工序，设备反馈与订单验收分别记录。',signals:[{name:'package_request',type:'boolean',critical:true},{name:'recipe_index',type:'number',min:0,max:9,critical:true}],stages:['批次识别','工序请求','包装读回','追溯归档'],endpoint:'本地工位控制器；不经浏览器直接访问 PLC',equipment:'包装工位 PLC / 低压教学工装',metric:'工序请求与状态读回',gateway:'modbus'},
 {id:'environment',name:'环境与设施控制站',subtitle:'MQTT · 有限范围设定',protocol:'mqtt',icon:'target',color:'sage',kind:'协议模板',description:'把环境设定作为有范围、可审批、可过期的请求。现场控制器负责传感和本地控制。',signals:[{name:'setpoint',type:'number',min:18,max:28,critical:true},{name:'enable_request',type:'boolean',critical:true}],stages:['采集状态','范围校验','设定请求','设备回执'],endpoint:'设备 Broker 和信号范围在边缘网关配置',equipment:'环境控制器 / 教学传感节点',metric:'18–28 的示例设定范围',gateway:'mqtt'},
]);
export const BEM_ASSET=Object.freeze({chainId:196,address:'0x60e62efa9405d6873c5deabd4e6cc91c25363952',symbol:'BEM',decimals:8});

export function decimalToUnits(text,decimals){
 if(!Number.isInteger(decimals)||decimals<0||decimals>18)throw new Error(t('代币精度尚未核验。'));
 if(typeof text!=='string'||!/^\d+(?:\.\d+)?$/.test(text.trim()))throw new Error(t('请输入十进制金额，不支持科学计数或负数。'));
 const [whole,fraction='']=text.trim().split('.');if(fraction.length>decimals)throw new Error(t('该代币最多 {decimals} 位小数。',{decimals}));
 const value=BigInt(whole)*10n**BigInt(decimals)+BigInt(fraction.padEnd(decimals,'0')||'0');
 if(value<=0n||value>=(1n<<256n))throw new Error(t('金额必须大于零并处于 uint256 范围内。'));return value.toString();
}
export function unitsToDecimal(value,decimals){try{const v=BigInt(value),base=10n**BigInt(decimals),frac=(v%base).toString().padStart(decimals,'0').replace(/0+$/,'');return (v/base).toString()+(frac?'.'+frac:'');}catch{return '—';}}
