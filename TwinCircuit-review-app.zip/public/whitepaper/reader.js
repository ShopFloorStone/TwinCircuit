(() => {
  const sections = Array.from(document.querySelectorAll('.chapter'));
  const byId = new Map(sections.map(s => [s.id, s]));
  const alternate = document.querySelector('[data-alternate]');
  const navLinks = Array.from(document.querySelectorAll('[data-section]'));
  const mobile = document.querySelector('.mobile-index details');
  const downloads = document.querySelector('.download-picker');
  const base = alternate.getAttribute('href');
  let current = '', pending = false;

  const update = () => {
    pending = false;
    const offset = document.querySelector('.sitebar').offsetHeight +
      (getComputedStyle(mobile.parentElement).display === 'none' ? 0 : mobile.querySelector('summary').offsetHeight) + 20;
    let next = '';
    for (const section of sections) {
      if (section.getBoundingClientRect().top > offset + 2) break;
      next = section.id;
    }
    const hash = location.hash.slice(1);
    const anchor = hash && document.getElementById(hash);
    // Keep source-level and explicit section links if the reader is still there.
    const inView = anchor && anchor.getBoundingClientRect().top >= 0 && anchor.getBoundingClientRect().top < innerHeight;
    alternate.href = base + (inView && (byId.has(hash) || hash.startsWith('ref-')) ? '#' + hash : next ? '#' + next : '');
    if (current === next) return;
    current = next;
    navLinks.forEach(a => {
      if (a.dataset.section === current) a.setAttribute('aria-current', 'location');
      else a.removeAttribute('aria-current');
    });
    const index = document.querySelector('.desktop-index');
    const visibleLink = index.querySelector('[aria-current="location"]');
    if (visibleLink && index.clientHeight && !index.contains(document.activeElement)) {
      const bounds = index.getBoundingClientRect();
      const link = visibleLink.getBoundingClientRect();
      if (link.bottom > bounds.bottom) index.scrollTop += link.bottom - bounds.bottom + 8;
      else if (link.top < bounds.top) index.scrollTop += link.top - bounds.top - 8;
    }
  };
  const schedule = () => {
    if (!pending) {pending = true; requestAnimationFrame(update);}
  };
  window.addEventListener('scroll',schedule,{passive:true});
  window.addEventListener('resize',schedule);
  window.addEventListener('hashchange',schedule);
  window.addEventListener('pageshow',schedule);
  alternate.addEventListener('click', update);
  alternate.addEventListener('focus', update);
  mobile.addEventListener('click', e => {
    const a = e.target.closest('a[data-section]');
    if (a) mobile.open = false;
  });
  document.addEventListener('click',e => {
    if (!downloads.contains(e.target)) downloads.open = false;
    if (!mobile.contains(e.target)) mobile.open = false;
  });
  document.addEventListener('keydown',e => {
    if (e.key !== 'Escape') return;
    for (const d of [mobile, downloads]) {
      if (d.open) { d.open=false; d.querySelector('summary').focus(); }
    }
  });
  update();
})();
