/** Persistent TC-IC workspace, rendered from server decisions and signed-in records. */
export function createIndustrialUI({api,t,h,icon,button,field,formFooter,notice,modal,closeModal,toast,download,when,techToken,getContext}) {
  let snapshot=null;
  let view='first';
  let workspaceId=null;
  const rules=()=>snapshot?.rules||{};
  const catalog=()=>snapshot?.catalog||{};
  const context=()=>getContext();
  const memberName=id=>context().members?.find(m=>(m.id||m.user?.id)===id)?.name||id||'—';
  const role=()=>context().user?.role;
  const canWrite=()=>!context().user?.isDemo&&['owner','operator'].includes(role());
  const canVerify=()=>!context().user?.isDemo&&role()==='verifier';
  const canGrant=()=>!context().user?.isDemo&&role()==='owner';
  const decisionValue=r=>r?.decision?.decision||r?.decision||'pending';
  const status=value=>({ready:t('可发首件要约'),pending:t('等待承诺'),accept:t('数字判据通过'),reject:t('数字判据超差'),review:t('需要人工复核'),payable:t('许可费用应计'),['not-payable']:t('未满足计费条件')})[value]||t('等待记录');
  const tone=value=>({ready:'green',accept:'green',payable:'green',reject:'amber',review:'amber',pending:'muted'})[value]||'muted';
  const chip=(label,value)=>`<span class="industrial-chip"><small>${h(label)}</small><b>${h(String(value??'—'))}</b></span>`;
  const tag=value=>`<span class="badge badge-${tone(value)}">${h(status(value))}</span>`;
  const empty=text=>`<div class="industrial-empty">${icon('file')}<p>${h(text)}</p></div>`;
  const requireSnapshot=()=>{if(!snapshot)throw new Error(t('请先加载工业标准工作台。'));};
  const byId=(items,id)=>items?.find(item=>item.id===id);
  const form=(name,inner,label)=>`<form data-form="industrial-${name}">${inner}${formFooter(t(label),'save')}</form>`;
  const chainProof=profile=>{
    const report=context().chainReport;
    if(report?.scope!=='imported-circuit-all-inputs'||!report.ok||report.total!==2**profile.nIn)return null;
    if(report.context?.workspaceId!==context().workspace?.id||report.context?.source!=='industrial-standard'||report.context?.specId!==profile.digest)return null;
    if(report.circuit?.nIn!==profile.nIn||report.circuit?.nOut!==profile.nOut||report.circuit?.netlistHex!==profile.netlistHex)return null;
    return report.evidence;
  };

  async function load() {
    const requested=context().workspace?.id;
    const response=await api('/api/industrial-rules');
    if(context().workspace?.id!==requested)return;
    snapshot=response;
    workspaceId=requested;
    return response;
  }
  function clear() {snapshot=null;workspaceId=null;view='first';}
  async function send(type,payload) {
    requireSnapshot();
    const response=await api('/api/industrial-rules/command',{method:'POST',body:{type,payload,expectedRevision:snapshot.revision,requestId:crypto.randomUUID()}});
    snapshot=response;
    workspaceId=context().workspace?.id;
    return response;
  }
  const current=()=>snapshot&&workspaceId===context().workspace?.id;

  function profileCard(key) {
    const profile=catalog()[key];if(!profile)return '';
    const descriptions={firstArticle:t('首件启动判据'),acceptancePass:t('测量区间通过判据'),acceptanceReject:t('测量区间超差判据'),license:t('工艺许可计费判据')};
    const proof=chainProof(profile);
    return `<article class="industrial-profile"><header><strong>${h(descriptions[key]||profile.name)}</strong><code>${h(profile.version)}</code></header><div class="industrial-expression">${h(profile.expression)}</div><dl><dt>${t('输入位序')}</dt><dd>${techToken(profile.inputOrder.join(' · '))}</dd><dt>${t('网表摘要')}</dt><dd><code title="${h(profile.digest)}">${h(profile.digest)}</code></dd><dt>${t('NAND 门数')}</dt><dd>${techToken(profile.gateCount)}</dd></dl><p class="industrial-chain-state">${proof? t('X Layer 已核对全部输入 · 区块 {p0}',{p0:h(proof.block)}):t('当前判据由服务器计算；尚无此网表的 X Layer 全向量核对。')}</p>${button(t('在 TapeOut 工作台打开'),'industrial-chain',{style:'secondary',ico:'layers',attrs:`data-profile="${h(key)}"`})}</article>`;
  }
  function profileDetails(key) {
    const profile=catalog()[key];if(!profile)return '';
    return `<details class="industrial-circuit"><summary>${t('查看此判据的电路输入与网表')}</summary>${profileCard(key)}<pre class="code-block">${h(profile.netlistHex)}</pre></details>`;
  }
  function firstArticle() {
    const items=rules().firstArticles||[];
    return `<section class="industrial-section"><div class="industrial-section-head"><div><h2>${icon('file')}${t('需求汇集与首件启动')}</h2><p>${t('需求、预算、合格工位、独立验证和工艺权利分别由有权成员承诺。电路给出发约资格，厂方仍需确认要约。')}</p></div>${button(t('发起首件计划'),'industrial-first-create',{ico:'plus',off:!canWrite()})}</div>${items.length?items.map(a=>{
      const d=decisionValue(a),demand=a.committedDemandUnits??a.pledgedDemandUnits??a.pledges?.filter(p=>!p.withdrawnAt).reduce((n,p)=>n+p.demandUnits,0)??0,budget=a.committedBudgetMinor??a.pledges?.filter(p=>!p.withdrawnAt).reduce((n,p)=>n+BigInt(p.budgetMinor),0n).toString()??'0';
      const actorId=context().user?.id,ownPledge=a.pledges?.find(p=>!p.withdrawnAt&&p.attestation?.actorId===actorId),ownCommits=a.commitments?.filter(c=>!c.withdrawnAt&&c.attestation?.actorId===actorId)||[];
      return `<article class="industrial-record"><div class="industrial-record-head"><h3>${h(a.title)}</h3>${tag(d)}</div><p class="industrial-record-id">${techToken(a.id)} · ${t('规则版本')} ${techToken(a.decision?.standardVersion||'TC-IC/0.1')}</p><div class="industrial-chips">${chip(t('需求承诺'),`${demand} / ${a.requiredDemandUnits}`)}${chip(t('预算承诺'),`${budget} / ${a.requiredBudgetMinor}`)}${chip(t('现场能力'),a.commitments?.some(c=>c.kind==='capability'&&!c.withdrawnAt)?t('已确认'):t('待确认'))}${chip(t('独立验证'),a.commitments?.some(c=>c.kind==='verifier'&&!c.withdrawnAt)?t('已确认'):t('待确认'))}${chip(t('工艺权利'),a.commitments?.some(c=>c.kind==='rights'&&!c.withdrawnAt)?t('已确认'):t('待确认'))}</div><p class="industrial-scope">${t('判据输入')} <code>${h(JSON.stringify(a.decision?.inputs||{}))}</code> · ${t('结果')} <code>${h(String(a.decision?.circuit?.output??'—'))}</code></p><div class="toolbar wrap">${button(t('提交需求承诺'),'industrial-first-pledge',{style:'secondary',attrs:`data-id="${h(a.id)}"`,off:!canWrite()||!!ownPledge})}${button(t('登记工位、验证或权利承诺'),'industrial-first-commit',{style:'ghost',attrs:`data-id="${h(a.id)}"`,off:context().user?.isDemo||role()==='viewer'})}${ownPledge?button(t('撤回我的需求承诺'),'industrial-withdraw-pledge',{style:'ghost',attrs:`data-id="${h(a.id)}"` }):''}${ownCommits.map(c=>button(t(c.kind==='capability'?'撤回我的工位承诺':c.kind==='verifier'?'撤回我的验证承诺':'撤回我的权利承诺'),'industrial-withdraw-commit',{style:'ghost',attrs:`data-id="${h(a.id)}" data-kind="${h(c.kind)}"` })).join('')}</div></article>`;
    }).join(''):empty(t('还没有首件计划。创建计划后，邀请具备相应角色的成员分别提交承诺。'))}${profileDetails('firstArticle')}</section>`;
  }
  function acceptance() {
    const specs=rules().acceptanceSpecs||[],evidence=rules().evidence||[];
    return `<section class="industrial-section"><div class="industrial-section-head"><div><h2>${icon('shield')}${t('跨厂测量与验收')}</h2><p>${t('以整数微米冻结公差，并逐件保存测量区间、工位、来源及复核人。电路负责数字判据，独立审阅负责证据签收。')}</p></div>${button(t('建立测量规格'),'industrial-acceptance-spec',{ico:'plus',off:!canWrite()})}</div>${specs.length?specs.map(s=>`<article class="industrial-record"><div class="industrial-record-head"><h3>${h(s.title)}</h3><span class="badge badge-green">${t('规格已冻结')}</span></div><p class="industrial-record-id">${techToken(s.id)} · ${t('规格摘要')} <code>${h(s.digest||s.specDigest||'—')}</code></p><div class="industrial-chips">${chip(t('下限'),`${s.lowerMicrometers} µm`)}${chip(t('上限'),`${s.upperMicrometers} µm`)}${chip(t('独立测量'),s.requireIndependentMeasurement?t('要求'):t('按合同选择'))}${chip(t('提交件数'),evidence.filter(e=>e.specId===s.id).length)}</div><div class="toolbar">${button(t('提交实物测量'),'industrial-acceptance-submit',{ico:'upload',attrs:`data-id="${h(s.id)}"`,off:!canWrite()})}</div></article>`).join(''):empty(t('先冻结测量范围，工厂才能按同一规格提交工件证据。'))}<h3>${t('逐件证据与独立审阅')}</h3>${evidence.length?evidence.slice().reverse().map(e=>{
      const d=decisionValue(e),review=e.review||{};
      return `<article class="industrial-evidence"><div class="industrial-record-head"><h3>${t('工件')} ${techToken(e.unitId)}</h3>${tag(d)}</div><p>${t('供应方')} ${h(e.supplierName||e.supplierId)} · ${t('测量来源')} ${h(e.source||'—')}</p><div class="industrial-chips">${chip(t('实测值'),`${e.measurement?.measuredMicrometers} µm`)}${chip(t('扩展不确定度'),`±${e.measurement?.uncertaintyMicrometers} µm`)}${chip(t('判定区间'),e.decision?.intervalMicrometers?`${e.decision.intervalMicrometers.lower}–${e.decision.intervalMicrometers.upper} µm`:'—')}${chip(t('复核状态'),e.reviewStatus==='accepted'?t('已接受'):e.reviewStatus==='retest'?t('需要人工复核'):e.reviewStatus==='rejected'?t('已拒绝'):t('待独立审阅'))}</div><p class="industrial-scope">${t('关联首件计划')} ${techToken(e.orderId)} · ${t('校准引用')} ${h(e.calibrationRef||'—')} · ${t('提交人')} ${h(e.submitted?.actorName||memberName(e.submitted?.actorId))}</p><div class="toolbar">${button(t('查看完整证据'),'industrial-evidence-detail',{style:'secondary',ico:'eye',attrs:`data-id="${h(e.id)}"`})}${e.reviewStatus==='pending'?button(t('独立审阅'),'industrial-evidence-review',{ico:'shield',attrs:`data-id="${h(e.id)}"`,off:!canVerify()}):''}</div></article>`;
    }).join(''):empty(t('还没有实物测量。测量值需来自实际设备或量具，并由具备独立身份的成员复核。'))}${profileDetails('acceptancePass')}${profileDetails('acceptanceReject')}</section>`;
  }
  function licenses() {
    const grants=rules().licenseGrants||[],uses=rules().licenseUses||[];
    return `<section class="industrial-section"><div class="industrial-section-head"><div><h2>${icon('file')}${t('工艺许可与按件计费')}</h2><p>${t('权利人冻结被许可人、适用规格、期限、额度和每件费率。验收的工件可登记一次许可使用，形成待支付凭据。')}</p></div>${button(t('登记工艺许可'),'industrial-license-grant',{ico:'plus',off:!canGrant()})}</div>${grants.length?grants.map(g=>`<article class="industrial-record"><div class="industrial-record-head"><h3>${h(g.title)}</h3><span class="badge badge-${g.revokedAt?'amber':'green'}">${g.revokedAt?t('已撤销'):t('有效期按合同核验')}</span></div><p class="industrial-record-id">${techToken(g.id)} · ${t('适用规格')} <code>${h(g.profileDigest)}</code></p><div class="industrial-chips">${chip(t('被许可人'),memberName(g.licenseeId))}${chip(t('每件费率'),`${g.rateMinor} ${g.assetSymbol||''} ${t('最小单位')}`)}${chip(t('授权额度'),`${g.usedUnits??0} / ${g.maxUnits}`)}${chip(t('有效期'),`${when(g.validFrom)} – ${when(g.validUntil)}`)}</div><div class="toolbar">${button(t('登记已验收工件使用'),'industrial-license-use',{style:'secondary',ico:'file',attrs:`data-id="${h(g.id)}"`,off:context().user?.isDemo||g.revokedAt||context().user?.id!==g.licenseeId})}${!g.revokedAt&&canGrant()?button(t('撤销此许可'),'industrial-license-revoke',{style:'ghost',attrs:`data-id="${h(g.id)}"` }):''}</div></article>`).join(''):empty(t('暂无工艺许可。先创建验收规格并邀请承制成员，再签发适用该规格的许可。'))}<h3>${t('已登记的许可使用')}</h3>${uses.length?uses.slice().reverse().map(u=>`<article class="industrial-evidence"><div class="industrial-record-head"><h3>${t('工件')} ${techToken(u.unitId)}</h3>${tag(decisionValue(u))}</div><p>${t('订单')} ${techToken(u.orderId)} · ${t('工艺许可')} ${techToken(u.grantId)}</p><div class="industrial-chips">${chip(t('应计费用'),`${u.decision?.feeMinor??u.feeMinor??0} ${u.assetSymbol||''} ${t('最小单位')}`)}${chip(t('支付状态'),u.paymentStatus==='paid'?t('已支付'):t('待结算'))}</div><details class="industrial-circuit"><summary>${t('查看计费判据输入与输出')}</summary><p class="industrial-record-id">${t('证据编号')} ${techToken(u.evidenceId)} · ${t('登记人')} ${h(u.recorded?.actorName||memberName(u.recorded?.actorId))}</p><pre class="code-block">${h(JSON.stringify(u.decision,null,2))}</pre></details></article>`).join(''):empty(t('还没有许可使用记录。只有已经独立验收的对应工件才能登记。'))}${notice(t('许可判据给出应计费用；链上转账、发票和真实到账需要另行完成并核对。'),'amber')}${profileDetails('license')}</section>`;
  }
  function audit() {
    const events=rules().events||[];
    return `<section class="industrial-section"><div class="industrial-section-head"><div><h2>${icon('file')}${t('标准事件与复算材料')}</h2><p>${t('每次承诺、证据审阅和许可使用保留主体、时间及规则版本，可导出后独立核对。')}</p></div>${button(t('导出完整 JSON'),'industrial-export',{style:'secondary',ico:'download'})}</div>${events.length?`<div class="industrial-audit">${events.slice().reverse().map(e=>`<article><strong>${h(e.type||e.action||t('工业标准事件'))}</strong><small>${h(when(e.at||e.createdAt))} · ${h(e.actorId||e.userId||'—')}</small><pre>${h(JSON.stringify(e,null,2))}</pre></article>`).join('')}</div>`:empty(t('尚无标准事件。'))}<div class="industrial-profiles">${Object.keys(catalog()).map(profileCard).join('')}</div></section>`;
  }
  function render() {
    if(!current())return `<section class="panel industrial-loading">${t('正在读取工业标准记录…')} ${button(t('重新加载'),'industrial-reload',{style:'secondary',ico:'refresh'})}</section>`;
    const recordCount=(rules().firstArticles?.length||0)+(rules().evidence?.length||0)+(rules().licenseUses?.length||0);
    return `<div class="industrial-workspace"><section class="industrial-intro"><div><span class="industrial-overline">TC-IC/0.1 · ${t('项目标准草案')}</span><h2>${t('让工序规则跨工厂复算')}</h2><p>${t('系统依据注明提交人及其角色的业务记录，核对首件启动、工件验收和工艺计费条件。服务器保留记录，TapeOut 可用相同的 NAND 判据复算结果。')}</p></div><div class="industrial-summary">${chip(t('工作区修订'),snapshot.revision)}${chip(t('已登记记录'),recordCount)}<a href="${context().locale==='en-US'?'/standard/en/':'/standard/'}" target="_blank" rel="noopener">${t('阅读公开标准与测试向量')} ${icon('arrow')}</a></div></section>${context().user?.isDemo?notice(t('当前为独立演示工作区。登录正式账号后可保存实际需求、设备承诺、工件证据与许可。'),'amber'):''}<div class="tabs industrial-tabs">${[['first',t('首件启动')],['acceptance',t('跨厂验收')],['license',t('工艺许可')],['audit',t('规则与审计')]].map(([key,label])=>`<button class="tab ${view===key?'active':''}" data-action="industrial-view" data-view="${key}">${label}</button>`).join('')}</div>${view==='acceptance'?acceptance():view==='license'?licenses():view==='audit'?audit():firstArticle()}</div>`;
  }
  function selectView(next) {if(['first','acceptance','license','audit'].includes(next))view=next;}
  function profile(key) {return catalog()[key]||null;}
  function exportSnapshot() {requireSnapshot();download('TwinCircuit-TC-IC-0.1-'+(context().workspace?.id||'workspace')+'.json',JSON.stringify({format:'twincircuit-industrial-rules/0.1',workspaceId:context().workspace?.id,exportedAt:new Date().toISOString(),revision:snapshot.revision,catalog:snapshot.catalog,rules:snapshot.rules},null,2));}

  function open(action,id) {
    requireSnapshot();
    if(action==='industrial-first-create')modal(t('发起首件计划'),form('first-create',`${field(t('制造需求名称'),'title')}${field(t('启动所需数量'),'requiredDemandUnits','',{type:'number',min:1,step:1})}${field(t('首件所需预算（最小记账单位）'),'requiredBudgetMinor','',{help:t('此处记录预算承诺，资金转移须按约定另行完成。')})}`, '冻结首件条件'));
    if(action==='industrial-first-pledge')modal(t('提交需求承诺'),form('first-pledge',`<input type="hidden" name="firstArticleId" value="${h(id)}">${field(t('承诺件数'),'demandUnits','',{type:'number',min:1,step:1})}${field(t('承诺预算（最小记账单位）'),'budgetMinor')}${notice(t('承诺会记录你的账号身份。预算承诺不自动划转资金。'),'blue')}`, '提交承诺'));
    if(action==='industrial-first-commit'){
      const article=byId(rules().firstArticles,id),mine=article?.commitments?.filter(c=>!c.withdrawnAt&&c.attestation?.actorId===context().user?.id).map(c=>c.kind)||[];
      const allowed=role()==='verifier'?['verifier']:role()==='owner'?['capability','rights']:role()==='operator'?['capability']:[];
      const choices=allowed.filter(k=>!mine.includes(k));
      if(!choices.length)throw new Error(t('你已提交本角色可用的承诺，可先撤回再更新。'));
      const labels={capability:t('合格工位'),verifier:t('独立验证'),rights:t('工艺权利已清理')};
      modal(t('登记首件资源承诺'),form('first-commit',`<input type="hidden" name="firstArticleId" value="${h(id)}"><label class="form-field"><span>${t('承诺类别')}</span><select name="kind">${choices.map(k=>`<option value="${k}">${labels[k]}</option>`).join('')}</select></label>${field(t('设备或工位编号'),'assetId','',{required:false})}${field(t('现场确认说明'),'statement','',{minlength:8})}${field(t('资质或协议引用'),'qualificationRef','',{required:false})}${notice(t('合格工位须填写设备编号及资质引用；独立验证由验证者账号确认。'),'amber')}`, '提交资源承诺'));
    }
    if(action==='industrial-acceptance-spec')modal(t('建立测量验收规格'),form('acceptance-spec',`${field(t('工序或产品名称'),'title')}${field(t('公差下限（整数 µm）'),'lowerMicrometers','',{type:'number',step:1})}${field(t('公差上限（整数 µm）'),'upperMicrometers','',{type:'number',step:1})}<label class="industrial-check"><input type="checkbox" name="requireIndependentMeasurement" value="yes" checked>${t('要求独立测量来源')}</label>${notice(t('公差在创建后固定。单位为微米，扩展不确定度在每条实物证据中填写。'),'blue')}`, '冻结测量规格'));
    if(action==='industrial-acceptance-submit'){
      const s=byId(rules().acceptanceSpecs,id),suppliers=(context().suppliers||[]).filter(x=>x.mode==='external'),ready=(rules().firstArticles||[]).filter(a=>decisionValue(a)==='ready');
      if(!s)throw new Error(t('找不到测量规格，请刷新。'));
      if(!suppliers.length)throw new Error(t('请先在能力目录登记外部供应商。'));
      if(!ready.length)throw new Error(t('请先完成可发首件要约的需求承诺。'));
      modal(t('提交工件测量证据'),form('acceptance-submit',`<input type="hidden" name="specId" value="${h(id)}"><label class="form-field"><span>${t('关联首件计划')}</span><select name="orderId">${ready.map(a=>`<option value="${h(a.id)}">${h(a.title)} · ${h(a.id)}</option>`).join('')}</select></label>${field(t('工件唯一编号'),'unitId')}${field(t('实测值（整数 µm）'),'measuredMicrometers','',{type:'number',step:1})}${field(t('扩展不确定度（整数 µm）'),'uncertaintyMicrometers','',{type:'number',min:0,step:1})}<label class="form-field"><span>${t('实际承制供应商')}</span><select name="supplierId">${suppliers.map(x=>`<option value="${h(x.id)}">${h(x.name)}</option>`).join('')}</select></label>${field(t('测量来源或仪器编号'),'source')}${field(t('校准文件或证书引用'),'calibrationRef')}<div class="industrial-confirmations"><label><input type="checkbox" name="identityVerified" value="yes">${t('已核对实物与工件编号')}</label><label><input type="checkbox" name="calibrationValid" value="yes">${t('已核对仪器校准有效')}</label><label><input type="checkbox" name="independentMeasurement" value="yes">${t('测量来源独立于承制方')}</label></div>${notice(t('这些是提交者的声明。技术判据需由另一身份审阅后才能成为验收记录。'),'amber')}`, '提交待审证据'));
    }
    if(action==='industrial-evidence-detail'){
      const e=byId(rules().evidence,id);if(!e)throw new Error(t('证据记录不存在。'));
      modal(t('工件证据与判据输入'),`<dl class="detail-dl"><dt>${t('工件')}</dt><dd>${techToken(e.unitId)}</dd><dt>${t('规格')}</dt><dd>${techToken(e.specId)}</dd><dt>${t('规格摘要')}</dt><dd><code>${h(e.specDigest)}</code></dd><dt>${t('关联首件计划')}</dt><dd>${techToken(e.orderId)}</dd><dt>${t('测量来源')}</dt><dd>${h(e.source)}</dd><dt>${t('校准引用')}</dt><dd>${h(e.calibrationRef)}</dd><dt>${t('实测值')}</dt><dd>${h(e.measurement?.measuredMicrometers)} µm</dd><dt>${t('扩展不确定度')}</dt><dd>±${h(e.measurement?.uncertaintyMicrometers)} µm</dd><dt>${t('提交人')}</dt><dd>${h(e.submitted?.actorName||memberName(e.submitted?.actorId))}</dd><dt>${t('复核人')}</dt><dd>${h(e.review?.actorName||memberName(e.review?.actorId))}</dd></dl><pre class="code-block">${h(JSON.stringify(e.decision,null,2))}</pre>`);
    }
    if(action==='industrial-evidence-review'){
      const e=byId(rules().evidence,id);if(!e)throw new Error(t('证据记录不存在。'));
      modal(t('独立审阅工件证据'),form('evidence-review',`<input type="hidden" name="evidenceId" value="${h(id)}"><p>${t('工件')} ${techToken(e.unitId)} · ${t('数字判据')} ${tag(decisionValue(e))}</p>${field(t('审阅依据与结论说明'),'note','',{minlength:8})}<label class="industrial-check"><input type="checkbox" name="approved" value="yes">${t('已核对原始证据并接受本件')}</label>${notice(t('不勾选将记录拒绝。审阅人必须与证据提交人不同。'),'amber')}`, '保存独立审阅'));
    }
    if(action==='industrial-license-grant'){
      const specs=rules().acceptanceSpecs||[],members=(context().members||[]).filter(m=>['operator','owner'].includes(m.role));
      if(!specs.length)throw new Error(t('请先建立测量验收规格。'));
      if(!members.length)throw new Error(t('请先邀请有权登记使用的成员。'));
      modal(t('登记工艺许可'),form('license-grant',`${field(t('工艺或权利名称'),'title')}<label class="form-field"><span>${t('被许可成员')}</span><select name="licenseeId">${members.map(m=>`<option value="${h(m.id||m.user?.id)}">${h(m.name||m.email)}</option>`).join('')}</select></label><label class="form-field"><span>${t('适用验收规格摘要')}</span><select name="profileDigest">${specs.map(s=>`<option value="${h(s.digest||s.specDigest)}">${h(s.title)} · ${h(s.digest||s.specDigest)}</option>`).join('')}</select></label>${field(t('生效时间'),'validFrom','',{type:'datetime-local'})}${field(t('到期时间'),'validUntil','',{type:'datetime-local'})}${field(t('每件费率（资产最小单位）'),'rateMinor','',{help:t('按资产合约 decimals 换算成最小单位整数；这里只登记应计金额。')})}${field(t('最大授权件数'),'maxUnits','',{type:'number',min:1,step:1})}${field(t('资产代码'),'assetSymbol','BEM')}${notice(t('签发许可建立应计条件，不会立即从钱包扣款。'),'blue')}`, '签发工艺许可'));
    }
    if(action==='industrial-license-use'){
      const g=byId(rules().licenseGrants,id),eligible=(rules().evidence||[]).filter(e=>(e.specDigest===g?.profileDigest||byId(rules().acceptanceSpecs,e.specId)?.digest===g?.profileDigest)&&e.reviewStatus==='accepted'&&decisionValue(byId(rules().firstArticles,e.orderId))==='ready'&&!(rules().licenseUses||[]).some(u=>u.grantId===g?.id&&u.evidenceId===e.id));
      if(!g)throw new Error(t('许可记录不存在。'));
      if(!eligible.length)throw new Error(t('还没有该规格下独立验收的工件。'));
      modal(t('登记已验收工件的许可使用'),form('license-use',`<input type="hidden" name="grantId" value="${h(id)}"><input type="hidden" name="licenseeId" value="${h(g.licenseeId)}"><input type="hidden" name="profileDigest" value="${h(g.profileDigest)}"><label class="form-field"><span>${t('已验收工件')}</span><select name="evidenceId">${eligible.map(e=>`<option value="${h(e.id)}">${h(e.unitId)} · ${h(e.orderId)}</option>`).join('')}</select></label>${notice(t('系统逐件校验许可与已审证据，并防止同一工件重复计费。生成的费用先记为待支付。'),'blue')}`, '登记许可使用'));
    }
    if(action==='industrial-license-revoke')modal(t('撤销此许可'),form('license-revoke',`<input type="hidden" name="grantId" value="${h(id)}">${field(t('撤销原因'),'reason','',{minlength:8})}${notice(t('撤销后，新的许可使用将被拒绝，已有记录保留。'),'amber')}`, '确认撤销'));
  }

  async function submit(kind,values) {
    const int=(name)=>Number(values[name]);
    const yes=(name)=>values[name]==='yes';
    const utc=(name)=>new Date(values[name]).toISOString();
    switch(kind){
      case 'industrial-first-create':await send('industrial.first.create',{title:values.title,requiredDemandUnits:int('requiredDemandUnits'),requiredBudgetMinor:values.requiredBudgetMinor});break;
      case 'industrial-first-pledge':await send('industrial.first.pledge',{firstArticleId:values.firstArticleId,demandUnits:int('demandUnits'),budgetMinor:values.budgetMinor});break;
      case 'industrial-first-commit':if(values.kind==='capability'&&(!values.assetId?.trim()||!values.qualificationRef?.trim()))throw new Error(t('请填写合格工位编号和资质引用。'));await send('industrial.first.commit',{firstArticleId:values.firstArticleId,kind:values.kind,assetId:values.assetId||undefined,statement:values.statement,qualificationRef:values.qualificationRef||undefined});break;
      case 'industrial-acceptance-spec':await send('industrial.acceptance.spec',{title:values.title,lowerMicrometers:int('lowerMicrometers'),upperMicrometers:int('upperMicrometers'),requireIndependentMeasurement:yes('requireIndependentMeasurement')});break;
      case 'industrial-acceptance-submit':await send('industrial.acceptance.submit',{orderId:values.orderId,specId:values.specId,unitId:values.unitId,supplierId:values.supplierId,measuredMicrometers:int('measuredMicrometers'),uncertaintyMicrometers:int('uncertaintyMicrometers'),identityVerified:yes('identityVerified'),calibrationValid:yes('calibrationValid'),independentMeasurement:yes('independentMeasurement'),source:values.source,calibrationRef:values.calibrationRef});break;
      case 'industrial-evidence-review':await send('industrial.acceptance.review',{evidenceId:values.evidenceId,approved:yes('approved'),note:values.note});break;
      case 'industrial-license-grant':await send('industrial.license.grant',{title:values.title,licenseeId:values.licenseeId,profileDigest:values.profileDigest,validFrom:utc('validFrom'),validUntil:utc('validUntil'),rateMinor:values.rateMinor,maxUnits:int('maxUnits'),assetSymbol:values.assetSymbol});break;
      case 'industrial-license-use':{const evidence=byId(rules().evidence,values.evidenceId);if(!evidence)throw new Error(t('证据记录不存在。'));await send('industrial.license.use',{grantId:values.grantId,orderId:evidence.orderId,unitId:evidence.unitId,licenseeId:values.licenseeId,profileDigest:values.profileDigest,quantity:1});break;}
      case 'industrial-license-revoke':await send('industrial.license.revoke',{grantId:values.grantId,reason:values.reason});break;
      default:return false;
    }
    closeModal();toast(t('工业标准记录已由服务器保存。'));
    return true;
  }
  async function withdrawPledge(firstArticleId){await send('industrial.first.pledge.withdraw',{firstArticleId});toast(t('已撤回承诺'));}
  async function withdrawCommit(firstArticleId,kind){await send('industrial.first.commit.withdraw',{firstArticleId,kind});toast(t('已撤回承诺'));}
  return {load,clear,render,selectView,profile,open,submit,withdrawPledge,withdrawCommit,exportSnapshot,current};
}
