// Shared entry point for workspace, equipment and settlement views.
export { icon } from './components/industrial-icons.mjs';
