import {truthTable,circuitHash} from './engine.mjs';
import {t} from './i18n.mjs';

export function validateReceipt(message,expected){
  return !!(message&&expected&&Number.isSafeInteger(message.seq)&&message.seq===expected.seq&&
    Array.isArray(message.inputs)&&message.inputs.length===expected.inputs.length&&
    message.inputs.every((bit,i)=>(bit===0||bit===1)&&bit===expected.inputs[i])&&
    (message.output===0||message.output===1)&&message.output===expected.output);
}

/** Exercises a user-selected port. Every reply must echo both inputs and sequence. */
export async function testSerialCircuit(circuit,{serial=globalThis.navigator?.serial,onProgress=()=>{},timeoutMs=8000}={}){
  if(!serial)throw new Error(t('当前浏览器不支持 Web Serial，请使用 HTTPS 或 localhost 上的桌面 Chrome / Edge。'));
  if(circuit.nIn!==3||circuit.nOut!==1||circuit.nState)throw new Error(t('当前串口协议支持 3 输入、1 输出、无状态网表。'));
  const port=await serial.requestPort();let reader,writer,timer,readTask,finished=false;
  const rows=truthTable(circuit),pending=new Map(),results=[];let complete;
  const done=new Promise(resolve=>complete=resolve);let failure;
  try{
    await port.open({baudRate:115200});writer=port.writable.getWriter();reader=port.readable.getReader();
    const decoder=new TextDecoder();let buffer='';
    readTask=(async()=>{
      try{while(!finished){const {value,done}=await reader.read();if(done){if(pending.size)failure=t('设备断开，未收到全部回执。');complete();break;}
        buffer+=decoder.decode(value,{stream:true});if(buffer.length>65536)throw new Error(t('设备返回数据超过限制。'));
        let cut;while((cut=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,cut);buffer=buffer.slice(cut+1);let message;try{message=JSON.parse(line);}catch{continue;}
          const expected=pending.get(message.seq);if(!expected)continue;
          const pass=validateReceipt(message,expected);results.push({seq:expected.seq,inputs:expected.inputs,expected:expected.output,actual:message.output,returnedInputs:message.inputs,pass});pending.delete(message.seq);
          onProgress({completed:results.length,total:rows.length,passed:results.filter(r=>r.pass).length,pending:pending.size});
          if(!pending.size){complete();break;}
        }
      }}catch(e){failure=e.message;complete();}
    })();
    // Register all requests before writing, so an early reply cannot finish a partial run.
    const start=Math.floor(Math.random()*1000000000);
    rows.forEach((row,i)=>pending.set(start+i,{seq:start+i,inputs:row.inputs.map(Number),output:Number(Array.isArray(row.output)?row.output[0]:row.output)}));
    onProgress({completed:0,total:rows.length,passed:0,pending:pending.size});
    timer=setTimeout(()=>{failure=t('等待设备超时，{count} 组没有回执。',{count:pending.size});complete();},timeoutMs);
    for(const request of pending.values())await writer.write(new TextEncoder().encode(`TC,${request.inputs.join(',')},${request.seq}\n`));
    await done;if(failure)throw new Error(failure);
    return {source:'user-selected-serial-port',circuitHash:await circuitHash(circuit),readAt:new Date().toISOString(),total:rows.length,passed:results.filter(r=>r.pass).length,ok:results.length===rows.length&&results.every(r=>r.pass),records:results};
  }finally{
    finished=true;clearTimeout(timer);try{await reader?.cancel();}catch{}try{await readTask;}catch{}
    try{reader?.releaseLock();}catch{}try{writer?.releaseLock();}catch{}try{await port.close();}catch{}
  }
}
