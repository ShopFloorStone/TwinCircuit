import {icon} from './icons.mjs';
import {seededText,memberDisplayName} from './seed-labels.mjs';
import {techText,techToken,metricValue,statusLed} from './precision.mjs';
import * as engine from './engine.mjs';
import * as chain from './chain.mjs';
import {testSerialCircuit} from './serial.mjs';
import {createFactoryTemplates} from './factory-templates.mjs';
import {createOperationsUI} from './operations-ui.mjs';
import {createIndustrialUI} from './industrial-ui.mjs';
import {t,getLocale,setLanguage,languageSwitcher,errorMessage} from './i18n.mjs';

const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const number=value=>new Intl.NumberFormat(getLocale(),{maximumFractionDigits:2}).format(Number(value)||0);
const money=cents=>number((Number(cents)||0)/100);
const when=value=>value?new Date(value).toLocaleString(getLocale(),{hour12:false}):'—';
const selected=bool=>bool?' selected':'';
const checked=bool=>bool?' checked':'';
const disabled=bool=>bool?' disabled':'';
let session={},data=null,busy=false,dialogReturn=null;
let authTab=null;
const authDrafts=Object.create(null);
const ui={page:location.hash.slice(1)||'capabilities',search:'',supplierMode:'all',orderId:localStorage.getItem('tc.order')||'TC-024',specId:'spec_io_v1',draft:null,inputs:[false,false,false],chainReport:null,publicationReport:null,publishReviewResolve:null,wallet:null,walletChain:null,toolsTab:'overview',sidebar:false,simulationTimer:null,chainBusy:false,localReport:null};
const pages = [
  ['capabilities','能力目录','chipMatrix'],
  ['specifications','规格工坊','blueprint'],
  ['reservations','订单与预约','batchSlots'],
  ['execution','履约监控','scopePulse'],
  ['settlement','验收与结算','verifyGate'],
  ['tools','工具与 API','terminalPins'],
  ['lines','产线接入目录','busTopology'],
  ['devices','设备与实际控制','chip'],
  ['payments','BEM 主网付款','settlementNodes']
];
const stepNames=['发现能力','定义规格','组合预约','执行与切换','验收结算'];
const compactStepNames=['发现服务','确定规格','预订产能','运行工单','验收交付'];
const statusNames={draft:'草稿',confirmed:'预约已确认',reserved:'已预约',running:'执行中',paused:'已暂停',faulted:'故障暂停',completed:'待验收',awaiting_verification:'待独立验收',rejected:'已拒绝',accepted:'已验收',settled:'已完成分账',pending:'待确认',published:'已登记',available:'可用',offline:'离线',cancelled:'已取消'};
const displayText=(record,field)=>seededText(data,record,field);
const supplierById=id=>data?.suppliers.find(s=>s.id===id);
const currentOrder=()=>data?.orders.find(o=>o.id===ui.orderId)||data?.orders[0];
const currentSpec=()=>data?.specs.find(s=>s.id===ui.specId)||data?.specs[0];
const reservations=order=>order?.reservations||[];
const remaining=r=>Math.max(0,r.quantity-r.completedQuantity-r.cancelledQuantity);
const liveReservations=order=>reservations(order).filter(r=>remaining(r)>0);
const allBatches=order=>order?.batches||[];
const canReviewBatch=b=>canVerify()&&b.status==='pending'&&(b.submittedBy!==data.user.id||(data.user.role==='owner'&&b.mode==='virtual'));
const orderEvents=o=>data.events.filter(e=>!(e.orderId||e.details?.orderId)||(e.orderId||e.details?.orderId)===o?.id);
const unassigned=o=>Math.max(0,o.quantity-reservations(o).reduce((n,r)=>n+r.quantity-r.cancelledQuantity,0));
const accepted=order=>Number(order?.acceptedQuantity)||0;
const canWrite=()=>['owner','operator'].includes(data?.user?.role||session?.user?.role)||data?.user?.isDemo;
const canSettle=()=>data?.user?.role==='owner';
const canVerify=()=>['owner','verifier'].includes(data?.user?.role||session?.user?.role)||data?.user?.isDemo;
const ops=createOperationsUI({api,getState:()=>data,getPage:()=>ui.page,setBusiness:state=>{data=state;if(state.csrfToken)session.csrfToken=state.csrfToken;if(state.user)session.user=state.user;},escape:h,modal,closeModal,toast,download,navigate:nav,rerender:render});
const templates=createFactoryTemplates({
  api,command,modal,closeModal,toast,h,icon,when,getLocale,errorMessage,
  state:()=>data,spec:currentSpec,circuit:draftCircuit,draft:()=>ui.draft,
  selectSpec(id){if(currentSpec()?.id!==id)ui.draft=null;ui.specId=id;if(ui.page==='specifications')render();else nav('specifications');},
  clearDraft(){ui.draft=null;render();}
});
const industrial=createIndustrialUI({api,t,h,icon,button,field,formFooter,notice,modal,closeModal,toast,download,when,techToken,getContext:()=>({workspace:data?.workspace,user:data?.user,members:data?.members,suppliers:data?.suppliers,chainReport:ui.chainReport,locale:getLocale()})});

async function api(path,{method='GET',body,signal}={}){
  const headers={};if(body!==undefined)headers['Content-Type']='application/json';
  if(method!=='GET'&&session.csrfToken)headers['x-csrf-token']=session.csrfToken;
  let response;try{response=await fetch(path,{method,headers,body:body===undefined?undefined:JSON.stringify(body),credentials:'same-origin',signal});}catch(error){throw new Error(error.name==='AbortError'?t("请求已取消"):t("无法连接服务器，请检查网络后重试。"));}
  const result=await response.json().catch(()=>({error:t("服务器返回了无法读取的结果。")}));
  if(!response.ok){if(response.status===401){data=null;await loadSession();}const message=typeof result.error==='string'?result.error:result.error?.message||result.message||t("请求失败（{p0}）",{p0:(response.status)});throw Object.assign(new Error(message),{status:response.status,code:result.error?.code||result.code});}
  return result;
}
async function loadSession(){session=await api('/api/session');return session;}
async function refresh(){data=await api('/api/bootstrap');if(data.user)session.user=data.user;if(data.csrfToken)session.csrfToken=data.csrfToken;if(!data.orders.find(o=>o.id===ui.orderId))ui.orderId=data.orders[0]?.id;if(!data.specs.find(s=>s.id===ui.specId))ui.specId=data.specs[0]?.id;return data;}
async function command(type,payload={},requestId=crypto.randomUUID()){
  if(!data)throw new Error(t("请先登录工作区。"));if(busy)throw new Error(t("正在保存上一项操作，请稍候。"));busy=true;setBusy(true);
  try{const next=await api('/api/command',{method:'POST',body:{type,payload,expectedRevision:data.revision,requestId}});data=next.state||next;session.user=data.user;if(data.csrfToken)session.csrfToken=data.csrfToken;render();return data;}
  catch(error){if(error.status===409){await refresh();render();}throw error;}
  finally{busy=false;setBusy(false);}
}
function setBusy(value){document.body.classList.toggle('busy',value);$('#app')?.setAttribute('aria-busy',String(value));}
function toast(message,type='success'){const div=document.createElement('div');div.className=`toast ${type}`;div.setAttribute('role',type==='error'?'alert':'status');div.innerHTML=`${icon(type==='error'?'alert':type==='warning'?'info':'checkcircle')}<span>${escape(message)}</span>`;$('#toasts').append(div);while($('#toasts').children.length>3)$('#toasts').firstElementChild.remove();setTimeout(()=>div.remove(),4500);}
function button(label,action,{style='primary',ico='',attrs='',className='',off=false}={}){return `<button type="button" class="btn-${style}${className?` ${className}`:''}" data-action="${action}" ${attrs}${disabled(off)}>${ico?icon(ico):''}<span>${t(label)}</span></button>`;}
function badge(text,type='muted'){return `<span class="badge badge-${type}">${escape(text)}</span>`;}
function title(text,ico='file',extra=''){return `<div class="panel-title"><h2>${icon(ico)}${text}</h2>${extra}</div>`;}
function notice(text,type='blue'){return `<div class="callout ${type}">${icon(type==='amber'?'alert':'info')}<span>${text}</span></div>`;}
function stat(label, value, unit, ico='file', tone='green') {
  const readout = unit ? metricValue(value, unit) : techToken(value, {chip:true});
  return `<div class="stat-card ${tone}"><span class="stat-icon">${icon(ico)}</span><div class="stat-body"><span class="stat-label">${label}</span><div class="stat-value">${readout}</div></div></div>`;
}
function empty(text,action=''){return `<div class="empty-state">${icon('file')}<p>${text}</p>${action}</div>`;}
function h(text){return escape(text);}
function captureAuthDraft(){const form=$('.auth-form');if(!form||!authTab)return;authDrafts[authTab]=Object.fromEntries($$('input[name],textarea[name],select[name]',form).map(input=>[input.name,input.value]));}
function restoreAuthDraft(){const draft=authDrafts[authTab],form=$('.auth-form');if(!draft||!form)return;for(const input of $$('input[name],textarea[name],select[name]',form))if(Object.hasOwn(draft,input.name))input.value=draft[input.name];}
function clearAuthDrafts(){for(const tab of Object.keys(authDrafts))delete authDrafts[tab];authTab=null;}
function beforeLanguageChange(event){
 if(event.defaultPrevented)return;
 if($('.dialog')){event.preventDefault();toast(t('请先完成或关闭当前对话框，再切换语言。'),'warning');return;}
 if(busy||ui.chainBusy||serialBusy||ops.isBusy?.()){event.preventDefault();toast(t('操作进行中，请等待完成后再切换语言。'),'warning');}
}
function handleLanguageChange(){
 // Preserve unsaved controls without emitting input/change events or business commands.
 const active=document.activeElement;
 const controls=$$('input[name],textarea[name],select[name],input[id],textarea[id],select[id]',$('#app')).map(input=>({name:input.name,id:input.id,value:input.value,checked:input.checked,focus:input===active,start:input.selectionStart,end:input.selectionEnd}));
 captureAuthDraft();
 if(data)render();else renderAuth(authTab||(session.setupRequired?'setup':'login'));
 for(const saved of controls){const input=$$('input,textarea,select',$('#app')).find(node=>saved.id?node.id===saved.id:node.name===saved.name);if(!input)continue;input.value=saved.value;if(typeof saved.checked==='boolean')input.checked=saved.checked;if(saved.focus){input.focus();if(saved.start!==null&&saved.start!==undefined&&typeof input.setSelectionRange==='function'){try{input.setSelectionRange(saved.start,saved.end);}catch{}}}}
}
function nav(page){stopSimulation();ui.page=pages.some(p=>p[0]===page)?page:'capabilities';ui.sidebar=false;location.hash=ui.page;render();window.scrollTo({top:0,behavior:'instant'});}
function stopSimulation(){if(ui.simulationTimer){clearInterval(ui.simulationTimer);ui.simulationTimer=null;}}
function chooseOrder(id){ui.orderId=id;localStorage.setItem('tc.order',id);render();}
function workspaceDisplayName(workspace) {
  if (data.workspace.demo && workspace.id === data.workspace.id && workspace.name === '独立虚拟工厂演示') {
    return t("独立虚拟工厂演示");
  }
  return workspace.name;
}

function renderBreadcrumb(order){
 const contexts={lines:[t("接入模板"),t("产线接入目录")],devices:[t("设备工作台"),t("实际控制与测量")],payments:[t("真实结算"),t("BEM 主网付款")]},context=contexts[ui.page];
 const workspaceName = workspaceDisplayName(data.workspace);
 const orderName = displayText(order) || t("数字 I/O 功能检测");
 const content=context?`<span>${context[0]}</span><span>/</span><span title="${h(workspaceName)}">${h(workspaceName)}</span><span>/</span><span>${techText(context[1])}</span>`:`<button data-action="order-switch">${data.user.isDemo?t("演示流程"):t("工作流程")}</button><span>/</span><button data-action="order-switch">${order?.id ? techToken(order.id,{chip:true}) : h(t("新订单"))}</button><span>/</span><span>${techText(orderName)}</span>`;
 return `<div class="breadcrumb">${icon('home')}${content}<button class="btn-icon refresh-button" data-action="refresh" aria-label="${h(t("刷新"))}">${icon('refresh')}</button></div>`;
}
function modal(heading,content,footer=''){
  dialogReturn=document.activeElement;
  $('#dialog-root').innerHTML=`<div class="dialog-backdrop"><section class="dialog" role="dialog" aria-modal="true" aria-label="${h(heading)}"><div class="dialog-header"><h2>${heading}</h2><button type="button" class="btn-icon" data-action="close-dialog" aria-label="${h(t("关闭"))}">${icon('close')}</button></div><div class="dialog-body">${content}</div>${footer?`<div class="dialog-footer">${footer}</div>`:''}</section></div>`;
  requestAnimationFrame(()=>$('.dialog input:not([type=hidden]),.dialog textarea,.dialog button')?.focus());
}
function closeModal(){const cancel=ui.publishReviewResolve;ui.publishReviewResolve=null;if(cancel)cancel(false);$('#dialog-root').innerHTML='';dialogReturn?.focus();}
function formFooter(label=t("保存"),ico='save'){return `<div class="dialog-footer"><span class="form-error" role="alert"></span><button type="button" class="btn-secondary" data-action="close-dialog">${t("取消")}</button><button class="btn-primary" type="submit">${icon(ico)}${label}</button></div>`;}
function field(label,name,value='',{type='text',required=true,min,max,step,minlength,autocomplete,help='',placeholder='',readonly=false}={}){return `<label class="form-field"><span>${label}</span><input name="${name}" type="${type}" value="${h(value)}"${required?' required':''}${min!==undefined?` min="${min}"`:''}${max!==undefined?` max="${max}"`:''}${step!==undefined?` step="${step}"`:''}${minlength!==undefined?` minlength="${minlength}"`:''}${autocomplete?` autocomplete="${h(autocomplete)}"`:''}${readonly?' readonly':''} placeholder="${h(placeholder)}">${help?`<small class="field-help">${help}</small>`:''}</label>`;}
function download(filename,content,type='application/json'){const blob=new Blob([content],{type}),url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download=filename;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
async function serverDownload(format='json',orderId=''){const res=await fetch(`/api/export?format=${encodeURIComponent(format)}${orderId?'&orderId='+encodeURIComponent(orderId):''}`,{credentials:'same-origin'});if(!res.ok)throw new Error(t("导出失败，请重试。"));const blob=await res.blob();const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=`TwinCircuit-${orderId||'workspace'}-${new Date().toISOString().slice(0,10)}.${format==='report'?'json':format}`;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}

const brandLockup = `<span class="brand-lockup"><img class="brand-symbol" src="/assets/twincircuit-mark.svg" width="369" height="283" alt=""><span class="brand-word">TwinCircuit</span></span>`;

function whitepaperLink(placement = 'login') {
  const english = getLocale() === 'en-US';
  const href = english ? '/whitepaper/en/' : '/whitepaper/';
  if (placement === 'footer') {
    return `<a class="paper-entry" href="${href}">${icon('book')}<span>${t('研究白皮书')}</span></a>`;
  }
  return `<a class="paper-entry paper-document" href="${href}">${icon('book','paper-book')}<span>${t('阅读白皮书')}</span><span class="paper-format" aria-hidden="true">DOC</span>${icon('arrowUpRight','paper-arrow')}</a>`;
}

function userGuideLink(placement) {
  const en = getLocale() === 'en-US';
  const label = en ? 'User Guide' : '使用指南';
  return `<a class="guide-entry guide-entry-${placement}" href="${en ? '/guide/en/' : '/guide/'}">${icon('book')}<span>${label}</span></a>`;
}

function publicDemoLink() {
  const directory = document.querySelector('meta[name="twincircuit-demo-url"]')?.content.trim();
  if (!directory) return '';
  let url;
  try { url = new URL(directory, location.origin); }
  catch { return ''; }
  if (url.origin !== location.origin || !['http:', 'https:'].includes(url.protocol)) return '';
  url.pathname = url.pathname.replace(/\/?$/, '/') + (getLocale() === 'en-US' ? 'en/' : '');
  return `<a class="auth-demo-link" href="${h(url.pathname)}">${t("观看工业演示视频")}</a>`;
}

function positionNumber(index) {
  return String(index + 1).padStart(2, '0');
}

function renderAuthFlow() {
  const labels = ['规格','预约','执行','核销'];
  return `<ol class="auth-mini-flow">${labels.map((label,index) =>
    `<li><span class="auth-stage-no" aria-hidden="true">${positionNumber(index)}</span>
      <span>${t(label)}</span>${index < labels.length - 1 ? icon('connectorArrow','flow-link') : ''}</li>`
  ).join('')}</ol>`;
}

function initialAuthTab() {
 if (session.setupRequired) return 'setup';
 const query = new URLSearchParams(location.search);
 if (query.get('invite')) return 'join';
 return query.get('signup') === '1' ? 'signup' : 'login';
}

function renderAuthForm(tab) {
 const signup = tab === 'signup';
 const setup = tab === 'setup';
 const join = tab === 'join';
 const login = tab === 'login';
 const tabs = [
   ['login', t('登录工作区')],
   session.setupRequired ? ['setup', t('首次部署设置')] : ['signup', t('邮箱注册')],
   ['join', t('受邀加入')]
 ];
 const submitLabel = {login:t('登录'), signup:t('注册并进入工作区'), join:t('加入工作区'), setup:t('创建管理员与工作区')}[tab];
 const passwordHelp = {
   signup: t('建议使用 12 个或更多字符。'),
   join: t('新账号建议使用 12 个或更多字符。已有账号请填写原密码。'),
   setup: t('至少 12 个字符。请使用独立的强密码。')
 }[tab];
 return `<div class="auth-tabs">${tabs.map(([key,label]) =>
   `<button type="button" class="tab ${key===tab?'active':''}" data-action="auth-tab" data-tab="${key}" aria-pressed="${key===tab}">${label}</button>`
 ).join('')}</div>
 <form class="auth-form" data-form="auth-${tab}">
   ${signup?`<p class="auth-signup-help">${t('注册后将进入自己的工作区。')}</p>`:''}
   ${setup?field(t('初始化令牌'),'setupToken','',{type:'password',autocomplete:'off',help:t('令牌来自服务器启动日志或 SETUP_TOKEN 环境变量。')}):''}
   ${join?field(t('邀请令牌'),'token',new URLSearchParams(location.search).get('invite')||'',{autocomplete:'off'}):''}
   ${setup||join?field(t('你的姓名'),'name','',{autocomplete:'name'}):''}
   ${field(t('邮箱'),'email','',{type:'email',autocomplete:'username'})}
   ${field(t('密码'),'password','',{type:'password',minlength:setup?12:undefined,autocomplete:login?'current-password':'new-password',help:passwordHelp})}
   <p class="form-error" role="alert"></p>
   <button class="btn-primary btn-full" type="submit">${icon(setup?'lock':'arrow')}${submitLabel}</button>
 </form>`;
}

function renderAuth(tab='login'){
 captureAuthDraft();authTab=tab;
 $('#app').innerHTML=`<main class="auth-layout"><section class="auth-card"><div class="auth-language-row">${whitepaperLink()}${languageSwitcher()}</div><div class="auth-brand"><a class="brand" href="/" aria-label="TwinCircuit · ${h(t("首页"))}">${brandLockup}</a><span>${t("工业能力协议与工具链")}</span></div><h1>${t("让工业能力，")}<br>${t("成为可调用的服务")}</h1><p class="muted">${t("从可执行规格到跨供应商履约，每一步都有可复查的依据。")}</p>${userGuideLink('home')}${renderAuthForm(tab)}<div class="auth-divider"><span>${t("或先了解完整流程")}</span></div>${button(t("进入独立演示工作区"),'enter-demo',{style:'secondary',ico:'play',className:'btn-full'})}<p class="auth-note">${t("演示数据按会话隔离并自动过期。虚拟订单和内部账本不转移真实资金。")}</p>${publicDemoLink()}<a class="auth-standard-link" href="${getLocale()==='en-US'?'/standard/en/':'/standard/'}" target="_blank" rel="noopener">${t("公开工业标准 TC-IC/0.1")}</a><p class="version-note">${techText(t("TwinCircuit 1.4 · 自托管版"))}</p></section><section class="auth-preview" aria-label="${h(t("产品预览"))}"><div class="auth-spec-strip">${t("可执行规格 · 能力预约 · 履约验收").split(" · ").map(label=>`<span>${h(label)}</span>`).join("")}</div><div class="auth-factory-visual"></div><div class="auth-preview-caption"><h2>${t("同一标准，连接不同供应商。")}</h2><p>${t("设计、测试与交付记录在同一个工作区协作。")}</p>${renderAuthFlow()}</div></section></main>`;
 restoreAuthDraft();
}
function renderSidebarNav() {
  return pages.map(([key,label,ico]) => {
    const active = key === ui.page;
    const name = t(label);
    return `<button class="nav-item${active ? ' active' : ''}" data-action="nav" data-page="${key}"
      aria-label="${h(name)}" title="${h(name)}"${active ? ' aria-current="page"' : ''}>
      <span class="nav-icon">${icon(ico)}</span><span class="nav-label">${techText(name)}</span>
      ${icon('chevron','nav-direction micro')}</button>`;
  }).join('');
}

function renderWorkflowSteps(current, order) {
  if (current >= stepNames.length) return '';
  const snapshot = order?.specSnapshot;
  const finished = [
    Boolean(snapshot && data.suppliers.some(s => s.capabilities.includes(snapshot.profile))),
    Boolean(snapshot?.vectors?.length),
    Boolean(order && order.status !== 'draft' && reservations(order).length > 0 && unassigned(order) === 0),
    Boolean(order && order.quantity > 0 && order.completedQuantity >= order.quantity),
    order?.status === 'settled'
  ];
  return `<div class="stepper" role="group" aria-label="${h(t("业务流程"))}">${stepNames.map((label,index) => {
    const active = index === current;
    const complete = !active && finished[index];
    return `<button class="step${active ? ' active' : complete ? ' complete' : ''}" data-action="nav"
      data-page="${pages[index][0]}" title="${h(t(label))}" aria-label="${h(t(label))}${complete ? ' · '+h(t("已完成")) : ''}"${active ? ' aria-current="step"' : ''}>
      <span class="step-number" aria-hidden="true">${complete ? icon('check','micro') : positionNumber(index)}</span><span class="step-label"><span class="step-full">${t(label)}</span><span class="step-compact">${t(compactStepNames[index])}</span></span></button>
      ${index < stepNames.length - 1 ? `<span aria-hidden="true" class="step-line${complete ? ' complete' : ''}"></span>` : ''}`;
  }).join('')}</div>`;
}

function render(){
 if(!data){renderAuth(authTab||(session.setupRequired?'setup':'login'));return;}
 const o=currentOrder(),step=Math.max(0,pages.findIndex(p=>p[0]===ui.page));
 const workspaceName = workspaceDisplayName(data.workspace);
 const hasExternal=o?.reservations?.some(r=>supplierById(r.supplierId)?.mode==='external');
 const environment=ui.page==='payments'?t("X Layer 主网 · BEM 实际资金"):ui.page==='devices'?t("真实设备 · 网关控制队列"):ui.page==='lines'?t("产线模板 · 按心跳显示连接"):hasExternal?t("外部设备 · 实际证据工作流"):t("虚拟设备 · 示例金额");
 $('#app').innerHTML=`<header class="app-header">
   <button class="mobile-nav-toggle btn-icon" data-action="toggle-nav" aria-controls="workspace-sidebar"
     aria-expanded="${ui.sidebar}" aria-label="${h(t("主导航"))}">${icon('menu','nav-open-glyph')}${icon('foldRail','nav-close-glyph')}</button>
   <a class="brand" href="#capabilities" aria-label="TwinCircuit · ${h(t("能力目录"))}">${brandLockup}<span class="brand-subtitle">${t("工业能力协议与工具链")}</span></a>
   <span class="environment-badge">${statusLed()}<span class="env-terms">${((data.user.isDemo?t("独立演示 · "):'')+environment).split(' · ').map((part,index,all)=>`<span class="env-term">${techText(part)}${index < all.length-1 ? '<span class="env-separator" aria-hidden="true"> · </span>' : ''}</span>`).join(' ')}</span></span>
   <div class="header-actions">${languageSwitcher()}${userGuideLink('header')}
     <button class="btn-ghost" data-action="nav" data-page="tools" data-tab="api" aria-label="${h(t("开发者 SDK"))}" title="${h(t("开发者 SDK"))}">${icon('sdk')}<span>${techText(t("开发者 SDK"))}</span></button>
     <button class="btn-ghost integration-status" data-action="chain-dialog" aria-label="X Layer / TapeOut" title="X Layer / TapeOut">${icon('layers')}${techToken("X Layer / TapeOut")}</button>
     <button class="account-button btn-icon" data-action="account-dialog" aria-label="${h(t("账号与工作区"))}">${icon('user')}</button>
   </div></header>
   <div class="app-layout ${ui.sidebar?'sidebar-open':''}">
     <aside class="sidebar" id="workspace-sidebar"><nav aria-label="${h(t("主导航"))}">${renderSidebarNav()}</nav>
       <div class="sidebar-meta">${userGuideLink('sidebar')}<button class="workspace-switch" data-action="workspace-dialog" title="${h(workspaceName)}" aria-label="${h(workspaceName)}">
         ${icon('layers','workspace-symbol')}<span class="workspace-name">${h(workspaceName)}</span>${icon('chevron','micro')}</button>
         <span class="workspace-profile">${techText(t("Profile 0.1 · 社区草案"))}</span>
         <small>${techText(t("服务端保存 · 修订 {p0}",{p0:data.revision}))}</small></div>
     </aside>
     <main class="main-area" data-page="${ui.page}">${renderBreadcrumb(o)}${renderWorkflowSteps(step,o)}
       <div id="page-content">${renderPage()}</div></main>
   </div>${renderFooter()}`;
 requestAnimationFrame(()=>updateSpecLive(false));
}
function renderFooter() {
  const idx=pages.findIndex(p=>p[0]===ui.page);
  const entries=[
    ['开放规范','统一的能力与数据模型','protocolCard'],
    ['编译与验证','将规则编译为可执行流程','logicGate'],
    ['设备适配','适配不同厂商的测试设备','fixturePlug'],
    ['订单 SDK','提供 API 与调用示例','sdk']
  ];
  const indicator=idx<5?`${positionNumber(idx)} / 05`:ui.page==='tools'?'SDK':'LIVE';
  return `<footer class="app-footer"><div class="footer-lead">${icon('busTopology')}<div>
    <strong>${idx===4?t("下一步：进入新的能力循环"):t("让其他应用也能接入")}</strong>
    <small>${t("统一能力描述与接口，支持更多工具接入")}</small>${whitepaperLink('footer')}</div></div>
    ${entries.map(([label,description,symbol]) => `<button class="footer-item" data-action="nav" data-page="tools">
      ${icon(symbol)}<span><strong>${techText(t(label))}</strong><small>${techText(t(description))}</small></span></button>`).join('')}
    <span class="footer-page">${techToken(indicator)} · ${techText(t(pages[idx]?.[1]||''))}</span></footer>`;
}
function pageTitle(main, sub, extra='') {
  // Let each short Chinese clause move as a whole beside an order selector.
  const heading = main.split(/(?<=，)/u).map(part =>
    `<span class="title-phrase">${techText(part)}</span>`
  ).join('');
  return `<div class="page-title"><div><h1>${heading}</h1><p class="page-subtitle">${techText(sub)}</p></div>${extra}</div>`;
}
function renderPage(){return ({capabilities:renderCapabilities,specifications:renderSpecifications,reservations:renderReservations,execution:renderExecution,settlement:renderSettlement,tools:renderTools,lines:ops.renderLines,devices:ops.renderDevices,payments:ops.renderPayments}[ui.page]||renderCapabilities)();}
function supplierVisual(s,extra=''){return `<div class="factory-visual factory-${s.code==='B'?'b':'a'} ${extra}" role="img" aria-label="${h(t("{p0}的虚拟检测工作站插画",{p0:displayText(s)}))}">${s.mode==='external'?`<span class="visual-mode">${t("外部设备 · 插画示意")}</span>`:''}</div>`;}
function catalogSupplierCard(supplier) {
  const virtual = supplier.mode === 'virtual';
  const supplierBadge = virtual
    ? `<span class="badge badge-green">${statusLed()}${t("虚拟供应商")}</span>`
    : badge(t("外部供应商"),'muted');
  const profile = supplier.capabilities[0];
  const fixture = virtual ? t("通用 I/O 测试夹具") : t("外部提交");
  return `<article class="supplier-card">
    <div class="supplier-header"><h2>${icon('factory')}${h(displayText(supplier))}</h2>${supplierBadge}</div>
    ${supplierVisual(supplier)}
    <div class="supplier-capability">${icon('chip')}<div>
      <strong>${techText(t("数字 I/O 功能检测"))}</strong>
      <small>${techText(displayText(supplier,'description') || t("GPIO / 输入输出功能 · 规则与结果核对"))}</small>
    </div></div>
    <div class="supplier-fields">
      <div class="supplier-field">${icon('capacityGauge','micro')}<div><small>${t("可用额度")}</small>${metricValue(number(supplier.availableCapacity ?? supplier.available), t("次"))}</div></div>
      <div class="supplier-field">${icon('protocolCard','micro')}<div><small>${t("兼容规格")}</small>${profile ? techToken(profile,{chip:true}) : h(t("未登记"))}</div></div>
      <div class="supplier-field">${icon('fixturePlug','micro')}<div><small>${virtual ? t("虚拟适配器") : t("证据来源")}</small><strong class="fixture-name" title="${h(fixture)}">${techText(fixture)}</strong></div></div>
    </div>
    <div class="supplier-actions">${button(t("查看能力"),'supplier-detail',{style:'secondary',ico:'inspectReticle',attrs:`data-id="${h(supplier.id)}"`})}</div>
  </article>`;
}

function catalogPanelText(text) {
  // Keep the ending together even when the inspector is only one short line wide.
  const ending = text.match(/(?:[\p{Script=Han}]{2,4}[。！？]?|\S+\s+\S+)$/u);
  if (!ending) return h(text);
  return h(text.slice(0, ending.index)) + `<span class="panel-ending">${h(ending[0])}</span>`;
}

function renderCapabilities() {
  const order = currentOrder(), q = ui.search.trim().toLowerCase();
  const suppliers = data.suppliers.filter(s => (ui.supplierMode === 'all' || s.mode === ui.supplierMode) &&
    (!q || `${s.name} ${s.description} ${displayText(s)} ${displayText(s,'description')} ${s.capabilities.join(' ')}`.toLowerCase().includes(q)));
  const features = [
    [t("输入输出定义"),t("引脚、时序、电气范围等结构化接口定义"),'ioPorts'],
    [t("可执行参考逻辑"),t("同一规格可编译、可复算，在不同目标中运行"),'logicGate'],
    [t("验收测试向量"),t("明确测试输入和判定规则，让结果可复现"),'vectorCheck'],
    [t("预约与核销规则"),t("支持按次预约、执行与核销，保留取消与替换记录"),'batchRedeem']
  ];
  const [tapeoutHeading, tapeoutDescription] = t("<strong>TapeOut：提供可复算的数字规则</strong><br>把可执行逻辑与测试证据连接到交付流程。").split('<br>');
  return `<div class="page-layout catalog-layout"><section class="main-column">
    ${pageTitle(t("让工业能力，成为可调用的服务"),t("用统一规格发现、比较和组合不同供应商"),templates.libraryButton())}
    <form class="search-bar" data-form="search"><label class="search-input">${icon('search')}<input name="query" value="${h(ui.search)}" aria-label="${h(t("搜索能力或供应商"))}" placeholder="${h(t("寻找可执行 TC-IO/0.1 的数字 I/O 功能检测服务"))}"></label><button type="submit" class="search-button">${t("搜索")}</button></form>
    <div class="stats-grid three">${stat(t("需求数量"),number(order?.quantity),t("次"),'batchCounter')}${stat(t("匹配供应商"),suppliers.length,t("家"),'busTopology','blue')}${stat(t("参考规格"),order?.specSnapshot?.profile || 'TC-IO/0.1','','specStack','blue')}</div>
    <div class="toolbar compact"><div class="tabs"><button class="tab ${ui.supplierMode==='all'?'active':''}" data-action="supplier-filter" data-mode="all">${t("全部能力")}</button><button class="tab ${ui.supplierMode==='virtual'?'active':''}" data-action="supplier-filter" data-mode="virtual">${t("虚拟设备")}</button><button class="tab ${ui.supplierMode==='external'?'active':''}" data-action="supplier-filter" data-mode="external">${t("外部设备")}</button></div>${button(t("登记供应商"),'supplier-new',{style:'ghost',ico:'plus',off:!canWrite()})}</div>
    <div class="supplier-grid">${suppliers.length ? suppliers.map(catalogSupplierCard).join('') : empty(t("没有匹配的供应商。请调整搜索或登记新的能力。"))}</div></section>
    <aside class="inspector"><section class="panel">${title(t("能力不是一张图片"),'protocolCard')}
      <p class="panel-intro">${catalogPanelText(t("每项能力都包含可执行的规格、测试与履约规则。"))}</p>
      <div class="feature-list">${features.map(([name,description,key])=>`<div class="feature-row"><span class="feature-icon">${icon(key)}</span><div><strong>${name}</strong><p>${catalogPanelText(description)}</p></div></div>`).join('')}</div>
      <div class="callout green tapeout-note">${icon('tapeoutAnchor')}<span>${tapeoutHeading.replace('TapeOut',techToken('TapeOut'))}<br>${catalogPanelText(tapeoutDescription)}</span></div>
      ${button(t("下一步：定义验收规格"),'nav',{ico:'arrow',attrs:'data-page="specifications"'})}
    </section></aside></div>`;
}

function draftCircuit(){const spec=currentSpec();return engine.compileExpression(ui.draft?.expression??spec?.expression??'E && (C || M)',{variables:['C','M','E'],title:spec?.name,id:spec?.id});}
function specificationCheck(id, symbol, label, description, state, pending = false) {
  return `<div class="check-row">
    <div class="check-heading"><strong>${icon(symbol)}${h(label)}</strong>
      <b class="check-result${pending ? ' pending' : ''}" id="${id}">${h(state)}</b></div>
    <small>${h(description)}</small>
  </div>`;
}
function renderSpecifications(){const spec=currentSpec();let circuit,report,error;try{circuit=draftCircuit();report=engine.verify(circuit);}catch(e){error=errorMessage(e);}ui.localReport=report;
 const rowData=report?.rows||[];
 const localState = report?.equivalent === true ? t("8 / 8 一致") : t("待检查");
 const chainMatch = chainReportForSpec(circuit);
 const checks = [
   specificationCheck('ast-result', 'file', t("参考规则"), t("独立解析并计算预期输出"), localState),
   specificationCheck('nand-result', 'code', t("本地求值"), t("直接执行导出的网表字节"), localState),
   specificationCheck('current-chain-result', 'layers', t("X Layer 复算"), t("读取真实目标电路后独立核对"),
     chainMatch ? t("当前网表已核对") : t("当前版本未核对"), !chainMatch)
 ].join('');
 return `${pageTitle(t("把工业规则，变成共同的执行依据"),t("同一规格，独立实现，结果可复算"),`<select class="spec-selector" aria-label="${h(t("选择规格"))}" id="spec-selector">${data.specs.map(s=>`<option value="${h(s.id)}"${selected(s.id===spec.id)}>${h(displayText(s))} · v${s.version}</option>`).join('')}</select>`)}${templates.entry()}<div class="spec-grid"><section class="panel spec-column">${title(t("输入与验收约定"),'file')}<div class="rule-card"><small>${t("功能规则")}</small><p>${h(displayText(spec,'description')||t("许可开启，并且条件或手动成立时，输出为 1；许可关闭时，输出为 0。"))}</p></div><h3>${t("输入输出接口")}</h3><div class="port-list">${[['C',t("条件 C"),t("外部条件输入（高电平为 1）")],['M',t("手动 M"),t("手动控制输入（高电平为 1）")],['E',t("许可 E"),t("使能 / 许可输入（高电平为 1）")],['Y',t("输出 Y"),t("数字输出（高电平为 1）")]].map(([p,t,d])=>`<div class="port-row"><b class="port-tag ${p==='Y'?'blue':''}">${p}</b><strong>${t}</strong><small>${d}</small></div>`).join('')}</div><label class="form-field expression-field"><span>${t("逻辑表达式 ")}<small>${t("!、&&、||、^、括号")}</small></span><textarea id="expression-input" rows="2" spellcheck="false">${h(ui.draft?.expression??spec.expression??'E && (C || M)')}</textarea></label><div class="formula" id="formula-live">${h(circuit?.expression||t("表达式待修正"))}</div><div class="inline-error" id="compile-error" role="alert">${h(error||'')}</div><div class="micro-stats"><div><b>3</b>${t(" 输入")}</div><div><b>1</b>${t(" 输出")}</div><div><b id="gate-count">${circuit?.gates.length||'—'}</b> NAND</div><div><b>8</b>${t(" 组测试")}</div></div><div class="toolbar wrap">${button(t("保存新版本"),'spec-save',{style:'primary',ico:'save',off:!canWrite()})}${button(t("另存新规格"),'spec-new',{style:'secondary',ico:'plus',off:!canWrite()})}</div><details class="assist-details"><summary>${t("{p0}用文字生成规则",{p0:(icon('sparkles'))})}</summary><form data-form="assist" class="assist-form"><textarea name="prompt" rows="3" required placeholder="${h(t("许可开启，且条件或手动成立时输出为 1。"))}"></textarea><button class="btn-secondary" type="submit">${t("解析为表达式")}</button><small id="assist-mode">${t("配置模型后使用 AI；未配置时仅匹配明确支持的规则。")}</small></form></details></section><section class="panel spec-column">${title(t("TapeOut 映射"),'layers')}<div class="logic-graph"><div class="logic-inputs"><span>C</span><span>M</span><span>E</span></div><svg viewBox="0 0 95 100" aria-hidden="true"><path d="M0 16h40v34h55M0 50h95M0 84h40V50" fill="none" stroke="#27332b" stroke-width="1.6"/></svg><div class="logic-block">${t("NAND 网表{p0}",{p0:(icon('network'))})}</div><span class="logic-output">Y</span></div><div class="code-toolbar"><strong>${t("网表（可导出）")}</strong><small>${t("TAP-02 · NAND 子集")}</small></div><pre class="netlist" id="netlist-live">${h(circuit?netlistText(circuit):t("等待有效表达式"))}</pre><div class="code-toolbar"><strong>${t("真值表（8 组组合）")}</strong><button class="btn-ghost btn-small" data-action="export-truth">${icon('download')}CSV</button></div><div class="table-wrap"><table class="truth-table"><thead><tr><th>#</th><th>C</th><th>M</th><th>E</th><th>Y</th><th>${t("核对")}</th></tr></thead><tbody id="truth-body">${renderTruthRows(rowData)}</tbody></table></div><div class="toolbar wrap">${button(t("导出网表"),'export-netlist',{style:'secondary',ico:'download'})}${button(t("导入表达式包"),'import-spec',{style:'ghost',ico:'upload'})}</div></section><section class="panel spec-column">${title(t("一致性验证"),'checkfile')}${checks}<div class="verification-result ${report?.equivalent===true?'pass':'fail'}" id="verify-result">${icon(report?.equivalent===true?'checkcircle':'alert')}<div><strong>${report?.equivalent===true?t("8 / 8 一致"):t("验证未通过")}</strong><small>${t("本地结果 · 与链上验证分别记录")}</small></div></div>${notice(t("网表、输入与目标版本共同记录。<br>本地通过不代表链上已部署。"))}<div class="metadata-list"><strong>${t("规格信息")}</strong><dl><dt>${t("规格")}</dt><dd>${h(spec.profile)}</dd><dt>${t("电路版本")}</dt><dd>v${spec.version}</dd><dt>${t("登记状态")}</dt><dd>${spec.status==='published'?t("本地已登记"):t("草稿")}</dd><dt>${t("链上状态")}</dt><dd>${chainReportForSpec(circuit)?t("当前网表已复算（本会话）"):t("当前版本未核对 / 未声明部署")}</dd></dl></div><div class="toolbar wrap">${button(t("X Layer 读取与复算"),'chain-dialog',{style:'secondary',ico:'layers'})}${button(t("登记当前版本"),'spec-publish',{style:'ghost',ico:'checkfile',off:!canWrite()||spec.status==='published'})}</div>${button(t("下一步：创建需求订单"),'nav',{ico:'arrow',attrs:'data-page="reservations"'})}</section></div><div class="evidence-strip"><strong>${t("从规格到验证的证据链")}</strong>${[t("规格版本"),t("可执行网表"),t("测试向量"),t("验证报告")].map(t=>`<span>${icon('file')}${t}</span>`).join('')}<small>${t("此页验证数字逻辑；实体质量需外部测试。")}</small></div>`;
}
function netlistText(c){return c.gates.map((g,i)=>`n${i+1} = NAND(${signalName(g.a,c)}, ${signalName(g.b,c)})`).join('\n')+`\nY = n${c.gates.length}`;}
function signalName(n,c){return n<2?String(n):n<2+c.nIn?(c.variables||['C','M','E'])[n-2]:`n${n-(1+c.nIn)}`;}
function renderTruthRows(rows){return rows.map((r,i)=>{const bits=Array.isArray(r.inputs)?r.inputs:['C','M','E'].map(k=>r.inputs[k]);const out=Array.isArray(r.output)?r.output[0]:r.output;return `<tr><td>${i+1}</td>${bits.map(x=>`<td>${Number(x)}</td>`).join('')}<td><strong>${Number(out)}</strong></td><td class="${r.pass===false?'text-danger':r.pass===true?'text-green':''}">${r.pass===false?t("不一致"):r.pass===true?t("一致"):t("未附独立规则")}</td></tr>`;}).join('');}
function updateSpecLive(recompile=true){if(ui.page!=='specifications'||!$('#expression-input'))return;const value=$('#expression-input').value;if(recompile)ui.draft={expression:value};let c,r,error;try{c=draftCircuit();r=engine.verify(c);if(r.equivalent!==true)throw new Error(t(r.message));}catch(e){error=errorMessage(e);}ui.localReport=r??null;$('#compile-error').textContent=error||'';$('#formula-live').textContent=c?.expression||t("表达式待修正");$('#gate-count').textContent=c?.gates.length??'—';$('#netlist-live').textContent=c?netlistText(c):t("等待有效表达式");$('#truth-body').innerHTML=renderTruthRows(r?.rows||[]);const summary=!error&&r?.equivalent===true?t("{p0} / {p1} 一致",{p0:(r.passed),p1:(r.total)}):t("待修正");$('#ast-result').textContent=summary;$('#nand-result').textContent=summary;const box=$('#verify-result');if(box){box.className=`verification-result ${!error&&r?.equivalent===true?'pass':'fail'}`;box.innerHTML=`${icon(!error&&r?.equivalent===true?'checkcircle':'alert')}<div><strong>${h(summary)}</strong><small>${t("本地穷举；与链上验证分别记录")}</small></div>`;}const status=$('#current-chain-result');if(status){const match=c?chainReportForSpec(c):null;status.textContent=match?t("{p0} / {p1} 当前网表一致",{p0:(match.passed),p1:(match.total)}):t("当前版本未核对");status.classList.toggle('pending',!match);}}


function budgetBar(order) {
  const roles = [
    ['fulfillment', t("履约执行")],
    ['verification', t("独立验证")],
    ['design', t("设计与维护")],
    ['platform', t("平台")]
  ];
  const segments = roles.map(([key,label]) => {
    const cents = order.fees[key], tooltip = label + ' · ' + money(cents) + ' USDT';
    return `<span class="budget-${key}" style="flex-grow:${Number(cents)}" title="${h(tooltip)}"></span>`;
  });
  const legend = roles.map(([key,label]) => `<div class="budget-entry">
    <dt><i class="budget-key budget-${key}" aria-hidden="true"></i>${h(label)}</dt>
    <dd>${metricValue(money(order.fees[key]),'USDT')}</dd>
  </div>`);
  return `<section class="budget-bar">
    <div class="code-toolbar"><strong>${t("示例分账 · 非利润")}</strong><small>${t("未执行不收费，默认转单不加价")}</small></div>
    <div class="budget-row"><div class="budget-detail">
      <div class="budget-segments" aria-hidden="true">${segments.join('')}</div>
      <dl class="budget-legend">${legend.join('')}</dl>
    </div><div class="budget-total"><small>${t("总计")}</small>${metricValue(money(order.budgetCents),'USDT')}</div></div>
  </section>`;
}
function orderSelector(){return `<select id="order-selector" aria-label="${h(t("选择订单"))}">${data.orders.map(o=>`<option value="${h(o.id)}"${selected(o.id===currentOrder()?.id)}>${h(o.id)} · ${h(t(statusNames[o.status]||o.status))}</option>`).join('')}</select>`;}
function renderReservations(){const o=currentOrder();if(!o)return empty(t("先创建一个需求订单。"),button(t("创建订单"),'order-new',{ico:'plus'}));const rs=reservations(o),reserved=rs.reduce((sum,r)=>sum+r.quantity-r.cancelledQuantity,0);
 return `<div class="page-layout reservation-layout"><section class="main-column">${pageTitle(t("一个需求，组合多家供应商"),t("需求规格保持一致，预约由供应商确认"),orderSelector())}<section class="order-summary panel"><strong>${t("{p0}需求订单 {p1}",{p0:(icon('file')),p1:techToken(o.id)})}<small>${h(displayText(o))}</small></strong><div><small>${t("目标")}</small><b>${metricValue(number(o.quantity),t("次"))}</b></div><div><small>${t("验收规格")}</small><b>${techToken(o.specSnapshot.profile,{chip:true})}</b></div><div><small>${t("示例总预算")}</small><b>${metricValue(money(o.budgetCents),"USDT")}</b></div></section><div class="allocation-tree"><div class="allocation-root">${t("{p0}{p1} · {p2} 次",{p0:(icon('file')),p1:techToken(o.id),p2:techToken(number(o.quantity))})}</div><div class="allocation-branches"><i></i><i></i></div></div><div class="supplier-grid reservation-suppliers">${data.suppliers.map(s=>{const own=rs.filter(r=>r.supplierId===s.id),qty=own.reduce((a,r)=>a+r.quantity-r.cancelledQuantity,0),allConfirmed=own.length&&own.every(r=>r.providerConfirmed||r.cancelledQuantity===r.quantity);return `<article class="supplier-card"><div class="supplier-header"><h2>${icon('factory')}${h(displayText(s))}</h2>${badge(qty?allConfirmed?t("已确认")+(s.mode==='virtual'?t("（模拟）"):''):t("待供应商确认"):s.mode==='virtual'?t("虚拟供应商"):t("外部供应商"),allConfirmed?'green':'muted')}</div>${supplierVisual(s)}<div class="supplier-fields"><div class="supplier-field">${icon('capacityGauge','micro')}<div><small>${t("剩余可用")}</small>${metricValue(number(s.availableCapacity??s.available),t("次"))}</div></div><div class="supplier-field">${icon('batchRedeem','micro')}<div><small>${t("本次预约")}</small>${metricValue(number(qty),t("次"))}</div></div><div class="supplier-field">${icon('vectorCheck','micro')}<div><small>${t("已完成")}</small>${metricValue(number(own.reduce((a,r)=>a+r.completedQuantity,0)),t("次"))}</div></div></div><div class="reservation-budget"><small>${t("履约预算（随实际数量分配）")}</small>${metricValue(money(Math.floor(o.fees.fulfillment*qty/o.quantity)),"USDT")}</div><div class="supplier-actions">${button(t("预约能力"),'reserve',{style:'secondary',ico:'calendar',attrs:`data-id="${h(s.id)}"`,off:!canWrite()||!['draft'].includes(o.status)})}${own.filter(r=>!r.providerConfirmed&&remaining(r)>0).map(r=>button(t("确认预约"),'confirm-reservation',{style:'ghost',ico:'check',attrs:`data-id="${h(r.id)}"`,off:!canWrite()})).join('')}</div></article>`;}).join('')}</div>${budgetBar(o)}<div class="toolbar wrap">${button(t("创建新订单"),'order-new',{style:'secondary',ico:'plus',off:!canWrite()})}${button(t("查看全部预约"),'reservation-list',{style:'ghost',ico:'calendar'})}${button(t("导出订单"),'export-order',{style:'ghost',ico:'download'})}</div></section><aside class="inspector"><section class="panel">${title(t("需求与预约分别记录"),'file')}<p class="panel-intro">${t("需求定义要什么；预约记录谁承接、时段与额度。")}</p><div class="feature-row">${icon('file','feature-icon')}<div><strong>${t("需求订单")}</strong><p>${t("要什么、多少、怎样验收。规格在创建订单时固定快照。")}</p></div></div><div class="feature-row">${icon('calendar','feature-icon')}<div><strong>${t("预约凭证")}</strong><p>${t("谁承接、额度、取消与替换规则；每条预约单独确认。")}</p></div></div><h3>${t("本次预约（供应商确认）")}</h3><div class="reservation-list">${rs.length?rs.map(r=>`<div class="reservation-item"><strong>${t("{p0}{p1} · {p2} 次",{p0:(icon('factory')),p1:(h(supplierById(r.supplierId)?.code)),p2:techToken(number(r.quantity-r.cancelledQuantity))})}</strong>${badge(r.providerConfirmed?t("已确认")+(supplierById(r.supplierId)?.mode==='virtual'?t("（模拟）"):''):t("待确认"),r.providerConfirmed?'green':'amber')}</div>`).join(''):empty(t("尚未分配。可先使用示例预约。"))}</div><div class="allocation-progress"><strong>${t("已预约 {p0} / {p1} 次",{p0:techToken(number(reserved)),p1:techToken(number(o.quantity))})}</strong><progress value="${reserved}" max="${o.quantity}"></progress></div><p class="field-help">${t("凭证记录已确认的服务权，不代表设备所有权。")}</p>${!rs.length?button(techText(t("一键填写 A60 / B40 示例")),'seed-reservations',{style:'secondary',ico:'sparkles',off:o.quantity!==100||!canWrite()}):''}${button(['running','completed','awaiting_verification','accepted','settled'].includes(o.status)?t("查看履约执行"):t("确认预约并开始虚拟执行"),'start-order',{ico:'arrow',off:!canWrite()&&o.status==='draft'})}</section></aside></div>`;
}

function renderExecution(){const o=currentOrder();if(!o)return empty(t("尚无订单。"));const done=o.completedQuantity||0,rs=reservations(o),fault=rs.find(r=>r.status==='faulted'),supTotals=data.suppliers.map(s=>({supplier:s,rows:rs.filter(r=>r.supplierId===s.id),completed:rs.filter(r=>r.supplierId===s.id).reduce((a,r)=>a+r.completedQuantity,0)}));const extra=rs.find(r=>r.reassignedFrom||r.replacesReservationId)||rs[2];const events=orderEvents(o).slice(-5);
 return `<div class="page-layout"><section class="main-column">${pageTitle(fault?t("供应商切换，验收规格保持不变"):t("让每一步履约，都有可复查的依据"),t("实时记录执行批次、故障与重新预约。虚拟和外部证据分别处理。"),orderSelector())}<div class="stats-grid four">${stat(t("目标"),o.quantity,t("次"),'file')}${stat(t("已完成"),done,t("次"),'checkcircle')}${stat(t("待完成"),o.quantity-done,t("次"),'clock','amber')}${stat(t("订单预算"),money(o.budgetCents),'USDT','wallet','blue')}</div><section class="execution-canvas"><div class="plant-scene ${fault?'has-fault':''}" role="img" aria-label="${h(t("虚拟工厂 A 与 B 的检测工作站"))}" data-caption="${h(fault || done || o.status === 'running' ? t("检测工作站插画 · 运行数据以上方状态为准") : t("检测工作站示意 · 等待虚拟批次执行"))}"><div class="plant-labels">${supTotals.slice(0,2).map(({supplier:s,rows,completed})=>`<div class="factory-overlay ${rows.some(r=>r.status==='faulted')?'fault-overlay':''}">${icon(rows.some(r=>r.status==='faulted')?'alert':'factory')}<strong>${t("{p0} · {p1} 次已完成",{p0:(h(displayText(s))),p1:(completed)})}</strong>${badge(rows.some(r=>r.status==='faulted')?t("故障暂停"):o.status==='running'?t("正常运行"):t("待执行"),rows.some(r=>r.status==='faulted')?'amber':'green')}</div>`).join('')}</div>${extra?`<div class="reroute">${t("{p0}重新预约 {p1} 次 {p2}",{p0:(icon('refresh')),p1:(extra.quantity),p2:(icon('arrow'))})}</div>`:''}<div class="plant-progress">${t("{p0}{p1} · 轨迹来源：{p2}",{p0:(o.status==='running'?'<span class="status-dot pulse"></span>':''),p1:(h(t(statusNames[o.status]||o.status))),p2:(o.specSnapshot.profile)})}</div></div><div class="timeline">${events.length?events.map((e,i)=>`<div class="timeline-item">${icon(e.type?.includes('fault')?'alert':e.type?.includes('reassign')?'refresh':'checkcircle')}<div><strong>${h(eventTitle(e))}</strong><small><time>${when(e.at||e.createdAt||e.timestamp)}</time></small></div>${i<events.length-1?icon('arrow'):''}</div>`).join(''):`<div class="timeline-item">${t("{p0}确认预约后，开始执行检测批次。",{p0:(icon('info'))})}</div>`}</div></section><section class="panel fault-evidence">${title(t("可复查的执行记录"),'file',button(t("查看完整审计"),'audit-dialog',{style:'ghost',ico:'eye'}))}${allBatches(o).length?renderBatchTable(o):empty(t("没有执行记录。右侧可运行虚拟批次，或提交外部设备证据。"))}</section></section><aside class="inspector"><section class="panel">${title(fault?t("重新分配剩余任务"):t("执行控制"),'chart')}<div class="metadata-list"><dl><dt>${t("订单状态")}</dt><dd>${badge(t(statusNames[o.status]||o.status),o.status==='paused'?'amber':'green')}</dd><dt>${t("验收规格")}</dt><dd>${techToken(o.specSnapshot.profile)} · ${techToken("v"+o.specVersion)}</dd><dt>${t("执行方式")}</dt><dd>${data.workspace.mode==='simulation'?t("虚拟设备"):t("外部证据")}</dd></dl></div><div class="execution-reservations">${rs.map(r=>{const s=supplierById(r.supplierId);return `<div class="execution-reservation ${r.status==='faulted'?'is-faulted':''}"><strong>${icon('factory')}${h(displayText(s))}</strong><dl><dt>${t("原预约")}</dt><dd>${t("{p0} 次",{p0:(r.quantity)})}</dd><dt>${t("已完成")}</dt><dd class="text-green">${t("{p0} 次",{p0:(r.completedQuantity)})}</dd>${r.cancelledQuantity?`<dt>${t("已取消")}</dt><dd class="text-danger">${t("{p0} 次",{p0:(r.cancelledQuantity)})}</dd>`:''}<dt>${t("待执行")}</dt><dd>${t("{p0} 次",{p0:(remaining(r))})}</dd></dl>${remaining(r)&&r.status!=='faulted'?`<div class="reservation-controls">${s?.mode==='virtual'?button(t("执行批次"),'advance-dialog',{style:'secondary',ico:'play',attrs:`data-id="${h(r.id)}"`,off:o.status!=='running'||!r.providerConfirmed||!canWrite()}):button(t("提交实际证据"),'evidence-dialog',{style:'secondary',ico:'upload',attrs:`data-id="${h(r.id)}"`,off:!canWrite()||o.status!=='running'||!r.providerConfirmed})}${button(t("暂停 / 故障"),'fault-dialog',{style:'ghost',ico:'alert',attrs:`data-id="${h(r.id)}"`,off:o.status!=='running'||!canWrite()})}</div>`:''}${r.status==='faulted'?button(t("重新分配取消额度"),'reassign-dialog',{style:'secondary',ico:'refresh',attrs:`data-id="${h(r.id)}"`,off:!canWrite()||o.status!=='paused'||unassigned(o)===0}):''}${!r.providerConfirmed&&remaining(r)>0?button(t("确认此预约"),'confirm-reservation',{style:'secondary',ico:'check',attrs:`data-id="${h(r.id)}"`,off:!canWrite()}):''}</div>`;}).join('')}</div>${!rs.length?notice(t("先到“订单与预约”分配能力。"),'amber'):''}<div class="toolbar stack">${button(o.status==='paused'?t("恢复执行"):t("开始执行"),'start-order',{ico:'play',off:!['draft','confirmed','reserved','paused'].includes(o.status)||!canWrite()})}${button(t("批次验收与核销"),'nav',{style:'secondary',ico:'arrow',attrs:'data-page="settlement"'})}</div>${notice(t("虚拟执行在服务端产生测试轨迹；外部设备必须提交真实来源的证据。"),'blue')}</section></aside></div>`;
}
function eventTitle(e){const labels={'order.create':t("创建订单"),'reservation.create':t("创建预约"),'reservation.confirm':t("确认预约"),'order.confirm':t("订单确认"),'order.start':t("开始执行"),'execution.advance':t("完成检测批次"),'order.fault':t("检测异常，暂停"),'reservation.reassign':t("重新预约剩余任务"),'batch.accept':t("批次验收"),'order.accept':t("订单验收"),'order.settle':t("内部账本分账"),'spec.update':t("更新规格"),'spec.publish':t("登记规格")};return e.summary||e.message||labels[e.type]||e.type||t("状态更新");}
function renderBatchTable(o){return `<div class="table-wrap"><table class="table"><thead><tr><th>${t("批次")}</th><th>${t("供应商")}</th><th>${t("数量")}</th><th>${t("证据来源")}</th><th>${t("验收")}</th><th></th></tr></thead><tbody>${allBatches(o).map(b=>`<tr><td><code>${h(b.id.slice(-8))}</code></td><td>${h(displayText(supplierById(b.supplierId)))}</td><td>${b.records?.length||b.quantity||b.count||0}</td><td>${badge(b.mode==='virtual'?t("虚拟执行"):t("外部提交"),b.mode==='virtual'?'muted':'amber')}</td><td>${badge(b.status==='accepted'?t("已验收"):b.status==='rejected'?t("已拒绝"):t("待独立验收"),b.status==='accepted'?'green':'amber')}</td><td>${button(t("详情"),'batch-detail',{style:'ghost',attrs:`data-id="${h(b.id)}"`})}</td></tr>`).join('')}</tbody></table></div>`;}

function renderSettlement(){const o=currentOrder();if(!o)return empty(t("尚无订单。"));const rs=reservations(o),totals=data.suppliers.map(s=>({s,done:rs.filter(r=>r.supplierId===s.id).reduce((a,r)=>a+r.completedQuantity,0)}));const settled=o.settlement;const totalTests=allBatches(o).filter(b=>b.status!=='rejected').flatMap(b=>b.records||[]).reduce((a,r)=>a+(r.tests?.length||0),0);const reservationTotal=rs.reduce((a,r)=>a+r.quantity,0),cancelledTotal=rs.reduce((a,r)=>a+r.cancelledQuantity,0);const payouts=settled?.entries||settled?.payouts||[];
 return `<div class="page-layout settlement-layout"><section class="main-column">${pageTitle(t("按同一标准验收，按实际交付结算"),t("内部账本和链上付款分别显示，按实际证据完成验收。"),orderSelector())}<div class="stats-grid four">${stat(t("验收通过"),accepted(o),t("次"),'shield')}${stat(t("已核销"),settled?accepted(o):0,t("次"),'checkfile')}${totals.slice(0,2).map(({s,done})=>stat(t("{p0} 完成",{p0:(h(s.code))}),done,t("次"),'factory',s.code==='B'?'blue':'green')).join('')}</div><section class="panel">${title(t("可复查的验收记录"),'checkfile',badge(o.status==='settled'?t("内部账本已结算"):accepted(o)===o.quantity?t("全部批次已验收"):t("等待验收"),accepted(o)===o.quantity?'green':'amber'))}<div class="report-metadata"><div><small>${t("需求订单")}</small><strong>${h(o.id)}</strong></div><div><small>${t("规格")}</small><strong>${h(o.specSnapshot.profile)}</strong></div><div><small>${t("电路版本")}</small><strong>v${o.specVersion}</strong></div><div><small>${t("每次")}</small><strong>${t("{p0} 组向量",{p0:(o.specSnapshot.vectors.length)})}</strong></div><div><small>${t("合计")}</small><strong>${t("{p0} 组测试",{p0:(totalTests)})}</strong></div></div>${renderBatchWaves(o)}<div class="report-links"><span>${t("{p0}独立验证记录 · 以实际审阅身份保存",{p0:(icon('file'))})}</span>${button(t("查看报告"),'report-dialog',{style:'ghost',ico:'chevron'})}</div><details class="batch-review-details"${accepted(o)<o.quantity?' open':''}><summary>${t("{p0}批次证据与验收 ",{p0:(icon('shield'))})}<span>${t("{p0} / {p1} 批已接受",{p0:(allBatches(o).filter(b=>b.status==='accepted').length),p1:(allBatches(o).filter(b=>b.status!=='rejected').length)})}</span>${icon('chevron')}</summary>${renderBatchTable(o)}</details><h3 class="section-title">${t("预约与履约明细（按工厂 / 批次）")}</h3><div class="table-wrap"><table class="reservation-table"><thead><tr><th>${t("工厂 / 批次")}</th><th>${t("预约（次）")}</th><th>${t("完成（次）")}</th><th>${t("取消（次）")}</th><th>${t("核销（次）")}</th><th>${t("状态")}</th></tr></thead><tbody>${rs.map((r,i)=>`<tr><td><strong>${h(supplierById(r.supplierId)?.code)} ${i<2?t("原预约"):t("新增预约")}</strong></td><td>${r.quantity}</td><td>${r.completedQuantity}</td><td>${r.cancelledQuantity}</td><td>${settled?r.completedQuantity:0}</td><td>${badge(r.cancelledQuantity?t("部分取消"):remaining(r)===0&&r.completedQuantity?t("已完成"):r.providerConfirmed?t("已确认"):t("待确认"),r.status==='faulted'?'amber':'green')}</td></tr>`).join('')}<tr class="total-row"><td>${t("合计")}</td><td>${reservationTotal}</td><td>${o.completedQuantity}</td><td>${cancelledTotal}</td><td>${settled?o.acceptedQuantity:0}</td><td>${t("有效 {p0} 次",{p0:(reservationTotal-cancelledTotal)})}</td></tr></tbody></table></div>${notice(t("累计预约 {p0} 次 − 取消 {p1} 次 = 有效 {p2} 次；已取消额度不可再次履约或结算。",{p0:(reservationTotal),p1:(cancelledTotal),p2:(reservationTotal-cancelledTotal)}),'amber')}</section></section><aside class="inspector"><section class="panel">${title(settled?t("内部结算清单"):t("预计分账清单"),'file',badge(t("分账不等于利润"),'amber'))}<table class="payout-table"><thead><tr><th>${t("费用项")}</th><th>${t("金额（USDT）")}</th></tr></thead><tbody>${totals.filter(t=>t.done).map(({s,done})=>`<tr><td>${t("{p0}{p1} 履约",{p0:(icon('factory')),p1:(h(displayText(s)))})}</td><td>${money(payoutValue(payouts,s.id,Math.floor(o.fees.fulfillment*done/o.quantity)))}</td></tr>`).join('')}${!settled&&o.fees.fulfillment>totals.reduce((n,t)=>n+Math.floor(o.fees.fulfillment*t.done/o.quantity),0)?`<tr><td>${t("未履约 / 待分配履约预算")}</td><td>${money(o.fees.fulfillment-totals.reduce((n,t)=>n+Math.floor(o.fees.fulfillment*t.done/o.quantity),0))}</td></tr>`:''}${[['verification',t("独立验证"),'shield'],['design',t("设计与适配维护"),'settings'],['platform',t("平台服务"),'cube']].map(([k,t,i])=>`<tr><td>${icon(i)}${t}</td><td>${money(o.fees[k])}</td></tr>`).join('')}</tbody></table><div class="payout-total"><span>${t("合计")}</span><strong>${metricValue(money(o.budgetCents),"USDT")}</strong></div>${notice(settled?t("已写入内部账本，可导出逐笔记录。此操作没有发送代币。"):t("所有批次经过验收，且数量达到订单目标后，才能完成账本结算。"),'green')}<div class="toolbar stack">${button(t("验收全部符合条件批次"),'accept-all',{style:'secondary',ico:'shield',off:!canVerify()||!allBatches(o).some(canReviewBatch)})}${button(t("确认订单验收"),'accept-order',{style:'secondary',ico:'checkfile',off:!canVerify()||accepted(o)!==o.quantity||['accepted','settled'].includes(o.status)})}${button(settled?t("内部账本已结算"):t("确认内部账本分账"),'settle-dialog',{ico:'wallet',off:o.status!=='accepted'||!canSettle()})}${button(t("导出交付与核销记录"),'export-order',{style:'secondary',ico:'download'})}</div><div class="settlement-boundary"><strong>${t("真实付款")}</strong><p>${t("当前账本不托管资产。链上发布与真实转账均需钱包独立确认；不得将内部分账作为付款凭据。")}</p>${button(t("钱包与链上设置"),'chain-dialog',{style:'ghost',ico:'external'})}</div></section></aside></div>`;
}
function payoutValue(entries,id,fallback){const e=entries.find(e=>e.supplierId===id||e.recipientId===id||e.recipient===id);return e?.amountCents??e?.amount??fallback;}
function waveform(values,label=t("逻辑向量序列"),tone='green'){if(!Array.isArray(values)||!values.length||values.some(v=>![true,false,0,1].includes(v)))return t("<div class=\"wave-pending\">暂无可用向量记录</div>");const width=450,step=width/values.length,y=v=>v?9:27;let path=`M0 ${y(values[0])}`;values.forEach((v,i)=>{if(i)path+=`V${y(v)}`;path+=`H${((i+1)*step).toFixed(2)}`;});return `<svg class="waveform-svg" viewBox="0 0 450 35" preserveAspectRatio="none" role="img" aria-label="${h(label)}"><title>${h(label)}：${values.map(Number).join(', ')}</title>${values.map((_,i)=>`<path d="M${(i*step).toFixed(2)} 0V35" stroke="#e0e7df"/>`).join('')}<path d="M0 28H450" stroke="#e0e7df"/><path d="${path}" fill="none" stroke="${tone==='red'?'#b34232':'#257f32'}" stroke-width="2"/></svg>`;}
function renderBatchWaves(o){const batch=allBatches(o).at(-1),record=batch?.records?.at(-1),tests=record?.tests||[],vectors=tests.length?tests:(o.specSnapshot.vectors||[]);const source=!batch?t("冻结规格向量"):batch.mode==='virtual'?t("服务端虚拟轨迹"):t("外部提交轨迹（来源未由本图证明）");const row=(name,values,badgeText,tone='green')=>`<div class="wave-row"><strong>${h(name)}</strong>${waveform(values,name,tone)}${badge(badgeText,tone==='red'?'amber':values?.length?'green':'muted')}</div>`;let rows=['C','M','E'].map(k=>row(t("输入 {p0}",{p0:(k)}),vectors.map(t=>t.inputs?.[k]),t("测试序列"))).join('');const expected=vectors.map(t=>t.expected?.Y),actual=tests.map(t=>t.actual?.Y);rows+=row(t("参考 Y"),expected,t("冻结规格"));rows+=row(batch?.mode==='virtual'?t("虚拟记录 Y"):t("提交记录 Y"),actual,tests.length?t("批次记录"):t("未执行"),actual.some((v,i)=>v!==expected[i])?'red':'green');const report=chainReportForOrder(o);if(report){const ys=vectors.map(t=>report.rows.find(r=>r.inputs.every((bit,i)=>bit===t.inputs?.[['C','M','E'][i]]))?.chainOutputs?.[0]);rows+=row('X Layer Y',ys,t("区块 {p0}",{p0:(report.evidence.block)}));}else rows+=t("<div class=\"wave-row\"><strong>X Layer Y</strong><div class=\"wave-pending\">未对本订单固定版本完成全向量链上核对；公开 NAND 参考不计入。</div></div>");return `<div class="wave-comparison">${rows}</div><p class="field-help">${t("{p0}{p1}。横轴是测试向量序号，不表示实时采样或实际时间。",{p0:(h(source)),p1:(batch?t(" · 批次 {p0} · 件号 {p1}",{p0:(h(batch.id)),p1:(h(record?.unit))}):'')})}</p>`;}
function renderTools(){const tab=ui.toolsTab;return `${pageTitle(t("开放工具，让不同实现共同工作"),t("服务器 API、规则规范、集成状态与团队协作集中管理。"))}<div class="tabs tools-tabs">${[['overview',t("集成状态")],['industrial',t("工业能力标准")],['api',t("开发者 API")],['team',t("团队与权限")],['data',t("数据与工作区")],['profile',t("开放规范")]].map(([k,t])=>`<button class="tab ${tab===k?'active':''}" data-action="tools-tab" data-tab="${k}">${t}</button>`).join('')}</div>${tab==='industrial'?industrial.render():tab==='team'?renderTeam():tab==='data'?renderDataTools():tab==='api'?renderApiDocs():tab==='profile'?renderProfile():renderIntegrations()}`;}
function renderIntegrations(){return `<div class="settings-grid"><section class="panel settings-card">${title(techText('X Layer / TapeOut'),'layers')}<p>${t("连接钱包、读取已有电路并复算真实结果，也可以向已有处理器发布网表。")}</p><dl class="settings-list"><dt>${t("网络")}</dt><dd>${techText("X Layer Mainnet · Chain ID 196")}</dd><dt>${t("付款方式")}</dt><dd>${t("钱包独立确认，不托管私钥")}</dd><dt>${t("当前验证")}</dt><dd>${h(chainReportSummary())}</dd></dl>${button(t("打开链上工作台"),'chain-dialog',{ico:'layers'})}</section><section class="panel settings-card">${title(t("AI 规则辅助"),'sparkles')}<p>${t("在服务器配置兼容接口，生成结果必须经过受限语法与穷举测试后才能采用。")}</p><div id="integration-status">${badge(t("点击检测读取实际配置"),'muted')}</div><div class="toolbar">${button(t("检测服务配置"),'integration-check',{style:'secondary',ico:'refresh'})}${button(t("进入规格工坊"),'nav',{style:'ghost',attrs:'data-page="specifications"'})}</div><small class="field-help">${t("未配置模型时明确使用规则匹配，不伪装为 AI 生成。")}</small></section><section class="panel settings-card">${title(t("本地规则串口实验"),'chip')}<p>${t("浏览器直连的规则实验使用独立串口协议。接入实际任务队列时，请到“设备与实际控制”下载网关固件。")}</p><div class="toolbar">${button(t("连接实验串口"),'serial-connect',{style:'secondary',ico:'link'})}${button(t("下载实验固件"),'export-firmware',{style:'ghost',ico:'download',off:currentSpec()?.profile==='TC-PANEL/0.1'})}${button(t("导出 PLC ST"),'export-st',{style:'ghost',ico:'download'})}</div>${currentSpec()?.profile==='TC-PANEL/0.1'?t("<p class=\"field-help\">当前显示规格不生成通用 GPIO 实验 sketch，其 GPIO14 输出与 TFT RESET 占用冲突。请到设备页使用已编译的 panel 专用固件；<a href=\"/firmware/esp32-s3-panel/manifest.json\" download>查看构建参数与哈希</a>。</p>"):''}<div id="serial-status" class="callout blue">${t("尚未连接设备。需要支持 Web Serial 的桌面 Chrome / Edge。")}</div></section><section class="panel settings-card">${title(t("运行与持久化"),'database')}<dl class="settings-list"><dt>${t("存储")}</dt><dd>${t("服务端 SQLite · 持久化工作区")}</dd><dt>${t("修订")}</dt><dd>${data.revision}</dd><dt>${t("用户角色")}</dt><dd>${roleName(data.user.role)}</dd><dt>${t("工作区模式")}</dt><dd>${data.workspace.mode==='simulation'?t("虚拟演示"):t("外部设备证据")}</dd></dl>${notice(t("本系统验证规则与提交证据的一致性；现实物理质量和仪器可信性需要外部测试。"))}</section></div>`;}
function roleName(role){return ({owner:t("所有者"),operator:t("操作者"),verifier:t("验证者"),viewer:t("只读成员")})[role]||role||t("成员");}
function renderTeam(){return `<section class="panel">${title(t("团队成员与职责"),'users',button(t("邀请成员"),'invite-dialog',{ico:'plus',off:data.user.role!=='owner'||data.user.isDemo}))}<div class="table-wrap"><table class="table"><thead><tr><th>${t("成员")}</th><th>${t("邮箱")}</th><th>${t("角色")}</th><th>${t("说明")}</th></tr></thead><tbody>${(data.members||[]).map(m=>`<tr><td>${h(memberDisplayName(m,data.user))}</td><td>${h(m.email||m.user?.email)}</td><td>${badge(roleName(m.role),'green')}</td><td>${m.role==='verifier'?t("可审阅并验收批次"):m.role==='operator'?t("可预约和执行，不可独立验收"):m.role==='viewer'?t("可查看与导出"):t("管理工作区与演示验收")}</td></tr>`).join('')}</tbody></table></div>${notice(t("操作者与验证者分离。所有者可协调验收，但真实外部证据的独立性必须按实际审阅人记录。"))}${data.user.isDemo?notice(t("演示会话不可作为正式团队账号；请创建管理员账号使用长期协作。"),'amber'):''}</section>`;}
function renderDataTools(){return `<div class="settings-grid"><section class="panel">${title(t("完整数据导出"),'download')}<p>${t("导出规格、供应商、订单、测试轨迹、审计记录和内部账本。")}</p><div class="toolbar">${button(t("导出工作区 JSON"),'export-workspace',{ico:'download'})}${button(t("导出订单 CSV"),'export-csv',{style:'secondary',ico:'download'})}</div></section><section class="panel">${title(t("工作区迁移"),'upload')}<p>${t("只导入未执行的草稿模板；已履约轨迹、验收和账本可导出审计，不可导入为有效记录。")}</p>${button(t("从 JSON 导入"),'import-workspace',{style:'secondary',ico:'upload',off:data.user.role!=='owner'||data.user.isDemo})}</section><section class="panel">${title(t("新建工作区"),'plus')}<p>${t("新工作区与当前工作区的数据和成员隔离。")}</p>${button(t("创建工作区"),'workspace-new',{style:'secondary',ico:'plus',off:data.user.isDemo})}</section><section class="panel">${title(t("重置演示数据"),'refresh')}<p>${t("只针对演示工作区。正式工作区不可用此操作清除订单。")}</p>${button(t("重置当前演示"),'reset-dialog',{style:'danger',ico:'refresh',off:!data.workspace.demo})}</section></div>`;}
function commandNames(names) {
  const commands = names.split(' / ');
  const options = commands.map((name, i) => `<span class="command-option"><code>${h(name)}</code>${i < commands.length - 1 ? ' /' : ''}</span>`);
  return `<div class="command-options">${options.join(' ')}</div>`;
}
function renderApiDocs(){const example={type:'reservation.create',payload:{orderId:currentOrder()?.id||'TC-024',supplierId:'supplier_a',quantity:60},expectedRevision:data.revision,requestId:'your-unique-request-id'};return `<div class="settings-grid"><section class="panel">${title(t("同源会话 API"),'code')}<p>${t("所有写请求需要登录会话、正确 Origin 和会话 CSRF token。SDK 使用同一套状态机，不能绕过权限或验收。")}</p><pre class="code-block">GET  /api/session
GET  /api/bootstrap
POST /api/command
GET  /api/export?format=json
GET  /api/export?format=csv
POST /api/assist
POST /api/rpc
GET  /api/integrations</pre>${button(t("复制预约请求"),'copy-api',{style:'secondary',ico:'copy'})}<pre class="code-block">${h(JSON.stringify(example,null,2))}</pre></section><section class="panel">${title(t("命令与状态"),'network')}<table class="table command-table"><tbody>${[['supplier.create / update',t("能力登记与容量")],['spec.create / update / publish',t("规格版本与本地登记")],['order.create / confirm / start',t("创建与开始履约")],['reservation.create / confirm',t("预约与供应商确认")],['execution.advance / order.fault',t("虚拟批次与故障")],['reservation.reassign',t("取消额度重新预约")],['evidence.submit / batch.accept',t("外部证据与独立验收")],['order.accept / order.settle',t("订单验收与内部账本")]].map(([names,description])=>`<tr><td>${commandNames(names)}</td><td>${description}</td></tr>`).join('')}</tbody></table><a class="subtle-link" href="/sdk.mjs" download>${t("下载浏览器 SDK ↗")}</a>${notice(t("expectedRevision 防止并发覆盖；requestId 用于幂等。冲突时重新读取状态后再明确重试。"))}</section></div>`;}
function renderProfile(){return `<section class="panel profile-document">${title(techText('TwinCircuit Industrial Profile 0.1'),'book',badge(t("项目社区草案"),'muted'))}<p class="lead">${t("首版支持 C / M / E 三个布尔输入和 Y 单输出，逻辑由受限表达式确定，并可编译为 TapeOut NAND 网表。")}</p><div class="settings-grid"><div><h3>${t("核心语义")}</h3><ul><li>${t("证据中的输入输出必须为 JSON 布尔值；设备 0 / 1 由适配器转换。")}</li><li>${t("相同输入与同一规格版本产生相同预期输出。")}</li><li>${t("订单固定规格快照；编辑规格不会改写已创建订单。")}</li><li>${t("批次记录完整测试向量，验收重算预期值。")}</li><li>${t("额度满足：累计预约 − 取消 ≥ 完成 ≥ 验收 ≥ 核销。")}</li><li>${t("虚拟执行与外部提交证据不能互换身份。")}</li></ul></div><div><h3>${t("符合性与限制")}</h3><p>${t("“测试通过”仅表示指定版本和测试范围内的逻辑结果一致，不构成工业安全认证、实体质量证明或官方标准认可。")}</p><p>${t("TapeOut 原始网表与参考规则独立验证。真实设备需独立的量测、校准和履约责任。")}</p><p><a href="https://github.com/TapeOutProtocol/TAPs/blob/main/TAPs/TAP-02.md" target="_blank" rel="noopener">${t("TapeOut TAP-02 规范 ↗")}</a></p></div></div>${button(t("导出当前规格与向量"),'export-netlist',{style:'secondary',ico:'download'})}</section>`;}

function supplierDialog(id){const s=data.suppliers.find(s=>s.id===id);if(!s)return;modal(t("{p0} · 能力详情",{p0:(h(displayText(s)))}),`${supplierVisual(s)}<dl class="detail-dl"><dt>${t("服务")}</dt><dd>${techText(t("数字 I/O 功能检测"))}</dd><dt>${t("模式")}</dt><dd>${s.mode==='virtual'?t("虚拟供应商"):t("外部证据供应商")}</dd><dt>${t("总容量")}</dt><dd>${t("{p0} 次",{p0:(s.capacity)})}</dd><dt>${t("当前可用")}</dt><dd>${t("{p0} 次",{p0:(s.availableCapacity??s.available)})}</dd><dt>${t("规格")}</dt><dd>${techText(s.capabilities.join('、'))}</dd><dt>${t("描述")}</dt><dd>${h(displayText(s,'description'))}</dd></dl>${notice(s.mode==='virtual'?t("虚拟设备用于验证完整协作流程，不代表现实产能。"):t("供应商登记信息需要实际履约方负责。验收以提交证据和审阅结果为准。"))}`,`${button(t("编辑能力"),'supplier-edit',{style:'secondary',ico:'settings',attrs:`data-id="${h(id)}"`,off:!canWrite()})}${button(t("预约此能力"),'reserve',{ico:'calendar',attrs:`data-id="${h(id)}"`,off:!canWrite()||currentOrder()?.status!=='draft'})}`);}
function supplierForm(id){const s=data.suppliers.find(s=>s.id===id);modal(s?t("编辑供应商"):t("登记供应商"),`<form data-form="supplier" data-id="${h(id||'')}"><div class="form-grid">${field(t("供应商名称"),'name',displayText(s))}${field(t("显示代码"),'code',s?.code||'C')}${field(t("总并发容量（次）"),'capacity',s?.capacity??60,{type:'number',min:1,max:100000})}<label class="form-field"><span>${t("设备模式")}</span><select name="mode"${s?' disabled':''}><option value="virtual"${selected(s?.mode!=='external')}>${t("虚拟设备（可运行演示）")}</option><option value="external"${selected(s?.mode==='external')}>${t("外部设备（必须提交证据）")}</option></select></label></div><label class="form-field"><span>${t("能力说明")}</span><textarea name="description" rows="3">${h(s ? displayText(s,'description') : t('兼容 TC-IO/0.1 的数字 I/O 功能检测服务'))}</textarea></label>${notice(t("容量是工作区声明值；真实供应商需自行保障权威预约记录。"))}${formFooter()}</form>`);}
function orderForm(){modal(t("创建需求订单"),`<form data-form="order"><div class="form-grid">${field(t("订单名称"),'name',t('数字 I/O 功能检测'))}${field(t("目标数量"),'quantity',100,{type:'number',min:1,max:1000})}${field(t("总预算（USDT）"),'budget',100,{type:'number',min:.01,max:1000000,step:.01})}<label class="form-field"><span>${t("验收规格")}</span><select name="specId">${data.specs.filter(s=>s.status==='published').map(s=>`<option value="${h(s.id)}">${h(displayText(s))} · v${s.version}</option>`).join('')}</select></label></div><p class="field-help">${t("默认分配：履约 70%、验证 15%、设计维护 10%、平台 5%。订单固定当前规格版本。")}</p>${formFooter(t("创建订单"),'plus')}</form>`);}
function reserveDialog(id){const s=supplierById(id),o=currentOrder(),already=reservations(o).reduce((a,r)=>a+r.quantity-r.cancelledQuantity,0),max=Math.min(o.quantity-already,s.availableCapacity??s.available);modal(t("预约 {p0}",{p0:(h(displayText(s)))}),`<form data-form="reserve"><input type="hidden" name="supplierId" value="${h(id)}">${field(t("预约次数"),'quantity',Math.max(1,Math.min(max,s.code==='A'?60:40)),{type:'number',min:1,max:Math.max(1,max),help:t("供应商可用 {p0} 次，订单未分配 {p1} 次。",{p0:(s.availableCapacity??s.available),p1:(o.quantity-already)})})}${notice(t("预约后还需供应商确认。虚拟供应商确认会明确标记为模拟。"))}${formFooter(t("创建预约"),'calendar')}</form>`);}
function advanceDialog(id){const r=reservations(currentOrder()).find(r=>r.id===id);modal(t("执行虚拟检测批次"),`<form data-form="advance"><input type="hidden" name="reservationId" value="${h(id)}">${field(t("本次执行数量"),'count',Math.min(40,remaining(r)),{type:'number',min:1,max:remaining(r)})}${notice(t("服务端会生成每次 {p0} 组测试轨迹，之后需要单独验收。",{p0:(currentOrder().specSnapshot.vectors.length)}))}${formFooter(t("执行并生成轨迹"),'play')}</form>`);}
function faultDialog(id){const r=reservations(currentOrder()).find(r=>r.id===id);modal(t("记录故障并暂停"),`<form data-form="fault"><input type="hidden" name="reservationId" value="${h(id)}">${field(t("故障说明"),'reason',t('虚拟设备发生异常，暂停未执行任务'))}${notice(t("此预约还有 {p0} 次未执行。提交后会取消未执行额度，保留已完成轨迹。",{p0:(remaining(r))}),'amber')}${formFooter(t("确认故障并取消剩余额度"),'alert')}</form>`);}
function reassignDialog(id){const o=currentOrder(),r=reservations(o).find(r=>r.id===id);modal(t("重新预约取消额度"),`<form data-form="reassign"><input type="hidden" name="reservationId" value="${h(id)}"><label class="form-field"><span>${t("新的承接供应商")}</span><select name="supplierId">${data.suppliers.filter(s=>s.id!==r.supplierId).map(s=>`<option value="${h(s.id)}">${t("{p0} · 可用 {p1} 次",{p0:(h(displayText(s))),p1:(s.availableCapacity??s.available)})}</option>`).join('')}</select></label>${field(t("重新预约次数"),'quantity',Math.min(unassigned(o),r.cancelledQuantity||0,20),{type:'number',min:1,max:Math.min(unassigned(o),r.cancelledQuantity)})}${notice(t("新预约需要重新确认。取消历史保留，原预约不能再次执行已取消额度。"))}${formFooter(t("创建新的预约"),'refresh')}</form>`);}
function batchDialog(id){const o=currentOrder(),b=allBatches(o).find(b=>b.id===id);if(!b)return;const records=b.records||[];modal(t("检测批次与验收"),`<div class="metadata-list"><dl><dt>${t("批次")}</dt><dd><code>${h(b.id)}</code></dd><dt>${t("供应商")}</dt><dd>${h(displayText(supplierById(b.supplierId)))}</dd><dt>${t("数量")}</dt><dd>${records.length}</dd><dt>${t("证据来源")}</dt><dd>${h(b.evidenceStatus||b.mode)}</dd><dt>${t("提交者")}</dt><dd>${h(b.submittedBy)}</dd><dt>${t("验收")}</dt><dd>${h(b.review?.note||t(statusNames[b.status]||b.status))}</dd></dl></div><div class="table-wrap batch-tests"><table class="table"><thead><tr><th>${t("件号")}</th><th>${t("输入 C/M/E")}</th><th>${t("预期 Y")}</th><th>${t("实际 Y")}</th></tr></thead><tbody>${records.slice(0,3).flatMap(r=>(r.tests||[]).map(t=>`<tr><td>${r.unit}</td><td><code>${h(JSON.stringify(t.inputs))}</code></td><td>${h(JSON.stringify(t.expected))}</td><td>${h(JSON.stringify(t.actual))}</td></tr>`)).join('')}</tbody></table></div><p class="field-help">${t("显示前 3 件，导出文件包含全部记录。实际证据真实性由提交者与审阅者负责。")}</p>`,`${button(t("导出完整订单"),'export-order',{style:'secondary',ico:'download'})}${button(t("审阅并接受此批次"),'accept-batch',{ico:'shield',attrs:`data-id="${h(id)}"`,off:!canReviewBatch(b)})}${button(t("拒绝并退回补证"),'reject-batch',{style:'ghost',ico:'alert',attrs:`data-id="${h(id)}"`,off:!canReviewBatch(b)})}`);}
function evidenceDialog(id){const v=currentOrder().specSnapshot.vectors;const used=new Set(allBatches(currentOrder()).filter(b=>b.status!=='rejected').flatMap(b=>b.records.map(r=>r.unit)));let unit=0;while(used.has(unit))unit++;const sample={records:[{unit,source:'请替换：设备编号 / 测试环境 / 操作者',tests:v.map(t=>({inputs:t.inputs,expected:t.expected,actual:t.expected}))}],sourceNote:'仪器校准、测试说明或证据文件链接，以及实际设备测试批次说明'};modal(t("提交外部设备证据"),`<form data-form="evidence"><input type="hidden" name="reservationId" value="${h(id)}"><label class="form-field"><span>${t("完整 JSON 证据")}</span><textarea name="evidence" rows="15" required spellcheck="false">${h(JSON.stringify(sample,null,2))}</textarea><small class="field-help">${t("请用实际测量替换样例值。服务端会对照订单快照重算，不相信提交的预期值。")}</small></label>${notice(t("外部证据必须由不同身份的验证者审阅；上传并不证明物理真实性。"),'amber')}${formFooter(t("提交待验证证据"),'upload')}</form>`);}
function showAudit(){const o=currentOrder(),events=orderEvents(o);modal(t("工作区审计记录"),`<div class="audit-list">${events.slice().reverse().map(e=>`<article><strong>${h(eventTitle(e))}</strong><small><time>${when(e.at||e.createdAt||e.timestamp)}</time></small><pre>${h(JSON.stringify(e,null,2))}</pre></article>`).join('')||t("暂无事件。")}</div>`,button(t("导出工作区"),'export-workspace',{ico:'download'}));}
function reportDialog(){const o=currentOrder();modal(t("验收报告"),`<dl class="detail-dl"><dt>${t("订单")}</dt><dd>${techToken(o.id)}</dd><dt>${t("规格")}</dt><dd>${techToken(o.specSnapshot.profile)} · ${techToken("v"+o.specVersion)}</dd><dt>${t("已完成")}</dt><dd>${techToken(o.completedQuantity+" / "+o.quantity)}</dd><dt>${t("已验收")}</dt><dd>${techToken(o.acceptedQuantity+" / "+o.quantity)}</dd><dt>${t("链上复算")}</dt><dd>${chainReportForOrder(o)?t("本订单固定网表已完成全向量复算（本会话）"):t("本订单固定版本未完成全向量链上复算；公开参考单独记录")}</dd><dt>${t("账本状态")}</dt><dd>${o.settlement?t("内部账本已分账"):t("未分账")}</dd></dl>${notice(t("报告只涵盖已提交的测试向量。不得将本地验收或内部账本当作实体认证、链上付款。"))}`,`${button(t("JSON 完整证据"),'export-order',{ico:'download'})}${button(t("CSV 明细"),'export-csv',{style:'secondary',ico:'download'})}`);}

const chainRPC=payload=>api('/api/rpc',{method:'POST',body:payload});
function circuitKey(c){return c?`${c.nIn}:${c.nOut}:${c.nState||0}:${c.netlistHex}`:null;}
function captureChainTarget(){const order=currentOrder(),fromOrder=['reservations','execution','settlement'].includes(ui.page),spec=fromOrder?order?.specSnapshot:currentSpec();if(!spec)throw new Error(t("没有可核对的规格。"));const circuit=fromOrder?engine.compileExpression(spec.expression,{variables:['C','M','E'],id:spec.id,title:spec.name}):draftCircuit();return {circuit,context:{workspaceId:data.workspace.id,specId:spec.id,specVersion:fromOrder?order.specVersion:spec.version,orderId:fromOrder?order.id:null,signature:circuitKey(circuit),source:fromOrder?'frozen-order-snapshot':'specification-draft'}};}
function industrialChainTarget(profileKey){
 const profile=industrial.profile(profileKey);if(!profile)throw new Error(t("此标准电路不可用，请刷新。"));
 const circuit={...engine.importNetlist({netlistHex:profile.netlistHex,nIn:profile.nIn,nOut:profile.nOut}),title:profile.name};
 return {circuit,context:{workspaceId:data.workspace.id,specId:profile.digest,specVersion:'0.1',orderId:null,signature:circuitKey(circuit),source:'industrial-standard',profileKey}};
}
function scopedChainReport(c,context){const r=ui.chainReport;if(!c||!r?.ok||r.scope!=='imported-circuit-all-inputs'||r.total!==2**c.nIn||c.nState||r.context?.workspaceId!==data.workspace.id||circuitKey(r.circuit)!==circuitKey(c))return null;if(r.context.specId!==context.specId||r.context.specVersion!==context.specVersion||context.orderId&&r.context.orderId!==context.orderId)return null;return r;}
function chainReportForSpec(c){return scopedChainReport(c,{specId:currentSpec()?.id,specVersion:currentSpec()?.version});}
function chainReportForOrder(o){if(!o)return null;try{return scopedChainReport(o.specSnapshot.circuit||engine.compileExpression(o.specSnapshot.expression),{specId:o.specId,specVersion:o.specVersion,orderId:o.id});}catch{return null;}}
function chainReportSummary(){const r=ui.chainReport;if(!r||r.context?.workspaceId!==data.workspace.id)return t("本工作区本会话尚未核对");if(r.scope==='existing-reference-nand')return r.ok?t("公开 NAND 参考 4/4 已核对（非当前规格）"):t("公开 NAND 参考不一致");return r.ok?t("{p0}/{p1} 导入目标已核对；业务范围另行匹配",{p0:(r.passed||1),p1:(r.total||1)}):t("导入目标存在不一致");}
function chainDialog(forcedTarget){if(!ui.chainBusy)ui.chainTarget=forcedTarget||captureChainTarget();const target=ui.chainTarget;modal(t("X Layer / TapeOut 工作台"),`<div class="tabs"><span class="badge badge-green">X Layer · 196</span><span class="badge badge-muted">${t("只读复算 / 用户钱包发布")}</span></div><p>${t("目标：{p0} · {p1} v{p2}。核对记录按工作区、规格版本及网表字节隔离。",{p0:(h(target.circuit.title)),p1:(target.context.source==='industrial-standard'?t("工业能力标准草案"):target.context.source==='frozen-order-snapshot'?t("订单固定版本"):t("当前规格草稿")),p2:(h(target.context.specVersion))})}</p><div class="toolbar">${button(ui.wallet?`${ui.wallet.slice(0,6)}…${ui.wallet.slice(-4)}`:t("连接钱包"),'wallet-connect',{style:'secondary',ico:'wallet',off:ui.chainBusy})}${button(t("切换钱包到 X Layer"),'wallet-switch',{style:'ghost',off:ui.chainBusy||!ui.wallet})}${button(t("检查公开 NAND 参考"),'chain-reference',{style:'secondary',ico:'layers',off:ui.chainBusy})}</div><p id="chain-summary" class="field-help">${t("钱包网络：{p0}。{p1}",{p0:(ui.walletChain??t("未连接")),p1:(h(chainReportSummary()))})}</p><div id="chain-result" class="callout blue">${ui.chainReport?.context?.workspaceId===data.workspace.id?h(JSON.stringify(ui.chainReport,null,2)):t("本工作区尚未发出请求。只读核对不需要签名或支付 Gas。")}</div><div class="toolbar">${button(t("导出本会话链上证据"),'chain-export',{style:'ghost',ico:'download',off:ui.chainReport?.context?.workspaceId!==data.workspace.id})}</div><form data-form="chain-read"><div class="form-grid">${field(t("处理器电路合约地址"),'address',chain.REFERENCE.address,{placeholder:'0x…'})}${field(t('Circuit ID'),'id',2,{type:'number',min:1})}${field(t("输入位（逗号分隔，可留空）"),'inputs','',{placeholder:'0,0,1',required:false})}${field(t("旧状态位（时序电路，可留空）"),'state','',{placeholder:'0,0',required:false})}</div><p class="field-help">${t("≤5 输入的无状态电路自动全组合复算；更大或有状态电路只核对填写的一组，留空明确使用全零。输入按目标电路端口顺序，不强行套用 C/M/E。")}</p><button type="submit" class="btn-secondary" ${disabled(ui.chainBusy)}>${t("{p0}读取并复算目标网表",{p0:(icon('eye'))})}</button></form><details class="chain-publish"><summary>${t("向已有处理器发布目标网表")}</summary><p>${t("钱包必须已持有足够晶体管。先读取当前协议费、晶体管消耗和 Gas 估算，审阅后进入钱包。本应用不自动购买资产或发送授权。")}</p><form data-form="chain-publish">${field(t("目标处理器电路合约地址"),'address','')}${notice(t("发布消耗 NAND / LATCH 和 OKB。Gas 与协议费分开；失败也可能消耗 Gas。"),'amber')}<button class="btn-primary" type="submit" ${disabled(ui.chainBusy)}>${t("{p0}读取费用并准备发布",{p0:(icon('upload'))})}</button></form></details><p class="field-help">${t("公开 NAND 参考不等于当前完整规格已发布。成功回执仅证明交易被包含；新电路需另行读回核对。全部证据为单一配置 RPC，本会话数据可导出。")}</p>`);}
async function chainResult(fn,context=ui.chainTarget?.context){if(ui.chainBusy)throw new Error(t("正在进行另一项链上操作，请稍候。"));ui.chainBusy=true;const target=$('#chain-result');if(target)target.textContent=t("正在读取并逐向量核对 X Layer…");try{const r=await fn();if(context?.workspaceId!==data?.workspace?.id)return {...r,context:{...context},ignoredForCurrentWorkspace:true};ui.chainReport={...r,context:{...context}};if(target?.isConnected)target.textContent=JSON.stringify(ui.chainReport,null,2);const summary=$('#chain-summary');if(summary?.isConnected)summary.textContent=t("钱包网络：{p0}。{p1}",{p0:(ui.walletChain??t("未连接")),p1:(chainReportSummary())});const exportButton=$('.dialog [data-action="chain-export"]');if(exportButton?.isConnected)exportButton.disabled=false;if(ui.page==='specifications')updateSpecLive(false);return ui.chainReport;}catch(e){if(target?.isConnected)target.textContent=errorMessage(e);throw e;}finally{ui.chainBusy=false;}}
function parseBitField(value,count,label){if(!value?.trim())return Array(count).fill(false);const parts=value.trim().split(/[,\s]+/);if(parts.length!==count||parts.some(x=>!['0','1'].includes(x)))throw new Error(t("{p0}必须包含恰好 {p1} 个 0/1。",{p0:(label),p1:(count)}));return parts.map(x=>x==='1');}
async function readChainTarget(values){const imported=await chain.readCircuit({address:values.address,id:values.id,rpc:chainRPC});if(!imported.circuit.nState&&imported.circuit.nIn<=5)return chain.compareCircuitVectors({address:values.address,id:values.id,block:imported.evidence.block,rpc:chainRPC});const inputs=parseBitField(values.inputs,imported.circuit.nIn,t("输入")),state=parseBitField(values.state,imported.circuit.nState,t("旧状态"));const result=await chain.readCircuit({address:values.address,id:values.id,inputs,state,block:imported.evidence.block,rpc:chainRPC});return {...result,scope:imported.circuit.nState?'single-state-step':'single-input-vector',ok:result.comparison?.match===true,passed:result.comparison?.match?1:0,total:1,note:'只覆盖这组输入与旧状态；未证明完整行为等价。'};}
function reviewPublication(review){return new Promise(resolve=>{modal(t("真实发布交易审阅"),`<dl class="detail-dl"><dt>${t("网络")}</dt><dd>X Layer · 196</dd><dt>${t("发送钱包")}</dt><dd><code>${h(review.from)}</code></dd><dt>${t("目标处理器")}</dt><dd><code>${h(review.address)}</code></dd><dt>${t("当前协议费")}</dt><dd>${h(review.feeOKB)} OKB（${h(review.feeWei)} wei）</dd><dt>${t("预计消耗")}</dt><dd>NAND ${review.tokenConsumption.NAND} · LATCH ${review.tokenConsumption.LATCH}</dd><dt>${t("Gas 估算")}</dt><dd>${t("{p0} 单位；金额由钱包显示，另计",{p0:(Number(BigInt(review.gasEstimate)).toLocaleString(getLocale()))})}</dd></dl><details><summary>${t("查看完整待签交易")}</summary><pre class="code-block">${h(JSON.stringify(review.transaction,null,2))}</pre></details>${notice(t("继续会请求钱包签名并消耗真实资产。取消、关闭或 Escape 均不发送交易。"),'amber')}`,`<button type="button" class="btn-secondary" id="publish-cancel">${t("取消")}</button><button type="button" class="btn-primary" id="publish-approve">${t("继续到钱包")}</button>`);const finish=approved=>{ui.publishReviewResolve=null;closeModal();resolve(approved);};ui.publishReviewResolve=resolve;$('#publish-cancel').onclick=()=>finish(false);$('#publish-approve').onclick=()=>finish(true);});}
async function publishChainTarget(address){if(ui.chainBusy)throw new Error(t("正在进行另一项链上操作。"));if(!ui.wallet)throw new Error(t("请先连接钱包，并切换到 X Layer。"));const target=ui.chainTarget||captureChainTarget(),c=target.circuit;ui.chainBusy=true;try{const sent=await chain.publishExistingCPU({address,netlistHex:c.netlistHex,nIn:c.nIn,nOut:c.nOut,rpc:chainRPC,onReview:reviewPublication});if(!sent.submitted){toast(t("已取消，未发送交易。"),'warning');return;}ui.publicationReport={...sent,context:target.context};modal(t("发布交易状态"),`<div id="publication-status" class="callout blue">${t("交易已提交，尚未确认：")}<code>${h(sent.transactionHash)}</code>${t("。正在等待回执…")}</div>`);toast(t("已提交真实交易，正在等待回执；尚未认定部署完成。"),'warning');const receipt=await chain.waitForReceipt(sent.transactionHash,{rpc:chainRPC,attempts:20,intervalMs:1500});ui.publicationReport={...ui.publicationReport,...receipt};if(!receipt.confirmed){if($('#publication-status'))$('#publication-status').textContent=t("交易仍待确认：{p0}。可在浏览器查看；未声明发布成功。",{p0:(sent.transactionHash)});return;}try{const id=chain.findPublishedCircuitId(receipt.receipt,sent.review.address,sent.review.from);const result=await chain.compareCircuitVectors({address:sent.review.address,id,rpc:chainRPC});if(circuitKey(result.circuit)!==circuitKey(c)||!result.ok)throw new Error(t("新电路网表或输出与本次发布目标不一致。"));ui.chainReport={...result,context:target.context,publication:{transactionHash:sent.transactionHash,receiptBlock:receipt.receipt.blockNumber,finality:receipt.finality}};ui.publicationReport={...ui.publicationReport,circuitId:id,readbackVerified:true,evidence:result.evidence};if($('#publication-status'))$('#publication-status').textContent=t("交易回执成功，新电路 #{p0} 已读回，{p1}/{p2} 组输出与网表一致。区块 {p3}；尚未声称最终确认。",{p0:(id),p1:(result.passed),p2:(result.total),p3:(result.evidence.block)});toast(t("成功回执与新电路读回核对已完成。"));}catch(e){ui.publicationReport.readbackVerified=false;ui.publicationReport.readbackError=e.message;if($('#publication-status'))$('#publication-status').textContent=t("交易回执成功，但新电路尚未完成核对：{p0}。哈希 {p1}",{p0:(errorMessage(e)),p1:(sent.transactionHash)});toast(t("回执成功；新电路读回核对尚未完成。"),'warning');}}catch(e){if($('#publication-status'))$('#publication-status').textContent=errorMessage(e);throw e;}finally{ui.chainBusy=false;}}

function accountDialog(){modal(t("账号与工作区"),`<dl class="detail-dl"><dt>${t("姓名")}</dt><dd>${h(memberDisplayName(data.user,data.user))}</dd><dt>${t("邮箱")}</dt><dd>${h(data.user.email)}</dd><dt>${t("角色")}</dt><dd>${roleName(data.user.role)}</dd><dt>${t("工作区")}</dt><dd>${h(workspaceDisplayName(data.workspace))}</dd></dl>${data.user.isDemo?notice(t("当前为隔离演示账号，退出后不会变成正式账号。"),'amber'):''}<div class="toolbar">${button(t("团队设置"),'nav',{style:'secondary',ico:'users',attrs:'data-page="tools" data-tab="team"'})}${!data.user.isDemo?button(t("修改密码"),'password-dialog',{style:'secondary',ico:'lock'}):''}${button(t("退出登录"),'logout',{style:'ghost',ico:'logout'})}</div>`);}
function workspaceDialog(){modal(t("选择工作区"),`<div class="workspace-list">${(data.workspaces||[]).map(w=>`<button class="workspace-option ${w.id===data.workspace.id?'active':''}" data-action="workspace-select" data-id="${h(w.id)}"><strong>${h(workspaceDisplayName(w))}</strong><span>${roleName(w.role)}</span>${icon(w.id===data.workspace.id?'checkcircle':'chevron')}</button>`).join('')||h(workspaceDisplayName(data.workspace))}</div>`,button(t("新建工作区"),'workspace-new',{ico:'plus',off:data.user.isDemo}));}

document.addEventListener('click',async event=>{
 const el=event.target.closest('[data-action]');if(!el||el.disabled)return;const action=el.dataset.action,id=el.dataset.id;
 try{
 switch(action){
 case 'nav':closeModal();if(el.dataset.tab)ui.toolsTab=el.dataset.tab;nav(el.dataset.page);if(ui.page==='tools'&&ui.toolsTab==='industrial'){await industrial.load();render();}break;
 case 'reload':location.reload();break;
 case 'toggle-nav':
   ui.sidebar=!ui.sidebar;
   $('.app-layout')?.classList.toggle('sidebar-open',ui.sidebar);
   el.setAttribute('aria-expanded',String(ui.sidebar));
   break;
 case 'auth-tab':renderAuth(el.dataset.tab);break;
 case 'set-language':setLanguage(el.dataset.language);break;
 case 'enter-demo':el.disabled=true;await api('/api/auth/demo',{method:'POST',body:{}});await loadSession();await refresh();render();toast(t("已进入独立演示工作区。"));break;
 case 'refresh':await refresh();if(ui.page==='tools'&&ui.toolsTab==='industrial')await industrial.load();render();toast(t("已读取服务器最新状态。"));break;
 case 'close-dialog':closeModal();break;
 case 'supplier-filter':ui.supplierMode=el.dataset.mode;render();break;
 case 'supplier-detail':supplierDialog(id);break;
 case 'supplier-new':supplierForm();break;
 case 'supplier-edit':supplierForm(id);break;
 case 'order-new':orderForm();break;
 case 'reserve':reserveDialog(id);break;
 case 'confirm-reservation':{const r=reservations(currentOrder()).find(r=>r.id===id);if(supplierById(r.supplierId)?.mode==='external'){modal(t("记录外部供应商确认"),`<form data-form="provider-confirm"><input type="hidden" name="reservationId" value="${h(id)}">${field(t("供应商确认依据"),'confirmationRef','',{help:t("填写实际确认单、邮件编号或双方确认记录；此输入不自动证明授权。")})}${formFooter(t("记录确认"),'check')}</form>`);}else{await command('reservation.confirm',{orderId:currentOrder().id,reservationId:id});closeModal();toast(t("虚拟预约已模拟确认。"));}break;}
 case 'reservation-list':modal(t("全部预约"),`<pre class="code-block">${h(JSON.stringify(reservations(currentOrder()),null,2))}</pre>`);break;
 case 'seed-reservations':{const o=currentOrder();for(const [sid,n] of [['supplier_a',60],['supplier_b',40]]){await command('reservation.create',{orderId:o.id,supplierId:sid,quantity:n});const r=reservations(currentOrder()).at(-1);await command('reservation.confirm',{orderId:o.id,reservationId:r.id});}toast(t("A60 / B40 示例预约已填写并模拟确认。"));break;}
 case 'start-order':{const o=currentOrder();if(['running','completed','awaiting_verification','accepted','settled'].includes(o.status)){nav('execution');break;}if(o.status==='draft')await command('order.confirm',{orderId:o.id});await command('order.start',{orderId:o.id});nav('execution');toast(t("订单已开始执行。"));break;}
 case 'advance-dialog':advanceDialog(id);break;
 case 'fault-dialog':faultDialog(id);break;
 case 'reassign-dialog':reassignDialog(id);break;
 case 'evidence-dialog':evidenceDialog(id);break;
 case 'batch-detail':batchDialog(id);break;
 case 'reject-batch':modal(t("拒绝此批次"),`<form data-form="batch-reject"><input type="hidden" name="batchId" value="${h(id)}">${field(t("不符合项与补证要求"),'note','',{minlength:10,help:t("至少 10 个字符。拒绝记录保留，数量释放后可重新提交。")})}${formFooter(t("拒绝并保留记录"),'alert')}</form>`);break;
 case 'accept-batch':await command('batch.accept',{orderId:currentOrder().id,batchId:id,note:'已审阅指定版本的全部测试向量'});closeModal();toast(t("批次已验收，审阅人已记录。"));break;
 case 'accept-all':{const list=allBatches(currentOrder()).filter(canReviewBatch).map(b=>b.id);for(const batchId of list)await command('batch.accept',{orderId:currentOrder().id,batchId,note:'已逐向量核对本批次，审阅仅限所提交的数字测试证据。'});toast(t("{p0} 个批次已验收。",{p0:(list.length)}));break;}
 case 'accept-order':await command('order.accept',{orderId:currentOrder().id});toast(t("订单验收完成。"));break;
 case 'settle-dialog':modal(t("确认内部账本分账"),`${notice(t("此操作只写入内部账本，不发送代币、不产生链上付款凭证。"),'amber')}<p>${t("订单 ")}<strong>${h(currentOrder().id)}</strong>${t("，示例总额 ")}<strong>${metricValue(money(currentOrder().budgetCents),"USDT")}</strong>${t("。按订单固定费用与已验收数量分配，操作具有幂等保护。")}</p>`,button(t("确认写入内部账本"),'settle-confirm',{ico:'wallet'}));break;
 case 'settle-confirm':await command('order.settle',{orderId:currentOrder().id});closeModal();toast(t("已完成内部账本分账，未发送真实资金。"));break;
 case 'factory-template-library':templates.openLibrary();break;
 case 'factory-template-publish':templates.openPublication();break;
 case 'spec-save':{const c=draftCircuit();await command('spec.update',{specId:currentSpec().id,expression:c.expression,variables:c.variables,netlistHex:c.netlistHex});ui.draft=null;render();toast(t("已保存规格新版本；历史订单快照保持不变。"));break;}
 case 'spec-new':modal(t("另存为新规格"),`<form data-form="spec-new">${field(t("规格名称"),'name',t('新的数字控制规格'))}<label class="form-field"><span>${t("说明")}</span><textarea name="description">${h(displayText(currentSpec(),'description'))}</textarea></label><label class="form-field"><span>${t("逻辑表达式")}</span><textarea name="expression">${h(ui.draft?.expression??currentSpec().expression)}</textarea></label>${formFooter(t("创建规格"),'plus')}</form>`);break;
 case 'spec-publish':await command('spec.publish',{specId:currentSpec().id});toast(t("当前版本已登记到本地数据库；尚未链上发布。"));break;
 case 'export-netlist':{const c=draftCircuit();download(`TwinCircuit-${currentSpec()?.id||'spec'}-v${currentSpec()?.version||1}.json`,JSON.stringify({format:'twincircuit-circuit/1',profile:currentSpec()?.profile||'TC-IO/0.1',name:currentSpec()?.name,circuit:c,verification:engine.verify(c),source:'local-compilation',chainDeployment:null},null,2));break;}
 case 'export-truth':download('truth-table.csv',engine.truthCSV(draftCircuit()),'text/csv;charset=utf-8');break;
 case 'export-firmware':if(currentSpec()?.profile==='TC-PANEL/0.1')throw new Error(t("显示规格不能使用通用 GPIO 实验固件；请到设备页使用已编译的 panel 专用固件。"));download('TwinCircuit.ino',engine.firmware(draftCircuit()),'text/plain');break;
 case 'export-st':download('TwinCircuit.st',engine.exportST(draftCircuit()),'text/plain');break;
 case 'import-spec':fileInput(async text=>{const obj=JSON.parse(text),c=obj.circuit||obj;const expr=c.expression;if(typeof expr!=='string')throw new Error(t("导入包需要包含可验证的 expression。"));engine.compileExpression(expr,{variables:['C','M','E']});ui.draft={expression:expr};closeModal();nav('specifications');toast(t("表达式已载入，保存前可检查真值表。"));});break;
 case 'export-order':await serverDownload('report',currentOrder()?.id);break;
 case 'export-workspace':await serverDownload('json');break;
 case 'export-csv':await serverDownload('csv',currentOrder()?.id);break;
 case 'audit-dialog':showAudit();break;
 case 'report-dialog':reportDialog();break;
 case 'order-switch':modal(t("选择需求订单"),`<div class="workspace-list">${data.orders.map(o=>`<button class="workspace-option" data-action="order-select" data-id="${h(o.id)}"><strong>${h(o.id)} · ${h(displayText(o))}</strong>${badge(t(statusNames[o.status]||o.status),'green')}</button>`).join('')}</div>`,button(t("创建新订单"),'order-new',{ico:'plus',off:!canWrite()}));break;
 case 'order-select':chooseOrder(id);closeModal();break;
 case 'tools-tab':ui.toolsTab=el.dataset.tab;if(ui.toolsTab==='industrial')await industrial.load();render();break;
 case 'industrial-view':industrial.selectView(el.dataset.view);render();break;
 case 'industrial-reload':await industrial.load();render();break;
 case 'industrial-export':industrial.exportSnapshot();break;
 case 'industrial-chain':chainDialog(industrialChainTarget(el.dataset.profile));break;
 case 'industrial-withdraw-pledge':await industrial.withdrawPledge(id);render();break;
 case 'industrial-withdraw-commit':await industrial.withdrawCommit(id,el.dataset.kind);render();break;
 case 'industrial-first-create':case 'industrial-first-pledge':case 'industrial-first-commit':
 case 'industrial-acceptance-spec':case 'industrial-acceptance-submit':
 case 'industrial-evidence-detail':case 'industrial-evidence-review':
 case 'industrial-license-grant':case 'industrial-license-use':case 'industrial-license-revoke':industrial.open(action,id);break;
 case 'integration-check':{const s=await api('/api/integrations');$('#integration-status').innerHTML=`${badge(s.ai?.configured?t("模型已配置"):t("未配置模型：规则匹配模式"),s.ai?.configured?'green':'amber')}<p>${t("模型：{p0}",{p0:(h(s.ai?.model||t("未设置")))})}<br>${t("链 ID：{p0}",{p0:(s.chain?.chainId||196)})}</p>`;break;}
 case 'chain-dialog':chainDialog();break;
 case 'wallet-connect':{const r=await chain.connectWallet();ui.wallet=r.address;ui.walletChain=r.chainId;chainDialog(ui.chainTarget);toast(r.chainId===196?t("钱包已连接到 X Layer；尚未发起交易。"):t("钱包已连接，但不在 X Layer；发布前请点击切换网络。"),r.chainId===196?'success':'warning');break;}
 case 'wallet-switch':await chain.switchToXLayer();ui.walletChain=196;chainDialog(ui.chainTarget);toast(t("钱包已切换到 X Layer；未发送交易。"));break;
 case 'chain-reference':{const r=await chainResult(()=>chain.checkReferenceNand({rpc:chainRPC}),{workspaceId:data.workspace.id,source:'public-nand-reference'});toast(r.ok?t("已有公开 NAND 参考 4/4 一致；未核对当前规格。"):t("公开参考存在不一致，请查看原始证据。"),r.ok?'success':'error');break;}
 case 'chain-export':download('twincircuit-chain-evidence.json',JSON.stringify({format:'twincircuit-chain-evidence/1',report:ui.chainReport,publication:ui.publicationReport,exportedAt:new Date().toISOString(),scope:'single-configured-rpc-session-evidence'},null,2));break;
 case 'account-dialog':accountDialog();break;
 case 'workspace-dialog':workspaceDialog();break;
 case 'workspace-select':ops.clear();industrial.clear();await command('workspace.select',{workspaceId:id});ui.draft=null;ui.chainReport=null;ui.publicationReport=null;ui.chainTarget=null;closeModal();if(ui.page==='tools'&&ui.toolsTab==='industrial')await industrial.load();render();break;
 case 'workspace-new':modal(t("创建新工作区"),`<form data-form="workspace"><div class="form-grid">${field(t("工作区名称"),'name',t('新工业协作工作区'))}<p class="field-help">${t("新工作区从虚拟样例开始；可单独登记外部供应商并提交独立证据。内部账本始终是示意。")}</p></div>${formFooter(t("创建工作区"),'plus')}</form>`);break;
 case 'invite-dialog':modal(t("邀请工作区成员"),`<form data-form="invite">${field(t("成员邮箱"),'email','',{type:'email'})}<label class="form-field"><span>${t("角色")}</span><select name="role"><option value="operator">${t("操作者：预约与执行")}</option><option value="verifier">${t("验证者：审阅与验收")}</option><option value="viewer">${t("只读：查看与导出")}</option><option value="owner">${t("共同所有者：管理与独立批准关键控制")}</option></select></label>${formFooter(t("生成一次性邀请"),'mail')}</form>`);break;
 case 'password-dialog':modal(t("修改密码"),`<form data-form="password">${field(t("当前密码"),'currentPassword','',{type:'password'})}${field(t("新密码"),'newPassword','',{type:'password',help:t("至少 12 个字符。")})}${formFooter(t("修改密码"),'lock')}</form>`);break;
 case 'logout':ops.clear();industrial.clear();stopSimulation();clearAuthDrafts();await api('/api/auth/logout',{method:'POST',body:{}});data=null;ui.draft=null;ui.chainReport=null;ui.publicationReport=null;ui.chainTarget=null;ui.wallet=null;ui.walletChain=null;closeModal();await loadSession();renderAuth();break;
 case 'reset-dialog':modal(t("重置演示工作区"),`<form data-form="reset">${notice(t("会删除当前演示工作区的订单、轨迹与内部账本，再载入初始示例。请先导出需要保留的数据。"),'amber')}${field(t("输入 RESET DEMO 确认"),'confirmation')}${formFooter(t("重置演示数据"),'refresh')}</form>`);break;
 case 'import-workspace':fileInput(async text=>{const obj=JSON.parse(text);modal(t("确认导入工作区"),`<p>${t("仅接受未执行草稿模板，将替换供应商、规格和草稿订单。履约、验收与账本不能导入；原审计历史保留。成员和账号不随数据导入。请先导出备份。")}</p><p>${t("规格 {p0} 条，订单 {p1} 条。",{p0:((obj.state||obj).specs?.length||0),p1:((obj.state||obj).orders?.length||0)})}</p>`,button(t("校验并导入"),'confirm-import',{ico:'upload'}));ui.pendingImport=obj.state||obj;});break;
 case 'confirm-import':await command('workspace.import',{data:ui.pendingImport});ui.pendingImport=null;ui.draft=null;closeModal();render();toast(t("已通过服务器校验并导入。"));break;
 case 'copy-api':await navigator.clipboard.writeText(JSON.stringify({type:'reservation.create',payload:{orderId:currentOrder().id,supplierId:'supplier_a',quantity:60},expectedRevision:data.revision,requestId:crypto.randomUUID()},null,2));toast(t("请求示例已复制。"));break;
 case 'serial-connect':await connectSerial();break;
 }
 }catch(error){toast(errorMessage(error),'error');if(el.isConnected)el.disabled=false;}
});
document.addEventListener('submit',async event=>{
 const form=event.target.closest('form[data-form]');if(!form)return;event.preventDefault();const values=Object.fromEntries(new FormData(form)),kind=form.dataset.form;const submit=$('button[type=submit]',form),errorNode=$('.form-error',form);if(submit)submit.disabled=true;if(errorNode)errorNode.textContent='';
 try{
 switch(kind){
 case 'auth-login':
 case 'auth-setup':
 case 'auth-signup': {
   const path = kind.slice('auth-'.length);
   await api(`/api/auth/${path}`, {method:'POST', body:values});
   await loadSession();
   await refresh();
   clearAuthDrafts();
   render();
   break;
 }
 case 'auth-join':{try{await api('/api/auth/register',{method:'POST',body:values});await loadSession();await refresh();}catch(e){if(e.status!==409)throw e;await api('/api/auth/login',{method:'POST',body:{email:values.email,password:values.password}});await loadSession();await refresh();await command('member.join',{token:values.token});}clearAuthDrafts();render();}break;
 case 'batch-reject':await command('batch.reject',{orderId:currentOrder().id,batchId:values.batchId,note:values.note});closeModal();toast(t("批次已退回，原证据保留，可提交更正证据。"));break;
 case 'search':ui.search=values.query;render();break;
 case 'supplier':{
   const supplier=supplierById(form.dataset.id);
   if(supplier){
     // Preserve the stored language when a user changes only capacity or status.
     for(const key of ['name','description'])if(values[key]===displayText(supplier,key))delete values[key];
   }
   await command(form.dataset.id?'supplier.update':'supplier.create',{...values,capacity:Number(values.capacity),...(form.dataset.id?{supplierId:form.dataset.id}:{})});closeModal();toast(t("供应商能力已保存。"));break;
 }
 case 'order':{const previous=new Set(data.orders.map(o=>o.id));await command('order.create',{name:values.name,quantity:Number(values.quantity),budgetCents:Math.round(Number(values.budget)*100),specId:values.specId});const added=data.orders.find(o=>!previous.has(o.id));if(added)ui.orderId=added.id;closeModal();nav('reservations');toast(t("订单已创建，验收规格快照已固定。"));break;}
 case 'provider-confirm':await command('reservation.confirm',{orderId:currentOrder().id,reservationId:values.reservationId,confirmationRef:values.confirmationRef});closeModal();toast(t("外部供应商确认依据已记录。"));break;
 case 'reserve':await command('reservation.create',{orderId:currentOrder().id,supplierId:values.supplierId,quantity:Number(values.quantity)});closeModal();toast(t("预约已创建，等待供应商确认。"));break;
 case 'advance':await command('execution.advance',{orderId:currentOrder().id,reservationId:values.reservationId,count:Number(values.count)});closeModal();toast(t("虚拟批次已完成，测试证据已保存，等待独立验收。"));break;
 case 'fault':await command('order.fault',{orderId:currentOrder().id,reservationId:values.reservationId,reason:values.reason,cancelRemaining:true});closeModal();toast(t("故障与取消额度已记录。"));break;
 case 'reassign':await command('reservation.reassign',{orderId:currentOrder().id,reservationId:values.reservationId,supplierId:values.supplierId,quantity:Number(values.quantity)});closeModal();toast(t("新预约已创建，请由供应商重新确认。"));break;
 case 'evidence':{const evidence=JSON.parse(values.evidence);await command('evidence.submit',{orderId:currentOrder().id,reservationId:values.reservationId,records:evidence.records,sourceNote:evidence.sourceNote||evidence.note||evidence.reference||''});closeModal();toast(t("外部证据已提交，等待独立审阅。"));break;}
 case 'spec-new':{engine.compileExpression(values.expression,{variables:['C','M','E']});const prev=new Set(data.specs.map(s=>s.id));await command('spec.create',{...values,variables:['C','M','E']});ui.specId=data.specs.find(s=>!prev.has(s.id))?.id||ui.specId;ui.draft=null;closeModal();render();break;}
 case 'assist':{const result=await api('/api/assist',{method:'POST',body:{prompt:values.prompt,variables:['C','M','E']}});if(!result.supported||!result.expression)throw new Error(t(result.message)||t("该需求超出支持范围，请直接编辑表达式。"));engine.compileExpression(result.expression,{variables:['C','M','E']});ui.draft={expression:result.expression};render();toast(result.mode==='model'?t("已生成模型候选，请审阅真值表后保存。"):t("已使用确定性规则匹配，请审阅后保存。"));break;}
 case 'chain-read':{const r=await chainResult(()=>readChainTarget(values));toast(r.ok?t("{p0}/{p1} 组目标输入与本地网表一致；业务范围按版本与网表匹配。",{p0:(r.passed),p1:(r.total)}):t("目标电路存在不一致，请检查原始结果。"),r.ok?'success':'error');break;}
 case 'chain-publish':await publishChainTarget(values.address);break;
 case 'invite':{const next=await command('member.invite',values);const inv=next.invitation;const token=inv?.token;closeModal();modal(t("邀请已创建"),`<p>${t("请将一次性令牌交给受邀成员。没有发送电子邮件。")}</p><pre class="code-block">${h(token||t("令牌仅在首次响应显示；请重新创建邀请"))}</pre><p class="field-help">${t("受邀邮箱：{p0} · 角色：{p1}",{p0:(h(values.email)),p1:(roleName(values.role))})}</p>`);break;}
 case 'password':await api('/api/auth/password',{method:'POST',body:values});closeModal();toast(t("密码已修改。"));break;
 case 'workspace':await command('workspace.create',values);ui.draft=null;closeModal();render();break;
 case 'reset':if(values.confirmation!=='RESET DEMO')throw new Error(t("请输入大写 RESET DEMO 确认。"));await command('workspace.reset',{confirmation:'RESET DEMO'});ui.draft=null;ui.chainReport=null;closeModal();render();toast(t("演示已重置。"));break;
 default:if(kind.startsWith('industrial-')&&await industrial.submit(kind,values))render();break;
 }
 }catch(e){if(errorNode&&errorNode.isConnected)errorNode.textContent=errorMessage(e);else toast(errorMessage(e),'error');}
 finally{if(submit?.isConnected)submit.disabled=false;}
});
function fileInput(callback){const input=document.createElement('input');input.type='file';input.accept='.json,application/json';input.onchange=async()=>{try{const file=input.files[0];if(!file)return;if(file.size>1048576)throw new Error(t("导入文件不能超过 1 MB。"));await callback(await file.text());}catch(e){toast(errorMessage(e),'error');}};input.click();}
document.addEventListener('change',event=>{if(event.target.id==='order-selector')chooseOrder(event.target.value);if(event.target.id==='spec-selector'){ui.specId=event.target.value;ui.draft=null;render();}});
document.addEventListener('input',event=>{if(event.target.id==='expression-input')updateSpecLive(true);});
document.addEventListener('keydown',event=>{if(event.key==='Escape')closeModal();if(event.key==='Tab'&&$('.dialog')){const focusable=$$('button:not(:disabled),input,textarea,select,a[href]', $('.dialog')).filter(e=>e.getClientRects().length);if(!focusable.length)return;const first=focusable[0],last=focusable.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}});
document.addEventListener('click',event=>{if(event.target.classList.contains('dialog-backdrop'))closeModal();});
window.addEventListener('hashchange',()=>{const next=location.hash.slice(1);if(pages.some(p=>p[0]===next)&&next!==ui.page){stopSimulation();ui.page=next;render();}});
window.addEventListener('twincircuit:beforelanguagechange',beforeLanguageChange);
window.addEventListener('twincircuit:languagechange',handleLanguageChange);

let serialBusy=false;
async function connectSerial(){
 if(serialBusy)throw new Error(t("正在检测已选择的串口，请等待本轮回执。"));
 serialBusy=true;const status=()=>$('#serial-status');
 try{
  const result=await testSerialCircuit(draftCircuit(),{onProgress:r=>{if(status())status().textContent=t("已回传 {p0} / {p1} 组，{p2} 组一致。正在等待设备…",{p0:(r.completed),p1:(r.total),p2:(r.passed)});}});
  ui.serialReport=result;
  if(status())status().textContent=result.ok?t("{p0} / {p1} 组输入与输出全部匹配。端口已关闭；这只证明本次串口回传一致，尚未提交为订单证据。",{p0:(result.passed),p1:(result.total)}):t("{p0} / {p1} 组通过，存在输入或输出不一致。端口已关闭。",{p0:(result.passed),p1:(result.total)});
  toast(result.ok?t("设备测试向量已逐组核对。"):t("设备测试未全部通过。"),result.ok?'success':'error');
 }finally{serialBusy=false;}
}

try{await loadSession();if(session.user){await refresh();render();}else renderAuth(initialAuthTab());}catch(error){$('#app').innerHTML=`<main class="error-screen"><h1>${t("暂时无法连接工作区")}</h1><p>${h(errorMessage(error))}</p><button class="btn-primary" data-action="reload">${t("重新连接")}</button></main>`;}



