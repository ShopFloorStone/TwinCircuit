import { requireCondition } from './config.mjs';

// A binding pins a physical boot and its starting counter; the server still sees
// the unmodified local journal revisions, beginning at zero for this registration.
export function panelRevisionMatches(hardware, gatewayRevision, binding) {
  if (!hardware || !Number.isSafeInteger(gatewayRevision) || gatewayRevision < 0) return false;
  if (binding && hardware.bootId !== binding.bootId) return false;
  const expected = gatewayRevision + (binding?.hardwareBaseRevision ?? 0);
  return expected < 0xffffffff && hardware.hardwareRevision === expected;
}

const integer = (v, max = 0xffffffff) => Number.isSafeInteger(v) && v >= 0 && v <= max;
function object(json, limit = 2400) {
  requireCondition(typeof json === 'string' && Buffer.byteLength(json) <= limit, 'Oversized panel response');
  const value = JSON.parse(json);
  requireCondition(value && typeof value === 'object' && !Array.isArray(value) && Object.keys(value).length <= 40, 'Invalid panel response');
  return value;
}
export function panelColor(pixel, x, y) {
  requireCondition(pixel && pixel.x === x && pixel.y === y && Array.isArray(pixel.rawRGB) && pixel.rawRGB.length === 3 && pixel.rawRGB.every(v => integer(v, 255)) && integer(pixel.actualColor, 0xffffff), 'Invalid measured panel pixel');
  // RAMRD returns six significant bits per channel in the upper bits. Expand
  // those measured bytes, without substituting the requested or expected color.
  const rgb = pixel.rawRGB.map(v => (v & 0xfc) | ((v & 0xfc) >>> 6));
  const color = (rgb[0] << 16) | (rgb[1] << 8) | rgb[2];
  requireCondition(color === pixel.actualColor, 'Panel color differs from raw GRAM bytes');
  requireCondition(pixel.rgb565 === undefined || integer(pixel.rgb565, 0xffff), 'Invalid measured RGB565');
  return color;
}
export function parsePanelState(json, state) {
  const p = object(json);
  requireCondition(p.enabled === true && p.capability === 'tft-panel' && p.panelOnly === true && p.gpioOutputsEnabled === false && p.signal === 'panel_vector' && typeof p.ready === 'boolean', 'Dedicated panel-only firmware capability is required');
  requireCondition(p.bootId === state.bootId && p.hardwareRevision === state.hardwareRevision && integer(p.tickMs), 'Panel capability boot or revision differs from HELLO');
  requireCondition(p.pixel?.x === 260 && p.pixel?.y === 116 && p.falseColor === 0 && p.trueColor === 0xffffff && p.pixelFormat === 'RGB888' && p.readback === 'ILI9341_GRAM_RGB888', 'Unsupported panel measurement configuration');
  if (p.ready) requireCondition(panelColor(p.references?.white, 20, 200) === 0xffffff && panelColor(p.references?.black, 44, 200) === 0, 'Panel readiness requires both live reference measurements');
  return p;
}
export function parsePanelResult(json, state, vectorIndex) {
  const p = object(json);
  requireCondition(['OK', 'FAILED', 'UNCERTAIN'].includes(p.status) && integer(p.hardwareRevision) && integer(p.tickMs), 'Invalid panel result status or revision');
  if (p.status !== 'OK') return p;
  requireCondition(p.hardwareRevision === state.hardwareRevision + 1 && p.profile === 'TC-PANEL/0.1' && p.quality === 'DISPLAY_PIXEL_READBACK' && p.scope === 'controller-GRAM-only' && p.ok === true && p.error === null, 'Panel result requires confirmed GRAM measurement');
  requireCondition(p.visibleVerified === undefined || p.visibleVerified === false, 'GRAM readback cannot verify physical visibility');
  const inputs = { C: Boolean(vectorIndex & 4), M: Boolean(vectorIndex & 2), E: Boolean(vectorIndex & 1) };
  requireCondition(p.vectorIndex === vectorIndex && p.inputs && Object.keys(p.inputs).sort().join() === 'C,E,M' && Object.keys(inputs).every(k => p.inputs[k] === inputs[k]) && typeof p.actualY === 'boolean', 'Panel vector echo mismatch');
  requireCondition(p.readRegister === '0x2E' && p.readRegisterHz === 1000000 && p.rotation === 1 && integer(p.sampledAtTickMs), 'Unsupported GRAM sampling source');
  requireCondition(p.pixel?.format === 'RGB888' && panelColor(p.references?.white, 20, 200) === 0xffffff && panelColor(p.references?.black, 44, 200) === 0, 'Panel reference calibration failed');
  const color = panelColor(p.pixel, 260, 116);
  requireCondition((color === 0 || color === 0xffffff) && p.actualY === (color === 0xffffff), 'Panel actualY must match measured black or white GRAM');
  return p;
}
