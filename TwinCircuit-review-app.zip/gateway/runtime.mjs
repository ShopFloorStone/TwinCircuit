import { GatewayQueueClient } from '../lib/device-client.mjs';
import { validateJob, requireCondition, expiryMs, jobIdentity } from './config.mjs';
import { SerialAdapter } from './serial.mjs';
import { panelRevisionMatches } from './panel.mjs';
import { ModbusTCPAdapter } from './modbus.mjs';
import { MQTTAdapter } from './mqtt.mjs';
import { OPCUAAdapter } from './opcua.mjs';
export function createAdapter(device, options = {}) { const Type = { serial: SerialAdapter, 'modbus-tcp': ModbusTCPAdapter, mqtt: MQTTAdapter, opcua: OPCUAAdapter }[device.protocol]; requireCondition(Type, 'Unsupported adapter'); return new Type(device, options); }
export class EdgeGateway {
  constructor({ config, journal, env = process.env, dataDir = './data', adapterFactory = createAdapter, clientFactory = opts => new GatewayQueueClient(opts), log = () => {} }) {
    this.config = config; this.journal = journal; this.log = log; this.adapters = new Map(); this.clients = new Map(); this.stopped = false;
    for (const device of config.devices.filter(d => d.enabled)) { journal.register(device); this.adapters.set(device.deviceId, adapterFactory(device, { env, dataDir, onDisconnect: reason => journal.connection(device.deviceId, false, reason) })); this.clients.set(device.deviceId, clientFactory({ baseURL: config.serverUrl, token: env[device.tokenEnv], deviceId: device.deviceId, agentId: config.agentId })); }
  }
  async connection(device) { const adapter = this.adapters.get(device.deviceId); try { await adapter.connect(); const hardware = await adapter.probe(); this.journal.connection(device.deviceId, true); return hardware; } catch (e) { this.journal.connection(device.deviceId, false, e.message); return null; } }
  async processJob(device, job) {
    const previous = this.journal.prior(job); if (previous) return previous;
    const adapter = this.adapters.get(device.deviceId); let revision, intent = false; const startedAt = new Date().toISOString();
    try {
      validateJob(job, device); const state = this.journal.state(device.deviceId);
      requireCondition(!state.blocked && state.armedUntil && state.writesLeft > 0 && state.revision === job.revision, 'Local arm, write budget and revision must match');
      const binding = device.capability === 'tft-panel' ? this.journal.panelBinding(device.deviceId) : null;
      await adapter.connect(); await adapter.preflight(job, binding);
      revision = this.journal.begin(device.deviceId, job); intent = true;
      const evidence = await adapter.write(job.payload.signal, job.payload.value, job, binding);
      return this.journal.finish(device.deviceId, job, { jobId: job.id, nonce: job.nonce, status: 'succeeded', result: { executed: true, revision, signal: job.payload.signal, requestedValue: job.payload.value, startedAt, finishedAt: new Date().toISOString(), evidence } });
    } catch (e) {
      if (!intent) { if (e.code === 'HARDWARE_BLOCKED') this.journal.block(device.deviceId, e.message); return this.journal.reject(device.deviceId, job, e.message); }
      const status = e.definitiveNotExecuted ? 'failed' : 'uncertain';
      this.journal.disarm(device.deviceId, 'Output attempt ended without confirmed matching readback');
      return this.journal.finish(device.deviceId, job, { jobId: job.id, nonce: job.nonce, status, error: String(e.message).slice(0, 1000), result: { executed: true, revision, signal: job.payload.signal, requestedValue: job.payload.value, startedAt, finishedAt: new Date().toISOString(), evidence: { protocol: device.protocol, source: 'gateway-output-attempt', quality: 'unconfirmed', physicalExecutionConfirmed: false, sourceTimestamp: null, receivedAt: new Date().toISOString(), scope: 'An output attempt is not proof that a machine or load moved' } } });
    }
  }
  async flush(device) { const client = this.clients.get(device.deviceId); for (const result of this.journal.pending(device.deviceId)) { const ack = await client.report(result); requireCondition(ack?.ok === true, 'Server did not acknowledge result'); this.journal.acknowledge(result.jobId); } }
  async runOnce(device) {
    await this.flush(device); const hardware = await this.connection(device), local = this.journal.state(device.deviceId);
    const panel = device.capability === 'tft-panel';
    const binding = panel ? this.journal.panelBinding(device.deviceId) : null;
    const aligned = panel && panelRevisionMatches(hardware, local.revision, binding);
    const physicalReady = device.protocol !== 'serial' || (panel ? aligned && hardware?.panelReady === true && !hardware?.blocked : hardware?.armed && hardware?.permit && !hardware?.blocked);
    const ready = Boolean(device.outputsEnabled && hardware && !local.blocked && local.armedUntil && local.writesLeft > 0 && physicalReady);
    let job = this.journal.held(device.deviceId);
    if (job && this.journal.prior(job)) { this.journal.clearHeld(device.deviceId); job = null; }
    // A persisted delivery is not continuing permission. Recheck token, owner arm and
    // approval immediately before every attempt, including after an edge restart.
    const pulled = await this.clients.get(device.deviceId).pull({ ...local, armedUntil: local.armedUntil && device.outputsEnabled ? Date.parse(local.armedUntil) : 0, ready, outputsEnabled: device.outputsEnabled, physicalArmed: device.protocol === 'serial' ? Boolean(hardware?.armed) : null, physicalPermit: device.protocol === 'serial' ? Boolean(hardware?.permit) : null, ...(panel ? { panelReady: Boolean(physicalReady), panelCapabilities: hardware?.panelCapabilities ?? null, panelBinding: binding } : {}), ...(hardware?.display ? { display: hardware.display } : {}) });
    if (pulled.reconciliationRequired || pulled.device?.status === 'uncertain') { this.journal.block(device.deviceId, 'Server requires manual reconciliation; preserve and compare both journal revisions'); return { blocked: true }; }
    if (pulled.job) { if (job) requireCondition(JSON.stringify(jobIdentity(job)) === JSON.stringify(jobIdentity(pulled.job)), 'Server changed an outstanding job'); job = pulled.job; this.journal.hold(device.deviceId, job); }
    if (!job) return null;
    if ((!ready || !pulled.job) && expiryMs(job.expiresAt) > Date.now()) return { held: true, jobId: job.id, reason: 'Waiting for fresh server/local/physical permission; no output attempted' };
    const result = await this.processJob(device, job); this.journal.clearHeld(device.deviceId); await this.flush(device); return result;
  }
  async run(signal) { while (!this.stopped && !signal?.aborted) { for (const device of this.config.devices.filter(d => d.enabled)) { if (this.stopped || signal?.aborted) break; try { await this.runOnce(device); } catch (e) { if ([401, 403].includes(e.status)) { this.stopped = true; for (const d of this.config.devices.filter(d => d.enabled)) this.journal.disarm(d.deviceId, 'Server token rejected; gateway stopped'); } this.log({ deviceId: device.deviceId, event: 'gateway-error', code: e.code ?? e.status ?? 'CONNECTION', message: e.message }); } } if (!this.stopped && !signal?.aborted) await new Promise(resolve => setTimeout(resolve, this.config.pollIntervalMs)); } }
  async close() { this.stopped = true; for (const adapter of this.adapters.values()) await adapter.close().catch(() => {}); }
}
