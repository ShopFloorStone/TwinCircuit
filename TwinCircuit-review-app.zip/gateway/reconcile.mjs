import { requireCondition } from './config.mjs';

export async function bindPanelHardware({ device, adapter, journal, expectedBootId, expectedRevision, acknowledgePanelOnly, confirm }) {
  requireCondition(acknowledgePanelOnly === true && confirm === 'BIND', 'First binding requires --acknowledge-panel-only and --confirm BIND');
  requireCondition(typeof expectedBootId === 'string' && /^[0-9a-f]{32}$/.test(expectedBootId) && Number.isSafeInteger(expectedRevision) && expectedRevision >= 0 && expectedRevision < 0xffffffff, 'Explicit current --expected-boot and --expected-revision are required');
  journal.assertCanBindPanel(device);
  await adapter.connect();
  const hardware = await adapter.probe();
  requireCondition(hardware.bootId === expectedBootId && hardware.hardwareRevision === expectedRevision, 'Live boot ID and hardware revision must match the observed TFT');
  requireCondition(hardware.panelReady === true && !hardware.blocked && !hardware.armed && !hardware.permit && hardware.panelCapabilities?.panelOnly === true && hardware.panelCapabilities.gpioOutputsEnabled === false, 'Binding requires an unblocked calibrated TFT panel-only workcell with GPIO inactive');
  return journal.bindPanel(device, hardware.bootId, hardware.hardwareRevision);
}

export async function reconcilePanelHardware({ device, adapter, journal, expectedBootId, expectedRevision, reason, acknowledgePanelOnly, confirm }) {
  requireCondition(device.protocol === 'serial' && device.capability === 'tft-panel', 'Select a dedicated TFT panel-only device');
  requireCondition(acknowledgePanelOnly === true && confirm === 'RECONCILE', 'Panel hardware recovery requires --acknowledge-panel-only and --confirm RECONCILE');
  requireCondition(typeof expectedBootId === 'string' && /^[0-9a-f]{32}$/.test(expectedBootId) && Number.isSafeInteger(expectedRevision) && expectedRevision >= 0 && expectedRevision <= 0xffffffff, 'Explicit --expected-boot and --expected-revision are required');
  requireCondition(typeof reason === 'string' && reason.trim().length >= 10 && reason.length <= 1000, 'A specific manual reconciliation reason is required');
  journal.assertRecoveryAllowed(device.deviceId);
  journal.disarm(device.deviceId, 'Manual panel hardware reconciliation; no automatic re-arm');
  const detail = { expectedBootId, expectedHardwareRevision: expectedRevision, reason: reason.trim() };
  journal.audit(device.deviceId, 'panel-hardware-reconciliation-requested', detail);
  let attempted = false;
  try {
    await adapter.connect(); attempted = true;
    const response = await adapter.reconcilePanel(expectedBootId, expectedRevision);
    journal.audit(device.deviceId, 'panel-hardware-reconciliation-confirmed', { ...detail, response });
    return { ...response, localRevision: journal.state(device.deviceId).revision, localArm: false, localJournalReconciliationRequired: journal.state(device.deviceId).blocked, serverOwnerReconciliationIsSeparate: true };
  } catch (error) {
    journal.audit(device.deviceId, 'panel-hardware-reconciliation-failed', { ...detail, error: String(error.message).slice(0, 500) });
    if (attempted) journal.block(device.deviceId, 'Panel hardware recovery was not confirmed; inspect device and audit before another manual command');
    throw error;
  }
}
