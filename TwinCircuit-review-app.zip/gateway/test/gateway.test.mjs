import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import http from 'node:http';
import { GatewayJournal } from '../journal.mjs';
import { EdgeGateway } from '../runtime.mjs';
import { ModbusTCPAdapter } from '../modbus.mjs';
import { validateConfig, validateJob } from '../config.mjs';
import { config, job, modbusFixture, listen, stop } from './helpers.mjs';

test('real TCP writes, correlated HTTP result ACK loss and redelivery never repeat a consumed output', async t => {
  const fixture = await modbusFixture(); t.after(() => fixture.close()); const cfg = config({ port: fixture.port }), d = cfg.devices[0], journal = new GatewayJournal(':memory:'); t.after(() => journal.close());
  const pending = job(), reports = []; let dropAck = true, authorized = true;
  const server = http.createServer(async (req, res) => { assert.equal(req.headers.authorization, 'Bearer tc_device_' + 'x'.repeat(43)); let input = ''; for await (const chunk of req) input += chunk; const body = JSON.parse(input); assert.equal(body.deviceId, d.deviceId); if (req.url === '/api/gateway/pull') { assert.equal(typeof body.state.armedUntil, 'number'); res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify({ device: { status: 'registered' }, job: authorized && reports.length === 0 ? pending : null })); } else { reports.push(body); if (dropAck) { dropAck = false; req.socket.destroy(); } else { res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify({ ok: true, replayed: true })); } } });
  const port = await listen(server); t.after(() => stop(server)); cfg.serverUrl = `http://127.0.0.1:${port}`;
  const gateway = new EdgeGateway({ config: cfg, journal, env: { TC_TOKEN: 'tc_device_' + 'x'.repeat(43) } }); t.after(() => gateway.close()); journal.arm(d.deviceId, 60);
  await assert.rejects(gateway.runOnce(d), /fetch failed|socket|terminated/i); assert.equal(fixture.state.writes, 1); assert.equal(journal.pending(d.deviceId).length, 1);
  await gateway.runOnce(d); assert.equal(reports.length, 2); assert.deepEqual(reports[0], reports[1]); assert.equal(fixture.state.writes, 1); assert.equal(journal.pending(d.deviceId).length, 0);
  assert.equal(reports[1].result.evidence.readback, true); assert.equal(reports[1].result.evidence.sourceTimestamp, null);
  // Mutable delivery metadata does not change immutable execution identity.
  assert.deepEqual(await gateway.processJob(d, { ...pending, state: 'succeeded', result: reports[1].result }), journal.prior(pending)); assert.equal(fixture.state.writes, 1);
  assert.throws(() => journal.prior({ ...pending, payload: { signal: 'led', value: false } }), /different content/);
  // A locally persisted delivery cannot bypass a later owner disarm/revocation.
  const next = job(1, 'led', false); journal.hold(d.deviceId, next); journal.arm(d.deviceId, 60); authorized = false;
  const held = await gateway.runOnce(d); assert.equal(held.held, true); assert.equal(fixture.state.writes, 1);
});

test('unknown outputs, stale revision, expiry and no local arm cannot touch a real TCP fixture', async t => {
  const fixture = await modbusFixture(); t.after(() => fixture.close()); const cfg = config({ port: fixture.port }), d = cfg.devices[0], journal = new GatewayJournal(':memory:'); t.after(() => journal.close()); const gateway = new EdgeGateway({ config: cfg, journal, clientFactory: () => ({}) }); t.after(() => gateway.close());
  for (const candidate of [job(0, 'not_allowlisted'), { ...job(), expiresAt: Date.now() - 1 }, job(9), job()]) { const result = await gateway.processJob(d, candidate); assert.equal(result.result.executed, false); }
  assert.equal(fixture.state.writes, 0); assert.equal(journal.state(d.deviceId).revision, 0);
  journal.arm(d.deviceId, 60); const ok = await gateway.processJob(d, job()); assert.equal(ok.status, 'succeeded'); assert.equal(fixture.state.writes, 1);
});

test('real TCP device may execute while its ACK is lost: mark uncertain, block and never retry', async t => {
  const fixture = await modbusFixture(); t.after(() => fixture.close()); fixture.state.dropWriteReply = true; const cfg = config({ port: fixture.port }), d = cfg.devices[0], journal = new GatewayJournal(':memory:'); t.after(() => journal.close()); const gateway = new EdgeGateway({ config: cfg, journal, clientFactory: () => ({}) }); t.after(() => gateway.close()); journal.arm(d.deviceId, 60); const candidate = job();
  const result = await gateway.processJob(d, candidate); assert.equal(result.status, 'uncertain'); assert.equal(result.result.executed, true); assert.equal(result.result.revision, 1); assert.equal(fixture.coils.get(4), true); assert.equal(journal.state(d.deviceId).blocked, true);
  assert.deepEqual(await gateway.processJob(d, candidate), result); assert.equal(fixture.state.writes, 1); assert.throws(() => journal.arm(d.deviceId, 60), /Blocked/);
  assert.throws(() => journal.reconcile(d.deviceId, 1, 'Checked fixture physically'), /unacknowledged/); journal.acknowledge(candidate.id);
  assert.throws(() => journal.reconcile(d.deviceId, 0, 'Checked fixture physically'), /conflict/);
  journal.reconcile(d.deviceId, 1, 'Checked fixture and server revision; output LOW'); assert.equal(journal.state(d.deviceId).armedUntil, null);
});

test('crash after persisted intent recovers as uncertain without sending a second output', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'tc-edge-')), path = join(dir, 'journal.sqlite'), d = config().devices[0], candidate = job(); let journal;
  try { journal = new GatewayJournal(path); journal.register(d); journal.arm(d.deviceId, 60); journal.begin(d.deviceId, candidate); journal.close(); journal = new GatewayJournal(path); assert.equal(journal.state(d.deviceId).blocked, true); assert.equal(journal.state(d.deviceId).revision, 1); assert.equal(journal.pending(d.deviceId)[0].status, 'uncertain'); assert.equal(journal.pending(d.deviceId)[0].result.executed, true); assert.equal(journal.state(d.deviceId).armedUntil, null); } finally { journal?.close(); await rm(dir, { recursive: true, force: true }); }
});

test('configuration and job boundaries are explicit, stable and fail closed', () => {
  const cfg = config(), d = cfg.devices[0]; assert.equal(validateConfig(cfg).devices[0].configFingerprint, d.configFingerprint); validateJob(job(), d);
  assert.throws(() => validateJob({ ...job(), payload: { signal: 'led', value: true, address: 99 } }, d), /Only allowlisted/);
  assert.throws(() => validateConfig({ schemaVersion: 1, serverUrl: 'http://unapproved.example', devices: [] }), /HTTP/);
  assert.throws(() => config({ interlocks: [{ signal: 'missing', equals: true }] }), /allowlisted/);
  for (const bounds of [{ min: 0, max: 10, integer: false }, { min: 0.5, max: 10 }]) assert.throws(() => config({ signals: { recipe: { type: 'number', write: true, area: 'holding-register', address: 4, ...bounds } } }), /UInt16/);
  assert.throws(() => config({ signals: { request: { type: 'boolean', write: true, area: 'coil', address: 0, feedbackArea: 'input-register', feedbackAddress: 1 } } }), /Feedback area/);
  assert.throws(() => config({ signals: { request: { type: 'boolean', write: true, area: 'coil', address: 0, feedbackSettleMs: 2001 } } }), /feedbackSettleMs/);
});

test('real Modbus TCP coil command can require separate fixed discrete-input feedback rather than command echo', async t => {
  const fixture = await modbusFixture(); t.after(() => fixture.close());
  const cfg = config({ port: fixture.port, signals: { led: { type: 'boolean', write: true, area: 'coil', address: 4, feedbackArea: 'discrete-input', feedbackAddress: 9 } } });
  const adapter = new ModbusTCPAdapter(cfg.devices[0]); t.after(() => adapter.close()); await adapter.connect();
  await assert.rejects(adapter.write('led', true), /readback did not match/); assert.equal(fixture.coils.get(4), true); assert.equal(fixture.discreteInputs.get(9), undefined);
  fixture.discreteInputs.set(9, true); const measured = await adapter.write('led', true);
  assert.equal(measured.readback, true); assert.deepEqual(measured.mapping, { commandArea: 'coil', commandAddress: 4, feedbackArea: 'discrete-input', feedbackAddress: 9, feedbackSettleMs: 0 });
  // A bounded settle delay performs one later read, never a second command.
  fixture.discreteInputs.set(9, false); cfg.devices[0].signals.led.feedbackSettleMs = 50;
  const count = fixture.state.writes, began = Date.now(); setTimeout(() => fixture.discreteInputs.set(9, true), 20);
  const delayed = await adapter.write('led', true); assert(Date.now() - began >= 45); assert.equal(fixture.state.writes, count + 1); assert.equal(delayed.mapping.feedbackSettleMs, 50);
});
