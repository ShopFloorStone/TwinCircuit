import test from 'node:test';
import assert from 'node:assert/strict';
import net from 'node:net';
import http from 'node:http';
import { once } from 'node:events';
import { SerialAdapter, frame, parseFrame, parseDisplayDiagnostics } from '../serial.mjs';
import { EdgeGateway } from '../runtime.mjs';
import { GatewayJournal } from '../journal.mjs';
import { config, listen, stop } from './helpers.mjs';

const diagnostic = () => ({ enabled: true, controller: 'ILI9341', controllerAssumed: true, rawControllerId: '0x00009341', rawControllerIdBytes: [0, 0, 147, 65], controllerIdAvailable: true, width: 320, height: 240, nativeWidth: 240, nativeHeight: 320, rotation: 1, visibleVerified: false, initStatus: 'driver-begin-returned', mode: 'hardware-spi', readRegister: '0xD3', powerMode: 156, spiHz: 10000000, gatewayHelloAgeMs: 2, serialHeartbeatFresh: true, pins: { sck: 12, mosi: 11, miso: 13, cs: 10, dc: 9, rst: 14 }, touchEnabled: false, sdEnabled: false });
const serialConfig = (extra = {}) => config({ protocol: 'serial', path: 'COM7', signals: { led: { type: 'boolean', write: true } }, ...extra });

async function fixture(t, extra = {}) {
  const sockets = new Set(), requests = [], state = { response: diagnostic() };
  const server = net.createServer(socket => {
    sockets.add(socket); socket.on('close', () => sockets.delete(socket)); let buffer = '';
    socket.on('data', chunk => {
      buffer += chunk.toString(); let cut;
      while ((cut = buffer.indexOf('\n')) >= 0) {
        const f = parseFrame(buffer.slice(0, cut)); buffer = buffer.slice(cut + 1); requests.push(f[1]);
        if (f[1] === 'HELLO') socket.write(frame(`TC1|STATE|${f[2]}|${'a'.repeat(32)}|0|1000|1|1|0|0`));
        if (f[1] === 'DISPLAY' && state.response !== null) {
          const json = typeof state.response === 'string' ? state.response : JSON.stringify(state.response), reply = frame(`TC1|DISPLAYSTATE|${f[2]}|${json}`);
          socket.write(reply.slice(0, 11)); setImmediate(() => { if (!socket.destroyed) socket.write(reply.slice(11)); });
        }
      }
    });
  });
  const port = await listen(server), d = serialConfig(extra).devices[0];
  const adapter = new SerialAdapter(d, { transportFactory: async () => { const socket = net.createConnection({ host: '127.0.0.1', port }); await once(socket, 'connect'); return socket; } });
  t.after(async () => { await adapter.close(); for (const socket of sockets) socket.destroy(); await stop(server); });
  await adapter.connect(); return { adapter, state, requests };
}

test('display telemetry is opt-in, serial-only and preserves disabled fingerprint compatibility', () => {
  assert.throws(() => serialConfig({ displayTelemetry: 'true' }), /boolean/);
  assert.throws(() => config({ displayTelemetry: true }), /only by serial/);
  assert.equal(serialConfig().devices[0].configFingerprint, serialConfig({ displayTelemetry: false }).devices[0].configFingerprint);
  assert.equal(serialConfig().devices[0].configFingerprint, serialConfig({ displayTelemetry: true }).devices[0].configFingerprint);
});

test('default and explicitly false flags preserve legacy ten-field HELLO byte stream', async t => {
  for (const displayTelemetry of [undefined, false]) {
    const f = await fixture(t, { displayTelemetry }); const state = await f.adapter.probe();
    assert.deepEqual(f.requests, ['HELLO']); assert.equal(state.display, undefined); assert.equal(state.hardwareRevision, 0); assert.equal(f.adapter.connected, true);
  }
});

test('opt-in DISPLAY byte stream retains raw controller bytes without verifying visibility', async t => {
  const f = await fixture(t, { displayTelemetry: true }); const state = await f.adapter.probe();
  assert.deepEqual(f.requests, ['HELLO', 'DISPLAY']); assert.equal(state.display.diagnosticStatus, 'reported');
  assert.equal(state.display.rawControllerId, '0x00009341'); assert.deepEqual(state.display.rawControllerIdBytes, [0, 0, 147, 65]);
  assert.equal(state.display.controllerAssumed, true); assert.equal(state.display.visibleVerified, false); assert.equal(state.display.spiHz, 10000000);
  f.state.response = { enabled: false, controller: null, rawControllerId: null, width: 0, height: 0, rotation: 0, visibleVerified: false, initStatus: 'disabled', touchEnabled: false, sdEnabled: false };
  assert.equal((await f.adapter.probe()).display.enabled, false);
});

test('current-query register sampling metadata survives TC1 bytes while legacy and bounded unknown fields remain safe', async t => {
  const f = await fixture(t, { displayTelemetry: true });
  f.state.response = { ...diagnostic(), registerSampledAtTickMs: 0xffffffff, readRegisterHz: 1000000, sampleScope: 'current-display-query', futureDiagnostic: { value: 'ignored' } };
  const display = (await f.adapter.probe()).display;
  assert.equal(display.registerSampledAtTickMs, 0xffffffff); assert.equal(display.readRegisterHz, 1000000); assert.equal(display.sampleScope, 'current-display-query');
  assert.equal(display.futureDiagnostic, undefined); assert.equal(display.visibleVerified, false);
  f.state.response = diagnostic(); const legacy = (await f.adapter.probe()).display;
  for (const key of ['registerSampledAtTickMs', 'readRegisterHz', 'sampleScope']) assert.equal(Object.hasOwn(legacy, key), false);
  for (const extra of [{ registerSampledAtTickMs: -1 }, { registerSampledAtTickMs: 0x100000000 }, { registerSampledAtTickMs: '123' }, { readRegisterHz: 10000000 }, { sampleScope: 'visible-verified' }]) {
    f.state.response = { ...diagnostic(), ...extra }; const bad = (await f.adapter.probe()).display;
    assert.equal(bad.diagnosticStatus, 'error'); assert.equal(bad.visibleVerified, false); assert.equal(f.adapter.connected, true);
  }
});

test('malformed, oversized, false visibility claims and timeout stay diagnostic-only; HELLO remains connected', async t => {
  const f = await fixture(t, { displayTelemetry: true, timeoutMs: 100 });
  for (const response of ['{bad-json', [], { ...diagnostic(), visibleVerified: true }, { ...diagnostic(), rawControllerIdBytes: [0, 0, 0, 0] }, JSON.stringify({ ...diagnostic(), extra: 'x'.repeat(2100) }), null]) {
    f.state.response = response; const state = await f.adapter.probe();
    assert.equal(state.display.diagnosticStatus, 'error'); assert.equal(state.display.visibleVerified, false); assert.equal(state.display.enabled, null);
    assert.equal(state.armed, true); assert.equal(f.adapter.connected, true); assert.equal(f.adapter.pending.size, 0);
  }
  f.state.response = diagnostic(); assert.equal((await f.adapter.preflight()).display.diagnosticStatus, 'reported');
  assert.equal(f.adapter.connected, true);
  assert.throws(() => parseDisplayDiagnostics(JSON.stringify({ ...diagnostic(), extra: 'x'.repeat(2100) })), /Oversized/);
});

test('runtime forwards optional serial display diagnostics in actual gateway HTTP heartbeat', async t => {
  const f = await fixture(t, { displayTelemetry: true }), cfg = serialConfig({ displayTelemetry: true }), journal = new GatewayJournal(':memory:');
  let heartbeat;
  const server = http.createServer(async (req, res) => {
    assert.equal(req.url, '/api/gateway/pull'); assert.equal(req.headers.authorization, 'Bearer tc_device_' + 'x'.repeat(43));
    let body = ''; for await (const chunk of req) body += chunk; heartbeat = JSON.parse(body).state;
    res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify({ device: { status: 'registered' }, job: null }));
  });
  const port = await listen(server); cfg.serverUrl = `http://127.0.0.1:${port}`;
  const gateway = new EdgeGateway({ config: cfg, journal, env: { TC_TOKEN: 'tc_device_' + 'x'.repeat(43) }, adapterFactory: () => f.adapter });
  t.after(async () => { await gateway.close(); journal.close(); await stop(server); });
  assert.equal(await gateway.runOnce(cfg.devices[0]), null); assert.equal(heartbeat.connected, true); assert.equal(heartbeat.display.rawControllerId, '0x00009341');
  assert.equal(heartbeat.display.visibleVerified, false); assert.equal(heartbeat.physicalArmed, true); assert.equal(heartbeat.ready, false);
  f.state.response = null; await gateway.runOnce(cfg.devices[0]); assert.equal(heartbeat.connected, true); assert.equal(heartbeat.display.diagnosticStatus, 'error');
});
