import test from 'node:test';
import assert from 'node:assert/strict';
import net from 'node:net';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { MQTTAdapter } from '../mqtt.mjs';
import { OPCUAAdapter } from '../opcua.mjs';
import { config, job, listen, stop, delay } from './helpers.mjs';

test('MQTT adapter connects to a real local broker and accepts only correlated non-retained fresh feedback', { timeout: 15000 }, async t => {
  const { Aedes } = await import('aedes'), mqtt = await import('mqtt'); const broker = await Aedes.createBroker({ heartbeatInterval: 0 }), server = net.createServer(broker.handle), port = await listen(server), url = `mqtt://127.0.0.1:${port}`;
  const receiver = await mqtt.connectAsync(url, { reconnectPeriod: 0 }); let commands = 0, mode = 'good';
  await receiver.subscribeAsync('tc/led/set', { qos: 0 });
  receiver.on('message', async (topic, buffer) => { const request = JSON.parse(buffer); commands++; const feedback = { jobId: request.jobId, nonce: request.nonce, idempotencyKey: request.idempotencyKey, value: request.value, quality: 'good', sourceTimestamp: new Date().toISOString() };
    if (mode === 'good') { await receiver.publishAsync('tc/led/result', JSON.stringify({ ...feedback, idempotencyKey: 'wrong' })); await receiver.publishAsync('tc/led/result', JSON.stringify(feedback)); }
    else if (mode === 'stale') await receiver.publishAsync('tc/led/result', JSON.stringify({ ...feedback, sourceTimestamp: '2000-01-01T00:00:00Z' }));
  });
  const d = config({ protocol: 'mqtt', url, timeoutMs: 250, signals: { led: { type: 'boolean', write: true, commandTopic: 'tc/led/set', feedbackTopic: 'tc/led/result' } } }).devices[0], adapter = new MQTTAdapter(d);
  t.after(async () => { await adapter.close(); await receiver.endAsync(true); await new Promise(resolve => broker.close(resolve)); await stop(server); });
  await adapter.connect(); await adapter.preflight(); const evidence = await adapter.write('led', true, job()); assert.equal(evidence.readback, true); assert.equal(evidence.quality, 'application-feedback-good'); assert.match(evidence.sourceTimestamp, /T/); assert.equal(commands, 1);
  mode = 'stale'; await assert.rejects(adapter.write('led', false, job(1, 'led', false)), /timestamp/); assert.equal(commands, 2);
  mode = 'silent'; await assert.rejects(adapter.write('led', false, job(2, 'led', false)), /timed out/); await delay(30); assert.equal(commands, 3, 'timeout must not republish an actuator command');
});

test('OPC UA adapter pins a real local server certificate and writes/reads with SignAndEncrypt', { timeout: 45000 }, async t => {
  const o = await import('node-opcua'), dir = await mkdtemp(join(tmpdir(), 'tc-opcua-'));
  const probe = net.createServer(), port = await listen(probe); await stop(probe);
  // This isolated test server accepts the generated test client certificate;
  // the gateway still explicitly trusts only this server's pinned certificate.
  const manager = new o.OPCUACertificateManager({ rootFolder: join(dir, 'server-pki'), automaticallyAcceptUnknownCertificate: true });
  const server = new o.OPCUAServer({ port, hostname: '127.0.0.1', host: '127.0.0.1', resourcePath: '/fixture', securityModes: [o.MessageSecurityMode.SignAndEncrypt], securityPolicies: [o.SecurityPolicy.Basic256Sha256], serverCertificateManager: manager, userCertificateManager: new o.OPCUACertificateManager({ rootFolder: join(dir, 'users-pki') }), registerServerMethod: o.RegisterServerMethod.HIDDEN });
  let adapter; t.after(async () => { await adapter?.close(); await server.shutdown(0); await manager.dispose(); await rm(dir, { recursive: true, force: true }); });
  await server.initialize(); const space = server.engine.addressSpace, ns = space.getOwnNamespace(); let actual = false, writes = 0;
  ns.addVariable({ organizedBy: space.rootFolder.objects, browseName: 'FixtureLED', nodeId: 's=FixtureLED', dataType: 'Boolean', minimumSamplingInterval: 50, accessLevel: 'CurrentRead | CurrentWrite', userAccessLevel: 'CurrentRead | CurrentWrite', value: { get: () => new o.Variant({ dataType: o.DataType.Boolean, value: actual }), set: variant => { actual = variant.value; writes++; return o.StatusCodes.Good; } } });
  await server.start(); const certificate = join(dir, 'approved-server.der'); await writeFile(certificate, server.getCertificate()); const d = config({ protocol: 'opcua', url: `opc.tcp://127.0.0.1:${port}/fixture`, timeoutMs: 5000, trustedServerCertificate: certificate, signals: { led: { type: 'boolean', write: true, nodeId: 'ns=1;s=FixtureLED', dataType: 'Boolean' } } }).devices[0];
  adapter = new OPCUAAdapter(d, { dataDir: join(dir, 'edge') }); await adapter.connect(); await adapter.preflight(); const evidence = await adapter.write('led', true); assert.equal(actual, true); assert.equal(writes, 1); assert.equal(evidence.readback, true); assert.equal(evidence.quality, 'Good'); assert(evidence.sourceTimestamp === null || Number.isFinite(Date.parse(evidence.sourceTimestamp)));
  await adapter.write('led', false); assert.equal(writes, 2); assert.equal(actual, false);
});
