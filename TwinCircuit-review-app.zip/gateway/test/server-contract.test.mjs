import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { createApp } from '../../server.mjs';
import { GatewayJournal } from '../journal.mjs';
import { EdgeGateway } from '../runtime.mjs';
import { config, modbusFixture } from './helpers.mjs';

test('actual website operations API → outbound edge → actual TCP fixture → acknowledged immutable result', async t => {
  const fixture = await modbusFixture(), app = createApp({ dbPath: ':memory:', setupToken: 'gateway-contract-test-token', log() {} });
  await new Promise(resolve => app.server.listen(0, '127.0.0.1', resolve)); const origin = `http://127.0.0.1:${app.server.address().port}`;
  let cookie = '', csrf = ''; async function request(path, body) { const response = await fetch(origin + path, { method: body ? 'POST' : 'GET', headers: { Origin: origin, cookie, 'Content-Type': 'application/json', 'x-csrf-token': csrf }, body: body ? JSON.stringify(body) : undefined }); if (response.headers.get('set-cookie')) cookie = response.headers.get('set-cookie').split(';')[0]; const result = await response.json(); assert.equal(response.status, 200, JSON.stringify(result)); if (result.csrfToken) csrf = result.csrfToken; return result; }
  let gateway; const journal = new GatewayJournal(':memory:'); t.after(async () => { await gateway?.close(); journal.close(); await fixture.close(); await app.close(); });
  await request('/api/auth/setup', { setupToken: 'gateway-contract-test-token', name: 'Gateway contract test', email: 'gateway-contract@example.com', password: 'local-only test strong password 123' });
  async function command(type, payload) { const state = await request('/api/operations'); return request('/api/operations/command', { type, payload, expectedRevision: state.revision, requestId: randomUUID() }); }
  const registered = await command('device.register', { name: 'Loopback low-voltage fixture', protocol: 'modbus-tcp', endpoint: 'test-only 127.0.0.1', signals: [{ name: 'led', type: 'boolean', critical: false }] });
  await command('device.arm', { deviceId: registered.deviceId, seconds: 60, reason: 'Only an in-process loopback integration fixture is connected' });
  const cfg = config({ deviceId: registered.deviceId, port: fixture.port }); cfg.serverUrl = origin;
  gateway = new EdgeGateway({ config: cfg, journal, env: { TC_TOKEN: registered.deviceToken } }); const device = cfg.devices[0]; journal.arm(device.deviceId, 60);
  const queued = await command('job.submit', { deviceId: device.deviceId, signal: 'led', value: true, expectedDeviceRevision: 0 });
  const result = await gateway.runOnce(device); assert.equal(result.status, 'succeeded'); assert.equal(fixture.state.writes, 1); assert.equal(journal.pending(device.deviceId).length, 0);
  const state = await request('/api/operations'), recorded = state.jobs.find(j => j.id === queued.jobId); assert.equal(recorded.state, 'succeeded'); assert.equal(recorded.result.evidence.readback, true); assert.equal(recorded.result.physicalQualification, 'not-established'); assert.equal(recorded.result.revision, 1);
  await gateway.runOnce(device); assert.equal(fixture.state.writes, 1); assert.equal((await request('/api/bootstrap')).orders[0].batches.length, 0);
  await command('device.revoke', { deviceId: device.deviceId, reason: 'End of loopback contract test' });
  await assert.rejects(gateway.runOnce(device), e => e.status === 401 || e.status === 403); assert.equal(fixture.state.writes, 1);
});
