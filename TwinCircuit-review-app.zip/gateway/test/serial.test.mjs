import test from 'node:test';
import assert from 'node:assert/strict';
import net from 'node:net';
import { once } from 'node:events';
import { SerialAdapter, frame, parseFrame } from '../serial.mjs';
import { config, job, listen, stop } from './helpers.mjs';

test('TC1 protocol over a real byte-stream server: all eight vectors preserve device actualY and quality', async t => {
  const boot = 'a'.repeat(32), state = { revision: 0, armed: true, permit: true, actualY: false, writes: 0 }, sockets = new Set();
  const server = net.createServer(socket => { sockets.add(socket); socket.on('close', () => sockets.delete(socket)); let buffer = ''; socket.on('data', data => { buffer += data; let cut; while ((cut = buffer.indexOf('\n')) >= 0) { const f = parseFrame(buffer.slice(0, cut)); buffer = buffer.slice(cut + 1); const tick = 1000;
    if (f[1] === 'HELLO') socket.write(frame(`TC1|STATE|${f[2]}|${boot}|${state.revision}|${tick}|${Number(state.armed)}|${Number(state.permit)}|0|${Number(state.actualY)}`));
    else { state.writes++; assert.equal(f[5], boot); assert.equal(Number(f[6]), state.revision); assert.equal(f[10], 'GPIO_ONLY'); assert(Number(f[7]) > tick); assert(Number(f[7]) - tick <= 5000); const index = Number(f[9]); state.revision++;
      // Deliberately return LOW even when an expected truth table would say HIGH.
      // The gateway must preserve measured actual, rather than manufacture a pass.
      state.actualY = false; const body = `TC1|RESULT|${f[2]}|${f[3]}|${f[4]}|OK|${state.revision}|1010|0|GPIO_READBACK|LOW_VOLTAGE_LED_ONLY|${index}|${index >> 2 & 1}|${index >> 1 & 1}|${index & 1}`;
      const reply = frame(body); socket.write(reply.slice(0, 7)); setImmediate(() => socket.write(reply.slice(7)));
    }
  } }); });
  const port = await listen(server); const d = config({ protocol: 'serial', path: 'COM7', signals: { led: { type: 'boolean', write: true }, cme_vector: { type: 'number', min: 0, max: 7, write: true } } }).devices[0];
  const adapter = new SerialAdapter(d, { transportFactory: async () => { const socket = net.createConnection({ host: '127.0.0.1', port }); await once(socket, 'connect'); return socket; } });
  t.after(async () => { await adapter.close(); for (const s of sockets) s.destroy(); await stop(server); }); await adapter.connect();
  for (let vector = 0; vector < 8; vector++) { await adapter.preflight(); const result = await adapter.write('cme_vector', vector, job(vector, 'cme_vector', vector)); assert.equal(result.vectorIndex, vector); assert.deepEqual(result.inputs, { C: Boolean(vector & 4), M: Boolean(vector & 2), E: Boolean(vector & 1) }); assert.equal(result.actualY, false); assert.equal(result.readbackQuality, 'GPIO_READBACK'); assert.equal(result.deviceTimestamp.bootId, boot); assert.equal(result.sourceTimestamp, null); }
  assert.equal(state.writes, 8); state.armed = false; await assert.rejects(adapter.preflight(), /physical ARM/); assert.equal(state.writes, 8);
  assert.throws(() => parseFrame('TC1|STATE|bad|00000000'), /CRC/);
});
