import test from 'node:test';
import assert from 'node:assert/strict';
import net from 'node:net';
import { once } from 'node:events';
import { randomUUID } from 'node:crypto';
import { mkdtemp, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { SerialAdapter, frame, parseFrame } from '../serial.mjs';
import { EdgeGateway } from '../runtime.mjs';
import { GatewayJournal } from '../journal.mjs';
import { reconcilePanelHardware, bindPanelHardware } from '../reconcile.mjs';
import { createApp } from '../../server.mjs';
import { config, job, listen, stop } from './helpers.mjs';

const panelConfig = (extra = {}) => config({ protocol: 'esp32-tft', path: 'COM7', signals: { panel_vector: { type: 'number', min: 0, max: 7, write: true } }, ...extra });
const pixel = (x, y, high) => ({ x, y, actualColor: high ? 0xffffff : 0, rawRGB: high ? [252, 252, 252] : [0, 0, 0] });
async function fixture(t, extra = {}) {
  const sockets = new Set(), boot = 'b'.repeat(32), state = { revision: 0, tick: 1000, writes: 0, requests: [], ready: true, blocked: false, reconcileCount: 0, dropReconcile: false, corruptReference: false, corruptPixel: false, dropReply: false, wrongBoot: false, actualY: false };
  const refs = () => ({ white: pixel(20, 200, !state.corruptReference), black: pixel(44, 200, false) });
  const server = net.createServer(socket => {
    sockets.add(socket); socket.on('close', () => sockets.delete(socket)); let buffer = '';
    socket.on('data', chunk => {
      buffer += chunk.toString(); let cut;
      while ((cut = buffer.indexOf('\n')) >= 0) {
        const f = parseFrame(buffer.slice(0, cut)); buffer = buffer.slice(cut + 1); state.requests.push(f[1]); state.tick += 10;
        if (f[1] === 'HELLO') socket.write(frame(`TC1|STATE|${f[2]}|${boot}|${state.revision}|${state.tick}|0|0|${Number(state.blocked)}|${Number(state.actualY)}`));
        else if (f[1] === 'PANEL') {
          const capability = { enabled: true, capability: 'tft-panel', panelOnly: true, gpioOutputsEnabled: false, signal: 'panel_vector', ready: state.ready, bootId: state.wrongBoot ? 'c'.repeat(32) : boot, hardwareRevision: state.revision, tickMs: state.tick, pixel: { x: 260, y: 116 }, falseColor: 0, trueColor: 0xffffff, pixelFormat: 'RGB888', readback: 'ILI9341_GRAM_RGB888', references: refs() };
          socket.write(frame(`TC1|PANELSTATE|${f[2]}|${JSON.stringify(capability)}`));
        } else if (f[1] === 'PANELRECONCILE') {
          assert.equal(f.length, 6); assert.equal(f[3], boot); assert.equal(Number(f[4]), state.revision); assert.equal(f[5], 'PANEL_ONLY'); state.reconcileCount++; state.blocked = false;
          if (!state.dropReconcile) socket.write(frame(`TC1|PANELRECONCILED|${f[2]}|${JSON.stringify({ status: 'OK', operation: 'panel-reconcile', bootId: boot, hardwareRevision: state.revision, tickMs: state.tick, blocked: false, panelOnly: true, gpioOutputsEnabled: false, reconcileCount: state.reconcileCount })}`));
        } else if (f[1] === 'PANELWRITE') {
          assert.equal(f.length, 11); assert.equal(f[5], boot); assert.equal(Number(f[6]), state.revision); assert.equal(f[8], 'panel_vector'); assert.equal(f[10], 'PANEL_ONLY'); assert(Number(f[7]) > state.tick); assert(Number(f[7]) - state.tick <= 5000);
          state.writes++; state.revision++; const v = Number(f[9]);
          // A deliberately LOW result is a valid measurement even when the
          // independent truth-table acceptance will reject it.
          const measurement = { status: 'OK', hardwareRevision: state.revision, tickMs: state.tick, profile: 'TC-PANEL/0.1', quality: 'DISPLAY_PIXEL_READBACK', scope: 'controller-GRAM-only', ok: true, vectorIndex: v, inputs: { C: Boolean(v & 4), M: Boolean(v & 2), E: Boolean(v & 1) }, actualY: state.actualY, pixel: { ...pixel(260, 116, state.actualY), format: 'RGB888' }, references: refs(), readRegister: '0x2E', readRegisterHz: 1000000, rotation: 1, sampledAtTickMs: state.tick, error: null };
          if (state.corruptPixel) measurement.pixel.actualColor = 0xffffff;
          if (!state.dropReply) { const reply = frame(`TC1|PANELRESULT|${f[2]}|${f[3]}|${f[4]}|${JSON.stringify(measurement)}`); socket.write(reply.slice(0, 13)); setImmediate(() => { if (!socket.destroyed) socket.write(reply.slice(13)); }); }
        } else assert.fail(`Unexpected command ${f[1]}`);
      }
    });
  });
  const port = await listen(server), cfg = panelConfig(extra), device = cfg.devices[0];
  const adapter = new SerialAdapter(device, { transportFactory: async () => { const socket = net.createConnection({ host: '127.0.0.1', port }); await once(socket, 'connect'); return socket; } });
  t.after(async () => { await adapter.close(); for (const s of sockets) s.destroy(); await stop(server); });
  return { state, adapter, cfg, device };
}

test('panel capability is explicit, integer-bounded and cannot mix or relabel GPIO signals', () => {
  const cfg = panelConfig(), d = cfg.devices[0]; assert.equal(d.protocol, 'serial'); assert.equal(d.capability, 'tft-panel'); assert.equal(panelConfig({ protocol: 'serial', capability: 'tft-panel' }).devices[0].configFingerprint, d.configFingerprint);
  assert.throws(() => panelConfig({ signals: { led: { type: 'boolean', write: true } } }), /only panel_vector/);
  assert.throws(() => panelConfig({ signals: { panel_vector: { type: 'number', min: 0, max: 7, write: true }, led: { type: 'boolean', write: true } } }), /only panel_vector/);
  assert.throws(() => panelConfig({ signals: { panel_vector: { type: 'number', min: 0, max: 7, integer: false, write: true } } }), /integer/);
  assert.throws(() => panelConfig({ protocol: 'serial', capability: undefined }), /S3 fixture/);
  assert.throws(() => config({ capability: 'tft-panel' }), /Unsupported device capability/);
});

test('real TCP TC1 panel stream measures eight vectors with GPIO ARM/permit false and preserves wrong actual', async t => {
  const f = await fixture(t); await f.adapter.connect();
  for (let v = 0; v < 8; v++) {
    await f.adapter.preflight(job(v, 'panel_vector', v)); const e = await f.adapter.write('panel_vector', v, job(v, 'panel_vector', v));
    assert.equal(e.actualY, false); assert.equal(e.readback, false); assert.equal(e.quality, 'DISPLAY_PIXEL_READBACK'); assert.equal(e.readbackQuality, e.quality); assert.equal(e.profile, 'TC-PANEL/0.1'); assert.equal(e.scope, 'controller-GRAM-only'); assert.equal(e.protocol, 'serial'); assert.equal(e.source, 'esp32-s3-panel-testcell'); assert.equal(e.hardwareRevision, v + 1); assert.equal(e.pixel.actualColor, 0); assert.deepEqual(e.references.white.rawRGB, [252, 252, 252]); assert.equal(e.sourceTimestamp, null); assert.equal(e.ok, true);
  }
  assert.equal(f.state.writes, 8); assert(!f.state.requests.includes('WRITE')); assert.equal(f.adapter.lastState.armed, false); assert.equal(f.adapter.lastState.permit, false);
  await assert.rejects(f.adapter.write('led', true, job(8)), /Panel-only/); assert.equal(f.state.writes, 8);
});

test('live black/white calibration, boot binding and hardware revision fail closed before panel writes', async t => {
  const f = await fixture(t); await f.adapter.connect();
  f.state.corruptReference = true; await assert.rejects(f.adapter.preflight(), /reference/);
  f.state.corruptReference = false; f.state.wrongBoot = true; await assert.rejects(f.adapter.preflight(), /boot or revision/);
  f.state.wrongBoot = false; f.state.ready = false; await assert.rejects(f.adapter.preflight(), /calibration must pass/);
  f.state.ready = true; await assert.rejects(f.adapter.preflight(job(4, 'panel_vector', 0)), /revision must match/);
  assert.equal(f.state.writes, 0);
  const legacy = new SerialAdapter({ ...f.device, capability: undefined }, { transportFactory: f.adapter.transportFactory }); t.after(() => legacy.close()); await legacy.connect();
  await assert.rejects(legacy.preflight(job()), /physical ARM/); assert.equal(f.state.writes, 0);
});

test('read-only commissioning preserves both counters, fresh authorizations and the measured TFT boot', async t => {
  const f = await fixture(t), dir = await mkdtemp(join(tmpdir(), 'tc-commission-'));
  const db = join(dir, 'journal.sqlite'), boot = 'b'.repeat(32);
  let journal = new GatewayJournal(db);
  t.after(() => journal.close());
  const readOnly = panelConfig({outputsEnabled:false}).devices[0];
  journal.register(readOnly); f.state.revision = 8;
  const args = { journal, device:f.device, adapter:f.adapter, expectedBootId:boot, expectedRevision:8, acknowledgePanelOnly:true, confirm:'BIND' };
  await assert.rejects(bindPanelHardware({ ...args, expectedRevision:7 }), /must match/);
  await assert.rejects(bindPanelHardware({ ...args, device:panelConfig({path:'COM8'}).devices[0] }), /previously registered/);
  journal.arm(f.device.deviceId, 30);
  await assert.rejects(bindPanelHardware(args), /disarmed/);
  journal.disarm(f.device.deviceId);
  const result = await bindPanelHardware(args);
  assert.equal(result.hardwareBaseRevision, 8); assert.equal(result.localArm, false);
  assert.deepEqual([...new Set(f.state.requests)].sort(), ['HELLO','PANEL']);
  assert.equal(f.state.writes, 0); assert.equal(f.state.revision, 8);
  await assert.rejects(bindPanelHardware(args), /already has a panel binding/);
  journal.close(); journal = new GatewayJournal(db);
  const binding = journal.panelBinding(f.device.deviceId);
  assert.deepEqual({ ...binding }, {bootId:boot, hardwareBaseRevision:8});
  const gateway = new EdgeGateway({config:f.cfg, journal, adapterFactory:()=>f.adapter, clientFactory:()=>({})});
  t.after(()=>gateway.close());
  const state = journal.state(f.device.deviceId);
  assert.equal(state.revision, 0); assert.equal(state.blocked, false); assert.equal(state.armedUntil, null);
  await assert.rejects(f.adapter.preflight(job(0,'panel_vector',3), { ...binding, bootId:'c'.repeat(32) }), /revision must match/);
  const denied = await gateway.processJob(f.device, job(0,'panel_vector',3));
  assert.equal(denied.status, 'failed'); assert.equal(f.state.writes, 0);
  journal.arm(f.device.deviceId, 60, 8);
  for (let i=0; i<8; i++) {
    const measurement = await gateway.processJob(f.device, job(i,'panel_vector',i));
    assert.equal(measurement.status, 'succeeded');
    assert.equal(measurement.result.revision, i+1);
    assert.equal(measurement.result.evidence.gatewayRevision, i+1);
    assert.equal(measurement.result.evidence.hardwareRevision, 8+i+1);
    assert.equal(measurement.result.evidence.panelBinding.bootId, boot);
  }
  assert.equal(f.state.writes, 8); assert.equal(journal.state(f.device.deviceId).writesLeft, 0);
  assert.equal(f.state.requests.includes('PANELRECONCILE'),false);
});

test('first binding preserves blocked registrations, held deliveries and previous job evidence', async t => {
  const f=await fixture(t);
  for(const cause of ['blocked','held','job']){
    const journal=new GatewayJournal(':memory:'); t.after(()=>journal.close()); journal.register(f.device);
    const sample=job(0,'panel_vector',1);
    if(cause==='blocked') journal.block(f.device.deviceId,'Operator inspection required');
    if(cause==='held') journal.hold(f.device.deviceId,sample);
    if(cause==='job') { journal.reject(f.device.deviceId,sample,'Previous preflight'); journal.acknowledge(sample.id); }
    await assert.rejects(bindPanelHardware({device:f.device,adapter:f.adapter,journal,expectedBootId:'b'.repeat(32),expectedRevision:0,acknowledgePanelOnly:true,confirm:'BIND'}),/unblocked|history/);
    assert.equal(journal.panelBinding(f.device.deviceId),null);
    assert.equal(f.state.requests.length,0);
    assert.equal(journal.state(f.device.deviceId).blocked,cause==='blocked');
  }
});

test('inconsistent measured RGB blocks the journal after exactly one panel attempt', async t => {
  const f = await fixture(t), journal = new GatewayJournal(':memory:'); f.state.corruptPixel = true;
  const gateway = new EdgeGateway({ config: f.cfg, journal, env: { TC_TOKEN: 'tc_device_' + 'x'.repeat(43) }, adapterFactory: () => f.adapter, clientFactory: () => ({}) });
  t.after(async () => { await gateway.close(); journal.close(); });
  const noArm = await gateway.processJob(f.device, job(0, 'panel_vector', 1)); assert.equal(noArm.result.executed, false); assert.equal(f.state.writes, 0);
  journal.arm(f.device.deviceId, 60); const candidate = job(0, 'panel_vector', 1), result = await gateway.processJob(f.device, candidate);
  assert.equal(result.status, 'uncertain'); assert.equal(result.result.executed, true); assert.equal(journal.state(f.device.deviceId).blocked, true); assert.equal(f.state.writes, 1);
  assert.deepEqual(await gateway.processJob(f.device, candidate), result); assert.equal(f.state.writes, 1);
});

test('lost real TCP panel reply is uncertain and at-most-once, including redelivery', async t => {
  const f = await fixture(t, { timeoutMs: 100 }), journal = new GatewayJournal(':memory:'); f.state.dropReply = true;
  const gateway = new EdgeGateway({ config: f.cfg, journal, env: { TC_TOKEN: 'tc_device_' + 'x'.repeat(43) }, adapterFactory: () => f.adapter, clientFactory: () => ({}) });
  t.after(async () => { await gateway.close(); journal.close(); }); journal.arm(f.device.deviceId, 60, 8);
  const candidate = job(0, 'panel_vector', 7), result = await gateway.processJob(f.device, candidate);
  assert.equal(result.status, 'uncertain'); assert.equal(result.result.executed, true); assert.equal(f.state.writes, 1); assert.equal(journal.state(f.device.deviceId).blocked, true);
  f.state.dropReply = false; assert.deepEqual(await gateway.processJob(f.device, candidate), result); assert.equal(f.state.writes, 1);
});

for (const previousWrites of [0, 8]) test(`website TFT queue validates dual permission and genuine readbacks starting at hardware revision ${previousWrites}`, async t => {
  const f = await fixture(t), app = createApp({ dbPath: ':memory:', setupToken: 'panel-contract-test-token', log() {} });
  await new Promise(resolve => app.server.listen(0, '127.0.0.1', resolve)); const origin = `http://127.0.0.1:${app.server.address().port}`;
  let cookie = '', csrf = '', gateway; const journal = new GatewayJournal(':memory:');
  t.after(async () => { await gateway?.close(); journal.close(); await app.close(); });
  async function request(path, body) { const response = await fetch(origin + path, { method: body ? 'POST' : 'GET', headers: { Origin: origin, cookie, 'Content-Type': 'application/json', 'x-csrf-token': csrf }, body: body ? JSON.stringify(body) : undefined }); if (response.headers.get('set-cookie')) cookie = response.headers.get('set-cookie').split(';')[0]; const result = await response.json(); assert.equal(response.status, 200, JSON.stringify(result)); if (result.csrfToken) csrf = result.csrfToken; return result; }
  async function command(type, payload) { const state = await request('/api/operations'); return request('/api/operations/command', { type, payload, expectedRevision: state.revision, requestId: randomUUID() }); }
  await request('/api/auth/setup', { setupToken: 'panel-contract-test-token', name: 'Panel contract test', email: 'panel-contract@example.com', password: 'local-only panel strong password 123' });
  const registered = await command('device.register', { name: 'Loopback TFT workcell', protocol: 'esp32-tft', endpoint: 'test-only TCP byte stream', signals: [{ name: 'panel_vector', type: 'number', min: 0, max: 7, critical: false }] });
  const cfg = panelConfig({ deviceId: registered.deviceId }); cfg.serverUrl = origin;
  // The adapter endpoints stay loopback and the registered cloud device is bound
  // to the same identity. No COM port is opened by this integration test.
  const d = cfg.devices[0];
  f.adapter.device = d;
  if (previousWrites) {
    f.state.revision = previousWrites;
    journal.register(panelConfig({ deviceId:registered.deviceId, outputsEnabled:false }).devices[0]);
    await bindPanelHardware({device:d, adapter:f.adapter, journal, expectedBootId:'b'.repeat(32), expectedRevision:previousWrites, acknowledgePanelOnly:true, confirm:'BIND'});
  }
  gateway = new EdgeGateway({ config: cfg, journal, env: { TC_TOKEN: registered.deviceToken }, adapterFactory: () => f.adapter });
  await command('device.arm', { deviceId: d.deviceId, seconds: 60, reason: 'Loopback GRAM protocol test only; no physical GPIO or COM port' });
  await command('job.submit', { deviceId: d.deviceId, signal: 'panel_vector', value: 0, expectedDeviceRevision: 0 });
  await gateway.runOnce(d); assert.equal(f.state.writes, 0); journal.arm(d.deviceId, 60, 8);
  for (let v = 0; v < 8; v++) {
    if (v) await command('job.submit', { deviceId: d.deviceId, signal: 'panel_vector', value: v, expectedDeviceRevision: v });
    const result = await gateway.runOnce(d); assert.equal(result.status, 'succeeded'); assert.equal(result.result.evidence.actualY, false); assert.equal(journal.pending(d.deviceId).length, 0);
  }
  const operations = await request('/api/operations'), device = operations.devices.find(d => d.id === registered.deviceId);
  assert.equal(device.revision, 8);
  assert.equal(device.localState.panelBinding?.hardwareBaseRevision ?? 0, previousWrites);
  assert.equal(f.state.revision, previousWrites + 8);
  assert.equal(f.state.writes, 8); assert.equal(device.localState.panelReady, true); assert.equal(device.localState.physicalArmed, false); assert.equal(device.localState.physicalPermit, false); assert.equal(device.localState.panelCapabilities.panelOnly, true);
  assert.equal(operations.jobs.filter(j => j.state === 'succeeded').length, 8); assert.equal((await request('/api/bootstrap')).orders[0].batches.length, 0);
});

test('explicit manual panel hardware recovery preserves revision, logs audit and grants no local arm or readiness', async t => {
  const f = await fixture(t), journal = new GatewayJournal(':memory:'); journal.register(f.device); journal.block(f.device.deviceId, 'Prior unknown panel attempt already reviewed'); f.state.blocked = true;
  t.after(() => journal.close());
  const args = { device: f.device, adapter: f.adapter, journal, expectedBootId: 'b'.repeat(32), expectedRevision: 0, reason: 'Reviewed prior device state and server audit manually', acknowledgePanelOnly: true, confirm: 'RECONCILE' };
  await assert.rejects(reconcilePanelHardware({ ...args, acknowledgePanelOnly: false }), /acknowledge-panel-only/); assert.equal(f.state.requests.length, 0);
  await assert.rejects(reconcilePanelHardware({ ...args, expectedRevision: 99 }), /must match/); assert.equal(f.state.reconcileCount, 0);
  const result = await reconcilePanelHardware(args);
  assert.equal(result.status, 'OK'); assert.equal(result.reconcileCount, 1); assert.equal(result.hardwareRevision, 0); assert.equal(f.state.revision, 0); assert.equal(f.state.writes, 0); assert.equal(f.state.blocked, false);
  assert.equal(journal.state(f.device.deviceId).revision, 0); assert.equal(journal.state(f.device.deviceId).armedUntil, null); assert.equal(journal.state(f.device.deviceId).blocked, true); assert.equal(result.localJournalReconciliationRequired, true); assert.equal(f.adapter.lastState, null);
  assert(journal.db.prepare('SELECT event FROM audit').all().some(r => r.event === 'panel-hardware-reconciliation-confirmed'));
  // Outstanding/unacknowledged attempt evidence must be retained and resolved.
  const pending = job(0, 'panel_vector', 0); journal.reject(f.device.deviceId, pending, 'Recorded earlier non-execution'); const count = f.state.requests.length;
  await assert.rejects(reconcilePanelHardware(args), /unacknowledged/); assert.equal(f.state.requests.length, count);
});

test('lost panel manual recovery acknowledgement locks locally and never retries the recovery command', async t => {
  const f = await fixture(t, { timeoutMs: 100 }), journal = new GatewayJournal(':memory:'); journal.register(f.device); f.state.blocked = true; f.state.dropReconcile = true;
  t.after(() => journal.close());
  await assert.rejects(reconcilePanelHardware({ device: f.device, adapter: f.adapter, journal, expectedBootId: 'b'.repeat(32), expectedRevision: 0, reason: 'Reviewed and confirmed panel-only recovery manually', acknowledgePanelOnly: true, confirm: 'RECONCILE' }), /timed out/);
  assert.equal(f.state.reconcileCount, 1); assert.equal(f.state.writes, 0); assert.equal(f.state.requests.filter(c => c === 'PANELRECONCILE').length, 1); assert.equal(journal.state(f.device.deviceId).blocked, true); assert.equal(journal.state(f.device.deviceId).armedUntil, null);
});

test('panel recovery CLI refuses a live worker lock before opening any device', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'tc-panel-lock-')), cfg = panelConfig();
  await writeFile(join(dir, 'config.json'), JSON.stringify(cfg)); await writeFile(join(dir, 'worker.lock'), JSON.stringify({ pid: process.pid, owner: 'live-fixture-worker' }));
  const output = await new Promise((resolve, reject) => {
    // Invalid expected boot provides a second independent pre-connect rejection
    // if the lock guard regresses. No serial device can be opened by this test.
    const child = spawn(process.execPath, [fileURLToPath(new URL('../cli.mjs', import.meta.url)), 'panel-reconcile', '--device', 'fixture', '--expected-boot', 'invalid', '--expected-revision', '0', '--acknowledge-panel-only', '--confirm', 'RECONCILE', '--reason', 'Only testing worker lock with no device operation', '--config', join(dir, 'config.json'), '--data', dir], { windowsHide: true });
    let text = ''; child.stdout.on('data', b => text += b); child.stderr.on('data', b => text += b); child.once('error', reject); child.once('exit', code => resolve({ code, text }));
  });
  assert.equal(output.code, 1); assert.match(output.text, /Gateway worker already running/);
});
