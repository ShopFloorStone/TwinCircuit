import net from 'node:net';
import { once } from 'node:events';
import { randomBytes } from 'node:crypto';
import { validateConfig } from '../config.mjs';
export async function listen(server) { server.listen(0, '127.0.0.1'); await once(server, 'listening'); return server.address().port; }
export async function stop(server) { await new Promise(resolve => server.close(resolve)); }
export const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
export function config(device = {}) { return validateConfig({ schemaVersion: 1, serverUrl: 'http://127.0.0.1:4173', devices: [{ deviceId: 'fixture', protocol: 'modbus-tcp', tokenEnv: 'TC_TOKEN', enabled: true, outputsEnabled: true, host: '127.0.0.1', port: 1502, unitId: 1, timeoutMs: 250, signals: { led: { type: 'boolean', write: true, area: 'coil', address: 4 } }, ...device }] }); }
export function job(revision = 0, signal = 'led', value = true) { const id = randomBytes(10).toString('hex'); return { id, deviceId: 'fixture', nonce: randomBytes(16).toString('hex'), command: 'write', payload: { signal, value }, expiresAt: Date.now() + 60000, revision, idempotencyKey: id, critical: false, state: 'claimed' }; }
export async function modbusFixture() {
  const sockets = new Set(), coils = new Map(), discreteInputs = new Map(), registers = new Map(), state = { writes: 0, dropWriteReply: false, denyWrites: false, fragment: true };
  const server = net.createServer(socket => { sockets.add(socket); socket.on('close', () => sockets.delete(socket)); let buffer = Buffer.alloc(0); socket.on('data', chunk => { buffer = Buffer.concat([buffer, chunk]); while (buffer.length >= 7 && buffer.length >= buffer.readUInt16BE(4) + 6) { const packet = buffer.subarray(0, buffer.readUInt16BE(4) + 6); buffer = buffer.subarray(packet.length); const pdu = packet.subarray(7), fn = pdu[0], address = pdu.readUInt16BE(1); let response;
      if ([5, 6].includes(fn)) { if (state.denyWrites) response = Buffer.from([fn | 128, 2]); else { state.writes++; (fn === 5 ? coils : registers).set(address, fn === 5 ? pdu.readUInt16BE(3) === 0xff00 : pdu.readUInt16BE(3)); response = pdu; if (state.dropWriteReply) continue; } }
      else if ([1, 2].includes(fn)) response = Buffer.from([fn, 1, (fn === 2 ? discreteInputs : coils).get(address) ? 1 : 0]);
      else if ([3, 4].includes(fn)) { response = Buffer.alloc(4); response[0] = fn; response[1] = 2; response.writeUInt16BE(registers.get(address) ?? 0, 2); }
      else response = Buffer.from([fn | 128, 1]);
      const reply = Buffer.alloc(7 + response.length); packet.copy(reply, 0, 0, 4); reply.writeUInt16BE(response.length + 1, 4); reply[6] = packet[6]; response.copy(reply, 7); if (state.fragment) { socket.write(reply.subarray(0, 3)); setImmediate(() => { if (!socket.destroyed) socket.write(reply.subarray(3)); }); } else socket.write(reply);
    } }); });
  const port = await listen(server); return { port, state, coils, discreteInputs, registers, close: async () => { for (const socket of sockets) socket.destroy(); await stop(server); } };
}
