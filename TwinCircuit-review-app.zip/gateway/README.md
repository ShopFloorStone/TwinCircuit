# TwinCircuit 现场设备网关

独立 Node 24 服务，运行在连接 ESP32-S3 或现场网络的电脑上。网站只维护设备权限和任务队列；网关主动向网站拉取任务，通过本地白名单执行，再回传设备反馈。网站服务器不扫描或主动连接工厂地址。网关没有入站 HTTP 控制端口。

当前交付包含串口、Modbus TCP、MQTT、OPC UA 适配器和 ESP32-S3 固件。协议测试连接本机 TCP 设备、MQTT broker 和 OPC UA server；另已对用户 16MB ESP32-S3 完成真实烧录校验、TC1 只读探测、网关和网页心跳，未验证外接 LED/负载。新增的 `esp32-tft` 是独立显示检测能力；其代码/本地协议测试与具体硬件执行记录分开，不因测试通过宣称已运行实体八向量。其他工业用途是待接入模板，没有连接 PLC 或真实产线。见 [验证记录](../docs/VALIDATION.md)。

## 1. 安装与首次配置

网站主项目保持零运行依赖。网关依赖单独安装：

```powershell
cd gateway
npm ci --omit=dev
Copy-Item config.example.json config.json
```

`serialport`、`mqtt`、`node-opcua` 均为可选运行依赖，未安装的协议会明确报错。Node 24 官方常见平台可使用 serialport 预编译绑定；没有匹配绑定时须按 serialport 官方环境要求构建原生模块。不要复制其他系统的 `node_modules`。

在网站使用正式 owner 账号登记设备，协议选择 `esp32-serial`，信号登记 `led:boolean` 和 `cme_vector:number(min=0,max=7)`。设备 token 只展示一次，绑定单个工作区及设备。将它放在**现场进程环境变量**，不要填到前端代码、仓库或 JSON：

```powershell
$env:TC_S3_TOKEN = 'tc_device_REPLACE_WITH_ONE_TIME_DEVICE_TOKEN'
```

编辑 `config.json`：

- `serverUrl` 为自己部署的网站 HTTPS 地址；本机测试可用 `http://127.0.0.1:4173`。其他 HTTP 地址须显式设置 `allowInsecureServer:true`，会暴露 token，应只用于隔离测试。
- S3 项的 `deviceId` 必须与网站登记 ID 一致；`path` 为用户确认的 COM 端口。不会枚举或扫描串口。
- 确认接线及信号后，只对该设备将 `enabled` 和 `outputsEnabled` 改为 `true`。其余模板保留 `false`。
- `signals` 是现场 owner 控制的白名单，网络任务只能引用已配置名称与值。任务不能指定寄存器地址、NodeId、主题、脚本或串口。

相对证书路径按网关进程的当前工作目录解析。`--data` 指定本地持久化目录。保护该目录与配置，限制到运行网关和现场操作人员；备份须包含 SQLite WAL 一致快照，不能只复制活动数据库主文件。

## 2. ESP32-S3 低压 LED 首次运行

### TFT 显示专用路径

只有已刷入 **panel-only 固件**的设备，才可在网站登记 `esp32-tft` 并使用 `config.example.json` 的 TFT 项。它在本地规范化为 `protocol:"serial", capability:"tft-panel"`，唯一信号为 `panel_vector:number`、整数范围 0..7，不能混入 `led` 或 `cme_vector`。TFT 状态显示固件与 panel-only 执行固件是不同能力，不能只修改配置来转换。

登记后将一次性 token 放入 `TC_TFT_TOKEN`，核对 `deviceId`、网站地址和明确的 COM 端口；仅该项设置 `enabled:true, outputsEnabled:true`。使用独立设备 ID、token 和 journal，避免混用 GPIO 序号。`status` 不访问串口；`run --enable-device-io` 才探测。

该路径保留网站 owner 短期放行、现场 CLI 短期 arm/写预算、bootId/revision/expiry 与先落盘后执行。因固件完全不访问 GPIO4/5/6，它不要求 GPIO ARM 按钮或 permit 跳线。现场可执行 `node cli.mjs arm --device YOUR_TFT_DEVICE_ID --seconds 120 --writes 8 --confirm ARM --config ./config.json --data ./data`；这只授权该明确的显示能力，不能用于普通 GPIO 设备。

网关在 HELLO 后查询 `TC1|PANEL|nonce`，只有 panel-only 声明、当前 boot/revision、实际黑白参考读回都匹配，才上报 `panelReady:true`。每个任务使用独立 `PANELWRITE`，固件求值后写像素 (260,116)，并实际读取该像素及白 (20,200)/黑 (44,200) 参考的 ILI9341 GRAM。`evidence` 平铺保存完整设备 JSON：`profile:"TC-PANEL/0.1"`、`quality/readbackQuality:"DISPLAY_PIXEL_READBACK"`、原始 `rawRGB`、归一化 `actualColor`、`actualY`、参考读回和设备时间。黑/白分别为 0/16777215；六位通道从实际原始字节归一化，不能用 expected 替代。网关再次检查三处颜色与布尔值；非黑白/校准失败/超时会停止并锁定不确定尝试。

此证据只证明控制器显存读回，`scope:"controller-GRAM-only"`；不证明光学显示、GPIO/负载动作或工业质量。八个成功测量仍须单独导入 `TC-PANEL/0.1` 外部批次并由其他用户审阅，付款另行授权。固件和网关不会因为执行成功自动验收或支付。

#### 在新工作区登记已有测量历史的 TFT 板

先用只读网关确认工作台的串口、当前启动标识、板上修订号和黑白参考测量，再停止网关进程。保留原来的数据目录。为同一设备准备配置文件，仅将 `outputsEnabled` 调整为 `true`。首次绑定读取实板，并把启动标识和原有硬件修订记录到本机审计日志。它要求新的本机登记修订为 0、写入许可关闭、设备未锁定，且无已处理或待处理的任务。

```sh
node cli.mjs panel-bind --device YOUR_TFT_DEVICE_ID --expected-boot CURRENT_32_HEX_BOOT_ID --expected-revision 8 --acknowledge-panel-only --confirm BIND --config ./config.json --data ./data
```

把命令里的 `8` 替换为本次实际观察到的板上修订号。绑定成功后用该配置重新启动正常网关，等待工作区显示新心跳。网站短期放行和现场 ARM 由操作者分别开启。若初始硬件修订为 8，新登记的第一笔写入由网关修订 0 进到 1，屏幕控制器证据同时记录硬件修订从 8 进到 9。每次执行都校验启动标识和两端计数，重新上电导致标识变化时会暂停执行，已有执行记录和绑定始终保留供核对。

### GPIO 夹具路径

先按 [固件说明](../firmware/esp32-s3/README.md)编译、烧录、接线。GPIO4 仅连接限流电阻和低压 LED；不连接电机、继电器、加热器或市电。

```powershell
node cli.mjs status --config ./config.json --data ./data
node cli.mjs run --config ./config.json --data ./data --enable-device-io
```

只有 `run --enable-device-io` 会打开显式配置的设备端口。启动时自动只读探测，**不会自动输出**；串口打开可能让开发板复位，应等网站收到设备心跳后再按 ARM。不要同时打开 Arduino Serial Monitor，占用串口会使网关连接失败。

在另一个现场终端授予本地短期权限：

```powershell
node cli.mjs arm --device YOUR_DEVICE_ID --seconds 60 --writes 1 --confirm ARM --config ./config.json --data ./data
```

然后：

1. 网站 owner 对设备短期 arm；critical 信号还要另行批准具体任务。
2. 闭合 GPIO6 permit 跳线；按住 GPIO5 ARM 一秒再松开，物理窗口 60 秒，仅允许一次写。
3. 网站提交 `led=true`，expected revision 使用网站最近收到的**网关 revision**。
4. 网关重新核验网站许可、现场 arm、物理 ARM/permit、任务到期时间、信号和值，记录 SQLite intent 后只发一次写指令。
5. 固件先持久化 intent 与硬件 revision，再写 GPIO4，最后 `digitalRead(GPIO4)` 回传。网站显示的是 GPIO 引脚反馈，不能推定 LED 负载实际发光、产线动作或认证通过。

现场撤销权限：

```powershell
node cli.mjs disarm --device YOUR_DEVICE_ID --config ./config.json --data ./data
```

本地 disarm、网站撤销、断连都会阻止后续命令；它们不保证撤销已发到设备的动作。GPIO6 打开时，当前固件会将 GPIO4 拉低并在曾为高时进入需恢复状态。该 permit、ARM 与网站都不是安全功能；真实设备的急停、安全联锁、限位必须由独立现场硬件/控制系统负责。

## 3. 八向量实证流程

`cme_vector` 仅接收整数 0..7：`C=(v>>2)&1`、`M=(v>>1)&1`、`E=v&1`。ESP32-S3 自己求 `Y=E&&(C||M)`，输出 GPIO4，再读回 GPIO4。网站/网关不发送 expected Y，也不把 expected 当 actual。

每个向量一个任务，逐个等待回执后使用下一个网关 revision。当前后端每设备只允许一个 queued/claimed 任务。现场本地 arm 默认一次写；明确安排八次低压测试时可 `--writes 8`，有效期仍最多 120 秒。**物理 ARM 每次写都消耗，需要用户逐次按住一秒再松开**；时间不够就重新 arm，过期任务不能自动续期。

成功反馈包含：

```json
{
  "executed": true,
  "revision": 1,
  "evidence": {
    "protocol": "serial",
    "source": "esp32-s3-tc1",
    "readbackQuality": "GPIO_READBACK",
    "quality": "GPIO_READBACK",
    "vectorIndex": 3,
    "inputs": { "C": false, "M": true, "E": true },
    "actualY": true,
    "readback": true,
    "hardwareRevision": 1,
    "deviceTimestamp": { "bootId": "example-only", "tickMs": 4000 },
    "sourceTimestamp": null,
    "receivedAt": "2026-11-12T00:00:00.000Z"
  }
}
```

`revision` 是网关 intent 尝试序号；`hardwareRevision` 是固件 NVS 序号，两者可不同，禁止互相自动覆盖。`deviceTimestamp` 是启动标识+设备 uptime，不是假造的 UTC 时间。后端将八个同设备、不同向量的成功任务显式导入外部批次，再按规格逐向量审核；不会因为 ACK 成功自动通过商业验收或触发付款。独立审阅和付款授权在网站业务层完成。

## 4. 不确定状态与恢复

网关采用 **at-most-once 输出尝试**，不宣称跨网络、数据库与硬件的 exactly-once：

- SQLite WAL/FULL 在输出前持久化 intent；每个 job ID/幂等 key 内容不可改变。
- 已消费任务不会再次下发；只重发相同结果直到服务器明确 `{ok:true}`。
- 写超时、掉电、连接中断或 intent 后崩溃，设备可能已经动作。结果记 `uncertain`，本地与服务器阻止继续输出；绝不因为没收到 ACK 自动重试。
- `executed:true` 表示网关已开始输出尝试，**不证明物理动作**。预检失败为 `false` 且网关 revision 不加；进入 intent 后即使设备明确拒绝，网关 revision 也加一。
- worker 重启撤销所有本地 arm；配置变更、服务器发现网关 journal 回退或异常前跳也会锁定。

恢复顺序：停止新增任务，现场确认输出和被控对象状态；让旧结果重传并确认服务器已记录；对照网站 known gateway revision 与本地 `status`。不得删除 journal、重置 revision、抹去 MCU NVS 来“修复”错误。

固件因断电 intent/permit 变化被锁定时，确认安全后闭合 permit、按住物理 ARM **三秒**进行现场恢复，硬件序号增加，输出为低。网关本地另行恢复：

```powershell
node cli.mjs reconcile --device YOUR_DEVICE_ID --revision 8 --observed-revision 8 --reason "已现场确认GPIO4为低，核对服务器已知网关revision=8与任务回执" --confirm RECONCILE --config ./config.json --data ./data
```

`--revision` 必须等于当前本地值；`--observed-revision` 只能显式保持或增加，不会自动追平、不能回退。若本地数据库丢失，先恢复备份并调查；只有现场人工确认、服务器已知序号及任务历史一致后才可补齐，不能用 MCU 硬件序号替代。网站 owner 再用带具体原因的 clearUncertain 清锁，最后重新授予各层 arm。未完结 intent 不允许人工清除；未知 physical 状态必须先查清。

显示专用固件没有 GPIO 恢复按钮，使用独立的**人工硬件清锁**命令。先停止 worker，确认先前不确定回执已被服务器 ACK，并核对设备当前 bootId 与 hardwareRevision，再执行：

```powershell
node cli.mjs panel-reconcile --device YOUR_TFT_DEVICE_ID --expected-boot REPLACE_WITH_CURRENT_32_HEX_BOOT_ID --expected-revision 8 --acknowledge-panel-only --reason "已核对设备状态与服务器回执，明确仅清除显示能力的不确定锁" --confirm RECONCILE --config ./config.json --data ./data
```

该命令取得同一个 worker 锁，只打开明确配置的专用串口。它先读取 HELLO/PANEL，匹配专用固件、bootId 与硬件序号，才发送 `PANELRECONCILE`。不会发送测试向量、写 GPIO 或自动授予许可；硬件保持已消耗的 revision，仅增加 NVS `reconcileCount` 并记录本地审计。回复丢失不会自动重发。成功也不自动解除网关 journal 或服务器的锁；分别完成上面的 `reconcile` 和网站 owner 核实后，再重新 arm。后续执行仍需新的实际黑白参考校准，清锁本身不构成 `panelReady`。

一台电脑/数据目录只允许一个 worker（PID 锁）；不要多个网关进程使用同一设备 token 或串口。锁残留会核验原 PID；无法读取的锁需要人工检查。现场 CLI 操作不启动 crash recovery，不会把在跑的 worker 误当崩溃。

## 5. 其他真实协议适配器

这些适配器已通过本机协议服务器集成测试，未连接客户设备。新增真实设备前，必须由设备所有者配置单个 endpoint 和信号，使用隔离测试负载验证；模板不等于产线接入证明。

网站登记工业模板后可下载 `twincircuit-gateway.json` 和一次性环境变量文件。JSON 中 `enabled/outputsEnabled` 均关闭，设备地址/寄存器/NodeId/主题是待核实的映射；它不是设备自动发现或厂家配置导入。先把下载文件保存为现场 `config.json`，按下表补全真实配置并用只读信号确认连接，再由现场 owner 开启明确的写白名单。原始 token 文件只给现场进程加载，不能上传仓库；Node 24 可用 `node --env-file=./gateway-device.env cli.mjs run --config ./config.json --data ./data --enable-device-io`，或改为系统环境变量/服务凭据。网站部署与网关安装是两个独立进程，网页不会安装驱动或启动现场网关。

| 协议 | 本地固定映射 | 写入与反馈边界 |
| --- | --- | --- |
| Modbus TCP | host/port/unitId；signal 的零基地址与 area | FC05 单 coil 或 FC06 单 UInt16 register；写响应后 FC01/02/03/04 读回；可固定独立 feedbackArea/feedbackAddress；不开放批量或任意地址写 |
| MQTT | 证书/环境凭证；精确 commandTopic/feedbackTopic | QoS0、retain=false、不重发；必须收到匹配 jobId/nonce/key 的非 retained 新反馈；broker 在线不代表执行器在线 |
| OPC UA | 固定 NodeId、Boolean/UInt16/Int16/Double | 默认 SignAndEncrypt/Basic256Sha256；显式信任服务器证书；写后以 maxAge=0 读回 Good scalar；保留设备提供的 source/server 时间 |

Modbus 没有身份认证和设备 UTC 时间，仅适用于隔离现场网络；回执 `sourceTimestamp:null`。配置 `interlocks:[{"signal":"permit","equals":true}]` 可检查 Modbus/OPC UA 的固定读信号，但它只是流程许可，不是安全等级联锁。

若现场接线能提供独立 DI 反馈，可把请求 coil 与另一地址的 DI 固定关联，例如 `{ "type":"boolean", "write":true, "area":"coil", "address":0, "feedbackArea":"discrete-input", "feedbackAddress":1, "feedbackSettleMs":200 }`。这里 0/1 是待厂家手册核对的**示例零基地址**。网关只发送一次 FC05，再等待本地配置的 0..2000ms，读取一次 FC02；不因为反馈未到而重写或轮询重试。回执保留命令与反馈 mapping。DI 触点只能证明该反馈电路状态；同 coil 的读回通常只是控制器命令状态，都不等于灯光、机械或生产质量证明。

MQTT 建议 `mqtts`，`usernameEnv/passwordEnv` 与可选 `caFile/certificateFile/privateKeyFile`。broker ACL 只给对应设备的两个 topic。接收端须自己检查 expiry、持久化幂等 key、在操作前记 intent，并返回真实应用反馈：

```json
{"jobId":"same-id","nonce":"same-nonce","idempotencyKey":"same-key","value":true,"quality":"good","sourceTimestamp":"actual-device-UTC-ISO"}
```

设备反馈时间须在 `feedbackMaxAgeMs`（默认5000ms）内，要求现场时钟同步；超时/不匹配/坏质量都会不确定，不自动 republish。未实现此接收契约的 MQTT 设备只能待接入，不能直接控制。

OPC UA `trustedServerCertificate` 放 owner 审核过的 DER 证书，PKI 在 data/opcua-pki/设备ID；匿名或 `usernameEnv/passwordEnv` 身份取决于服务器。服务器还须按自己的策略信任网关客户端证书并授权这些 NodeId。只在隔离测试明确设置 `securityMode:"None",allowInsecure:true`；不得用自动接受所有未知证书替代信任配置。

电子检测可复用低压夹具指示/读回；装配、分拣、环境控制需设备厂家提供可安全映射的非安全信号后再启用。当前不提供通用电机/加热/安全设备写入模板。

## 6. 服务接口与部署

`POST /api/gateway/pull`、`POST /api/gateway/result` 使用 `Authorization: Bearer tc_device_...`。浏览器 cookie/CSRF 不用于现场网关；设备 token 只允许对应设备拉任务/回结果，不能创建任务或审批。pull 当前是立即轮询（默认1500ms），不是持久连接。重复 result 必须字节意义相同且服务器 ACK，ACK 丢失只重传结果。

网关需要到自己网站的出站 HTTPS、到显式允许现场 endpoint 的本地访问；不需要对公网开放现场端口。作为独立受限用户服务运行，机器重启后必须重新现场 arm。串口使用运行服务的用户权限。日志不打印 token/密码。主机时钟应同步；设备 lease 通过当前 bootId+uptime 转换，CRC 只防串口损坏，不是数字签名或硬件身份认证。

## 7. 验证

1.2增加可选TFT诊断：serial设备明确配置 `displayTelemetry:true` 后，HELLO之后只读查询DISPLAY并随state.display上报；默认false完全保留旧HELLO字节流。驱动/原始ID不代表可见性，visibleVerified必须false；诊断坏JSON/超时只记录显示错误，不破坏HELLO或授予输出许可。用户照片的人工确认独立记录。详见 [TFT.md](../docs/TFT.md)。

```powershell
npm ci
npm test
```

测试会只在 `127.0.0.1` 随机端口启动真实本地 Modbus TCP 字节服务器、MQTT broker、OPC UA server、HTTP 队列，以及 TC1 字节流固件协议测试端。验证写读、超时不重试、ACK 重传、journal 崩溃恢复、白名单/权限/过期、八向量 actualY 原样保留。串口协议测试用 TCP 字节流，不等同于 USB 硬件测试；固件编译结果与实物测试需分别记录。

显示诊断基线套件为 15 项，新增显示专用协议/人工恢复/CLI 锁 9 项、独立 Modbus DI 1 项后，完整网关套件 **25/25** 通过（本地协议服务器，不开 COM）。见 [测试报告](../docs/validation/gateway-panel-tests.json) 与 [完整日志](../docs/validation/gateway-panel-tests.txt)。[干净生产安装](../docs/validation/gateway-install.json) 另验证 `npm ci --omit=dev --offline` 及三个可选依赖的实际导入/串口原生绑定，未开设备。网站生产 COPY 树的 [零依赖启动](../docs/validation/production-startup.json) 与网关安装分开验证；没有执行 Docker 构建。实体 TFT 烧录、GRAM 读回、用户照片与支付交易分别记录，不能从自动测试相互推导。
