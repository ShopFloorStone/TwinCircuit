import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { createHash } from 'node:crypto';
import { requireCondition, expiryMs, jobIdentity, deviceFingerprint } from './config.mjs';
const stamp = () => new Date().toISOString();
const hash = job => createHash('sha256').update(JSON.stringify(jobIdentity(job))).digest('hex');
export class GatewayJournal {
  constructor(file, { recover = true } = {}) {
    if (file !== ':memory:') mkdirSync(dirname(file), { recursive: true });
    this.db = new DatabaseSync(file); this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA busy_timeout=5000;
      CREATE TABLE IF NOT EXISTS devices(id TEXT PRIMARY KEY, revision INTEGER NOT NULL DEFAULT 0,armed_until INTEGER NOT NULL DEFAULT 0,writes_left INTEGER NOT NULL DEFAULT 0,blocked INTEGER NOT NULL DEFAULT 0,connected INTEGER NOT NULL DEFAULT 0,reason TEXT,config_hash TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,device_id TEXT NOT NULL,key TEXT UNIQUE NOT NULL,hash TEXT NOT NULL,job TEXT NOT NULL,status TEXT NOT NULL,result TEXT,acked INTEGER NOT NULL DEFAULT 0,started_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS held(device_id TEXT PRIMARY KEY,job TEXT NOT NULL,hash TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS panel_bindings(device_id TEXT PRIMARY KEY,boot_id TEXT NOT NULL,hardware_base_revision INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT NOT NULL,device_id TEXT NOT NULL,event TEXT NOT NULL,detail TEXT NOT NULL);`);
    if (recover) this.recover();
  }
  close() { this.db.close(); }
  transaction(fn) { this.db.exec('BEGIN IMMEDIATE'); try { const result = fn(); this.db.exec('COMMIT'); return result; } catch (e) { this.db.exec('ROLLBACK'); throw e; } }
  audit(id, event, detail) { this.db.prepare('INSERT INTO audit(at,device_id,event,detail) VALUES(?,?,?,?)').run(stamp(), id, event, JSON.stringify(detail)); }
  panelBinding(id) {
    return this.db.prepare('SELECT boot_id AS bootId,hardware_base_revision AS hardwareBaseRevision FROM panel_bindings WHERE device_id=?').get(id) ?? null;
  }
  assertCanBindPanel(device) {
    const id = device.deviceId;
    requireCondition(device.enabled && device.protocol === 'serial' && device.capability === 'tft-panel' && device.outputsEnabled && device.signals.panel_vector?.write, 'Select an enabled dedicated TFT panel_vector configuration for commissioning');
    const current = this.db.prepare('SELECT * FROM devices WHERE id=?').get(id);
    requireCondition(current && !current.blocked && current.revision === 0 && !current.armed_until && !current.writes_left, 'Binding requires an existing disarmed, unblocked, unused local registration at revision 0');
    requireCondition(!this.panelBinding(id), 'This registration already has a panel binding');
    requireCondition(!this.held(id) && !this.db.prepare('SELECT 1 FROM jobs WHERE device_id=? LIMIT 1').get(id), 'Existing deliveries or job history prevent first binding');
    requireCondition(current.config_hash === device.configFingerprint || current.config_hash === deviceFingerprint({ ...device, outputsEnabled: false }), 'Only the previously registered TFT configuration can be commissioned');
    return current;
  }
  bindPanel(device, bootId, hardwareBaseRevision) {
    return this.transaction(() => {
      const previous = this.assertCanBindPanel(device);
      this.db.prepare('INSERT INTO panel_bindings VALUES(?,?,?)').run(device.deviceId, bootId, hardwareBaseRevision);
      this.db.prepare('UPDATE devices SET config_hash=? WHERE id=?').run(device.configFingerprint, device.deviceId);
      this.audit(device.deviceId, 'panel-first-binding', { bootId, hardwareBaseRevision, gatewayBaseRevision: 0, previousConfig: previous.config_hash, nextConfig: device.configFingerprint });
      return { deviceId: device.deviceId, bootId, hardwareBaseRevision, gatewayBaseRevision: 0, localArm: false };
    });
  }
  register(device) { this.transaction(() => { const old = this.db.prepare('SELECT * FROM devices WHERE id=?').get(device.deviceId); if (!old) this.db.prepare('INSERT INTO devices(id,config_hash) VALUES(?,?)').run(device.deviceId, device.configFingerprint); else if (old.config_hash !== device.configFingerprint) { this.db.prepare('UPDATE devices SET config_hash=?,blocked=1,armed_until=0,writes_left=0,reason=? WHERE id=?').run(device.configFingerprint, 'Configuration changed; manual reconciliation required', device.deviceId); this.audit(device.deviceId, 'configuration-changed', {}); } }); }
  state(deviceId) { const d = this.db.prepare('SELECT * FROM devices WHERE id=?').get(deviceId); requireCondition(d, 'Device is not registered locally'); return { deviceId, revision: d.revision, armedUntil: d.armed_until > Date.now() && d.writes_left > 0 ? new Date(d.armed_until).toISOString() : null, writesLeft: d.writes_left, blocked: Boolean(d.blocked), connected: Boolean(d.connected), reason: d.reason }; }
  arm(id, seconds, writes = 1, maxSeconds = 120) { requireCondition(Number.isSafeInteger(seconds) && seconds >= 1 && seconds <= maxSeconds && Number.isSafeInteger(writes) && writes >= 1 && writes <= 10, 'Invalid arm duration or write budget'); this.transaction(() => { requireCondition(!this.state(id).blocked, 'Blocked device requires manual reconciliation'); const until = Date.now() + seconds * 1000; this.db.prepare('UPDATE devices SET armed_until=?,writes_left=? WHERE id=?').run(until, writes, id); this.audit(id, 'local-arm', { seconds, writes }); }); return this.state(id); }
  disarm(id, reason = 'Local disarm') { this.db.prepare('UPDATE devices SET armed_until=0,writes_left=0,reason=? WHERE id=?').run(reason, id); this.audit(id, 'local-disarm', { reason }); }
  connection(id, connected, reason = null) { this.db.prepare('UPDATE devices SET connected=?,reason=CASE WHEN blocked=1 AND ?=1 THEN reason ELSE ? END WHERE id=?').run(connected ? 1 : 0, connected ? 1 : 0, reason, id); if (!connected) this.disarm(id, reason || 'Device disconnected'); }
  block(id, reason) { this.db.prepare('UPDATE devices SET blocked=1,armed_until=0,writes_left=0,reason=? WHERE id=?').run(reason, id); this.audit(id, 'blocked', { reason }); }
  assertRecoveryAllowed(id) { requireCondition(!this.db.prepare("SELECT id FROM jobs WHERE device_id=? AND (status='intent' OR acked=0)").get(id), 'A pending intent or unacknowledged result must be resolved before reconciliation'); return this.state(id); }
  reconcile(id, expectedRevision, reason, observedRevision) { requireCondition(typeof reason === 'string' && reason.trim().length >= 10 && reason.length <= 1000, 'A specific manual reconciliation reason is required'); return this.transaction(() => { requireCondition(!this.db.prepare("SELECT id FROM jobs WHERE device_id=? AND (status='intent' OR acked=0)").get(id), 'A pending intent or unacknowledged result must be resolved before reconciliation'); const state = this.state(id); requireCondition(state.revision === expectedRevision, 'Reconciliation revision conflict'); const revision = observedRevision ?? state.revision; requireCondition(Number.isSafeInteger(revision) && revision >= state.revision && revision <= 0xffffffff, 'Observed revision cannot go backwards'); this.db.prepare('UPDATE devices SET revision=?,blocked=0,armed_until=0,writes_left=0,reason=? WHERE id=?').run(revision, 'Manually reconciled; local re-arm required', id); const held = this.held(id); this.clearHeld(id); this.audit(id, 'manual-reconciliation', { expectedRevision, observedRevision: revision, reason, abandonedHeldJobId: held?.id ?? null }); return this.state(id); }); }
  prior(job) { const row = this.db.prepare('SELECT * FROM jobs WHERE id=? OR key=?').get(job.id, job.idempotencyKey); if (!row) return null; requireCondition(row.id === job.id && row.hash === hash(job), 'Job ID/idempotency key was reused with different content', 'KEY_CONFLICT'); return row.result ? JSON.parse(row.result) : null; }
  begin(deviceId, job) { return this.transaction(() => { requireCondition(!this.db.prepare('SELECT id FROM jobs WHERE id=? OR key=?').get(job.id, job.idempotencyKey), 'Job was already consumed'); requireCondition(!this.db.prepare("SELECT id FROM jobs WHERE device_id=? AND status='intent'").get(deviceId), 'Another output is still in progress'); const state = this.state(deviceId); requireCondition(!state.blocked, 'Device is blocked'); requireCondition(state.armedUntil && Date.parse(state.armedUntil) > Date.now() && state.writesLeft > 0, 'Local arm is absent or expired', 'DISARMED'); requireCondition(state.revision === job.revision, 'Local device revision conflict', 'REVISION_CONFLICT'); requireCondition(expiryMs(job.expiresAt) > Date.now(), 'Job expired before intent commit', 'EXPIRED'); const revision = state.revision + 1; requireCondition(revision <= 0xffffffff, 'Revision exhausted'); this.db.prepare('INSERT INTO jobs VALUES(?,?,?,?,?,?,NULL,0,?)').run(job.id, deviceId, job.idempotencyKey, hash(job), JSON.stringify(job), 'intent', stamp()); this.db.prepare('UPDATE devices SET revision=?,writes_left=writes_left-1 WHERE id=?').run(revision, deviceId); this.audit(deviceId, 'intent-before-output', { jobId: job.id, revision }); return revision; }); }
  reject(deviceId, job, reason) { const prior = this.prior(job); if (prior) return prior; const result = { jobId: job.id, nonce: job.nonce, status: 'failed', error: String(reason).slice(0, 1000), result: { executed: false, revision: this.state(deviceId).revision, signal: job.payload?.signal ?? null, requestedValue: job.payload?.value ?? null, evidence: { quality: 'not-executed', source: 'gateway-preflight', sourceTimestamp: null, receivedAt: stamp() } } }; this.db.prepare('INSERT INTO jobs VALUES(?,?,?,?,?,?,?,?,?)').run(job.id, deviceId, job.idempotencyKey, hash(job), JSON.stringify(job), 'failed', JSON.stringify(result), 0, stamp()); this.audit(deviceId, 'preflight-rejected', { jobId: job.id, reason: result.error }); return result; }
  finish(deviceId, job, result) { this.transaction(() => { const row = this.db.prepare('SELECT status FROM jobs WHERE id=?').get(job.id); requireCondition(row?.status === 'intent', 'Only an intent can be completed'); this.db.prepare('UPDATE jobs SET status=?,result=? WHERE id=?').run(result.status, JSON.stringify(result), job.id); if (result.status === 'uncertain') this.block(deviceId, 'Uncertain output; physical check and manual reconciliation required'); this.audit(deviceId, 'result-recorded', { jobId: job.id, status: result.status }); }); return result; }
  pending(deviceId) { return this.db.prepare('SELECT result FROM jobs WHERE device_id=? AND acked=0 AND result IS NOT NULL ORDER BY started_at').all(deviceId).map(r => JSON.parse(r.result)); }
  acknowledge(jobId) { this.db.prepare('UPDATE jobs SET acked=1 WHERE id=? AND result IS NOT NULL').run(jobId); }
  held(deviceId) { const r = this.db.prepare('SELECT job FROM held WHERE device_id=?').get(deviceId); return r ? JSON.parse(r.job) : null; }
  hold(deviceId, job) { const previous = this.db.prepare('SELECT hash FROM held WHERE device_id=?').get(deviceId); requireCondition(!previous || previous.hash === hash(job), 'Server delivered a second job while one is awaiting local permission'); if (!previous) this.db.prepare('INSERT INTO held VALUES(?,?,?)').run(deviceId, JSON.stringify(job), hash(job)); }
  clearHeld(deviceId) { this.db.prepare('DELETE FROM held WHERE device_id=?').run(deviceId); }
  recover() { for (const row of this.db.prepare("SELECT * FROM jobs WHERE status='intent'").all()) { const job = JSON.parse(row.job), revision = this.db.prepare('SELECT revision FROM devices WHERE id=?').get(row.device_id).revision; const result = { jobId: job.id, nonce: job.nonce, status: 'uncertain', error: 'Gateway restarted after intent; output was not retried', result: { executed: true, revision, signal: job.payload.signal, requestedValue: job.payload.value, evidence: { quality: 'unconfirmed', source: 'gateway-crash-recovery', sourceTimestamp: null, receivedAt: stamp() } } }; this.finish(row.device_id, job, result); } this.db.exec('UPDATE devices SET armed_until=0,writes_left=0,connected=0'); }
}



