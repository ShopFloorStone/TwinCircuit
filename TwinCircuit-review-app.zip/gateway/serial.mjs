import { randomBytes } from 'node:crypto';
import { GatewayError, requireCondition, expiryMs } from './config.mjs';
import { parsePanelState, parsePanelResult, panelRevisionMatches } from './panel.mjs';
export function crc32(text) { let crc = 0xffffffff; for (const byte of Buffer.from(text)) { crc ^= byte; for (let i = 0; i < 8; i++) crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0); } return (~crc >>> 0).toString(16).padStart(8, '0'); }
export const frame = body => `${body}|${crc32(body)}\n`;
export function parseFrame(line) { requireCondition(typeof line === 'string' && line.length < 3072, 'Oversized serial frame'); const split = line.lastIndexOf('|'); requireCondition(split > 0 && /^[0-9a-f]{8}$/i.test(line.slice(split + 1)) && crc32(line.slice(0, split)) === line.slice(split + 1).toLowerCase(), 'Serial CRC mismatch'); return line.slice(0, split).split('|'); }
const uint = value => { requireCondition(/^(0|[1-9][0-9]{0,9})$/.test(value) && Number(value) <= 0xffffffff, 'Invalid device integer'); return Number(value); };
const bool = value => { requireCondition(value === '0' || value === '1', 'Invalid device bit'); return value === '1'; };
// Device-reported driver diagnostics never establish that a screen is visible.
export function parseDisplayDiagnostics(json) {
  requireCondition(typeof json === 'string' && Buffer.byteLength(json) <= 2048, 'Oversized display diagnostics');
  const d = JSON.parse(json), integer = (v, max = 0xffffffff) => Number.isSafeInteger(v) && v >= 0 && v <= max;
  requireCondition(d && typeof d === 'object' && !Array.isArray(d) && Object.keys(d).length <= 30, 'Invalid display diagnostic object');
  requireCondition((d.registerSampledAtTickMs === undefined || integer(d.registerSampledAtTickMs)) && (d.readRegisterHz === undefined || d.readRegisterHz === 1000000) && (d.sampleScope === undefined || d.sampleScope === 'current-display-query'), 'Invalid display register sampling metadata');
  const sampling = Object.fromEntries(['registerSampledAtTickMs', 'readRegisterHz', 'sampleScope'].filter(k => d[k] !== undefined).map(k => [k, d[k]]));
  if (d.enabled === false) {
    requireCondition(d.controller === null && d.rawControllerId === null && d.visibleVerified === false && d.initStatus === 'disabled' && d.width === 0 && d.height === 0 && d.rotation === 0 && d.touchEnabled === false && d.sdEnabled === false, 'Invalid disabled display diagnostics');
    return { enabled: false, controller: null, rawControllerId: null, visibleVerified: false, width: 0, height: 0, rotation: 0, initStatus: 'disabled', touchEnabled: false, sdEnabled: false, ...sampling, diagnosticStatus: 'reported', receivedAt: new Date().toISOString() };
  }
  requireCondition(typeof d.enabled === 'boolean' && d.visibleVerified === false && typeof d.controllerAssumed === 'boolean', 'Display diagnostics cannot verify physical visibility');
  requireCondition(d.controller === 'ILI9341' || d.controller === null, 'Unknown display controller claim');
  requireCondition(d.rawControllerId === null || typeof d.rawControllerId === 'string' && /^0x[0-9a-f]{8}$/i.test(d.rawControllerId), 'Invalid raw display ID');
  requireCondition(Array.isArray(d.rawControllerIdBytes) && d.rawControllerIdBytes.length === 4 && d.rawControllerIdBytes.every(v => integer(v, 255)), 'Invalid display ID bytes');
  if (d.rawControllerId !== null) requireCondition(d.rawControllerId.toLowerCase() === '0x' + d.rawControllerIdBytes.map(v => v.toString(16).padStart(2, '0')).join(''), 'Display ID bytes do not match');
  requireCondition(typeof d.controllerIdAvailable === 'boolean' && ['width', 'height', 'nativeWidth', 'nativeHeight'].every(k => integer(d[k], 1024)) && integer(d.rotation, 3), 'Invalid display dimensions or ID status');
  requireCondition(d.controllerIdAvailable === (!d.rawControllerIdBytes.every(v => v === 0) && !d.rawControllerIdBytes.every(v => v === 255)), 'Inconsistent display ID availability');
  requireCondition(['driver-begin-returned', 'not-started'].includes(d.initStatus) && d.mode === 'hardware-spi' && d.readRegister === '0xD3', 'Invalid display driver status');
  requireCondition((d.gatewayHelloAgeMs === null || integer(d.gatewayHelloAgeMs)) && typeof d.serialHeartbeatFresh === 'boolean' && d.touchEnabled === false && d.sdEnabled === false, 'Invalid display diagnostic status');
  requireCondition(d.pins && typeof d.pins === 'object' && !Array.isArray(d.pins) && Object.keys(d.pins).length === 6 && ['sck', 'mosi', 'miso', 'cs', 'dc', 'rst'].every(k => integer(d.pins[k], 48)), 'Invalid display diagnostic pins');
  requireCondition((d.powerMode === undefined || integer(d.powerMode, 255)) && (d.spiHz === undefined || integer(d.spiHz, 80000000)), 'Invalid display SPI diagnostic values');
  const fields = ['enabled', 'controller', 'controllerAssumed', 'rawControllerId', 'rawControllerIdBytes', 'controllerIdAvailable', 'width', 'height', 'nativeWidth', 'nativeHeight', 'rotation', 'initStatus', 'mode', 'readRegister', 'gatewayHelloAgeMs', 'serialHeartbeatFresh', 'pins', 'touchEnabled', 'sdEnabled', 'powerMode', 'spiHz'];
  return { ...Object.fromEntries(fields.map(k => [k, d[k]])), ...sampling, visibleVerified: false, diagnosticStatus: 'reported', receivedAt: new Date().toISOString() };
}
export class SerialAdapter {
  constructor(device, { onDisconnect = () => {}, transportFactory } = {}) { this.device = device; this.onDisconnect = onDisconnect; this.transportFactory = transportFactory; this.pending = new Set(); this.buffer = ''; this.connected = false; this.closing = false; }
  async connect() {
    if (this.connected) return;
    if (this.transportFactory) this.port = await this.transportFactory();
    else { let SerialPort; try { ({ SerialPort } = await import('serialport')); } catch { throw new GatewayError('Install the optional serialport dependency in gateway/', 'MISSING_DEPENDENCY'); } this.port = new SerialPort({ path: this.device.path, baudRate: this.device.baudRate ?? 115200, autoOpen: false, lock: true }); await new Promise((resolve, reject) => this.port.open(error => error ? reject(error) : resolve())); }
    const port = this.port; this.buffer = ''; port.on('data', chunk => { if (this.port === port) this.receive(chunk); }); port.on('error', e => { if (this.port === port) this.disconnected(e); }); port.on('close', () => { if (this.port === port) this.disconnected(new Error('Serial connection closed')); }); this.connected = true; this.closing = false;
  }
  disconnected(error) { this.connected = false; for (const p of this.pending) p.reject(error); this.pending.clear(); if (!this.closing) this.onDisconnect(error.message); }
  receive(chunk) { this.buffer += chunk.toString('utf8'); if (this.buffer.length > 4096) { this.buffer = ''; this.disconnected(new Error('Serial frame buffer exceeded limit')); this.port.destroy?.(); return; } let cut; while ((cut = this.buffer.indexOf('\n')) >= 0) { const line = this.buffer.slice(0, cut).replace(/\r$/, ''); this.buffer = this.buffer.slice(cut + 1); let fields; try { fields = parseFrame(line); } catch { continue; } for (const pending of [...this.pending]) if (pending.match(fields)) { this.pending.delete(pending); pending.resolve(fields); } } }
  request(body, match) { requireCondition(this.connected, 'Serial port is disconnected'); return new Promise((resolve, reject) => { const timer = setTimeout(() => { this.pending.delete(p); reject(new GatewayError('Device reply timed out; a write is never automatically retried', 'REPLY_TIMEOUT')); }, this.device.timeoutMs); const p = { match, resolve: value => { clearTimeout(timer); resolve(value); }, reject: error => { clearTimeout(timer); reject(error); } }; this.pending.add(p); this.port.write(frame(body), error => { if (error) { this.pending.delete(p); p.reject(error); } }); }); }
  async probe() {
    const nonce = randomBytes(12).toString('hex'), began = Date.now();
    const f = await this.request(`TC1|HELLO|${nonce}`, f => f[0] === 'TC1' && f[1] === 'STATE' && f[2] === nonce);
    requireCondition(f.length === 10 && /^[0-9a-f]{32}$/i.test(f[3]), 'Invalid S3 state response');
    this.lastState = { bootId: f[3], hardwareRevision: uint(f[4]), tickMs: uint(f[5]), armed: bool(f[6]), permit: bool(f[7]), blocked: bool(f[8]), readback: bool(f[9]), receivedAtMs: Date.now(), roundTripMs: Date.now() - began };
    if (this.device.capability === 'tft-panel') {
      const panelNonce = randomBytes(12).toString('hex');
      const reply = await this.request(`TC1|PANEL|${panelNonce}`, f => f[0] === 'TC1' && f[1] === 'PANELSTATE' && f[2] === panelNonce);
      requireCondition(reply.length === 4, 'Invalid panel capability response');
      this.lastState.panelCapabilities = parsePanelState(reply[3], this.lastState);
      this.lastState.panelReady = this.lastState.panelCapabilities.ready;
    }
    if (this.device.displayTelemetry === true) {
      try {
        const displayNonce = randomBytes(12).toString('hex');
        const reply = await this.request(`TC1|DISPLAY|${displayNonce}`, f => f[0] === 'TC1' && f[1] === 'DISPLAYSTATE' && f[2] === displayNonce);
        requireCondition(reply.length === 4, 'Invalid display diagnostic response');
        this.lastState.display = parseDisplayDiagnostics(reply[3]);
      } catch (error) {
        this.lastState.display = { enabled: null, visibleVerified: false, diagnosticStatus: 'error', error: String(error.message).slice(0, 200), receivedAt: new Date().toISOString() };
      }
    }
    return this.lastState;
  }
  async preflight(job, panelBinding) {
    const state = await this.probe();
    requireCondition(!state.blocked, 'S3 requires manual reconciliation', 'HARDWARE_BLOCKED');
    if (this.device.capability === 'tft-panel') {
      requireCondition(state.panelReady === true, 'Panel GRAM reference calibration must pass', 'PANEL_NOT_READY');
      requireCondition(!job || job.payload?.signal === 'panel_vector' && panelRevisionMatches(state, job.revision, panelBinding), 'Panel signal and device revision must match the bound board');
    } else requireCondition(state.armed && state.permit, 'S3 physical ARM button and permit jumper are required', 'PHYSICAL_ARM_REQUIRED');
    return state;
  }
  async write(signal, value, job, panelBinding) {
    const state = this.lastState; requireCondition(state, 'Probe the device before writing');
    if (this.device.capability === 'tft-panel') return this.writePanel(signal, value, job, state, panelBinding);
    requireCondition(signal === 'led' && typeof value === 'boolean' || signal === 'cme_vector' && Number.isSafeInteger(value) && value >= 0 && value <= 7, 'Unknown S3 fixture signal');
    const lease = Math.min(4500, expiryMs(job.expiresAt) - Date.now()); requireCondition(lease > state.roundTripMs + 100, 'Lease is too short for this device', 'EXPIRED');
    const deadline = (state.tickMs + (Date.now() - state.receivedAtMs) + lease - state.roundTripMs - 50) >>> 0;
    const body = `TC1|WRITE|${job.id}|${job.nonce}|${job.idempotencyKey}|${state.bootId}|${state.hardwareRevision}|${deadline}|${signal}|${typeof value === 'boolean' ? Number(value) : value}|GPIO_ONLY`;
    const f = await this.request(body, f => f[0] === 'TC1' && f[1] === 'RESULT' && f[2] === job.id && f[3] === job.nonce && f[4] === job.idempotencyKey);
    requireCondition(f.length === 15, 'Invalid S3 result response');
    if (f[5] !== 'OK') { const rejected = f[5] === 'FAILED' && !f[10].includes('UNCERTAIN') && uint(f[6]) === state.hardwareRevision; const e = new GatewayError(`S3 rejected output: ${f[10]}`, rejected ? 'DEVICE_REJECTED' : 'UNCERTAIN'); e.definitiveNotExecuted = rejected; throw e; }
    const hardwareRevision = uint(f[6]), tickMs = uint(f[7]), readback = bool(f[8]); requireCondition(hardwareRevision === state.hardwareRevision + 1 && f[9] === 'GPIO_READBACK', 'S3 result revision or quality mismatch');
    const evidence = { protocol: 'serial', source: 'esp32-s3-tc1', endpointId: this.device.deviceId, quality: 'GPIO_READBACK', readbackQuality: 'GPIO_READBACK', readback, hardwareRevision, deviceTimestamp: { bootId: state.bootId, tickMs }, sourceTimestamp: null, receivedAt: new Date().toISOString(), scope: 'GPIO pin readback only; does not establish LED load operation, physical quality, or industrial certification' };
    if (signal === 'cme_vector') { const vectorIndex = uint(f[11]), inputs = { C: bool(f[12]), M: bool(f[13]), E: bool(f[14]) }; requireCondition(vectorIndex === value && inputs.C === Boolean(value & 4) && inputs.M === Boolean(value & 2) && inputs.E === Boolean(value & 1), 'Device vector echo mismatch'); Object.assign(evidence, { vectorIndex, inputs, actualY: readback }); }
    else requireCondition(signal === 'led' && readback === value && f[11] === '-1', 'GPIO did not read back the requested LED value');
    return evidence;
  }
  async writePanel(signal, value, job, state, panelBinding) {
    requireCondition(signal === 'panel_vector' && Number.isSafeInteger(value) && value >= 0 && value <= 7 && state.panelReady === true && !state.blocked && panelRevisionMatches(state, job.revision, panelBinding), 'Panel-only signal, readiness and revision are required');
    const lease = Math.min(4500, expiryMs(job.expiresAt) - Date.now());
    requireCondition(lease > state.roundTripMs + 100, 'Lease is too short for this device', 'EXPIRED');
    const deadline = (state.tickMs + (Date.now() - state.receivedAtMs) + lease - state.roundTripMs - 50) >>> 0;
    const body = `TC1|PANELWRITE|${job.id}|${job.nonce}|${job.idempotencyKey}|${state.bootId}|${state.hardwareRevision}|${deadline}|panel_vector|${value}|PANEL_ONLY`;
    const f = await this.request(body, f => f[0] === 'TC1' && f[1] === 'PANELRESULT' && f[2] === job.id && f[3] === job.nonce && f[4] === job.idempotencyKey);
    requireCondition(f.length === 6, 'Invalid panel result response');
    const measured = parsePanelResult(f[5], state, value);
    if (measured.status !== 'OK') {
      const rejected = measured.status === 'FAILED' && measured.hardwareRevision === state.hardwareRevision && !String(measured.error).includes('UNCERTAIN');
      const error = new GatewayError(`Panel rejected measurement: ${String(measured.error ?? 'unconfirmed').slice(0, 200)}`, rejected ? 'DEVICE_REJECTED' : 'UNCERTAIN');
      error.definitiveNotExecuted = rejected; throw error;
    }
    // Preserve the complete measured reply. A false result for a HIGH truth-table
    // vector remains false here; only the independent business review judges it.
    return { ...measured, ...(panelBinding ? { panelBinding, gatewayRevision: job.revision + 1 } : {}), protocol: 'serial', source: 'esp32-s3-panel-testcell', endpointId: this.device.deviceId, readbackQuality: 'DISPLAY_PIXEL_READBACK', readback: measured.actualY, hardwareRevision: measured.hardwareRevision, deviceTimestamp: { bootId: state.bootId, tickMs: measured.tickMs }, sourceTimestamp: null, receivedAt: new Date().toISOString() };
  }
  async reconcilePanel(expectedBootId, expectedRevision) {
    requireCondition(this.device.capability === 'tft-panel', 'Hardware reconciliation requires dedicated panel-only firmware');
    const state = await this.probe();
    requireCondition(state.bootId === expectedBootId && state.hardwareRevision === expectedRevision, 'Expected panel boot ID and hardware revision must match the live device');
    const nonce = randomBytes(12).toString('hex');
    const f = await this.request(`TC1|PANELRECONCILE|${nonce}|${state.bootId}|${state.hardwareRevision}|PANEL_ONLY`, f => f[0] === 'TC1' && f[1] === 'PANELRECONCILED' && f[2] === nonce);
    requireCondition(f.length === 4 && Buffer.byteLength(f[3]) <= 2048, 'Invalid panel reconciliation reply');
    const result = JSON.parse(f[3]);
    requireCondition(result && result.status === 'OK' && result.bootId === state.bootId && result.hardwareRevision === state.hardwareRevision && result.blocked === false && result.panelOnly === true && result.gpioOutputsEnabled === false && result.operation === 'panel-reconcile' && Number.isSafeInteger(result.reconcileCount) && result.reconcileCount >= 1 && result.reconcileCount <= 0xffffffff && Number.isSafeInteger(result.tickMs) && result.tickMs >= 0 && result.tickMs <= 0xffffffff, 'Panel reconciliation was not confirmed with unchanged revision');
    // A clear acknowledgement grants no ready/arm state. A subsequent worker
    // must perform a new live PANEL reference calibration before any job.
    this.lastState = null;
    return result;
  }
  async close() { this.closing = true; this.connected = false; if (this.port?.isOpen) await new Promise(resolve => this.port.close(() => resolve())); else this.port?.destroy?.(); }
}
