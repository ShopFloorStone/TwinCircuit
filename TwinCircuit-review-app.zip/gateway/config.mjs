import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
export class GatewayError extends Error { constructor(message, code = 'REJECTED') { super(message); this.code = code; } }
export const requireCondition = (condition, message, code) => { if (!condition) throw new GatewayError(message, code); };
const name = v => typeof v === 'string' && /^[A-Za-z0-9_-]{1,100}$/.test(v);
const int = (v, min, max) => Number.isSafeInteger(v) && v >= min && v <= max;
export const expiryMs = value => typeof value === 'number' && Number.isSafeInteger(value) ? value : typeof value === 'string' ? Date.parse(value) : NaN;
// Delivery status and acknowledgement fields can change; execution identity cannot.
export const jobIdentity = job => ({ id: job.id, deviceId: job.deviceId, nonce: job.nonce, command: job.command, payload: job.payload, expiresAt: expiryMs(job.expiresAt), revision: job.revision, idempotencyKey: job.idempotencyKey, critical: job.critical === true });
export function deviceFingerprint(device) {
  const { displayTelemetry, configFingerprint, ...executionConfig } = device;
  return createHash('sha256').update(JSON.stringify(executionConfig)).digest('hex');
}
export function validateConfig(raw) {
  requireCondition(raw && raw.schemaVersion === 1 && Array.isArray(raw.devices) && raw.devices.length <= 100, 'Invalid gateway configuration');
  const server = new URL(raw.serverUrl); requireCondition(['https:', 'http:'].includes(server.protocol) && !server.username && !server.password && !server.search && !server.hash, 'Invalid server URL');
  requireCondition(server.protocol === 'https:' || ['localhost', '127.0.0.1', '[::1]'].includes(server.hostname) || raw.allowInsecureServer === true, 'HTTP server outside loopback requires explicit allowInsecureServer');
  const ids = new Set(); const config = structuredClone(raw);
  config.pollIntervalMs ??= 1500; requireCondition(int(config.pollIntervalMs, 250, 60000), 'pollIntervalMs must be 250..60000');
  config.maxArmSeconds ??= 120; requireCondition(int(config.maxArmSeconds, 1, 120), 'Local arm may last at most 120 seconds');
  config.agentId ??= 'twincircuit-edge'; requireCondition(name(config.agentId), 'Invalid agentId');
  for (const device of config.devices) {
    if (device.protocol === 'esp32-tft') { device.protocol = 'serial'; requireCondition(device.capability === undefined || device.capability === 'tft-panel', 'esp32-tft cannot use a different capability'); device.capability = 'tft-panel'; }
    if (device.protocol === 'esp32-serial') device.protocol = 'serial';
    requireCondition(name(device.deviceId) && !ids.has(device.deviceId), 'Invalid or duplicate device ID'); ids.add(device.deviceId);
    requireCondition(['serial', 'modbus-tcp', 'mqtt', 'opcua'].includes(device.protocol), 'Unsupported protocol');
    requireCondition(device.capability === undefined || device.protocol === 'serial' && device.capability === 'tft-panel', 'Unsupported device capability');
    requireCondition(typeof device.tokenEnv === 'string' && /^[A-Z][A-Z0-9_]{0,99}$/.test(device.tokenEnv), 'A tokenEnv variable name is required');
    device.enabled = device.enabled === true; device.outputsEnabled = device.outputsEnabled === true;
    requireCondition(device.displayTelemetry === undefined || typeof device.displayTelemetry === 'boolean', 'displayTelemetry must be a boolean');
    requireCondition(device.protocol === 'serial' || device.displayTelemetry !== true, 'Display telemetry is supported only by serial devices');
    device.timeoutMs ??= 3000; requireCondition(int(device.timeoutMs, 100, 15000), 'timeoutMs must be 100..15000');
    requireCondition(device.signals && typeof device.signals === 'object' && !Array.isArray(device.signals) && Object.keys(device.signals).length <= 100, 'A signal allowlist is required');
    if (device.capability === 'tft-panel') requireCondition(Object.keys(device.signals).length === 1 && Object.hasOwn(device.signals, 'panel_vector'), 'TFT panel capability permits only panel_vector');
    if (device.enabled && device.protocol === 'serial') requireCondition(typeof device.path === 'string' && /^(COM[1-9][0-9]{0,3}|\/dev\/[A-Za-z0-9_./-]+)$/.test(device.path) && !device.path.includes('..'), 'Set an explicit COM or /dev path; no port scanning is performed');
    if (device.enabled && device.protocol === 'modbus-tcp') { requireCondition(typeof device.host === 'string' && device.host.length > 0 && !/[\s/@]/.test(device.host), 'Explicit Modbus host required'); device.port ??= 502; device.unitId ??= 1; requireCondition(int(device.port, 1, 65535) && int(device.unitId, 0, 247), 'Invalid Modbus port/unit ID'); }
    if (device.enabled && ['mqtt', 'opcua'].includes(device.protocol)) { const endpoint = new URL(device.url); requireCondition(!endpoint.username && !endpoint.password, 'Credentials belong in environment variables, not endpoint URLs'); requireCondition(device.protocol === 'mqtt' ? ['mqtt:', 'mqtts:'].includes(endpoint.protocol) : endpoint.protocol === 'opc.tcp:', 'Invalid protocol endpoint'); }
    for (const [signalName, signal] of Object.entries(device.signals)) {
      requireCondition(name(signalName) && signal && typeof signal === 'object' && ['boolean', 'number'].includes(signal.type), 'Invalid signal definition');
      signal.write = signal.write === true;
      if (signal.type === 'number') requireCondition(typeof signal.min === 'number' && Number.isFinite(signal.min) && typeof signal.max === 'number' && Number.isFinite(signal.max) && signal.min <= signal.max, 'Numeric signals require explicit min/max');
      if (device.protocol === 'serial') {
        if (device.capability === 'tft-panel') requireCondition(signalName === 'panel_vector' && signal.type === 'number' && signal.min === 0 && signal.max === 7 && signal.integer !== false, 'TFT panel supports panel_vector:integer 0..7 only');
        else requireCondition(signalName === 'led' && signal.type === 'boolean' || signalName === 'cme_vector' && signal.type === 'number' && signal.min === 0 && signal.max === 7 && signal.integer !== false, 'S3 fixture supports led:boolean and cme_vector:integer 0..7 only');
      }
      if (device.protocol === 'modbus-tcp') { requireCondition(['coil', 'holding-register', 'input-register', 'discrete-input'].includes(signal.area) && int(signal.address, 0, 65535), 'Each Modbus signal needs a fixed area and zero-based address'); if (signal.write) requireCondition(['coil', 'holding-register'].includes(signal.area), 'Cannot write a read-only Modbus area'); requireCondition(signal.area === 'coil' || signal.area === 'discrete-input' ? signal.type === 'boolean' : signal.type === 'number' && int(signal.min, 0, 65535) && int(signal.max, 0, 65535) && signal.integer !== false, 'Modbus register adapter supports UInt16 only'); if (signal.feedbackAddress !== undefined) requireCondition(int(signal.feedbackAddress, 0, 65535), 'Invalid feedbackAddress'); }
      if (device.protocol === 'modbus-tcp' && signal.feedbackArea !== undefined) requireCondition(int(signal.feedbackAddress, 0, 65535) && (signal.type === 'boolean' ? ['coil', 'discrete-input'].includes(signal.feedbackArea) : ['holding-register', 'input-register'].includes(signal.feedbackArea)), 'Feedback area/address must be explicitly mapped and match the signal type');
      if (signal.feedbackSettleMs !== undefined) requireCondition(device.protocol === 'modbus-tcp' && int(signal.feedbackSettleMs, 0, 2000), 'Modbus feedbackSettleMs must be 0..2000');
      if (device.protocol === 'mqtt') requireCondition(typeof signal.commandTopic === 'string' && typeof signal.feedbackTopic === 'string' && [signal.commandTopic, signal.feedbackTopic].every(t => t.length > 0 && t.length < 256 && !/[+#\0]/.test(t)), 'MQTT topics must be exact allowlisted topics, without wildcards');
      if (device.protocol === 'opcua') {
        requireCondition(typeof signal.nodeId === 'string' && signal.nodeId.length > 0 && signal.nodeId.length < 500 && ['Boolean', 'UInt16', 'Int16', 'Double'].includes(signal.dataType), 'OPC UA signals require fixed nodeId and explicit supported dataType');
        requireCondition(signal.type === 'boolean' ? signal.dataType === 'Boolean' : signal.dataType !== 'Boolean', 'OPC UA dataType must match the configured signal type');
        if (['UInt16', 'Int16'].includes(signal.dataType)) requireCondition(Number.isSafeInteger(signal.min) && Number.isSafeInteger(signal.max) && signal.min >= (signal.dataType === 'UInt16' ? 0 : -32768) && signal.max <= (signal.dataType === 'UInt16' ? 65535 : 32767) && signal.integer !== false, 'OPC UA integer signal bounds exceed the datatype');
      }
    }
    requireCondition(device.interlocks === undefined || Array.isArray(device.interlocks) && device.interlocks.length <= 20, 'Invalid process interlock list');
    for (const interlock of device.interlocks ?? []) { requireCondition(['modbus-tcp', 'opcua'].includes(device.protocol) && interlock && Object.hasOwn(device.signals, interlock.signal), 'Interlocks must refer to an allowlisted readable signal'); validateValue(device.signals[interlock.signal], interlock.equals); }
    if (device.feedbackMaxAgeMs !== undefined) requireCondition(int(device.feedbackMaxAgeMs, 100, 60000), 'Invalid feedbackMaxAgeMs');
    // This read-only diagnostic changes no output policy or execution identity.
    // Toggling it must preserve the existing output journal and its revision.
    device.configFingerprint = deviceFingerprint(device);
  }
  return config;
}
export async function loadConfig(file) { return validateConfig(JSON.parse(await readFile(file, 'utf8'))); }
export function validateValue(signal, value) { requireCondition(signal.type === 'boolean' ? typeof value === 'boolean' : typeof value === 'number' && Number.isFinite(value) && value >= signal.min && value <= signal.max, 'Value is outside the configured signal type/range'); if (signal.integer !== false && signal.type === 'number') requireCondition(Number.isSafeInteger(value), 'This signal requires an integer'); if (signal.allowedValues) requireCondition(signal.allowedValues.includes(value), 'Value is outside allowedValues'); return value; }
export function validateJob(job, device, timestamp = Date.now()) {
  requireCondition(job && name(job.id) && name(job.nonce) && name(job.idempotencyKey), 'Malformed job identity');
  requireCondition(job.command === 'write' && job.payload && Object.keys(job.payload).sort().join() === 'signal,value', 'Only allowlisted signal writes are supported');
  requireCondition(name(job.payload.signal) && Object.hasOwn(device.signals, job.payload.signal), 'Unknown signal');
  requireCondition(device.outputsEnabled && device.signals[job.payload.signal].write, 'Output is not locally enabled');
  requireCondition(int(job.revision, 0, 0xffffffff), 'Invalid expected revision');
  requireCondition(!job.deviceId || job.deviceId === device.deviceId, 'Job targets a different device');
  requireCondition(Number.isFinite(expiryMs(job.expiresAt)) && expiryMs(job.expiresAt) > timestamp && expiryMs(job.expiresAt) - timestamp <= 300000, 'Job is expired or has an excessive lease', 'EXPIRED');
  validateValue(device.signals[job.payload.signal], job.payload.value); return job;
}
