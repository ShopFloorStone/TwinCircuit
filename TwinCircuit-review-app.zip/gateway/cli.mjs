import { resolve } from 'node:path';
import { mkdirSync, openSync, writeFileSync, readFileSync, unlinkSync, closeSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { loadConfig, requireCondition } from './config.mjs';
import { GatewayJournal } from './journal.mjs';
import { EdgeGateway } from './runtime.mjs';
import { SerialAdapter } from './serial.mjs';
import { reconcilePanelHardware, bindPanelHardware } from './reconcile.mjs';

const help = `TwinCircuit edge gateway (Node 24)
  node cli.mjs status --config ./config.json --data ./data
  node cli.mjs run --config ./config.json --data ./data --enable-device-io
  node cli.mjs arm --device DEVICE --seconds 60 --writes 1 --confirm ARM [--config ... --data ...]
  node cli.mjs disarm --device DEVICE [--config ... --data ...]
  node cli.mjs reconcile --device DEVICE --revision LOCAL_REV --observed-revision SERVER_KNOWN_REV --reason "physical check and server audit details" --confirm RECONCILE [--config ... --data ...]
  node cli.mjs panel-reconcile --device DEVICE --expected-boot BOOT_ID --expected-revision HW_REV --acknowledge-panel-only --reason "manual inspection and prior result review" --confirm RECONCILE [--config ... --data ...]
  node cli.mjs panel-bind --device DEVICE --expected-boot BOOT_ID --expected-revision HW_REV --acknowledge-panel-only --confirm BIND [--config ... --data ...]
No device discovery or IO occurs in status/arm/disarm/reconcile. A run requires explicit IO opt-in.
panel-reconcile opens only the explicitly configured panel port after acquiring the
worker lock; stop the worker first. It sends no vector and does not enable outputs.
Local arm does not replace server owner arm or critical approval.
GPIO devices also require physical ARM/permit; dedicated TFT panel-only firmware
instead requires live black/white controller GRAM reference calibration.`;
function argumentsOf(args) { const out = { command: args.shift() ?? 'help' }; for (let i = 0; i < args.length; i++) { const key = args[i]; requireCondition(/^--[a-z-]+$/.test(key), 'Invalid argument'); if (['--enable-device-io', '--acknowledge-panel-only'].includes(key)) out[key.slice(2)] = true; else { requireCondition(args[i + 1] && !args[i + 1].startsWith('--'), `Missing value for ${key}`); out[key.slice(2)] = args[++i]; } } return out; }
// Exclusive worker lock is acquired before crash recovery, which disarms old arms.
function workerLock(dir) {
  mkdirSync(dir, { recursive: true }); const file = resolve(dir, 'worker.lock'), owner = randomUUID();
  for (let attempt = 0; attempt < 2; attempt++) { try { const fd = openSync(file, 'wx', 0o600); writeFileSync(fd, JSON.stringify({ pid: process.pid, owner, createdAt: new Date().toISOString() })); closeSync(fd); return () => { try { if (JSON.parse(readFileSync(file, 'utf8')).owner === owner) unlinkSync(file); } catch {} }; } catch (e) { if (e.code !== 'EEXIST') throw e; let previous; try { previous = JSON.parse(readFileSync(file, 'utf8')); } catch { throw new Error('Unreadable worker.lock; inspect it manually before removing'); } requireCondition(Number.isSafeInteger(previous.pid) && previous.pid > 0, 'Invalid worker.lock; inspect manually'); try { process.kill(previous.pid, 0); throw new Error(`Gateway worker already running (PID ${previous.pid})`); } catch (probe) { if (probe.code !== 'ESRCH') throw probe; } unlinkSync(file); } }
  throw new Error('Could not acquire gateway worker lock');
}
async function main() {
  const args = argumentsOf(process.argv.slice(2)); if (['help', '--help'].includes(args.command)) { console.log(help); return; }
  requireCondition(['run', 'status', 'arm', 'disarm', 'reconcile', 'panel-reconcile', 'panel-bind'].includes(args.command), help);
  const config = await loadConfig(resolve(args.config ?? './config.json')), dataDir = resolve(args.data ?? './data');
  let unlock, gateway, journal, recoveryAdapter;
  try {
    if (args.command === 'run') { requireCondition(args['enable-device-io'] === true, 'Run requires --enable-device-io after checking every enabled endpoint and allowlist'); requireCondition(config.devices.some(d => d.enabled), 'No enabled devices; config.example.json is intentionally disabled'); unlock = workerLock(dataDir); }
    if (args.command === 'panel-reconcile' || args.command === 'panel-bind') {
      const confirmation = args.command === 'panel-bind' ? 'BIND' : 'RECONCILE';
      requireCondition(args['acknowledge-panel-only'] === true && args.confirm === confirmation, 'Explicit panel-only acknowledgement and command confirmation required');
      requireCondition(config.devices.some(d => d.enabled && d.deviceId === args.device && d.capability === 'tft-panel'), 'Select an enabled dedicated panel-only device');
      unlock = workerLock(dataDir);
    }
    journal = new GatewayJournal(resolve(dataDir, 'gateway.sqlite'), { recover: args.command === 'run' });
    if (args.command === 'panel-bind') {
      const device = config.devices.find(d => d.deviceId === args.device);
      recoveryAdapter = new SerialAdapter(device);
      const result = await bindPanelHardware({ device, adapter: recoveryAdapter, journal, expectedBootId: args['expected-boot'], expectedRevision: args['expected-revision'] === undefined ? NaN : Number(args['expected-revision']), acknowledgePanelOnly: args['acknowledge-panel-only'], confirm: args.confirm });
      console.log(JSON.stringify(result, null, 2));
      return;
    }
    for (const d of config.devices.filter(d => d.enabled)) journal.register(d);
    if (args.command === 'run') {
      gateway = new EdgeGateway({ config, journal, dataDir, log: event => console.error(JSON.stringify({ at: new Date().toISOString(), ...event })) });
      const stop = new AbortController(); const shutdown = () => { stop.abort(); gateway.stopped = true; for (const d of config.devices.filter(d => d.enabled)) journal.disarm(d.deviceId, 'Worker stopping'); }; process.once('SIGINT', shutdown); process.once('SIGTERM', shutdown);
      console.log(JSON.stringify({ event: 'gateway-started', deviceIds: config.devices.filter(d => d.enabled).map(d => d.deviceId), dataDir, ioEnabled: true })); await gateway.run(stop.signal);
    } else if (args.command === 'status') console.log(JSON.stringify({ devices: config.devices.filter(d => d.enabled).map(d => journal.state(d.deviceId)) }, null, 2));
    else { requireCondition(config.devices.some(d => d.enabled && d.deviceId === args.device), 'Select an enabled configured --device'); let result;
      if (args.command === 'arm') { requireCondition(args.confirm === 'ARM', 'Local arm requires --confirm ARM'); result = journal.arm(args.device, Number(args.seconds ?? 60), Number(args.writes ?? 1), config.maxArmSeconds); }
      else if (args.command === 'disarm') { journal.disarm(args.device); result = journal.state(args.device); }
      else if (args.command === 'panel-reconcile') { const device = config.devices.find(d => d.deviceId === args.device); recoveryAdapter = new SerialAdapter(device); result = await reconcilePanelHardware({ device, adapter: recoveryAdapter, journal, expectedBootId: args['expected-boot'], expectedRevision: args['expected-revision'] === undefined ? NaN : Number(args['expected-revision']), reason: args.reason, acknowledgePanelOnly: args['acknowledge-panel-only'], confirm: args.confirm }); }
      else { requireCondition(args.confirm === 'RECONCILE' && args.revision !== undefined, 'Reconciliation requires --revision and --confirm RECONCILE'); result = journal.reconcile(args.device, Number(args.revision), args.reason, args['observed-revision'] === undefined ? undefined : Number(args['observed-revision'])); }
      console.log(JSON.stringify(result, null, 2));
    }
  } finally { await gateway?.close(); await recoveryAdapter?.close(); journal?.close(); unlock?.(); }
}
main().catch(error => { console.error(JSON.stringify({ error: error.code ?? 'GATEWAY', message: error.message })); process.exitCode = 1; });
